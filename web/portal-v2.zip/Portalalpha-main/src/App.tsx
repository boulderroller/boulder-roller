import RideView from './pages/RideView';
import SegmentView from './pages/SegmentView';
import MyActivities from './pages/MyActivities';
import { useState, useEffect, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner@2.0.3';
import { ThemeProvider } from './contexts/ThemeContext';
import DashboardLayout from './components/layout/DashboardLayout';
import ScrollToTop from './components/layout/ScrollToTop';
import ScrollProgress from './components/layout/ScrollProgress';
import InviteGate from './components/auth/InviteGate';
import ActivityFeed from './components/feed/ActivityFeed';
import ActivityFeedSkeleton from './components/loading/ActivityFeedSkeleton';
import RiderView from './pages/RiderView';
import ItemDetail from './pages/ItemDetail';
import MySegments from './pages/MySegments';
import Data from './pages/Data';
import Portfolio from './pages/Portfolio';
import Map from './pages/Map';
import Leaderboard from './pages/Leaderboard';
import FindFriends from './pages/FindFriends';
import Achievements from './pages/Achievements';
import BeetleStore from './pages/BeetleStore';
import Settings from './pages/Settings';
import Profile from './pages/Profile';
import Docs from './pages/Docs';
import NotFound from './pages/NotFound';
import AchievementUnlockModal from './components/modals/AchievementUnlockModal';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  const [isConnected, setIsConnected] = useState(false);
  const [walletAddress, setWalletAddress] = useState('');
  const [showAchievementModal, setShowAchievementModal] = useState(false);

  // Mock achievement data - trigger this when user completes something
  const mockAchievement = {
    id: 'century-rider',
    emoji: '🏆',
    name: 'Century Rider',
    description: 'Complete 100km in one ride',
    dungReward: 500,
    nextAchievement: {
      name: 'Double Century',
      requirement: 'Complete 200km in one ride',
      progress: 124,
      total: 200,
    },
  };

  const handleDisconnect = () => {
    setIsConnected(false);
    setWalletAddress('');
  };

  const handleInviteSuccess = (address: string) => {
    // Instant transition - no loading screen needed
    setIsConnected(true);
    setWalletAddress(address);
  };

  const handleShare = (platform: string) => {
    console.log(`Sharing achievement to ${platform}`);
  };

  // Demo trigger - remove this in production
  // useEffect(() => {
  //   setTimeout(() => {
  //     setShowAchievementModal(true);
  //   }, 2000);
  // }, []);

  return (
    <ThemeProvider>
      <ErrorBoundary>
        <Router>
          {!isConnected ? (
            <InviteGate onInviteSuccess={handleInviteSuccess} />
          ) : (
            <DashboardLayout
              isConnected={isConnected}
              walletAddress={walletAddress}
              onDisconnect={handleDisconnect}
            >
              {/* Scroll to top on route change */}
              <ScrollToTop />
              
              {/* Scroll progress indicator */}
              <ScrollProgress />
              
              <div className="relative min-h-[calc(100vh-4rem)]">
                {/* BackButton moved to DashboardLayout header */}
                <div className="pt-0"> {/* Removed spacer as header handles spacing */}
                  <Suspense fallback={<ActivityFeedSkeleton />}>
                    <Routes>
                      {/* Core Pages */}
                      <Route path="/" element={<ActivityFeed isConnected={isConnected} />} />
                      <Route path="/profile" element={<Profile />} />
                      <Route path="/athletes/:beetleNumber" element={<Profile />} />
                      
                      {/* Dashboard Routes */}
                      <Route path="/my-activities" element={<MyActivities />} />
                      <Route path="/my-segments" element={<MySegments />} />
                      <Route path="/data" element={<Data />} />
                      <Route path="/portfolio" element={<Portfolio />} />
                      
                      {/* Explore Routes */}
                      <Route path="/map" element={<Map />} />
                      <Route path="/leaderboard" element={<Leaderboard />} />
                      <Route path="/find-friends" element={<FindFriends />} />
                      <Route path="/achievements" element={<Achievements />} />
                      <Route path="/store" element={<BeetleStore />} />
                      
                      {/* Detail Pages */}
                      <Route path="/activities/:activityId" element={<RideView />} />
                      <Route path="/segments/:segmentId" element={<SegmentView />} />
                      <Route path="/rider/:riderId" element={<RiderView />} />
                      <Route path="/item/:itemId" element={<ItemDetail />} />
                      <Route path="/settings" element={<Settings />} />
                      <Route path="/docs" element={<Docs />} />
                      
                      {/* 404 Catch-All */}
                      <Route path="*" element={<NotFound />} />
                    </Routes>
                  </Suspense>
                </div>
              </div>

              <Toaster 
                position="bottom-right" 
                toastOptions={{
                  style: {
                    background: 'var(--color-bg)',
                    color: 'var(--color-text)',
                    border: '2px solid var(--color-border)',
                    borderRadius: '0px',
                    boxShadow: '4px 4px 0px 0px var(--color-border)',
                  },
                }}
              />

              {/* Achievement Unlock Modal (Demo) */}
              {showAchievementModal && (
                <AchievementUnlockModal
                  achievement={mockAchievement}
                  onClose={() => setShowAchievementModal(false)}
                  onShare={handleShare}
                />
              )}
            </DashboardLayout>
          )}
        </Router>
      </ErrorBoundary>
    </ThemeProvider>
  );
}