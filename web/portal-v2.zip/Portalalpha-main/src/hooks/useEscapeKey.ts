import { useEffect } from 'react';

/**
 * useEscapeKey - Handle ESC key press for modals/dropdowns
 * 
 * @param onEscape - Callback to run when ESC is pressed
 * @param enabled - Whether the listener is active (default: true)
 * 
 * @example
 * useEscapeKey(() => setModalOpen(false));
 */
export function useEscapeKey(onEscape: () => void, enabled: boolean = true) {
  useEffect(() => {
    if (!enabled) return;

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onEscape();
      }
    };

    window.addEventListener('keydown', handleEscape);

    return () => {
      window.removeEventListener('keydown', handleEscape);
    };
  }, [onEscape, enabled]);
}
