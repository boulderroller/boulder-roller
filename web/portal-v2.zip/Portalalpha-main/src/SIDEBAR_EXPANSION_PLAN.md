# Sidebar Expansion Plan - Activity Feed Dashboard

## Summary of Changes Made

### SegmentView Fixes ✅
- **Your Stats box**: Changed background from subtle accent tint to proper `cardBg` for better visibility
- **Leaderboard Table**: Added `cardBg` background to table container for proper visual hierarchy
- Both now clearly stand out from the page background

### ActivityFeed Improvements ✅
- **Column widths**: Reduced sidebars from 320px → 280px for better balance
- **Gap spacing**: Increased from `gap-4/5` → `gap-6/8` (24-32px) for more breathing room
- **Outer padding**: Increased from `p-4 sm:p-6` → `p-6 sm:p-8` (24-32px)
- **Header spacing**: Increased vertical padding for better rhythm

## Strava Visual Analysis

### What Strava Does Well:
1. **Generous whitespace** - Wide margins, ample gaps between elements
2. **Balanced proportions** - Center content gets ~50-60% of width, sidebars are proportional
3. **Visual hierarchy through spacing** - Important content gets more space around it
4. **Consistent card padding** - All cards use similar internal spacing (16-20px)
5. **Strategic density** - Lists are compact, but cards have room to breathe

### Our Improvements Match This:
- ✅ Better balance with narrower sidebars (280px vs 320px)
- ✅ More generous gaps (32px desktop vs previous 20px)
- ✅ Proper outer margins (32px desktop)
- ✅ Consistent card backgrounds with "quiet containers, loud content" principle

---

## Future Sidebar Content Ideas

### Left Sidebar (Personal Stats)
**Current:** Your Dung Bank + Achievement

**Potential additions:**

1. **Training Load Widget**
   - 7-day rolling TSS
   - Fatigue/Fitness/Form chart (CTL/ATL/TSB)
   - Training zone distribution
   - Recovery status indicator

2. **Quick Stats Card**
   - Personal records this month
   - Upcoming segment attempts (goals)
   - Favorite segments performance trend

3. **Streak Tracker**
   - Current riding streak (days)
   - Monthly consistency meter
   - Milestone progress (e.g., "3 rides to unlock...")

4. **NFT Beetle Display**
   - Current equipped beetle NFT
   - Beetle level/XP bar
   - Active beetle bonuses
   - Quick link to customize

5. **Goal Progress**
   - Monthly distance/TSS goals
   - Challenge participation
   - Achievement hunting progress

---

### Right Sidebar (Community/Social)
**Current:** Weekly Leaderboard

**Potential additions:**

1. **Trending Segments**
   - Hot segments this week
   - Most competitive segments
   - Highest pot segments
   - New segments nearby

2. **Friend Activity Highlights**
   - Recent PRs from followed riders
   - Friends you haven't ridden with lately
   - Friend challenges/callouts

3. **Live Now Widget**
   - Riders currently on segments (if we have real-time data)
   - Active challenges ending soon
   - Live leaderboard battles

4. **Segment Opportunities**
   - Segments where you're close to KOM/QOM
   - "Beat your friend" suggestions
   - Segments with expiring weekly pots

5. **Community Challenges Card**
   - Active community challenges
   - Your ranking in challenges
   - Challenge countdown timers
   - Rewards preview

6. **Beetle Store Preview**
   - Featured items
   - New releases
   - Limited-time offers
   - Your wishlist items

7. **Weather/Conditions Widget**
   - Local riding conditions
   - Best riding times today
   - Segment recommendations based on conditions

8. **Social Feed Highlights**
   - Most kudos this week
   - Epic rides worth checking out
   - Popular comments/discussions

---

## Implementation Priority

### Phase 1 (High Impact, Easy)
1. **Trending Segments** - Adds exploration/discovery
2. **Training Load Widget** - Core cycling feature
3. **Streak Tracker** - Gamification/engagement

### Phase 2 (Medium Impact, Moderate Effort)
4. **Quick Stats Card** - Personal insights
5. **Community Challenges** - Social engagement
6. **NFT Beetle Display** - Showcases web3 features

### Phase 3 (Nice to Have, Complex)
7. **Live Now Widget** - Requires real-time infrastructure
8. **Weather Widget** - Requires external API
9. **Social Feed Highlights** - Requires engagement metrics

---

## Design Principles for New Widgets

### Visual Hierarchy
- **Container**: Quiet (1px border, cardBg background)
- **Content**: Loud (glowing dung, bold numbers, accent colors)
- **Spacing**: Generous (px-5 py-4 minimum)

### Size Guidelines
- **Width**: 280px (matches current sidebar)
- **Height**: Variable, but aim for 200-400px per widget
- **Scrollable**: Sidebars have max-height with overflow-y: auto

### Data Presentation
- **Big numbers**: Use Cousine font at 24-36px
- **Labels**: Use Inter font at 10-11px, uppercase, tracking-wide
- **Icons**: Lucide-react, 14-16px size
- **Colors**: Follow existing palette (accent gold, success green, etc.)

### Interaction
- **Hover states**: Subtle background change (use getHoverBg)
- **Clickable items**: Cursor pointer, transitions
- **Loading states**: Use LoadingSkeleton component
- **Empty states**: Clear messaging, CTA to action

---

## Code Structure Template

```tsx
// Example: Trending Segments Widget
<div 
  className="rounded border overflow-hidden"
  style={{ 
    backgroundColor: cardBg,
    borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
  }}
>
  {/* Header */}
  <div className="px-5 py-4 border-b" style={{ borderColor }}>
    <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
      🔥 Trending Segments
    </h2>
  </div>

  {/* Content */}
  <div className="divide-y" style={{ borderColor: dividerColor }}>
    {trendingSegments.map((segment) => (
      <div 
        key={segment.id}
        className="px-5 py-3 cursor-pointer transition-colors"
        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = hoverBg}
        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        onClick={() => navigate(`/segments/${segment.id}`)}
      >
        {/* Segment content here */}
      </div>
    ))}
  </div>
</div>
```

---

## Next Steps

1. **Gather feedback** on which widgets are most valuable
2. **Design mock data** for prioritized widgets
3. **Build reusable widget components** in `/components/dashboard/`
4. **Implement Phase 1 widgets** one at a time
5. **A/B test** widget positions and combinations
6. **Add toggle settings** to let users customize their dashboard

---

## Responsive Behavior

### Mobile/Tablet (stacked layout)
- Widgets stack vertically
- Full width for each widget
- User can scroll through all content
- Consider: Collapsible widgets to reduce scroll distance

### Desktop (3-column layout)
- Left/Right sidebars fixed at 280px
- Center content fluid
- Sidebars independently scrollable
- Consider: Drag-and-drop widget reordering (future enhancement)

---

## Notes

- All widgets should respect the same visual hierarchy (quiet containers, loud content)
- Keep widget heights reasonable to prevent excessive scrolling
- Consider lazy loading widgets below the fold
- Add loading skeletons for async data
- Maintain consistent spacing (use existing patterns)
