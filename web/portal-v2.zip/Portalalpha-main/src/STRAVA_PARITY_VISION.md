# 🚴 BoulderRoller - The Strava Parity Vision

**Mission:** Think like the Strava founders. Obsessive attention to cyclist desires. Information density. Tactical decisions.

---

## 🎯 THE CURRENT PROBLEM

### **What We Have:**
```
Activity Feed → Click card → Modal (quick preview)
                                ↓
                            [DEAD END]
```

### **What Strava Does:**
```
Activity Feed → Click card → Full Activity Page
                                ↓
                         Power Curve, Map, Splits,
                         Comments, Segments, Kudos,
                         Weather, Heart Rate Zones,
                         Export, Edit, Delete, Share
```

### **What We Need:**
```
Activity Feed → Click card → Modal (quick preview)
                                ↓
                         "View Full Activity" button
                                ↓
                         Full RideView Page (DENSE!)
                                ↓
                         Everything a cyclist wants
```

---

## 🗺️ INFORMATION ARCHITECTURE

### **The Two-Tier System:**

#### **Tier 1: Modal (Quick Glance)**
**Use case:** "Did I beat my PR? Was it a good ride?"

**Shows:**
- Basic stats (distance, time, elevation)
- Dung breakdown (gamification hook)
- Quick CTA: "View Full Activity →"

**Interaction:**
- Click activity → Modal fades in
- Scan info in <5 seconds
- ESC to close (back to feed)
- OR click "View Full Activity" → Navigate to page

---

#### **Tier 2: RideView Page (Deep Analysis)**
**Use case:** "I want to analyze every watt, see the route, check my zones, leave comments"

**URL Structure:**
```
/activities/:activityId

Example:
/activities/morning-ride-dec-8-2025
```

**Navigation:**
- TopNav shows breadcrumb: "🪲 BOULDER ROLLER > Activities > Morning Ride"
- Back button to feed
- Edit/Delete in corner (like Strava)

**Content Density:**
- Full-width layout (Strava proportions)
- Left column: Stats, charts, map
- Right sidebar: Dung breakdown, segments, kudos
- Below: Comments, achievements, related activities

---

## 📐 THE STRAVA LAYOUT BREAKDOWN

### **Strava Activity Page Anatomy:**

```
┌─────────────────────────────────────────────────────────────┐
│ TOPNAV: Logo | Upload | Dashboard | [Profile]               │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│ ┌─────────────────────────────────┬─────────────────────┐   │
│ │ MAIN CONTENT (65%)              │ SIDEBAR (35%)       │   │
│ │                                 │                     │   │
│ │ ┌─────────────────────────────┐ │ ┌─────────────────┐ │   │
│ │ │ TITLE + DATE                │ │ │ KUDOS / COMMENTS│ │   │
│ │ │ Morning Ride                │ │ │ 🔥 Give Kudos   │ │   │
│ │ │ Dec 8, 2025 • 7:30 AM       │ │ │ 12 people      │ │   │
│ │ └─────────────────────────────┘ │ └─────────────────┘ │   │
│ │                                 │                     │   │
│ │ ┌─────────────────────────────┐ │ ┌─────────────────┐ │   │
│ │ │ STATS ROW                   │ │ │ ACHIEVEMENTS    │ │   │
│ │ │ 45km  1:42:30  823m  250W   │ │ │ 🏆 New PR      │ │   │
│ │ └─────────────────────────────┘ │ │ 🪲 +45 Dung    │ │   │
│ │                                 │ └─────────────────┘ │   │
│ │ ┌─────────────────────────────┐ │                     │   │
│ │ │ MAP (Interactive)           │ │ ┌─────────────────┐ │   │
│ │ │ [Route visualization]       │ │ │ SEGMENTS        │ │   │
│ │ │                             │ │ │ HAWK HILL       │ │   │
│ │ └─────────────────────────────┘ │ │ 3rd / 1,240     │ │   │
│ │                                 │ └─────────────────┘ │   │
│ │ ┌─────────────────────────────┐ │                     │   │
│ │ │ POWER CURVE (Chart)         │ │ ┌─────────────────┐ │   │
│ │ │ [Line graph, 20s zones]     │ │ │ WEATHER         │ │   │
│ │ └─────────────────────────────┘ │ │ 18°C Partly ☁️  │ │   │
│ │                                 │ └─────────────────┘ │   │
│ │ ┌─────────────────────────────┐ │                     │   │
│ │ │ SPLITS TABLE                │ │                     │   │
│ │ │ KM | Time | Watts | HR      │ │                     │   │
│ │ │  1 | 3:45 | 245W  | 142bpm  │ │                     │   │
│ │ │  2 | 3:52 | 238W  | 145bpm  │ │                     │   │
│ │ └─────────────────────────────┘ │                     │   │
│ └─────────────────────────────────┴─────────────────────┘   │
│                                                               │
│ ┌─────────────────────────────────────────────────────────┐ │
│ │ COMMENTS SECTION (Full Width Below)                     │ │
│ │ ───────────────────────────────────────────────────────  │ │
│ │ climber_420: "Killed it on Hawk Hill! 🔥"               │ │
│ │ diesel_dave: "That power curve is insane"               │ │
│ └─────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### **Key Proportions:**
- **Main content:** 65% width
- **Sidebar:** 35% width
- **Gutters:** 24px (Strava uses generous spacing)
- **Max width:** 1200px centered
- **Stats cards:** 4-6 per row, dense but not cramped

---

## 🚀 GIANT PUSH #1: ROUTING + RIDEVIEW PAGE

### **What We Need to Build:**

#### **1. Add React Router**
```bash
# Install
npm install react-router-dom
```

```tsx
// App.tsx - Wrap in Router
import { BrowserRouter, Routes, Route } from 'react-router-dom';

<BrowserRouter>
  <Routes>
    <Route path="/" element={<MainLayout />}>
      <Route index element={<ActivityFeed />} />
      <Route path="/activities/:activityId" element={<RideView />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/training" element={<TrainingLog />} />
    </Route>
  </Routes>
</BrowserRouter>
```

---

#### **2. Update ActivityDetailModal**
Add "View Full Activity" button at bottom:

```tsx
<div className="flex gap-3">
  <BeetleButton
    onClick={() => navigate(`/activities/${activity.id}`)}
    variant="primary"
    className="flex-1"
  >
    View Full Activity →
  </BeetleButton>
  
  <BeetleButton
    onClick={onClose}
    variant="secondary"
    className="flex-1"
  >
    Close
  </BeetleButton>
</div>
```

**User Flow:**
```
Feed → Click card → Modal opens
         ↓
    Quick scan stats
         ↓
    Click "View Full Activity"
         ↓
    Navigate to /activities/[id]
         ↓
    Modal closes, page loads
```

---

#### **3. Build RideView Page Component**

**File:** `/pages/RideView.tsx`

**Structure:**
```tsx
export default function RideView() {
  const { activityId } = useParams();
  const activity = useActivity(activityId); // Fetch full data
  
  return (
    <div className="max-w-[1200px] mx-auto p-6">
      {/* Breadcrumb */}
      <Breadcrumb />
      
      {/* Hero Section: Title + Edit/Delete */}
      <ActivityHeader activity={activity} />
      
      {/* Two-Column Layout */}
      <div className="grid grid-cols-[2fr_1fr] gap-6">
        {/* LEFT: Main Content */}
        <div className="space-y-6">
          <StatsRow activity={activity} />
          <MapCard activity={activity} />
          <PowerCurveChart activity={activity} />
          <SplitsTable activity={activity} />
          <HeartRateZones activity={activity} />
        </div>
        
        {/* RIGHT: Sidebar */}
        <div className="space-y-6">
          <KudosCard activity={activity} />
          <DungBreakdownCard activity={activity} />
          <SegmentsCard activity={activity} />
          <WeatherCard activity={activity} />
          <EquipmentCard activity={activity} />
        </div>
      </div>
      
      {/* Full Width: Comments */}
      <CommentsSection activity={activity} />
    </div>
  );
}
```

---

## 🧠 APPLYING FRIEND'S INTERACTION WISDOM

### **From the Knowledge Dump:**

> **"Information scent"** - Every element should advertise where it leads

**Applied to RideView:**
- Modal button text: "View Full Activity →" (arrow = navigation)
- Breadcrumbs show path back: "Feed > Activities > Morning Ride"
- Segment cards show ranking: "3rd / 1,240" (scent = competitive depth)

---

> **"Progressive disclosure"** - Reveal complexity gradually

**Applied to RideView:**
```
Feed (Simple)
  ↓
Modal (Medium - 3 stats + dung)
  ↓
RideView (Complex - 15+ data points)
```

Each tier adds detail. No overwhelming users.

---

> **"Tiny contracts"** - Every button must keep its promise

**Applied to RideView:**
- "View Full Activity" → Shows FULL activity (not partial)
- "Edit" button → Opens edit form (not settings)
- "Download GPX" → Actually downloads (instant feedback)
- "Give Kudos" → Shows +1 immediately (optimistic UI)

---

> **"<100ms feedback"** - Instant response to all actions

**Applied to RideView:**
- Kudos button animates instantly (heart pops)
- Comment submit shows comment immediately (optimistic)
- Tab switching (Overview/Splits/Zones) = instant
- Map zoom/pan = 60fps (use lightweight library)

---

## 🎨 COMPONENTS WE NEED TO BUILD

### **For RideView Page:**

#### **1. StatsRow Component**
```tsx
<StatsRow>
  <StatCard label="Distance" value="45.2 km" />
  <StatCard label="Time" value="1:42:30" />
  <StatCard label="Elevation" value="823 m" />
  <StatCard label="Avg Power" value="245 W" />
  <StatCard label="NP" value="258 W" />
  <StatCard label="TSS" value="120" />
</StatsRow>
```

**Beetle Treatment:**
- Cards have subtle shadow (not clickable)
- Hover shows tooltip with context
- Use BeetleCard with flat variant

---

#### **2. MapCard Component**
```tsx
<MapCard route={activity.route}>
  {/* Interactive map showing route */}
  {/* Elevation profile below */}
</MapCard>
```

**Library:** Use `react-leaflet` (lightweight, works offline with cached tiles)

**Beetle Treatment:**
- Map controls (zoom +/-) use beetle button style
- Route line is bold (3px) with beetle green (#8b9475)
- Start/End markers are beetle icons (🪲)

---

#### **3. PowerCurveChart Component**
```tsx
<PowerCurveChart data={activity.powerData}>
  {/* Line chart showing watts over time */}
  {/* Tabs: 20s / 5min / 20min best efforts */}
</PowerCurveChart>
```

**Library:** Use `recharts` (already suggested, works great)

**Beetle Treatment:**
- Chart line color matches theme accent
- Hover shows exact wattage (tooltip)
- Grid lines are subtle (beetle border color @ 20% opacity)
- Tab switcher uses beetle button physics

---

#### **4. SplitsTable Component**
```tsx
<SplitsTable splits={activity.splits}>
  {/* Table: KM | Time | Pace | Power | HR | Cadence */}
  {/* Highlight best split (fastest) */}
</SplitsTable>
```

**Beetle Treatment:**
- Row hover = background highlight (subtle)
- Best split row = accent background (#d4c993)
- Borders = 2px solid (brutalist)
- Sticky header on scroll

---

#### **5. KudosCard Component**
```tsx
<KudosCard 
  kudosCount={12}
  hasGivenKudos={false}
  onGiveKudos={handleKudos}
>
  {/* Big "Give Kudos" button */}
  {/* List of who gave kudos */}
</KudosCard>
```

**Beetle Treatment:**
- Kudos button = BeetleButton with heart icon
- On click: Heart animates (scale + rotation)
- Optimistic UI: +1 immediately
- Undo button appears for 3s (toast-style)

---

#### **6. DungBreakdownCard Component**
(We already built this in the modal! Can reuse)

**Enhancements for full page:**
- Add historical graph: "Dung earned per week"
- Show percentile: "Top 15% of riders this week"
- Link to leaderboard: "View rankings →"

---

#### **7. SegmentsCard Component**
```tsx
<SegmentsCard segments={activity.segments}>
  {/* List of segments with ranks */}
  {/* "3rd / 1,240 on HAWK HILL" */}
  {/* Click segment → View leaderboard */}
</SegmentsCard>
```

**Beetle Treatment:**
- Each segment = BeetleCard (interactive)
- Click segment → Navigate to segment detail page
- PR indicator = gold beetle icon (🪲✨)
- Ranking shows percentile: "Top 0.2%"

---

#### **8. CommentsSection Component**
```tsx
<CommentsSection 
  comments={activity.comments}
  onAddComment={handleComment}
>
  {/* BeetleInput for new comment */}
  {/* List of existing comments */}
  {/* Reply threads (nested) */}
</CommentsSection>
```

**Beetle Treatment:**
- Comment input = BeetleInput (multiline)
- Submit button = BeetleButton
- Comments have timestamp + author
- Delete own comments (trash icon button)

---

## 🗺️ NAVIGATION STRUCTURE

### **TopNav Updates:**

Add dropdown menu for "Dashboard":

```tsx
<TopNav>
  <Logo />
  <NavDropdown label="Dashboard">
    <NavItem href="/" icon="📊">Activity Feed</NavItem>
    <NavItem href="/training" icon="📈">Training Log</NavItem>
    <NavItem href="/calendar" icon="📅">Calendar</NavItem>
    <NavItem href="/progress" icon="🎯">Progress</NavItem>
  </NavDropdown>
  <NavButton>Upload</NavButton>
  <ProfileDropdown />
</TopNav>
```

**Beetle Treatment:**
- Dropdown opens below (no shadow jump)
- Items have hover state (background + transform)
- Active page highlighted (accent color)
- Arrow rotates on open (like profile dropdown)

---

## 🚀 GIANT PUSH #2: DATA VISUALIZATION

### **The Cyclist's Data Needs:**

Cyclists are **data obsessed**. They want:
1. **Power zones** - Am I training correctly?
2. **Heart rate zones** - Am I overtraining?
3. **Cadence distribution** - Optimal pedaling?
4. **Elevation profile** - Where were the climbs?
5. **Speed over time** - Did I fade at the end?
6. **Comparison to PRs** - Am I improving?

### **Charts We Need:**

#### **1. Power Zone Distribution (Donut Chart)**
```
┌─────────────────┐
│   Power Zones   │
├─────────────────┤
│                 │
│      [🍩]      │
│                 │
│ Z1: 15%  Active │
│ Z2: 35%  Endur. │
│ Z3: 25%  Tempo  │
│ Z4: 20%  Thresh │
│ Z5: 5%   VO2Max │
└─────────────────┘
```

**Library:** Recharts `<PieChart>` with custom colors

**Beetle Colors:**
- Z1 (Active): #d0d8bf (light)
- Z2 (Endurance): #8b9475 (beetle green)
- Z3 (Tempo): #d4c993 (gold)
- Z4 (Threshold): #c7a76f (dark gold)
- Z5 (VO2Max): #a87373 (red)

---

#### **2. Elevation Profile (Area Chart)**
```
┌───────────────────────────────────┐
│   Elevation Profile              │
├───────────────────────────────────┤
│                                   │
│ 800m    /\      /\                │
│        /  \    /  \               │
│ 400m  /    \  /    \___           │
│ 0m ──────────────────────────     │
│    0km   10km  20km  30km  45km   │
└───────────────────────────────────┘
```

**Library:** Recharts `<AreaChart>` with gradient fill

**Beetle Treatment:**
- Fill = accent color with opacity gradient
- Stroke = solid border color (3px)
- Grid lines = subtle (10% opacity)
- Hover = Show exact elevation at point

---

#### **3. Heart Rate Zones (Stacked Bar)**
```
┌───────────────────────────────────┐
│   Heart Rate Zones               │
├───────────────────────────────────┤
│                                   │
│ 100% │████████████████████████│   │
│  75% │████████████░░░░░░░░░░░│   │
│  50% │████████░░░░░░░░░░░░░░░│   │
│  25% │████░░░░░░░░░░░░░░░░░░░│   │
│   0% └────────────────────────┘   │
│      Z1  Z2  Z3  Z4  Z5           │
└───────────────────────────────────┘
```

---

#### **4. Best Efforts Table**
```
┌───────────────────────────────────┐
│   Best Efforts                    │
├───────────────────────────────────┤
│ Duration │ Power │  When  │ PR?   │
├──────────┼───────┼────────┼───────┤
│ 20 sec   │ 450W  │ 12:34  │  🪲   │
│ 1 min    │ 380W  │ 15:22  │       │
│ 5 min    │ 310W  │ 08:45  │  🪲   │
│ 20 min   │ 265W  │ 22:10  │       │
│ 60 min   │ 245W  │ Full   │       │
└──────────┴───────┴────────┴───────┘
```

**Beetle Treatment:**
- PR rows highlighted (accent background)
- Click row → Scroll to that time in power curve
- Beetle icon for PRs (animated pulse)

---

## 🚀 GIANT PUSH #3: SOCIAL FEATURES

### **Kudos System:**

**How it works:**
1. User clicks "Give Kudos" button
2. Optimistic UI: Button changes to "Kudos Given ✓"
3. Heart icon animates (scale 1 → 1.2 → 1, rotate 0 → 15° → 0)
4. Count increases: 12 → 13
5. Backend saves kudos

**Undo Flow:**
- Toast appears: "Kudos given! [Undo]"
- 3 second window to undo
- If undo: Revert all changes
- If no undo: Toast fades, kudos confirmed

**Beetle Treatment:**
- Kudos button = BeetleButton with heart icon
- Active state = accent color fill
- Animation uses CSS transforms (no janky JS)

---

### **Comments System:**

**Structure:**
```tsx
interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  timestamp: Date;
  kudosCount: number;
  replies: Comment[]; // Nested replies
}
```

**Features:**
- ✅ Add top-level comment
- ✅ Reply to comment (1 level deep only)
- ✅ Give kudos to comments
- ✅ Delete own comments
- ✅ Edit own comments (5 min window)
- ✅ @mention users (autocomplete)

**Beetle Treatment:**
- Comment cards = BeetleCard (flat variant)
- Reply button = link-style button (underline on hover)
- Kudos on comment = small beetle icon (clickable)
- Timestamp = relative ("2 hours ago")

---

## 🚀 GIANT PUSH #4: EDIT ACTIVITY

### **Edit Modal/Page:**

**What users can edit:**
- ✅ Title (default: "Morning Ride")
- ✅ Description (markdown supported)
- ✅ Activity type (Ride, Run, Swim, etc.)
- ✅ Privacy (Public, Followers, Private)
- ✅ Commute toggle
- ✅ Trainer toggle
- ✅ Equipment (bike selection)
- ✅ Perceived exertion (1-10 scale)

**UI Pattern:**
- Click "Edit" in RideView header
- Slide-in panel from right (like ProfileEditPanel)
- BeetleInput for all fields
- Save button = BeetleButton (primary)
- Cancel = close panel

**Beetle Treatment:**
- All inputs = BeetleInput
- Toggles = BeetleButton (on/off states)
- Equipment selector = custom dropdown (beetle styled)
- Save shows toast: "Activity updated! 🪲"

---

## 🚀 GIANT PUSH #5: SEGMENTS

### **What are Segments?**
Segments are specific sections of a route (e.g., "HAWK HILL climb") where riders compete for best times.

### **Segment Detail Page:**

**URL:** `/segments/hawk-hill`

**Content:**
```
┌───────────────────────────────────────────┐
│ HAWK HILL                                 │
│ 1.2 km • 10% grade • 245m elevation       │
├───────────────────────────────────────────┤
│                                           │
│ [MAP SHOWING SEGMENT ROUTE]               │
│                                           │
├───────────────────────────────────────────┤
│ YOUR BEST EFFORT                          │
│ 3rd / 1,240 riders                        │
│ 6:45 • 285W • Dec 8, 2025                 │
├───────────────────────────────────────────┤
│ LEADERBOARD                               │
│  1. diesel_dave     6:12  🪲 KOM          │
│  2. climber_420     6:32  🪲              │
│ →3. YOU              6:45  🪲 PR!         │
│  4. tt_master       6:52  🪲              │
│  5. sprinter_99     7:01                  │
└───────────────────────────────────────────┘
```

**Features:**
- ✅ See all your attempts on this segment
- ✅ Compare to friends (side-by-side power curves)
- ✅ Leaderboard (all-time, this month, your age group)
- ✅ Segment achievements (KOM, top 10, PR)
- ✅ Route hazards (reported by users)

**Beetle Treatment:**
- Leaderboard rows = alternating backgrounds (zebra striping)
- Your row = accent background (highlighted)
- KOM crown = animated beetle icon (gold)
- PR indicator = green beetle icon

---

## 🧩 ROUTING SUMMARY

### **Full Site Map:**

```
/
├─ / (Activity Feed)
├─ /activities/:id (RideView)
├─ /training (Training Log)
├─ /calendar (Calendar View)
├─ /progress (Long-term trends)
├─ /segments/:slug (Segment Detail)
├─ /leaderboard (Global Rankings)
├─ /profile/:username (Public Profile)
└─ /settings (Account Settings)
```

### **TopNav Structure:**

```tsx
<TopNav>
  {/* Logo (always visible) */}
  <Logo href="/" />
  
  {/* Main Nav */}
  <NavDropdown label="Dashboard">
    <NavItem href="/">Activity Feed</NavItem>
    <NavItem href="/training">Training Log</NavItem>
    <NavItem href="/calendar">Calendar</NavItem>
    <NavItem href="/progress">Progress</NavItem>
  </NavDropdown>
  
  <NavDropdown label="Explore">
    <NavItem href="/segments">Segments</NavItem>
    <NavItem href="/leaderboard">Leaderboard</NavItem>
  </NavDropdown>
  
  {/* Actions */}
  <NavButton icon="📤">Upload</NavButton>
  
  {/* Profile (right side) */}
  <ProfileDropdown />
</TopNav>
```

---

## 📊 PRIORITY MATRIX

### **What to Build First:**

#### **P0 - Ship This Week:**
1. ✅ React Router setup
2. ✅ RideView page (basic structure)
3. ✅ StatsRow component
4. ✅ Update modal with "View Full Activity" button
5. ✅ Breadcrumb navigation

**Goal:** Make the modal → page flow work.

---

#### **P1 - Next Week:**
6. MapCard (with leaflet)
7. PowerCurveChart (recharts)
8. SplitsTable
9. KudosCard (with animation)
10. CommentsSection (basic)

**Goal:** RideView feels feature-complete.

---

#### **P2 - Following Week:**
11. Edit Activity panel
12. Segment detail pages
13. Training Log page
14. Calendar view
15. Leaderboard

**Goal:** Full Strava parity on core features.

---

#### **P3 - Future:**
16. Upload activity (GPX/FIT files)
17. Route builder
18. Training plans
19. Export to third-party services
20. Mobile app (React Native)

---

## 🎨 DESIGN SYSTEM EXPANSION

### **New Components Needed:**

1. **BeetleChart** - Wrapper for recharts with beetle styling
2. **BeetleTable** - Data tables with beetle borders
3. **BeetleTabs** - Tab switcher (Overview/Splits/Zones)
4. **BeetleDropdown** - Custom select with beetle styling
5. **BeetleBreadcrumb** - Navigation breadcrumbs
6. **BeetleTooltip** - Hover tooltips for stats
7. **BeetleModal** - Larger modals for edit/delete confirm
8. **BeetleAvatar** - User profile pictures (rounded with border)

---

## 🔥 THE GIANT PUSH SUMMARY

### **What Makes This "Giant":**

1. **Routing** - Entire app becomes multi-page (architectural shift)
2. **Data Viz** - 5+ chart types (power, HR, elevation, zones, splits)
3. **Social** - Kudos + comments (backend integration required)
4. **Edit** - Full CRUD on activities
5. **Segments** - Competitive leaderboards (complex queries)

### **Why It's Worth It:**

- **Strava parity** = Users can actually switch from Strava
- **Deep engagement** = Users spend 10+ minutes analyzing rides
- **Viral loop** = Comments/kudos bring users back daily
- **Dung system** = Gamification hooks users (unique to us!)
- **Beetle aesthetic** = Consistent throughout (no generic UI)

---

## 🎯 THE FIRST MOVE

### **Let's Start With This:**

**Session Goal:** Make modal → page flow work

**Steps:**
1. Install React Router
2. Update App.tsx with Routes
3. Create `/pages/RideView.tsx` (stub with basic stats)
4. Update ActivityDetailModal with "View Full Activity" button
5. Add Breadcrumb component
6. Test navigation flow

**Time Estimate:** 90 minutes

**Outcome:** Users can click activity → modal → full page → back to feed

---

## 🪲 STRAVA FOUNDER MINDSET

### **What Would They Do?**

> **"Every click should feel purposeful"**
- Modal isn't a dead end, it's a gateway

> **"Data density matters, but not at the cost of clarity"**
- RideView shows 15+ data points, but organized in clear sections

> **"Competitive features drive engagement"**
- Segments, leaderboards, kudos = social pressure = daily active users

> **"The map is the hero"**
- Route visualization is first thing you see on RideView

> **"Mobile is just as important as desktop"**
- Beetle physics work on touch (no hover needed)

---

## 💭 STRATEGIC QUESTIONS

### **Before We Build:**

1. **Backend Ready?**
   - Do we have API endpoints for full activity data?
   - Where is the power/HR data stored?
   - Can we query segments efficiently?

2. **Data Source?**
   - Are users uploading .fit files? (need parser)
   - Connecting to Garmin/Wahoo? (need OAuth)
   - Manual entry? (need forms)

3. **Social Backend?**
   - How do we store comments? (database schema)
   - Real-time updates? (WebSockets or polling?)
   - Notification system? (email, push?)

4. **Solana Integration?**
   - Are dung points on-chain? (NFTs, tokens?)
   - Do we need wallet signatures for actions?
   - Gas fees for comments/kudos? (probably not lol)

---

## 🚀 LET'S GO

**You said "giant pushes" - this is it.**

- Routing architecture ✅
- Full ride view page ✅
- Data visualization suite ✅
- Social features ✅
- Strava parity roadmap ✅

**The modal → page flow is the unlock.**

Once that works, every other feature slots in naturally:
- Add a chart? Drop it in RideView.
- Add comments? Below the main content.
- Add segments? Sidebar card.

**Ready to start with React Router + RideView stub?** 

Or do you want to strategize more on backend/data sources first?

🪲⚡ **LET'S ROLL THIS BOULDER.** 🪲⚡
