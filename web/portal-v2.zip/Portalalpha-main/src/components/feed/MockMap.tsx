import React from 'react';

export const MockMap = () => (
    <div className="w-full h-full bg-[#1a1c15] dark:bg-[#0f100c] relative overflow-hidden flex items-center justify-center">
        {/* Grid Lines */}
        <div className="absolute inset-0 opacity-10" 
             style={{ 
                 backgroundImage: 'linear-gradient(#444 1px, transparent 1px), linear-gradient(90deg, #444 1px, transparent 1px)',
                 backgroundSize: '40px 40px'
             }} 
        />
        {/* Route Line (Simulated) */}
        <svg className="w-[80%] h-[60%] drop-shadow-[0_0_8px_rgba(212,165,116,0.5)]" viewBox="0 0 100 100" fill="none" stroke="#d4a574" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M10,90 Q30,80 40,60 T70,40 T90,10" />
        </svg>
        {/* UI Elements */}
        <div className="absolute bottom-3 right-3 px-2 py-1 bg-black/50 backdrop-blur-sm border border-white/10 text-[8px] font-mono text-white/50">
            MAP DATUM: WGS84
        </div>
    </div>
);