import { memo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';

interface ProfileCardProps {
  beetleNumber: number;
  rank: 'C' | 'B' | 'A' | 'S' | 'SS';
  userName?: string;
  following: number;
  followers: number;
  activities: number;
  latestActivity?: string;
  currentStreak: number;
}

function ProfileCard({
  beetleNumber,
  rank,
  userName = `Beetle #${beetleNumber}`,
  following,
  followers,
  activities,
  latestActivity = 'Morning Ride — Today at 6:47 AM',
  currentStreak,
}: ProfileCardProps) {
  const { colors, isDarkMode } = useTheme();
  const navigate = useNavigate();

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'SS': return '#d4af37';
      case 'S': return '#c89b5c';
      case 'A': return '#8ba87a';
      case 'B': return '#7a8a7a';
      case 'C': return '#5a6a5a';
      default: return '#5a6a5a';
    }
  };

  const StatButton = ({ label, value }: { label: string, value: string | number }) => (
    <button
      className="group w-full text-center py-2 rounded-none hover:bg-black/5 dark:hover:bg-white/5 active:translate-y-[1px] active:bg-black/10 dark:active:bg-white/10 transition-all duration-75 ease-out cursor-pointer select-none"
    >
      <div className="font-['Cousine'] text-[18px] font-bold group-hover:scale-105 transition-transform duration-75" style={{ color: colors.text }}>
        {value}
      </div>
      <div className="font-['Inter'] text-[10px] uppercase tracking-wide group-hover:text-zinc-800 dark:group-hover:text-zinc-200 transition-colors" style={{ color: colors.textMuted }}>
        {label}
      </div>
    </button>
  );

  return (
    <div
      className="rounded-none border overflow-hidden"
      style={{
        backgroundColor: isDarkMode ? '#2a2d1e' : colors.bg,
        borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
      }}
    >
      {/* Identity Section - "Heavy Card" Click */}
      <button 
        className="w-full text-left px-5 py-5 border-b group transition-all duration-75 active:scale-[0.98] active:brightness-95 hover:bg-black/5 dark:hover:bg-white/5 cursor-pointer outline-none"
        style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
        onClick={() => navigate('/profile')}
      >
        <div className="flex items-center gap-3 mb-4">
          {/* Avatar */}
          <div
            className="w-14 h-14 rounded-none border-[2px] flex items-center justify-center flex-shrink-0 transition-colors group-hover:border-[3px]"
            style={{
              borderColor: getTierColor(rank),
              backgroundColor: isDarkMode ? 'rgba(139, 168, 122, 0.1)' : 'rgba(139, 168, 122, 0.05)',
            }}
          >
            <span className="text-[28px] select-none">🪲</span>
          </div>

          {/* Name and Rank */}
          <div className="flex-1 min-w-0">
            <div className="font-['Inter'] font-bold text-[14px] truncate mb-1 group-hover:underline decoration-1 underline-offset-4" style={{ color: colors.text }}>
              {userName}
            </div>
            <div
              className="inline-flex px-2 py-0.5 rounded-none border-[2px]"
              style={{
                backgroundColor: getTierColor(rank),
                borderColor: getTierColor(rank),
                boxShadow: `1px 1px 0px 0px ${isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'}`,
              }}
            >
              <span
                className="font-['Inter'] text-[11px] font-black"
                style={{ color: isDarkMode ? '#1a1d14' : colors.bg }}
              >
                {rank} RANK
              </span>
            </div>
          </div>
        </div>
      </button>

      {/* Stats Grid - "Control Panel Buttons" */}
      <div 
        className="grid grid-cols-2 sm:grid-cols-3 gap-1 p-2 border-b" 
        style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
      >
        <StatButton label="Following" value={following} />
        <StatButton label="Followers" value={followers} />
        <div className="col-span-2 sm:col-span-1">
           <StatButton label="Activities" value={activities} />
        </div>
      </div>

      {/* Latest Activity - "Ticker Tape" */}
      <button 
        className="w-full text-left px-5 py-3 border-b hover:bg-black/5 dark:hover:bg-white/5 transition-colors group cursor-pointer"
        style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
      >
        <div className="font-['Inter'] text-[10px] uppercase tracking-wide mb-1 flex items-center justify-between" style={{ color: colors.textMuted }}>
          <span>Latest Activity</span>
          <span className="opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-150 text-[10px]">→</span>
        </div>
        <div className="font-['Inter'] text-[12px] font-medium group-hover:text-[#d4a574] transition-colors" style={{ color: colors.text }}>
          {latestActivity}
        </div>
      </button>

      {/* Streak Indicator */}
      <div className="px-5 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[16px]">🔥</span>
            <span className="font-['Inter'] text-[12px]" style={{ color: colors.text }}>
              Current Streak
            </span>
          </div>
          <div className="font-['Cousine'] text-[16px] font-bold" style={{ color: '#c89b5c' }}>
            {currentStreak}
          </div>
        </div>
      </div>
    </div>
  );
}

export default memo(ProfileCard);