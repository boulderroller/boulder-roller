import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { useTheme } from '../../contexts/ThemeContext';
import { cn } from '../ui/utils';

interface ActivityFilterProps {
  value: string;
  onChange: (value: string) => void;
}

export default function ActivityFilter({ value, onChange }: ActivityFilterProps) {
  const { isDarkMode, colors } = useTheme();

  const options = [
    { value: 'all', label: 'All Activity' },
    { value: 'following', label: 'Following' },
    { value: 'my-beetles', label: 'My Beetles' },
    { value: 'nearby', label: 'Nearby' },
  ];

  return (
    <div className="mb-6 flex justify-start">
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger 
          className={cn(
            "w-[180px] h-9 text-[13px] font-['Inter'] font-medium transition-colors border shadow-sm",
            isDarkMode 
              ? "bg-[#2a2d1e] border-white/10 hover:border-white/20 text-zinc-200" 
              : "bg-white border-black/10 hover:border-black/20 text-zinc-700"
          )}
        >
          <SelectValue placeholder="Filter Activity" />
        </SelectTrigger>
        <SelectContent 
          className={cn(
            "backdrop-blur-xl border font-['Inter'] text-[13px]",
            isDarkMode 
              ? "bg-[#2a2d1e]/95 border-white/10 text-zinc-200" 
              : "bg-white/95 border-black/10 text-zinc-700"
          )}
        >
          {options.map((option) => (
            <SelectItem 
              key={option.value} 
              value={option.value}
              className={cn(
                "focus:bg-black/5 dark:focus:bg-white/10 cursor-pointer",
                isDarkMode ? "focus:text-white" : "focus:text-black"
              )}
            >
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}