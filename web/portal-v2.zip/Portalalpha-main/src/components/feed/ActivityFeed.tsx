import { useState, useEffect, useRef, memo, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleCard } from '../ui/beetle-card';
import { LoadingSkeleton } from '../ui/loading-skeleton';
import { SEMANTIC_COLORS, getOverlay, getHoverBg, getDivider } from '../../constants/colors';
import ProfileCard from './ProfileCard';
import ActivityFilter from './ActivityFilter';
import { ActivityFeedItem as ActivityFeedItemType } from '../../types';
import { useWindowVirtualizer } from '@tanstack/react-virtual';
import { Map, Zap, Mountain, Clock, Heart, Share2, MessageSquare, MoreHorizontal, Hand, Link as LinkIcon, Send } from 'lucide-react';
import { ActivityFeedItem } from './ActivityFeedItem';
import { cn } from '../../components/ui/utils';

interface ActivityFeedProps {
  isConnected: boolean;
}

// --- Smart Sticky Hook ---
const useStickyOffset = (headerOffset: number = 88, bottomPadding: number = 24) => {
  const ref = useRef<HTMLDivElement>(null);
  
  const state = useRef({
    lastScrollY: typeof window !== 'undefined' ? window.scrollY : 0,
    currTop: headerOffset,
  });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    el.style.top = `${headerOffset}px`;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      const { lastScrollY, currTop } = state.current;
      const delta = lastScrollY - currentScrollY;
      
      const sidebarHeight = el.offsetHeight;
      const windowHeight = window.innerHeight;
      
      if (sidebarHeight + headerOffset + bottomPadding <= windowHeight) {
        if (currTop !== headerOffset) {
           el.style.top = `${headerOffset}px`;
           state.current.currTop = headerOffset;
        }
        state.current.lastScrollY = currentScrollY;
        return;
      }

      const minTop = windowHeight - sidebarHeight - bottomPadding;
      const maxTop = headerOffset;

      let newTop = currTop + delta;
      
      if (newTop > maxTop) newTop = maxTop;
      if (newTop < minTop) newTop = minTop;

      if (newTop !== currTop) {
        el.style.top = `${newTop}px`;
        state.current.currTop = newTop;
      }
      
      state.current.lastScrollY = currentScrollY;
    };

    const handleResize = () => {
       if (ref.current) {
         state.current.currTop = headerOffset;
         ref.current.style.top = `${headerOffset}px`;
       }
       handleScroll();
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    window.addEventListener('resize', handleResize);
    
    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('resize', handleResize);
    };
  }, [headerOffset, bottomPadding]);

  return { 
    ref, 
    style: { 
      position: 'sticky' as const,
    } 
  };
};

// --- Mock Data Generator ---
const generateActivity = (id: number): ActivityFeedItemType => {
  // Skew heavily towards RIDES for the feed demo
  const types = ['RIDE', 'RIDE', 'RIDE', 'RIDE', 'ACHIEVEMENT', 'REWARD'];
  const users = ['climber_420', 'tt_master', 'diesel_dave', 'sprinter_99', 'mountain_goat', 'velo_queen', 'gravel_grinder', 'fixie_fan'];
  const titles = ['Morning Loop', 'Big Sur Coastal', 'Mt. Tam Ascent', 'Recovery Spin', 'Lunch Crit', 'Sunset Gravel', 'Industrial Zone Sprints', 'Port of Oakland Lap'];
  const locations = ['Marin County, CA', 'San Francisco, CA', 'Boulder, CO', 'Girona, ES', 'Watopia', 'Oakland, CA'];
  
  // Reliable Unsplash IDs for Cycling/Industrial textures
  const imageIds = [
      '1517649763962-0c623066013b', // Cyclist silhouette
      '1559166631-ef208440c75a', // Forest road
      '1628191014330-db33b345a55b', // Concrete brutalist
      '1596727147705-54a9d0c2067d', // Asphalt texture
      '1474552226712-ac0f0961a954', // Foggy road
      '1531326487053-96b66d82d49c'  // Urban cycling
  ];

  const type = types[Math.floor(Math.random() * types.length)];
  const user = users[Math.floor(Math.random() * users.length)];
  const location = locations[Math.floor(Math.random() * locations.length)];
  const color = type === 'RIDE' ? '#8ba87a' : type === 'ACHIEVEMENT' ? '#d4c993' : '#c7a76f';
  
  const hoursAgo = Math.floor(Math.random() * 24) + 1;
  const timeStr = hoursAgo === 1 ? '1h ago' : `${hoursAgo}h ago`;

  // Visuals Logic
  let visualType: 'map' | 'image' | 'none' = 'none';
  let visualUrl = '';
  
  if (type === 'RIDE') {
    // 80% chance of Map, 20% chance of Image for Rides
    const r = Math.random();
    if (r > 0.8) {
        visualType = 'image';
        const imgId = imageIds[Math.floor(Math.random() * imageIds.length)];
        visualUrl = `https://images.unsplash.com/photo-${imgId}?auto=format&fit=crop&w=1000&q=80`;
    } else {
        visualType = 'map';
    }
  } else if (type === 'ACHIEVEMENT') {
    // 50% chance of visual for Achievements
    if (Math.random() > 0.5) {
        visualType = 'image';
        const imgId = imageIds[Math.floor(Math.random() * imageIds.length)];
        visualUrl = `https://images.unsplash.com/photo-${imgId}?auto=format&fit=crop&w=1000&q=80`;
    }
  }

  const claps = Math.floor(Math.random() * 50);
  const distance = Math.floor(Math.random() * 80 + 10);
  const elevation = Math.floor(Math.random() * 1500 + 100);
  const avgPower = Math.floor(Math.random() * 150 + 150);

  return {
    id: `activity-${id}`,
    type: 'ride' as const,
    title: titles[Math.floor(Math.random() * titles.length)],
    date: timeStr,
    distance: `${distance}km`,
    duration: `${Math.floor(Math.random() * 3)}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`,
    elevation: `${elevation}m`,
    avgPower: `${avgPower}w`,
    location,
    tss: Math.floor(Math.random() * 150 + 30),
    dung: Math.floor(Math.random() * 80 + 10),
    displayType: type as any,
    user,
    action: type === 'RIDE' ? 'Ride' : type === 'ACHIEVEMENT' ? 'Achievement' : 'Reward',
    time: timeStr,
    dungDisplay: `+${Math.floor(Math.random() * 80 + 10)}`,
    color,
    visualType,
    visualUrl,
    claps
  };
};

const INITIAL_ACTIVITIES = Array.from({ length: 15 }, (_, i) => generateActivity(i));
const ESTIMATE_SIZE = () => 450;

// --- Components ---

interface VirtualizedFeedListProps {
  activities: ActivityFeedItemType[];
  scrollMargin: number;
  isLoading: boolean;
  isConnected: boolean;
  onLoadMore: () => void;
  isDarkMode: boolean;
  colors: any;
  hoverBg: string;
  cardBg: string;
  borderColor: string;
  onActivityClick: (activity: ActivityFeedItemType) => void;
  onActivityDoubleClick: (activity: ActivityFeedItemType) => void;
}

const VirtualizedFeedList = memo(({
  activities,
  scrollMargin,
  isLoading,
  isConnected,
  onLoadMore,
  isDarkMode,
  colors,
  hoverBg,
  cardBg,
  borderColor,
  onActivityClick,
  onActivityDoubleClick
}: VirtualizedFeedListProps) => {
  const rowVirtualizer = useWindowVirtualizer({
    count: activities.length,
    estimateSize: ESTIMATE_SIZE,
    overscan: 3,
    scrollMargin,
  });

  const [lastItem] = [...rowVirtualizer.getVirtualItems()].reverse();
  
  useEffect(() => {
    if (!lastItem) return;
    if (lastItem.index >= activities.length - 2 && !isLoading && isConnected) {
       const t = setTimeout(() => {
         onLoadMore();
       }, 0);
       return () => clearTimeout(t);
    }
  }, [lastItem, activities.length, isLoading, isConnected, onLoadMore]);

  return (
    <div 
      style={{ 
        height: `${rowVirtualizer.getTotalSize() - scrollMargin}px`, 
        width: '100%', 
        position: 'relative' 
      }}
    >
      {rowVirtualizer.getVirtualItems().map((virtualItem) => (
        <div
          key={virtualItem.key}
          ref={rowVirtualizer.measureElement}
          data-index={virtualItem.index}
          className="pb-6" 
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            transform: `translateY(${virtualItem.start - scrollMargin}px)`,
          }}
        >
          <ActivityFeedItem
            activity={activities[virtualItem.index]}
            hoverBg={hoverBg}
            textColor={colors.text}
            textMuted={colors.textMuted}
            isDarkMode={isDarkMode}
            cardBg={cardBg}
            borderColor={borderColor}
            onClick={() => onActivityClick(activities[virtualItem.index])}
            onDoubleClick={() => onActivityDoubleClick(activities[virtualItem.index])}
          />
        </div>
      ))}
    </div>
  );
});
VirtualizedFeedList.displayName = 'VirtualizedFeedList';

export default function ActivityFeed({ isConnected }: ActivityFeedProps) {
  const { isDarkMode, colors } = useTheme();
  const navigate = useNavigate();
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const hoverBg = getHoverBg(isDarkMode);

  // Global loading state for "hydraulic" initial load
  const [isHydrating, setIsHydrating] = useState(true);

  useEffect(() => {
    // Simulate system hydration
    const timer = setTimeout(() => setIsHydrating(false), 800);
    return () => clearTimeout(timer);
  }, []);
  
  const [activities, setActivities] = useState(INITIAL_ACTIVITIES);
  const [isLoading, setIsLoading] = useState(false);
  const [page, setPage] = useState(1);
  const [filterType, setFilterType] = useState('all');
  
  const leftSidebar = useStickyOffset(88, 24);
  const rightSidebar = useStickyOffset(88, 24);

  const parentRef = useRef<HTMLDivElement>(null);
  const [scrollMargin, setScrollMargin] = useState(0);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    if (parentRef.current) {
      const rect = parentRef.current.getBoundingClientRect();
      const scrollTop = window.scrollY || document.documentElement.scrollTop;
      setScrollMargin(rect.top + scrollTop);
      setIsMounted(true);
    }
  }, []);

  const profileData = {
    beetleNumber: 1247,
    rank: 'B' as const,
    following: 84,
    followers: 127,
    activities: 342,
    currentStreak: 7,
  };

  const streakData = {
    currentStreak: 7,
    longestStreak: 23,
    weekProgress: 6,
    nextMilestone: 10,
  };

  const trendingSegments = [
    { id: 'hawk-hill-climb', name: 'Hawk Hill Climb', location: 'Marin Headlands', pot: 45280, attempts: 47 },
    { id: 'golden-gate-sprint', name: 'Golden Gate Sprint', location: 'San Francisco', pot: 28950, attempts: 38 },
    { id: 'old-la-honda', name: 'Old La Honda', location: 'Woodside', pot: 38400, attempts: 52 },
    { id: 'mt-tam-climb', name: 'Mt Tamalpais', location: 'Mill Valley', pot: 31200, attempts: 29 },
    { id: 'paradise-loop', name: 'Paradise Loop', location: 'Tiburon', pot: 24600, attempts: 41 },
    { id: 'tunitas-creek', name: 'Tunitas Creek', location: 'San Gregorio', pot: 19800, attempts: 33 },
  ];

  const suggestedBeetles = [
    { id: 1, username: 'velo_queen', rank: 'A', mutualFollowers: 12, weeklyDung: 892 },
    { id: 2, username: 'gravel_grinder', rank: 'B', mutualFollowers: 8, weeklyDung: 645 },
    { id: 3, username: 'fixie_fan', rank: 'C', mutualFollowers: 5, weeklyDung: 423 },
    { id: 4, username: 'century_beast', rank: 'A', mutualFollowers: 15, weeklyDung: 1024 },
  ];

  const recentAchievements = [
    { id: 1, emoji: '🏆', name: 'Century Beetle', description: '100km in one ride', daysAgo: 2 },
    { id: 2, emoji: '⚡', name: 'Speed Demon', description: '40km/h avg speed', daysAgo: 5 },
    { id: 3, emoji: '🔥', name: 'Week Warrior', description: '7-day streak', daysAgo: 7 },
    { id: 4, emoji: '⛰️', name: 'Climbing Goat', description: '1000m elevation', daysAgo: 9 },
  ];

  const handleActivityClick = useCallback((activity: ActivityFeedItemType) => {
    navigate(`/activities/${activity.id}`);
  }, [navigate]);

  const handleActivityDoubleClick = useCallback((activity: ActivityFeedItemType) => {
    navigate(`/activities/${activity.id}`);
  }, [navigate]);

  const loadMoreActivities = () => {
    if (isLoading) return;
    setIsLoading(true);
    setTimeout(() => {
      const newActivities = Array.from({ length: 10 }, (_, i) => 
        generateActivity(activities.length + i)
      );
      setActivities(prev => [...prev, ...newActivities]);
      setPage(prev => prev + 1);
      setIsLoading(false);
    }, 500);
  };

  return (
    <div 
      className="p-6 sm:p-8 animate-in fade-in slide-in-from-bottom-2 duration-500 ease-out" 
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[1400px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr_280px] gap-6 sm:gap-8">
          {/* Left Sidebar - Smart Sticky */}
          <div 
            ref={leftSidebar.ref}
            style={leftSidebar.style}
            className="hidden lg:block self-start space-y-4"
          >
              {/* Profile Card */}
              {isConnected && (
                <ProfileCard
                  beetleNumber={profileData.beetleNumber}
                  rank={profileData.rank}
                  following={profileData.following}
                  followers={profileData.followers}
                  activities={profileData.activities}
                  currentStreak={profileData.currentStreak}
                />
              )}

              {/* Dung Bank - Interactive */}
              <button 
                className="w-full text-left rounded-none border overflow-hidden transition-all duration-75 active:scale-[0.98] active:brightness-95 hover:shadow-md cursor-pointer group"
                style={{ backgroundColor: cardBg, borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
                onClick={() => navigate('/portfolio')}
              >
                <div className="px-5 py-4 border-b group-hover:bg-black/5 dark:group-hover:bg-white/5 transition-colors" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}>
                  <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide flex justify-between items-center" style={{ color: colors.text }}>
                    <span>Your Dung Bank</span>
                    <span className="opacity-0 group-hover:opacity-100 transition-opacity">→</span>
                  </h2>
                </div>
                <div className="px-5 py-6 border-b" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}>
                  <div className="text-center">
                    <div className="font-['Cousine'] text-[48px] font-bold mb-1 group-hover:scale-105 transition-transform duration-100" style={{ color: '#d4a574', textShadow: '0 0 20px rgba(212, 165, 116, 0.3)' }}>
                      {isConnected ? '2,847' : '—'}
                    </div>
                    <div className="font-['Inter'] text-[11px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
                      Total Dung
                    </div>
                  </div>
                </div>
              </button>

              {/* Streak Tracker - Interactive */}
              {isConnected && (
                <button 
                  className="w-full text-left rounded-none border overflow-hidden transition-all duration-75 active:scale-[0.98] active:brightness-95 hover:shadow-md cursor-pointer group"
                  style={{ backgroundColor: cardBg, borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
                  onClick={() => navigate('/activities')}
                >
                  <div className="px-5 py-4 border-b group-hover:bg-black/5 dark:group-hover:bg-white/5 transition-colors" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}>
                    <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
                      🔥 Riding Streak
                    </h2>
                  </div>
                  <div className="px-5 py-6 border-b" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}>
                    <div className="text-center">
                      <div className="font-['Cousine'] text-[48px] font-bold mb-1 group-hover:scale-105 transition-transform duration-100" style={{ color: '#c89b5c', textShadow: '0 0 20px rgba(200, 155, 92, 0.3)' }}>
                        {streakData.currentStreak}
                      </div>
                      <div className="font-['Inter'] text-[11px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
                        Day Streak
                      </div>
                    </div>
                  </div>
                </button>
              )}

              {/* Recent Achievements */}
              {isConnected && (
                <div 
                  className="rounded-none border overflow-hidden"
                  style={{ backgroundColor: cardBg, borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
                >
                  <div className="px-5 py-4 border-b" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}>
                    <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
                      Recent Achievements
                    </h2>
                  </div>
                  <div className="divide-y" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.06)' }}>
                    {recentAchievements.map((achievement) => (
                      <div 
                        key={achievement.id}
                        className="px-5 py-3 cursor-pointer transition-colors"
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = hoverBg}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      >
                        <div className="flex items-center gap-3">
                          <div className="text-[24px] flex-shrink-0">{achievement.emoji}</div>
                          <div className="flex-1 min-w-0">
                            <div className="font-['Inter'] text-[13px] font-bold truncate" style={{ color: colors.text }}>
                              {achievement.name}
                            </div>
                            <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                              {achievement.description}
                            </div>
                          </div>
                          <div className="text-right flex-shrink-0">
                            <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                              {achievement.daysAgo}d ago
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
               )}
          </div>

          {/* Center Panel - Virtualized */}
          <div className="space-y-6">
            {isConnected && (
              <ActivityFilter
                value={filterType}
                onChange={setFilterType}
              />
            )}
            
            {/* Virtualized List Container */}
            <div ref={parentRef}>
              {isHydrating ? (
                <div className="flex flex-col items-center justify-center py-20 space-y-4">
                   <div className="font-mono text-xs tracking-[0.2em] animate-pulse text-[#d4a574]">
                      SYSTEM HYDRATION IN PROGRESS
                   </div>
                   <div className="w-48 h-[2px] bg-zinc-200 dark:bg-zinc-800 relative overflow-hidden">
                      <div className="absolute inset-0 bg-[#d4a574] animate-[shimmer_1s_infinite]" />
                   </div>
                </div>
              ) : (
                isMounted && (
                  <VirtualizedFeedList
                    activities={activities}
                    scrollMargin={scrollMargin}
                    isLoading={isLoading}
                    isConnected={isConnected}
                    onLoadMore={loadMoreActivities}
                    isDarkMode={isDarkMode}
                    colors={colors}
                    hoverBg={hoverBg}
                    cardBg={cardBg}
                    borderColor={isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'}
                    onActivityClick={handleActivityClick}
                    onActivityDoubleClick={handleActivityDoubleClick}
                  />
                )
              )}
            </div>
            
            {isLoading && (
                <LoadingSkeleton variant="activity-feed-item" count={3} />
            )}
            {!isLoading && (
              <div className="py-4 text-center">
                <div className="text-[13px] font-['Inter']" style={{ color: colors.textMuted }}>
                  Scroll for more
                </div>
              </div>
            )}
          </div>

          {/* Right Sidebar - Smart Sticky */}
          <div 
            ref={rightSidebar.ref}
            style={rightSidebar.style}
            className="hidden lg:block self-start"
          >
             <div className="space-y-4">
               
                {/* Suggested Beetles - "Punch Card List" */}
                {isConnected && (
                  <div 
                    className="rounded-none overflow-hidden"
                    style={{ backgroundColor: cardBg }}
                  >
                    <div className="px-5 py-4 border-b border-transparent">
                      <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
                        Suggested Beetles
                      </h2>
                    </div>
                    <div className="flex flex-col gap-[1px] bg-transparent p-[1px]">
                      {suggestedBeetles.map((beetle) => (
                        <div 
                          key={beetle.id}
                          onClick={() => navigate(`/rider/${beetle.id}`)}
                          className="group relative px-5 py-3 flex items-center gap-3 cursor-pointer transition-all duration-75 hover:z-10 hover:shadow-sm active:translate-y-[1px] active:shadow-none hover:bg-black/5 dark:hover:bg-white/5 rounded-none"
                          style={{ backgroundColor: cardBg }}
                        >
                          <div className="w-8 h-8 rounded-none bg-[#8ba87a] flex items-center justify-center font-bold text-white text-xs shadow-sm group-hover:scale-110 transition-transform duration-75">
                            {beetle.rank}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-['Inter'] text-[13px] font-bold truncate group-hover:text-[#8ba87a] transition-colors" style={{ color: colors.text }}>
                              @{beetle.username}
                            </div>
                            <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                              {beetle.mutualFollowers} mutuals
                            </div>
                          </div>
                          <button 
                            className="text-[10px] uppercase font-bold px-2 py-1 border border-[#8ba87a] text-[#8ba87a] rounded-none hover:bg-[#8ba87a] hover:text-white transition-colors"
                            onClick={(e) => {
                                e.stopPropagation();
                                // Follow logic here
                            }}
                          >
                            Follow
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Trending Climbs - "Slot Machine" */}
                {isConnected && (
                  <div 
                    className="rounded-none overflow-hidden"
                    style={{ backgroundColor: cardBg }}
                  >
                    <div className="px-5 py-4 border-b border-transparent">
                      <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
                        Trending Climbs
                      </h2>
                    </div>
                    <div className="flex flex-col gap-[1px] bg-transparent p-[1px]">
                      {trendingSegments.map((segment) => (
                        <div 
                          key={segment.id}
                          onClick={() => navigate(`/climb/${segment.id}`)}
                          className="group relative px-5 py-3 cursor-pointer transition-all duration-75 hover:z-10 hover:shadow-sm active:translate-y-[1px] hover:bg-black/5 dark:hover:bg-white/5 rounded-none"
                          style={{ backgroundColor: cardBg }}
                        >
                          <div className="flex justify-between items-start mb-1">
                            <div className="font-['Inter'] text-[13px] font-bold truncate pr-2 group-hover:text-[#c89b5c] transition-colors" style={{ color: colors.text }}>
                              {segment.name}
                            </div>
                            <div className="font-['Inter'] text-[11px] uppercase tracking-wide group-hover:text-zinc-800 dark:group-hover:text-zinc-200 transition-colors" style={{ color: colors.textMuted }}>
                              {segment.location}
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                              {segment.attempts} attempts today
                            </div>
                            <div className="font-['Cousine'] text-[11px] font-bold text-[#c89b5c] bg-[#c89b5c]/10 px-1.5 py-0.5 rounded-none">
                              {segment.pot.toLocaleString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

             </div>
          </div>
        </div>
      </div>

      {/* Activity Detail Modal Removed */}
    </div>
  );
}
