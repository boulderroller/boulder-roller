import React, { useState, useRef, useEffect, memo } from 'react';
import { ActivityFeedItem as ActivityFeedItemType } from '../../types';
import { Zap, Hand, MessageSquare, MoreHorizontal, Link as LinkIcon } from 'lucide-react';
import { MockMap } from './MockMap';

export const ActivityFeedItem = memo(({ 
  activity, 
  hoverBg, 
  textColor, 
  textMuted,
  onClick, 
  onDoubleClick,
  isDarkMode,
  cardBg,
  borderColor
}: {
  activity: ActivityFeedItemType;
  hoverBg: string;
  textColor: string;
  textMuted: string;
  onClick: () => void;
  onDoubleClick: () => void;
  isDarkMode: boolean;
  cardBg: string;
  borderColor: string;
}) => {
    const isMap = activity.visualType === 'map';
    const isImage = activity.visualType === 'image';
    
    // Local state for interactions
    const [localClaps, setLocalClaps] = useState(activity.claps || 0);
    const [isCommentOpen, setIsCommentOpen] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const [commentText, setCommentText] = useState('');
    const menuRef = useRef<HTMLDivElement>(null);
    const cardRef = useRef<HTMLDivElement>(null);

    // Handle clicks outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            const target = event.target as Node;
            
            // Close Menu if clicked outside menu
            if (isMenuOpen && menuRef.current && !menuRef.current.contains(target)) {
                setIsMenuOpen(false);
            }
            
            // Close Comment if clicked outside the entire card
            if (isCommentOpen && cardRef.current && !cardRef.current.contains(target)) {
                setIsCommentOpen(false);
            }
        };

        if (isMenuOpen || isCommentOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        }
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [isMenuOpen, isCommentOpen]);

    const handleCardClick = (e: React.MouseEvent) => {
        // If comment section is open, a click on the card body acts as a dismiss
        if (isCommentOpen) {
            setIsCommentOpen(false);
            return;
        }
        onClick();
    };

    const handleClap = (e: React.MouseEvent) => {
        e.stopPropagation();
        setLocalClaps(prev => prev + 1);
    };

    const handleCommentToggle = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsCommentOpen(!isCommentOpen);
    };

    const handleMenuToggle = (e: React.MouseEvent) => {
        e.stopPropagation();
        setIsMenuOpen(!isMenuOpen);
    };

    const handleCopyLink = (e: React.MouseEvent) => {
        e.stopPropagation();
        navigator.clipboard.writeText(`https://boulderroller.app/activity/${activity.id}`);
        setIsMenuOpen(false);
    };

    // Hazard Logic: High intensity rides get special styling
    const isHazard = (parseInt(activity.distance) > 100) || (activity.dung > 60);

  return (
    <div 
      ref={cardRef}
      className={`group relative flex flex-col pt-6 pb-0 rounded-none overflow-hidden border shadow-sm cursor-pointer transition-all duration-200 ease-out hover:-translate-y-[1px] hover:shadow-md active:translate-y-[1px] active:!shadow-none ${isHazard ? 'border-l-4 border-l-yellow-500' : 'border-l border-l-transparent'}`}
      style={{ 
          backgroundColor: cardBg,
          borderColor: borderColor, // Keep base border color
          borderLeftColor: isHazard ? '#eab308' : borderColor // If hazard, yellow. If not, match base.
      }}
      onClick={handleCardClick}
      onDoubleClick={onDoubleClick}
    >
      {/* Hazard Warning Stamp */}
      {isHazard && (
        <div className="absolute top-0 right-0 bg-yellow-500 text-black text-[9px] font-black px-2 py-0.5 tracking-tighter">
            HIGH INTENSITY
        </div>
      )}

      {/* 1. Header: User Info */}
      <div className="flex items-center justify-between px-6 mb-4 relative">
        <div className="flex items-center gap-3">
             <div 
                className="w-8 h-8 rounded-none border border-zinc-200 dark:border-zinc-800 flex items-center justify-center"
                style={{ backgroundColor: activity.color }}
             >
                <span className="font-mono text-xs font-bold text-white/90">{activity.user.substring(0,2).toUpperCase()}</span>
             </div>
             <div className="flex flex-col">
                <span className="text-sm font-medium leading-none mb-1" style={{ color: textColor }}>
                    {activity.user}
                </span>
                <span className="text-[10px] uppercase tracking-wide" style={{ color: textMuted }}>
                    {activity.location} • {activity.time}
                </span>
             </div>
        </div>
        
        {/* Top Right Action: Menu */}
        <div className="relative" ref={menuRef}>
            <button 
                className="text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-all duration-75 active:scale-90 p-1"
                onClick={handleMenuToggle}
            >
                <MoreHorizontal size={20} />
            </button>
            
            {isMenuOpen && (
                <div className="absolute right-0 top-full mt-1 w-32 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded shadow-lg z-10 py-1">
                    <button 
                        className="w-full text-left px-3 py-2 text-xs flex items-center gap-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors"
                        style={{ color: textColor }}
                        onClick={handleCopyLink}
                    >
                        <LinkIcon size={12} />
                        Copy Link
                    </button>
                </div>
            )}
        </div>
      </div>

      {/* 2. Data Cap: Title + Metrics Grid */}
      <div className="px-6 mb-5">
          <h3 className="font-semibold text-xl mb-4 tracking-tight" style={{ color: textColor }}>
              {activity.title}
          </h3>
          
          <div className="grid grid-cols-3 gap-4">
              <div className="flex flex-col">
                  <span className="text-[10px] uppercase text-zinc-400 mb-0.5">Dist</span>
                  <div className="flex items-baseline gap-1">
                     <span className="font-mono text-lg font-normal" style={{ color: textColor }}>{activity.distance}</span>
                  </div>
              </div>
              <div className="flex flex-col pl-2">
                  <span className="text-[10px] uppercase text-zinc-400 mb-0.5">Elev</span>
                  <div className="flex items-baseline gap-1">
                     <span className="font-mono text-lg font-normal" style={{ color: textColor }}>{activity.elevation}</span>
                  </div>
              </div>
              <div className="flex flex-col pl-2">
                  <span className="text-[10px] uppercase text-zinc-400 mb-0.5">Pwr</span>
                  <div className="flex items-baseline gap-1">
                     <span className="font-mono text-lg font-normal" style={{ color: textColor }}>{activity.avgPower || '---'}</span>
                  </div>
              </div>
          </div>
      </div>

      {/* 3. Visual Anchor */}
      {(isMap || isImage) && (
          <div className="w-full aspect-[16/9] md:aspect-[2/1] bg-zinc-100 dark:bg-zinc-900 relative">
              {isImage ? (
                  <img src={activity.visualUrl} className="w-full h-full object-cover grayscale-[20%] contrast-110" alt="Ride" />
              ) : (
                  <MockMap />
              )}
              
              <div className="absolute bottom-4 right-4">
                   <div className="flex items-center gap-1.5 px-2 py-1 bg-black/40 backdrop-blur-md rounded border border-white/10">
                        <Zap size={12} className="text-yellow-500" />
                        <span className="font-mono text-[10px] text-white font-bold">{activity.dung} DUNG</span>
                   </div>
              </div>
          </div>
      )}

      {/* 4. Footer Actions (Restored Compact Style) */}
      <div 
        className="px-6 py-4 flex justify-between items-center border-t"
        style={{ borderColor: borderColor }}
      >
         {/* Left: Claps Count */}
         <div className="text-[13px] font-medium text-zinc-500 dark:text-zinc-400 flex items-center gap-1.5">
             <Hand size={14} className={localClaps > (activity.claps || 0) ? "text-[#d4a574]" : ""} />
             <span>{localClaps} claps</span>
         </div>
         
         {/* Right: Icon Buttons */}
         <div className="flex items-center gap-1">
             <button 
                className="p-2 rounded-none hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-200 transition-all duration-75 active:scale-90"
                onClick={handleCommentToggle}
                title="Comment"
             >
                 <MessageSquare size={18} />
             </button>
             
             <button 
                className="p-2 rounded-none hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-[#d4a574] transition-all duration-75 active:scale-90"
                onClick={handleClap}
                title="Clap"
             >
                 <Hand size={18} />
             </button>
         </div>
      </div>

      {/* 5. Comment Tile (Expands Below) */}
      {isCommentOpen && (
          <div 
            className="w-full border-t animate-in fade-in duration-200 flex items-center bg-transparent" 
            style={{ borderColor: borderColor }}
            onClick={(e) => e.stopPropagation()}
          >
              <input 
                  type="text" 
                  ref={(el) => {
                    if (el) {
                      el.style.setProperty('box-shadow', 'none', 'important');
                      el.style.setProperty('border-color', 'transparent', 'important');
                      el.style.setProperty('outline', 'none', 'important');
                    }
                  }}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Write a comment..."
                  className="flex-1 bg-transparent border-none text-sm px-6 py-4 outline-none focus:outline-none focus:ring-0 focus-visible:ring-0 focus-visible:outline-none shadow-none placeholder:text-zinc-500 font-medium"
                  style={{ color: textColor }}
                  autoComplete="off"
                  autoFocus
              />
              <button 
                className="mr-6 text-xs font-bold uppercase tracking-wide transition-all duration-75 disabled:opacity-30 disabled:cursor-not-allowed hover:text-[#d4a574] active:scale-95"
                style={{ color: textMuted }}
                disabled={!commentText.trim()}
              >
                  Post
              </button>
          </div>
      )}

    </div>
  );
});

ActivityFeedItem.displayName = 'ActivityFeedItem';