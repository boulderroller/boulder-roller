import { X, TrendingUp, Crown, Star } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';

interface SegmentDetailModalProps {
  segment: {
    id: string;
    name: string;
    location: string;
    distance: number;
    elevation: number;
    grade: number;
    attempts: number;
    personalRecord: {
      time: string;
      date: string;
      avgPower: number;
      dung: number;
      rank?: number;
    } | null;
    kom: {
      time: string;
      holder: string;
      beetleNumber: number;
    };
    isStarred: boolean;
    hasKOM: boolean;
  };
  onClose: () => void;
  onViewFull: () => void;
}

export default function SegmentDetailModal({ segment, onClose, onViewFull }: SegmentDetailModalProps) {
  const { colors, isDarkMode } = useTheme();

  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  return (
    <div 
      className="fixed inset-0 z-[60] flex items-center justify-center p-4"
      onClick={onClose}
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.7)' }}
    >
      <div
        className="w-full max-w-[520px] rounded border shadow-2xl z-[65]"
        style={{ backgroundColor: cardBg, borderColor }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-6 py-4 border-b flex items-start justify-between" style={{ borderColor }}>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              {segment.isStarred && (
                <Star size={16} fill="#c89b5c" style={{ color: '#c89b5c' }} />
              )}
              <h2 
                className="font-['Inter'] font-bold text-[18px]"
                style={{ color: colors.text }}
              >
                {segment.name}
              </h2>
              {segment.hasKOM && (
                <Crown size={16} fill="#d4af37" style={{ color: '#d4af37' }} />
              )}
            </div>
            <p className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
              📍 {segment.location}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-opacity-10 rounded transition-colors"
            style={{ color: colors.textMuted }}
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-5 space-y-5">
          {/* Segment Stats */}
          <div>
            <div className="font-['Inter'] text-[10px] uppercase tracking-wide mb-3 flex items-center gap-2" style={{ color: colors.textMuted }}>
              <TrendingUp className="w-3.5 h-3.5" />
              Segment Stats
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div>
                <div className="font-['Cousine'] text-[24px] font-bold leading-none mb-1" style={{ color: colors.text }}>
                  {segment.distance}
                </div>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  Distance (km)
                </div>
              </div>
              <div>
                <div className="font-['Cousine'] text-[24px] font-bold leading-none mb-1" style={{ color: colors.text }}>
                  {segment.elevation}
                </div>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  Elevation (m)
                </div>
              </div>
              <div>
                <div className="font-['Cousine'] text-[24px] font-bold leading-none mb-1" style={{ color: colors.text }}>
                  {segment.grade}%
                </div>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  Avg Grade
                </div>
              </div>
              <div>
                <div className="font-['Cousine'] text-[24px] font-bold leading-none mb-1" style={{ color: colors.text }}>
                  {segment.attempts}
                </div>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  Your Attempts
                </div>
              </div>
            </div>
          </div>

          {/* Personal Record */}
          {segment.personalRecord && (
            <div 
              className="p-4 rounded border"
              style={{ 
                backgroundColor: isDarkMode ? 'rgba(200, 155, 92, 0.05)' : 'rgba(200, 155, 92, 0.03)',
                borderColor: colors.accent 
              }}
            >
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide mb-3" style={{ color: colors.accent }}>
                💪 Your PR
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <div className="font-['Cousine'] text-[20px] font-bold leading-none mb-1" style={{ color: colors.text }}>
                    {segment.personalRecord.time}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Best Time
                  </div>
                </div>
                {segment.personalRecord.rank && (
                  <div>
                    <div className="font-['Cousine'] text-[20px] font-bold leading-none mb-1" style={{ color: colors.text }}>
                      #{segment.personalRecord.rank}
                    </div>
                    <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                      Your Rank
                    </div>
                  </div>
                )}
                <div>
                  <div 
                    className="font-['Cousine'] text-[20px] font-bold leading-none mb-1"
                    style={{ 
                      color: '#c89b5c',
                      textShadow: '0 0 12px rgba(200, 155, 92, 0.2)'
                    }}
                  >
                    {segment.personalRecord.dung}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    CAL Earned
                  </div>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t" style={{ borderColor }}>
                <div className="flex items-center justify-between">
                  <span className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                    Set on {segment.personalRecord.date}
                  </span>
                  <span className="font-['Cousine'] text-[11px] font-bold" style={{ color: colors.text }}>
                    {segment.personalRecord.avgPower}w avg
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* KOM/QOM */}
          <div 
            className="p-4 rounded border"
            style={{ 
              backgroundColor: segment.hasKOM 
                ? (isDarkMode ? 'rgba(212, 175, 55, 0.1)' : 'rgba(212, 175, 55, 0.05)')
                : (isDarkMode ? 'rgba(0, 0, 0, 0.2)' : 'rgba(0, 0, 0, 0.02)'),
              borderColor: segment.hasKOM ? '#d4af37' : borderColor
            }}
          >
            <div className="font-['Inter'] text-[10px] uppercase tracking-wide mb-3 flex items-center gap-2" style={{ color: segment.hasKOM ? '#d4af37' : colors.textMuted }}>
              <Crown className="w-3.5 h-3.5" />
              {segment.hasKOM ? 'You Hold the KOM!' : 'Current KOM'}
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="font-['Cousine'] text-[24px] font-bold leading-none mb-1" style={{ color: segment.hasKOM ? '#d4af37' : colors.text }}>
                  {segment.kom.time}
                </div>
                <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                  {segment.hasKOM ? 'Your best time!' : `Held by ${segment.kom.holder}`}
                </div>
              </div>
              <div className="text-right">
                <div className="font-['Inter'] text-[11px] mb-1" style={{ color: colors.textMuted }}>
                  Beetle #{segment.kom.beetleNumber}
                </div>
                <div className="text-[20px]">🪲</div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t flex gap-3" style={{ borderColor }}>
          <BeetleButton 
            variant="secondary" 
            onClick={onClose}
            className="flex-1"
          >
            Close
          </BeetleButton>
          <BeetleButton 
            variant="primary" 
            onClick={onViewFull}
            className="flex-1"
          >
            View Full Segment →
          </BeetleButton>
        </div>
      </div>
    </div>
  );
}