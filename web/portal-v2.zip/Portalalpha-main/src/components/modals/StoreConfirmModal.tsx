import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';

interface StoreItem {
  id: string;
  emoji: string;
  name: string;
  description: string;
  price: number;
}

interface StoreConfirmModalProps {
  item: StoreItem;
  currentBalance: number;
  onClose: () => void;
  onConfirm: () => void;
}

export default function StoreConfirmModal({ item, currentBalance, onClose, onConfirm }: StoreConfirmModalProps) {
  const { colors, isDarkMode } = useTheme();
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const afterBalance = currentBalance - item.price;
  const hasEnoughFunds = afterBalance >= 0;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[400px]">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 
              className="font-['Inter'] font-black text-[20px]"
              style={{ color: colors.text }}
            >
              Confirm Purchase
            </h2>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Item Preview */}
          <div className="text-center mb-6">
            <div className="text-[64px] mb-3 leading-none">
              {item.emoji}
            </div>
            <div 
              className="font-['Inter'] text-[18px] font-bold mb-1"
              style={{ color: colors.text }}
            >
              {item.name}
            </div>
            <div 
              className="font-['Inter'] text-[12px]"
              style={{ color: colors.textMuted }}
            >
              {item.description}
            </div>
          </div>

          {/* Price Panel */}
          <div
            className="rounded-[6px] border-[1px] p-5 mb-6"
            style={{
              backgroundColor: cardBg,
              borderColor: borderColor,
            }}
          >
            {/* Price - LOUD */}
            <div className="mb-4 pb-4" style={{ borderBottom: `1px solid ${borderColor}` }}>
              <div 
                className="font-['Inter'] text-[11px] uppercase tracking-wide mb-1"
                style={{ color: colors.textMuted }}
              >
                Price
              </div>
              <div 
                className="font-['Cousine'] text-[28px] font-bold leading-none"
                style={{
                  color: '#d4a574',
                  textShadow: hasEnoughFunds ? '0 0 12px rgba(212, 165, 116, 0.3)' : 'none',
                }}
              >
                {item.price.toLocaleString()}
                <span 
                  className="text-[14px] ml-2"
                  style={{ color: colors.textMuted }}
                >
                  dung
                </span>
              </div>
            </div>

            {/* Balance Info */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide"
                  style={{ color: colors.textMuted }}
                >
                  Your Balance
                </span>
                <span 
                  className="font-['Cousine'] text-[16px] font-bold"
                  style={{ color: colors.text }}
                >
                  {currentBalance.toLocaleString()}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide"
                  style={{ color: colors.textMuted }}
                >
                  After Purchase
                </span>
                <span 
                  className="font-['Cousine'] text-[16px] font-bold flex items-center gap-1.5"
                  style={{ color: hasEnoughFunds ? colors.text : '#d32f2f' }}
                >
                  {afterBalance.toLocaleString()}
                  {!hasEnoughFunds && <span>⚠️</span>}
                </span>
              </div>
            </div>
          </div>

          {/* Insufficient Funds Warning */}
          {!hasEnoughFunds && (
            <div 
              className="rounded-[6px] border-[1px] p-3 mb-5 text-center"
              style={{
                backgroundColor: isDarkMode ? 'rgba(211, 47, 47, 0.08)' : 'rgba(211, 47, 47, 0.04)',
                borderColor: '#d32f2f',
              }}
            >
              <p 
                className="font-['Inter'] text-[12px] font-bold"
                style={{ color: '#d32f2f' }}
              >
                Insufficient dung. Ride more to earn!
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <BeetleButton
              variant="secondary"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </BeetleButton>
            <BeetleButton
              onClick={onConfirm}
              disabled={!hasEnoughFunds}
              className="flex-1"
            >
              {hasEnoughFunds ? 'Confirm' : 'Can\'t Afford'}
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}