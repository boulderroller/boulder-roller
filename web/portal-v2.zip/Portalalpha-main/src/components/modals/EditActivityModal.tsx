import { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { BeetleInput } from '../ui/beetle-input';

interface Activity {
  id: string;
  title: string;
  description: string;
  distance: number;
  duration: string;
  date: string;
  visibility: 'public' | 'followers' | 'private';
  commentsEnabled: boolean;
  hideFromLeaderboards: boolean;
}

interface EditActivityModalProps {
  activity: Activity;
  onClose: () => void;
  onSave: (updatedActivity: Activity) => void;
}

export default function EditActivityModal({ activity, onClose, onSave }: EditActivityModalProps) {
  const { colors, isDarkMode } = useTheme();
  
  const [title, setTitle] = useState(activity.title);
  const [description, setDescription] = useState(activity.description);
  const [visibility, setVisibility] = useState(activity.visibility);
  const [commentsEnabled, setCommentsEnabled] = useState(activity.commentsEnabled);
  const [hideFromLeaderboards, setHideFromLeaderboards] = useState(activity.hideFromLeaderboards);
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';

  const handleSave = () => {
    onSave({
      ...activity,
      title,
      description,
      visibility,
      commentsEnabled,
      hideFromLeaderboards,
    });
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[520px]">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 
              className="font-['Inter'] font-black text-[20px]"
              style={{ color: colors.text }}
            >
              ✏️ Edit Activity
            </h2>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Activity Info Panel - Read-only data */}
          <div
            className="rounded-[6px] border-[1px] p-4 mb-6"
            style={{
              backgroundColor: isDarkMode ? '#2a2d1e' : colors.bg,
              borderColor: borderColor,
            }}
          >
            <div className="flex justify-between items-center">
              <div>
                <div 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide mb-0.5"
                  style={{ color: colors.textMuted }}
                >
                  Distance
                </div>
                <div 
                  className="font-['Cousine'] text-[18px] font-bold"
                  style={{ color: colors.text }}
                >
                  {activity.distance} km
                </div>
              </div>
              <div>
                <div 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide mb-0.5"
                  style={{ color: colors.textMuted }}
                >
                  Duration
                </div>
                <div 
                  className="font-['Cousine'] text-[18px] font-bold"
                  style={{ color: colors.text }}
                >
                  {activity.duration}
                </div>
              </div>
              <div>
                <div 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide mb-0.5"
                  style={{ color: colors.textMuted }}
                >
                  Date
                </div>
                <div 
                  className="font-['Cousine'] text-[13px] font-bold"
                  style={{ color: colors.text }}
                >
                  {activity.date}
                </div>
              </div>
            </div>
          </div>

          {/* Title Input */}
          <div className="mb-5">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Title
            </label>
            <BeetleInput
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Activity title"
            />
          </div>

          {/* Description Textarea */}
          <div className="mb-6">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Description (Optional)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add a description..."
              rows={3}
              className="w-full rounded-[6px] border-[2px] px-3 py-2 font-['Inter'] text-[13px] resize-none transition-all outline-none"
              style={{
                backgroundColor: isDarkMode ? '#2a2d1e' : 'white',
                borderColor: colors.border,
                color: colors.text,
                boxShadow: `2px 2px 0px 0px ${colors.border}`,
              }}
            />
          </div>

          {/* Privacy Settings */}
          <div className="mb-6">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
              style={{ color: colors.textMuted }}
            >
              Privacy & Settings
            </label>

            {/* Visibility Radio */}
            <div className="space-y-2.5 mb-4">
              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="radio"
                  name="visibility"
                  checked={visibility === 'public'}
                  onChange={() => setVisibility('public')}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div>
                  <div 
                    className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                    style={{ color: colors.text }}
                  >
                    🌍 Public
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="radio"
                  name="visibility"
                  checked={visibility === 'followers'}
                  onChange={() => setVisibility('followers')}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div>
                  <div 
                    className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                    style={{ color: colors.text }}
                  >
                    👥 Followers Only
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="radio"
                  name="visibility"
                  checked={visibility === 'private'}
                  onChange={() => setVisibility('private')}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div>
                  <div 
                    className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                    style={{ color: colors.text }}
                  >
                    🔒 Private
                  </div>
                </div>
              </label>
            </div>

            {/* Additional Options */}
            <div className="space-y-2.5">
              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={commentsEnabled}
                  onChange={(e) => setCommentsEnabled(e.target.checked)}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div 
                  className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                  style={{ color: colors.text }}
                >
                  💬 Enable comments
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={hideFromLeaderboards}
                  onChange={(e) => setHideFromLeaderboards(e.target.checked)}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div 
                  className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                  style={{ color: colors.text }}
                >
                  🏆 Hide from leaderboards
                </div>
              </label>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <BeetleButton
              variant="secondary"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </BeetleButton>
            <BeetleButton
              onClick={handleSave}
              className="flex-1"
            >
              Save Changes
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}