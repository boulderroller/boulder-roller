import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { Share2 } from 'lucide-react';
import { useEscapeKey } from '../../hooks/useEscapeKey';
import { useScrollLock } from '../../hooks/useScrollLock';

interface Achievement {
  id: string;
  emoji: string;
  name: string;
  description: string;
  dungReward: number;
  nextAchievement?: {
    name: string;
    requirement: string;
    progress: number;
    total: number;
  };
}

interface AchievementUnlockModalProps {
  achievement: Achievement;
  onClose: () => void;
  onShare?: () => void;
}

export default function AchievementUnlockModal({ achievement, onClose, onShare }: AchievementUnlockModalProps) {
  const { colors, isDarkMode } = useTheme();
  
  useEscapeKey(onClose);
  useScrollLock(true);
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const progressPercent = achievement.nextAchievement 
    ? (achievement.nextAchievement.progress / achievement.nextAchievement.total) * 100 
    : 0;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[520px]">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}, 0 0 24px rgba(200, 155, 92, 0.15)`,
          }}
        >
          {/* Close Button */}
          <div className="flex justify-end mb-4">
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Achievement Hero */}
          <div className="text-center mb-6">
            {/* MASSIVE Emoji */}
            <div className="text-[96px] mb-4 leading-none">
              {achievement.emoji}
            </div>

            {/* Achievement Name - LOUD */}
            <h2 
              className="font-['Inter'] font-black text-[24px] mb-2"
              style={{ color: colors.text }}
            >
              {achievement.name}
            </h2>

            {/* Description - Muted */}
            <p 
              className="font-['Inter'] text-[13px]"
              style={{ color: colors.textMuted }}
            >
              {achievement.description}
            </p>
          </div>

          {/* Dung Reward Panel - LOOT EMPHASIS */}
          <div
            className="rounded-[6px] border-[2px] py-6 mb-6"
            style={{
              backgroundColor: isDarkMode ? 'rgba(200, 155, 92, 0.08)' : 'rgba(200, 155, 92, 0.04)',
              borderColor: '#c89b5c',
            }}
          >
            <div className="text-center">
              <div 
                className="font-['Cousine'] text-[42px] font-bold leading-none mb-1"
                style={{
                  color: '#d4a574',
                  textShadow: '0 0 20px rgba(212, 165, 116, 0.4)',
                  filter: 'drop-shadow(0 0 8px rgba(212, 165, 116, 0.3))',
                }}
              >
                +{achievement.dungReward}
              </div>
              <div 
                className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold"
                style={{ color: colors.textMuted }}
              >
                Dung Earned
              </div>
            </div>
          </div>

          {/* Progress to Next Achievement */}
          {achievement.nextAchievement && (
            <div className="mb-6">
              <div 
                className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold mb-2"
                style={{ color: colors.textMuted }}
              >
                Next Achievement
              </div>

              <div
                className="rounded-[6px] border-[1px] p-4"
                style={{
                  backgroundColor: isDarkMode ? '#2a2d1e' : colors.bg,
                  borderColor: borderColor,
                }}
              >
                <div 
                  className="font-['Inter'] text-[13px] font-bold mb-1"
                  style={{ color: colors.text }}
                >
                  {achievement.nextAchievement.name}
                </div>
                <div 
                  className="font-['Inter'] text-[11px] mb-3"
                  style={{ color: colors.textMuted }}
                >
                  {achievement.nextAchievement.requirement}
                </div>

                {/* Progress Bar */}
                <div className="relative">
                  <div 
                    className="h-2 rounded-full overflow-hidden"
                    style={{ backgroundColor: borderColor }}
                  >
                    <div 
                      className="h-full transition-all duration-500"
                      style={{ 
                        width: `${progressPercent}%`,
                        backgroundColor: colors.accent,
                      }}
                    />
                  </div>
                  <div 
                    className="font-['Cousine'] text-[11px] mt-1 text-right"
                    style={{ color: colors.textMuted }}
                  >
                    {achievement.nextAchievement.progress} / {achievement.nextAchievement.total}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            {onShare && (
              <BeetleButton
                onClick={onShare}
                variant="secondary"
                className="flex-1"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </BeetleButton>
            )}
            <BeetleButton
              onClick={onClose}
              className="flex-1"
            >
              Close
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}