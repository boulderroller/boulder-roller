import { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { Copy, Check } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface InvitedFriend {
  username: string;
  status: 'joined' | 'pending';
  date: string;
}

interface InviteFriendModalProps {
  inviteCode: string;
  invitesRemaining: number;
  invitedFriends: InvitedFriend[];
  onClose: () => void;
}

export default function InviteFriendModal({ inviteCode, invitesRemaining, invitedFriends, onClose }: InviteFriendModalProps) {
  const { colors, isDarkMode } = useTheme();
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  
  const inviteLink = `https://boulderroller.xyz/invite/${inviteCode}`;

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(inviteCode);
    setCopiedCode(true);
    toast.success('Code copied! 📋');
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(inviteLink);
    setCopiedLink(true);
    toast.success('Link copied! 🔗');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[520px]">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 
              className="font-['Inter'] font-black text-[20px]"
              style={{ color: colors.text }}
            >
              🎟️ Invite Friends
            </h2>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Invite Stats */}
          <div
            className="rounded-[6px] border-[1px] p-4 mb-5"
            style={{
              backgroundColor: cardBg,
              borderColor: borderColor,
            }}
          >
            <div className="flex justify-between items-center">
              <div>
                <div 
                  className="font-['Cousine'] text-[22px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {invitesRemaining}
                </div>
                <div 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide"
                  style={{ color: colors.textMuted }}
                >
                  Invites Remaining
                </div>
              </div>
              <div className="text-right">
                <div 
                  className="font-['Cousine'] text-[16px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {invitedFriends.length}
                </div>
                <div 
                  className="font-['Inter'] text-[11px] uppercase tracking-wide"
                  style={{ color: colors.textMuted }}
                >
                  Friends Invited
                </div>
              </div>
            </div>
          </div>

          {/* Invite Code - HERO */}
          <div className="mb-4">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Your Invite Code
            </label>
            <div
              className="rounded-[6px] border-[2px] p-5 mb-3 text-center"
              style={{
                backgroundColor: isDarkMode ? 'rgba(139, 168, 122, 0.08)' : 'rgba(139, 168, 122, 0.04)',
                borderColor: colors.accent,
              }}
            >
              <div 
                className="font-['Cousine'] text-[32px] font-bold leading-none tracking-wider select-all"
                style={{ color: colors.text }}
              >
                {inviteCode}
              </div>
            </div>
            <BeetleButton
              onClick={handleCopyCode}
              className="w-full"
            >
              {copiedCode ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copy Code</span>
                </>
              )}
            </BeetleButton>
          </div>

          {/* Or Share Link */}
          <div className="mb-6">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Or Share Link
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={inviteLink}
                readOnly
                className="flex-1 rounded-[6px] border-[2px] px-3 py-2 font-['Cousine'] text-[12px] outline-none select-all"
                style={{
                  backgroundColor: cardBg,
                  borderColor: colors.border,
                  color: colors.textMuted,
                }}
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-2 rounded-[6px] border-[2px] transition-all"
                style={{
                  backgroundColor: colors.bg,
                  borderColor: colors.border,
                  color: colors.text,
                  boxShadow: `2px 2px 0px 0px ${colors.border}`,
                }}
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Divider */}
          <div className="h-[1px] mb-5" style={{ backgroundColor: borderColor }} />

          {/* Invited Friends List */}
          <div>
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
              style={{ color: colors.textMuted }}
            >
              Invited Friends
            </label>
            <div className="space-y-2 max-h-[160px] overflow-y-auto">
              {invitedFriends.length === 0 ? (
                <div 
                  className="text-center py-4 font-['Inter'] text-[12px]"
                  style={{ color: colors.textMuted }}
                >
                  No friends invited yet
                </div>
              ) : (
                invitedFriends.map((friend, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between py-2 px-3 rounded-[6px]"
                    style={{
                      backgroundColor: friend.status === 'joined' ? 'transparent' : cardBg,
                      borderLeft: friend.status === 'joined' 
                        ? `3px solid ${colors.accent}` 
                        : `3px solid ${borderColor}`,
                    }}
                  >
                    <div>
                      <div 
                        className="font-['Inter'] text-[13px] font-bold"
                        style={{ color: colors.text }}
                      >
                        {friend.username}
                      </div>
                      <div 
                        className="font-['Inter'] text-[11px]"
                        style={{ color: colors.textMuted }}
                      >
                        {friend.status === 'joined' ? `Joined ${friend.date}` : 'Pending'}
                      </div>
                    </div>
                    <div className="text-[18px]">
                      {friend.status === 'joined' ? '✅' : '⏳'}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Close Button */}
          <div className="mt-6">
            <BeetleButton
              onClick={onClose}
              variant="secondary"
              className="w-full"
            >
              Close
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}