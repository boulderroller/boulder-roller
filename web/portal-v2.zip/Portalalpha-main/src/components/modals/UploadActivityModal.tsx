import { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { useEscapeKey } from '../../hooks/useEscapeKey';
import { useScrollLock } from '../../hooks/useScrollLock';

interface UploadActivityModalProps {
  onClose: () => void;
  onUploadSuccess: (file: File) => void;
}

export default function UploadActivityModal({ onClose, onUploadSuccess }: UploadActivityModalProps) {
  const { colors, isDarkMode } = useTheme();

  useEscapeKey(onClose);
  useScrollLock(true);

  const handleMockUpload = () => {
    // Create a mock file object
    const mockFile = new File([''], 'morning-ride-2024-12-08.fit', { type: 'application/fit' });
    onUploadSuccess(mockFile);
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[520px]">
        <div
          className="rounded border p-6"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 
              className="font-['Inter'] font-bold text-[16px]"
              style={{ color: colors.text }}
            >
              📤 Upload Ride
            </h2>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Simple upload message */}
          <div className="text-center py-8 mb-6">
            <div className="text-[48px] mb-3">📁</div>
            <p 
              className="font-['Inter'] text-[14px] mb-1"
              style={{ color: colors.text }}
            >
              Upload your ride file
            </p>
            <p 
              className="font-['Inter'] text-[11px] uppercase tracking-wide"
              style={{ color: colors.textMuted }}
            >
              .fit, .tcx, or .gpx files
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <BeetleButton
              onClick={handleMockUpload}
              className="flex-1"
            >
              Choose File
            </BeetleButton>
            <BeetleButton
              variant="secondary"
              onClick={onClose}
            >
              Cancel
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}