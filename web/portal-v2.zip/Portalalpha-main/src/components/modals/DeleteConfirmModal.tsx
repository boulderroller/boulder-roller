import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';

interface Activity {
  id: string;
  title: string;
  date: string;
  distance: string;
  dung: number;
}

interface DeleteConfirmModalProps {
  activity: Activity;
  onClose: () => void;
  onConfirm: () => void;
}

export default function DeleteConfirmModal({ activity, onClose, onConfirm }: DeleteConfirmModalProps) {
  const { colors, isDarkMode } = useTheme();
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[400px]">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header with Warning */}
          <div className="text-center mb-6">
            <div className="text-[48px] mb-3">⚠️</div>
            <h2 
              className="font-['Inter'] font-black text-[20px]"
              style={{ color: colors.text }}
            >
              Delete Activity?
            </h2>
          </div>

          {/* Activity Preview - Muted */}
          <div
            className="rounded-[6px] border-[1px] p-4 mb-5"
            style={{
              backgroundColor: cardBg,
              borderColor: borderColor,
            }}
          >
            <div 
              className="font-['Inter'] text-[16px] font-bold mb-1"
              style={{ color: colors.text }}
            >
              {activity.title}
            </div>
            <div 
              className="font-['Inter'] text-[13px] mb-1"
              style={{ color: colors.textMuted }}
            >
              {activity.date} • {activity.distance}
            </div>
            <div 
              className="font-['Cousine'] text-[13px]"
              style={{ color: colors.textMuted }}
            >
              {activity.dung} dung earned
            </div>
          </div>

          {/* Warning Text */}
          <div className="text-center mb-6">
            <p 
              className="font-['Inter'] text-[13px] mb-1"
              style={{ color: colors.text }}
            >
              This action cannot be undone.
            </p>
            <p 
              className="font-['Inter'] text-[14px] font-bold"
              style={{ color: '#d32f2f' }}
            >
              You will lose {activity.dung} dung.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <BeetleButton
              variant="secondary"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </BeetleButton>
            <BeetleButton
              onClick={onConfirm}
              className="flex-1 border-[2px] rounded-[10px] px-4 py-2.5 font-['Inter'] text-[13px] font-bold uppercase tracking-wide transition-all cursor-pointer"
              style={{
                backgroundColor: isDarkMode ? '#3a2e2e' : '#fff5f5',
                borderColor: '#d32f2f',
                color: '#d32f2f',
                boxShadow: '3px 3px 0px 0px #d32f2f',
              }}
            >
              Delete
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}