import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { BeetleInput } from '../ui/beetle-input';
import { Upload, X } from 'lucide-react';

interface RideUploadSuccessModalProps {
  fileName: string;
  onClose: () => void;
}

export default function RideUploadSuccessModal({ fileName, onClose }: RideUploadSuccessModalProps) {
  const { colors, isDarkMode } = useTheme();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('Morning Ride');
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<File[]>([]);
  const [photoPreviewUrls, setPhotoPreviewUrls] = useState<string[]>([]);
  const [visibility, setVisibility] = useState<'public' | 'followers' | 'private'>('public');
  const [commentsEnabled, setCommentsEnabled] = useState(true);
  const [hideFromLeaderboards, setHideFromLeaderboards] = useState(false);
  const [activityType, setActivityType] = useState<'ride' | 'virtual-ride' | 'race' | 'workout'>('ride');

  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setPhotos([...photos, ...newFiles]);
      
      // Create preview URLs
      const newUrls = newFiles.map(file => URL.createObjectURL(file));
      setPhotoPreviewUrls([...photoPreviewUrls, ...newUrls]);
    }
  };

  const removePhoto = (index: number) => {
    URL.revokeObjectURL(photoPreviewUrls[index]);
    setPhotos(photos.filter((_, i) => i !== index));
    setPhotoPreviewUrls(photoPreviewUrls.filter((_, i) => i !== index));
  };

  const handleSave = () => {
    // Mock save logic
    console.log('Saving ride:', { title, description, photos });
    
    // Navigate to home feed
    navigate('/');
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[680px] max-h-[90vh] overflow-y-auto">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 
                className="font-['Inter'] font-black text-[20px] mb-1"
                style={{ color: colors.text }}
              >
                ✅ Ride Uploaded!
              </h2>
              <p 
                className="font-['Inter'] text-[12px]"
                style={{ color: colors.textMuted }}
              >
                {fileName}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Title Input */}
          <div className="mb-5">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Title
            </label>
            <BeetleInput
              placeholder="Morning Ride"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          {/* Activity Type */}
          <div className="mb-5">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Activity Type
            </label>
            <select
              value={activityType}
              onChange={(e) => setActivityType(e.target.value as any)}
              className="w-full px-4 py-2.5 rounded border font-['Inter'] text-[13px] outline-none transition-all"
              style={{
                backgroundColor: isDarkMode ? '#2a2d1e' : 'white',
                borderColor: colors.border,
                color: colors.text,
                boxShadow: `2px 2px 0px 0px ${colors.border}`,
              }}
            >
              <option value="ride">🚴 Ride</option>
              <option value="virtual-ride">💻 Virtual Ride</option>
              <option value="race">🏁 Race</option>
              <option value="workout">💪 Workout</option>
            </select>
          </div>

          {/* Description */}
          <div className="mb-5">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Description
            </label>
            <textarea
              placeholder="Add notes about your ride..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full rounded-[6px] border-[2px] px-4 py-3 font-['Inter'] text-[14px] transition-all outline-none resize-none"
              style={{
                backgroundColor: isDarkMode ? '#2a2d1e' : 'white',
                borderColor: colors.border,
                color: colors.text,
                boxShadow: `2px 2px 0px 0px ${colors.border}`,
              }}
            />
          </div>

          {/* Photo Upload Section */}
          <div className="mb-5">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Photos (Optional)
            </label>
            
            {/* Photo Grid */}
            <div className="grid grid-cols-3 gap-3 mb-3">
              {photoPreviewUrls.map((url, index) => (
                <div 
                  key={index}
                  className="relative aspect-square rounded-[6px] border-[1px] overflow-hidden group"
                  style={{
                    borderColor: borderColor,
                    backgroundColor: cardBg,
                  }}
                >
                  <img 
                    src={url} 
                    alt={`Preview ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <button
                    onClick={() => removePhoto(index)}
                    className="absolute top-2 right-2 p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    style={{
                      backgroundColor: 'rgba(0, 0, 0, 0.6)',
                      color: 'white',
                    }}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
              
              {/* Upload Button */}
              {photoPreviewUrls.length < 6 && (
                <label
                  className="aspect-square rounded-[6px] border-[1px] border-dashed flex flex-col items-center justify-center cursor-pointer transition-all"
                  style={{
                    borderColor: borderColor,
                    backgroundColor: 'transparent',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = isDarkMode 
                      ? 'rgba(139, 168, 122, 0.08)' 
                      : 'rgba(139, 168, 122, 0.04)';
                    e.currentTarget.style.borderColor = colors.accent;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                    e.currentTarget.style.borderColor = borderColor;
                  }}
                >
                  <Upload className="w-6 h-6 mb-1" style={{ color: colors.textMuted }} />
                  <span 
                    className="font-['Inter'] text-[11px] font-bold"
                    style={{ color: colors.textMuted }}
                  >
                    Add Photo
                  </span>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    multiple
                    onChange={handlePhotoUpload}
                  />
                </label>
              )}
            </div>
            
            <p 
              className="font-['Inter'] text-[11px]"
              style={{ color: colors.textMuted }}
            >
              You can upload up to 6 photos
            </p>
          </div>

          {/* Privacy Settings */}
          <div className="mb-6">
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
              style={{ color: colors.textMuted }}
            >
              Privacy & Settings
            </label>

            {/* Visibility Radio */}
            <div className="space-y-2.5 mb-4">
              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="radio"
                  name="visibility"
                  checked={visibility === 'public'}
                  onChange={() => setVisibility('public')}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div>
                  <div 
                    className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                    style={{ color: colors.text }}
                  >
                    🌍 Public
                  </div>
                  <div 
                    className="font-['Inter'] text-[11px]"
                    style={{ color: colors.textMuted }}
                  >
                    Everyone can see this ride
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="radio"
                  name="visibility"
                  checked={visibility === 'followers'}
                  onChange={() => setVisibility('followers')}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div>
                  <div 
                    className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                    style={{ color: colors.text }}
                  >
                    👥 Followers Only
                  </div>
                  <div 
                    className="font-['Inter'] text-[11px]"
                    style={{ color: colors.textMuted }}
                  >
                    Only your followers can see this ride
                  </div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="radio"
                  name="visibility"
                  checked={visibility === 'private'}
                  onChange={() => setVisibility('private')}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div>
                  <div 
                    className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                    style={{ color: colors.text }}
                  >
                    🔒 Private
                  </div>
                  <div 
                    className="font-['Inter'] text-[11px]"
                    style={{ color: colors.textMuted }}
                  >
                    Only you can see this ride
                  </div>
                </div>
              </label>
            </div>

            {/* Additional Options */}
            <div className="space-y-2.5">
              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={commentsEnabled}
                  onChange={(e) => setCommentsEnabled(e.target.checked)}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div 
                  className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                  style={{ color: colors.text }}
                >
                  💬 Enable comments
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer group">
                <input
                  type="checkbox"
                  checked={hideFromLeaderboards}
                  onChange={(e) => setHideFromLeaderboards(e.target.checked)}
                  className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                />
                <div 
                  className="font-['Inter'] text-[13px] font-bold group-hover:underline"
                  style={{ color: colors.text }}
                >
                  🏆 Hide from leaderboards
                </div>
              </label>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <BeetleButton
              onClick={handleSave}
              className="flex-1"
            >
              Save & View Feed
            </BeetleButton>
            <BeetleButton
              variant="secondary"
              onClick={() => {
                navigate('/');
                onClose();
              }}
            >
              Skip
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}