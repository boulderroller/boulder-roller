import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { Search, TrendingUp, User, MapPin } from 'lucide-react';
import { useEscapeKey } from '../../hooks/useEscapeKey';
import { useScrollLock } from '../../hooks/useScrollLock';

interface SearchModalProps {
  onClose: () => void;
}

type SearchCategory = 'all' | 'activities' | 'segments' | 'riders';

interface SearchResult {
  id: string;
  type: 'activity' | 'segment' | 'rider';
  title: string;
  subtitle: string;
  dung?: number;
  distance?: string;
  avatar?: string;
}

const mockResults: SearchResult[] = [
  { id: '1', type: 'activity', title: 'Morning Climb', subtitle: 'Dec 5, 2024 • 7:30 AM', dung: 62, distance: '45.2 km' },
  { id: '2', type: 'activity', title: 'Afternoon Recovery', subtitle: 'Dec 4, 2024 • 2:15 PM', dung: 18, distance: '25.5 km' },
  { id: '3', type: 'segment', title: 'Mt. Diablo Summit', subtitle: '11.2 km climb • 823m elevation', dung: 45 },
  { id: '4', type: 'rider', title: 'Sarah Martinez', subtitle: '@sarahm • 2,340 dung', avatar: '👩' },
  { id: '5', type: 'activity', title: 'Evening Tempo', subtitle: 'Dec 3, 2024 • 6:00 PM', dung: 38, distance: '32.1 km' },
  { id: '6', type: 'segment', title: 'Hawk Hill', subtitle: '2.1 km climb • 284m elevation', dung: 28 },
  { id: '7', type: 'rider', title: 'Mike Chen', subtitle: '@mikechen • 1,890 dung', avatar: '👨' },
];

export default function SearchModal({ onClose }: SearchModalProps) {
  const { colors, isDarkMode } = useTheme();
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('all');
  
  useEscapeKey(onClose);
  useScrollLock(true);
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const hoverBg = isDarkMode ? 'rgba(139, 168, 122, 0.08)' : 'rgba(139, 168, 122, 0.04)';

  // Filter results
  const filteredResults = mockResults.filter(result => {
    const matchesQuery = query === '' || 
      result.title.toLowerCase().includes(query.toLowerCase()) ||
      result.subtitle.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = category === 'all' || result.type === category.replace('ies', 'y').replace('s', '');
    return matchesQuery && matchesCategory;
  });

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleResultClick = (result: SearchResult) => {
    if (result.type === 'activity') {
      navigate(`/activities/${result.id}`);
      onClose();
    } else if (result.type === 'segment') {
      navigate(`/my-segments`); // Navigate to segments page, then could filter/highlight
      onClose();
    } else if (result.type === 'rider') {
      navigate(`/rider/${result.id}`);
      onClose();
    }
  };

  const getResultIcon = (type: string) => {
    if (type === 'activity') return '🚴';
    if (type === 'segment') return '🏔️';
    if (type === 'rider') return '';
  };

  return (
    <>
      {/* Backdrop - positioned below nav */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[840px] h-[600px] flex flex-col">
        <div
          className="rounded border overflow-hidden flex flex-col h-full"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `2px 2px 0px 0px ${colors.border}`,
          }}
        >
          {/* Search Input Area */}
          <div className="p-5 pb-4 flex-shrink-0">
            <div className="relative">
              <Search 
                className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4"
                style={{ color: colors.textMuted }}
              />
              <input
                type="text"
                placeholder="Search activities, segments, riders..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                autoFocus
                className="w-full rounded border pl-10 pr-4 py-2.5 font-['Inter'] text-[14px] transition-all outline-none"
                style={{
                  backgroundColor: isDarkMode ? 'rgba(42, 45, 30, 0.3)' : 'rgba(255, 255, 255, 0.5)',
                  borderColor: borderColor,
                  color: colors.text,
                }}
                onFocus={(e) => {
                  e.currentTarget.style.borderColor = colors.accent;
                }}
                onBlur={(e) => {
                  e.currentTarget.style.borderColor = borderColor;
                }}
              />
            </div>
          </div>

          {/* Category Pills */}
          <div className="px-5 pb-4 flex-shrink-0">
            <div className="flex gap-2">
              {(['all', 'activities', 'segments', 'riders'] as SearchCategory[]).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className="px-3 py-1.5 rounded border font-['Inter'] text-[11px] font-bold uppercase tracking-wide transition-all"
                  style={{
                    backgroundColor: category === cat ? colors.accent : 'transparent',
                    borderColor: category === cat ? colors.accent : borderColor,
                    color: category === cat ? '#2a2d1e' : colors.text,
                  }}
                >
                  {cat === 'all' ? 'All' : cat.charAt(0).toUpperCase() + cat.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="h-[1px] flex-shrink-0" style={{ backgroundColor: borderColor }} />

          {/* Results List - Fixed height with scroll */}
          <div className="flex-1 overflow-y-auto">
            {filteredResults.length === 0 ? (
              <div className="py-12 text-center">
                <p 
                  className="font-['Inter'] text-[13px]"
                  style={{ color: colors.textMuted }}
                >
                  No results found
                </p>
              </div>
            ) : (
              <div>
                {filteredResults.map((result) => (
                  <button
                    key={result.id}
                    onClick={() => handleResultClick(result)}
                    className="w-full px-5 py-3 flex items-center gap-3 transition-colors text-left"
                    style={{
                      backgroundColor: 'transparent',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = hoverBg;
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    {/* Icon */}
                    <div className="text-[24px] w-8 text-center">
                      {result.type === 'rider' ? result.avatar : getResultIcon(result.type)}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div 
                        className="font-['Inter'] text-[14px] font-bold truncate"
                        style={{ color: colors.text }}
                      >
                        {result.title}
                      </div>
                      <div 
                        className="font-['Inter'] text-[11px] truncate"
                        style={{ color: colors.textMuted }}
                      >
                        {result.subtitle}
                      </div>
                    </div>

                    {/* Right Side - Data emphasis */}
                    <div className="flex items-center gap-4">
                      {result.distance && (
                        <div 
                          className="font-['Cousine'] text-[14px] font-bold"
                          style={{ color: colors.text }}
                        >
                          {result.distance}
                        </div>
                      )}
                      {result.dung !== undefined && (
                        <div className="text-right">
                          <div 
                            className="font-['Cousine'] text-[16px] font-bold"
                            style={{ color: '#d4a574' }}
                          >
                            {result.dung}
                          </div>
                          <div 
                            className="font-['Inter'] text-[9px] uppercase tracking-wide"
                            style={{ color: colors.textMuted }}
                          >
                            dung
                          </div>
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Footer hint */}
          <div 
            className="px-5 py-3 border-t flex items-center justify-between flex-shrink-0"
            style={{ borderColor: borderColor }}
          >
            <div 
              className="font-['Inter'] text-[11px]"
              style={{ color: colors.textMuted }}
            >
              Press <kbd className="px-1.5 py-0.5 rounded border font-['Cousine'] text-[10px]" style={{ borderColor: borderColor }}>ESC</kbd> to close
            </div>
            <div 
              className="font-['Inter'] text-[11px]"
              style={{ color: colors.textMuted }}
            >
              {filteredResults.length} result{filteredResults.length !== 1 ? 's' : ''}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}