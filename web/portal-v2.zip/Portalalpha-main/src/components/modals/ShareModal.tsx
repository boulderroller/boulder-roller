import { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { Copy, Check, Download } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useEscapeKey } from '../../hooks/useEscapeKey';
import { useScrollLock } from '../../hooks/useScrollLock';

interface Activity {
  id: string;
  title: string;
  date: string;
  distance: number;
  duration: string;
  elevation: number;
  dungEarned: number;
}

interface ShareModalProps {
  activity: Activity;
  onClose: () => void;
}

export default function ShareModal({ activity, onClose }: ShareModalProps) {
  const { colors, isDarkMode } = useTheme();
  const [copiedLink, setCopiedLink] = useState(false);
  
  useEscapeKey(onClose);
  useScrollLock(true);
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  
  const shareUrl = `https://boulderroller.xyz/ride/${activity.id}`;

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    toast.success('Link copied! 🔗');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleShareTwitter = () => {
    const text = `Just crushed ${activity.distance}km and earned ${activity.dungEarned} dung on BoulderRoller! 🪲`;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
  };

  const handleDownloadImage = () => {
    toast.success('Image downloaded! 📸');
    // TODO: Generate and download image
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[520px]">
        <div
          className="rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 
              className="font-['Inter'] font-black text-[20px]"
              style={{ color: colors.text }}
            >
              📤 Share Activity
            </h2>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Activity Preview Card - Terminal Aesthetic */}
          <div
            className="rounded-[6px] border-[1px] p-5 mb-6"
            style={{
              backgroundColor: cardBg,
              borderColor: borderColor,
            }}
          >
            {/* Title & Date */}
            <div className="mb-4">
              <div 
                className="font-['Inter'] text-[18px] font-bold mb-1"
                style={{ color: colors.text }}
              >
                🚴 {activity.title}
              </div>
              <div 
                className="font-['Inter'] text-[12px]"
                style={{ color: colors.textMuted }}
              >
                {activity.date}
              </div>
            </div>

            {/* Stats - DATA EMPHASIS */}
            <div className="mb-3">
              <div 
                className="font-['Cousine'] text-[18px] font-bold"
                style={{ color: colors.text }}
              >
                {activity.distance} km • {activity.duration} • {activity.elevation}m
              </div>
            </div>

            {/* Dung Earned - AMBER EMPHASIS */}
            <div 
              className="font-['Cousine'] text-[18px] font-bold"
              style={{ color: '#d4a574' }}
            >
              Earned {activity.dungEarned} dung 🪲
            </div>
          </div>

          {/* Share Options */}
          <div className="space-y-3 mb-6">
            {/* Twitter/X */}
            <button
              onClick={handleShareTwitter}
              className="w-full rounded-[6px] border-[1px] px-4 py-3 flex items-center gap-3 transition-all"
              style={{
                backgroundColor: 'transparent',
                borderColor: borderColor,
                color: colors.text,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = isDarkMode 
                  ? 'rgba(139, 168, 122, 0.08)' 
                  : 'rgba(139, 168, 122, 0.04)';
                e.currentTarget.style.borderColor = colors.accent;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.borderColor = borderColor;
              }}
            >
              <span className="text-[20px]">𝕏</span>
              <span className="font-['Inter'] text-[13px] font-bold flex-1 text-left">
                Share to Twitter/X
              </span>
            </button>

            {/* Download Image */}
            <button
              onClick={handleDownloadImage}
              className="w-full rounded-[6px] border-[1px] px-4 py-3 flex items-center gap-3 transition-all"
              style={{
                backgroundColor: 'transparent',
                borderColor: borderColor,
                color: colors.text,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = isDarkMode 
                  ? 'rgba(139, 168, 122, 0.08)' 
                  : 'rgba(139, 168, 122, 0.04)';
                e.currentTarget.style.borderColor = colors.accent;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
                e.currentTarget.style.borderColor = borderColor;
              }}
            >
              <Download className="w-5 h-5" />
              <span className="font-['Inter'] text-[13px] font-bold flex-1 text-left">
                Download Image
              </span>
            </button>
          </div>

          {/* Divider */}
          <div className="h-[1px] mb-5" style={{ backgroundColor: borderColor }} />

          {/* Copy Link */}
          <div>
            <label 
              className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
              style={{ color: colors.textMuted }}
            >
              Or Copy Link
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className="flex-1 rounded-[6px] border-[2px] px-3 py-2 font-['Cousine'] text-[12px] outline-none select-all"
                style={{
                  backgroundColor: cardBg,
                  borderColor: colors.border,
                  color: colors.textMuted,
                }}
              />
              <button
                onClick={handleCopyLink}
                className="px-3 py-2 rounded-[6px] border-[2px] transition-all"
                style={{
                  backgroundColor: colors.bg,
                  borderColor: colors.border,
                  color: colors.text,
                  boxShadow: `2px 2px 0px 0px ${colors.border}`,
                }}
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Close Button */}
          <div className="mt-6">
            <BeetleButton
              onClick={onClose}
              variant="secondary"
              className="w-full"
            >
              Close
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}