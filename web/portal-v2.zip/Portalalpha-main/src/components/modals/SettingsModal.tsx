import { useState } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { BeetleInput } from '../ui/beetle-input';
import { Download, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { useEscapeKey } from '../../hooks/useEscapeKey';
import { useScrollLock } from '../../hooks/useScrollLock';

type SettingsTab = 'profile' | 'units' | 'privacy' | 'data' | 'account';
type UnitSystem = 'metric' | 'imperial';
type ThemeMode = 'light' | 'dark' | 'auto';

interface SettingsModalProps {
  onClose: () => void;
}

export default function SettingsModal({ onClose }: SettingsModalProps) {
  const { colors, isDarkMode, toggleDarkMode } = useTheme();
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  
  useEscapeKey(onClose);
  useScrollLock(true);
  
  // Settings state
  const [displayName, setDisplayName] = useState('climber_420');
  const [ftp, setFtp] = useState('285');
  const [weight, setWeight] = useState('72');
  const [units, setUnits] = useState<UnitSystem>('metric');
  const [themeMode, setThemeMode] = useState<ThemeMode>('dark');
  const [profileVisibility, setProfileVisibility] = useState<'public' | 'private'>('public');
  const [activitiesVisibility, setActivitiesVisibility] = useState<'public' | 'followers' | 'private'>('public');
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  // Mock stats
  const totalActivities = 287;
  const totalDistance = 8456;
  const totalDung = 38456;

  const handleSave = () => {
    toast.success('Settings saved! ⚙️');
    onClose();
  };

  const handleExportData = () => {
    toast.success('Data exported! 📦');
  };

  const handleDeleteAccount = () => {
    toast.error('Account deletion requires confirmation');
  };

  const tabs: { id: SettingsTab; label: string; emoji: string }[] = [
    { id: 'profile', label: 'Profile', emoji: '👤' },
    { id: 'units', label: 'Units', emoji: '📏' },
    { id: 'privacy', label: 'Privacy', emoji: '🔒' },
    { id: 'data', label: 'Data', emoji: '📊' },
    { id: 'account', label: 'Account', emoji: '⚙️' },
  ];

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-[60]"
        style={{ top: '64px' }}
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-[65] w-[680px]">
        <div
          className="rounded-[8px] border-[2px] overflow-hidden"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-8 pb-6">
            <h2 
              className="font-['Inter'] font-black text-[20px]"
              style={{ color: colors.text }}
            >
              ⚙️ Settings
            </h2>
            <button
              onClick={onClose}
              className="text-[20px] cursor-pointer transition-colors"
              style={{ color: colors.textMuted }}
            >
              ✕
            </button>
          </div>

          {/* Tab Navigation */}
          <div 
            className="flex border-b-[1px] px-8"
            style={{ borderColor: borderColor }}
          >
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="px-4 py-3 font-['Inter'] text-[12px] font-bold uppercase tracking-wide transition-all relative"
                style={{
                  color: activeTab === tab.id ? colors.text : colors.textMuted,
                  borderBottom: activeTab === tab.id ? `2px solid ${colors.accent}` : '2px solid transparent',
                  marginBottom: '-1px',
                }}
              >
                <span className="mr-1.5">{tab.emoji}</span>
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="p-8 max-h-[400px] overflow-y-auto">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <div className="space-y-5">
                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
                    style={{ color: colors.textMuted }}
                  >
                    Display Name
                  </label>
                  <BeetleInput
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Your username"
                  />
                </div>

                <div className="h-[1px]" style={{ backgroundColor: borderColor }} />

                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
                    style={{ color: colors.textMuted }}
                  >
                    FTP (Functional Threshold Power)
                  </label>
                  <div className="flex gap-3 items-end">
                    <div className="flex-1">
                      <BeetleInput
                        value={ftp}
                        onChange={(e) => setFtp(e.target.value)}
                        placeholder="285"
                        type="number"
                      />
                    </div>
                    <div 
                      className="font-['Inter'] text-[13px] pb-3"
                      style={{ color: colors.textMuted }}
                    >
                      watts
                    </div>
                  </div>
                </div>

                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
                    style={{ color: colors.textMuted }}
                  >
                    Weight
                  </label>
                  <div className="flex gap-3 items-end">
                    <div className="flex-1">
                      <BeetleInput
                        value={weight}
                        onChange={(e) => setWeight(e.target.value)}
                        placeholder="72"
                        type="number"
                      />
                    </div>
                    <div 
                      className="font-['Inter'] text-[13px] pb-3"
                      style={{ color: colors.textMuted }}
                    >
                      {units === 'metric' ? 'kg' : 'lb'}
                    </div>
                  </div>
                </div>

                {/* Current Stats Panel */}
                <div
                  className="rounded-[6px] border-[1px] p-4 mt-6"
                  style={{
                    backgroundColor: cardBg,
                    borderColor: borderColor,
                  }}
                >
                  <div 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Current Stats
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>Current FTP</span>
                      <span className="font-['Cousine'] text-[16px] font-bold" style={{ color: colors.text }}>{ftp} W</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>Weight</span>
                      <span className="font-['Cousine'] text-[16px] font-bold" style={{ color: colors.text }}>{weight} {units === 'metric' ? 'kg' : 'lb'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>Power/Weight</span>
                      <span className="font-['Cousine'] text-[16px] font-bold" style={{ color: colors.text }}>{(Number(ftp) / Number(weight)).toFixed(1)} W/kg</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Units Tab */}
            {activeTab === 'units' && (
              <div className="space-y-5">
                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Unit System
                  </label>
                  <div className="space-y-2.5">
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={units === 'metric'}
                        onChange={() => setUnits('metric')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        Metric (km, kg, °C)
                      </div>
                    </label>
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={units === 'imperial'}
                        onChange={() => setUnits('imperial')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        Imperial (mi, lb, °F)
                      </div>
                    </label>
                  </div>
                </div>

                <div className="h-[1px]" style={{ backgroundColor: borderColor }} />

                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Theme
                  </label>
                  <div className="space-y-2.5">
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={themeMode === 'light'}
                        onChange={() => setThemeMode('light')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        ☀️ Light
                      </div>
                    </label>
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={themeMode === 'dark'}
                        onChange={() => setThemeMode('dark')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        🌙 Dark
                      </div>
                    </label>
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={themeMode === 'auto'}
                        onChange={() => setThemeMode('auto')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        🌗 Auto (System)
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Privacy Tab */}
            {activeTab === 'privacy' && (
              <div className="space-y-5">
                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Profile Visibility
                  </label>
                  <div className="space-y-2.5">
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={profileVisibility === 'public'}
                        onChange={() => setProfileVisibility('public')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        🌍 Public - Everyone can see your profile
                      </div>
                    </label>
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={profileVisibility === 'private'}
                        onChange={() => setProfileVisibility('private')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        🔒 Private - Only you can see your profile
                      </div>
                    </label>
                  </div>
                </div>

                <div className="h-[1px]" style={{ backgroundColor: borderColor }} />

                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Default Activity Visibility
                  </label>
                  <div className="space-y-2.5">
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={activitiesVisibility === 'public'}
                        onChange={() => setActivitiesVisibility('public')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        🌍 Public
                      </div>
                    </label>
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={activitiesVisibility === 'followers'}
                        onChange={() => setActivitiesVisibility('followers')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        👥 Followers Only
                      </div>
                    </label>
                    <label className="flex items-center gap-2.5 cursor-pointer group">
                      <input
                        type="radio"
                        checked={activitiesVisibility === 'private'}
                        onChange={() => setActivitiesVisibility('private')}
                        className="w-4 h-4 cursor-pointer accent-[#8ba87a]"
                      />
                      <div className="font-['Inter'] text-[13px] font-bold group-hover:underline" style={{ color: colors.text }}>
                        🔒 Private
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Data Tab */}
            {activeTab === 'data' && (
              <div className="space-y-5">
                <div
                  className="rounded-[6px] border-[1px] p-5"
                  style={{
                    backgroundColor: cardBg,
                    borderColor: borderColor,
                  }}
                >
                  <div 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold mb-4"
                    style={{ color: colors.textMuted }}
                  >
                    Your Stats
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-['Inter'] text-[13px]" style={{ color: colors.textMuted }}>Total Activities</span>
                      <span className="font-['Cousine'] text-[22px] font-bold" style={{ color: colors.text }}>{totalActivities}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-['Inter'] text-[13px]" style={{ color: colors.textMuted }}>Total Distance</span>
                      <span className="font-['Cousine'] text-[22px] font-bold" style={{ color: colors.text }}>{totalDistance.toLocaleString()} km</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-['Inter'] text-[13px]" style={{ color: colors.textMuted }}>Total Dung Earned</span>
                      <span className="font-['Cousine'] text-[22px] font-bold" style={{ color: '#d4a574' }}>{totalDung.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="h-[1px]" style={{ backgroundColor: borderColor }} />

                <BeetleButton
                  onClick={handleExportData}
                  variant="secondary"
                  className="w-full"
                >
                  <Download className="w-4 h-4" />
                  <span>Export All Data (.json)</span>
                </BeetleButton>

                <p 
                  className="font-['Inter'] text-[11px] text-center"
                  style={{ color: colors.textMuted }}
                >
                  Download all your activities, stats, and dung history
                </p>
              </div>
            )}

            {/* Account Tab */}
            {activeTab === 'account' && (
              <div className="space-y-5">
                <div>
                  <label 
                    className="font-['Inter'] text-[11px] uppercase tracking-wide font-bold block mb-2"
                    style={{ color: colors.textMuted }}
                  >
                    Wallet Address
                  </label>
                  <div
                    className="rounded-[6px] border-[1px] px-3 py-2.5 font-['Cousine'] text-[12px]"
                    style={{
                      backgroundColor: cardBg,
                      borderColor: borderColor,
                      color: colors.textMuted,
                    }}
                  >
                    7xK9wLmP3qR2nV8sT4uY6zX1mB5cD9fE
                  </div>
                  <p 
                    className="font-['Inter'] text-[11px] mt-2"
                    style={{ color: colors.textMuted }}
                  >
                    Connected wallet on Solana blockchain
                  </p>
                </div>

                <div className="h-[1px]" style={{ backgroundColor: borderColor }} />

                {/* Danger Zone */}
                <div
                  className="rounded-[6px] border-[2px] p-5"
                  style={{
                    backgroundColor: isDarkMode ? 'rgba(211, 47, 47, 0.08)' : 'rgba(211, 47, 47, 0.04)',
                    borderColor: '#d32f2f',
                  }}
                >
                  <div className="flex items-start gap-3 mb-4">
                    <AlertTriangle className="w-5 h-5 text-[#d32f2f] flex-shrink-0 mt-0.5" />
                    <div>
                      <div 
                        className="font-['Inter'] text-[14px] font-bold mb-1"
                        style={{ color: '#d32f2f' }}
                      >
                        Danger Zone
                      </div>
                      <p 
                        className="font-['Inter'] text-[12px]"
                        style={{ color: colors.textMuted }}
                      >
                        This action cannot be undone. All your activities, dung, and achievements will be permanently deleted.
                      </p>
                    </div>
                  </div>
                  <BeetleButton
                    onClick={handleDeleteAccount}
                    variant="danger"
                    className="w-full"
                  >
                    Delete Account
                  </BeetleButton>
                </div>
              </div>
            )}
          </div>

          {/* Footer Actions */}
          <div 
            className="p-8 pt-6 border-t-[1px] flex gap-3"
            style={{ borderColor: borderColor }}
          >
            <BeetleButton
              variant="secondary"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </BeetleButton>
            <BeetleButton
              onClick={handleSave}
              className="flex-1"
            >
              Save Changes
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}