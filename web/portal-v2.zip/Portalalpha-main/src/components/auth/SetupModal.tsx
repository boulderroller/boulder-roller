import { useState } from 'react';
import { BeetleInput } from '../ui/beetle-input';
import { BeetleButton } from '../ui/beetle-button';
import { toast } from 'sonner';

interface SetupModalProps {
  onComplete: () => void;
  walletAddress: string | null;
}

const RIDER_TYPES = [
  { 
    id: 'sprinter', 
    name: 'Sprinter', 
    emoji: '⚡', 
    desc: 'Explosive power in short bursts' 
  },
  { 
    id: 'tt', 
    name: 'Time Trialist', 
    emoji: '🏁', 
    desc: 'Sustained power over long distances' 
  },
  { 
    id: 'climber', 
    name: 'Climber', 
    emoji: '🏔️', 
    desc: 'Excels on steep gradients' 
  },
  { 
    id: 'allrounder', 
    name: 'All-Rounder', 
    emoji: '🎯', 
    desc: 'Balanced across all terrains' 
  },
  { 
    id: 'diesel', 
    name: 'Diesel', 
    emoji: '🚂', 
    desc: 'Endurance and consistency' 
  },
];

export default function SetupModal({ onComplete, walletAddress }: SetupModalProps) {
  const [username, setUsername] = useState('');
  const [ftp, setFtp] = useState('');
  const [weight, setWeight] = useState('');
  const [riderType, setRiderType] = useState<string>('');
  const [canSkip, setCanSkip] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // TODO: Save user profile to your backend
    const profile = {
      username,
      ftp: parseInt(ftp),
      weight: parseInt(weight),
      riderType,
      walletAddress,
    };
    
    console.log('Profile created:', profile);
    toast.success(`Welcome, ${username}! 🪲`);
    onComplete();
  };

  const handleSkip = () => {
    onComplete();
  };

  return (
    <div className="fixed inset-0 bg-[#f9faf5] flex items-center justify-center z-50">
      <div className="bg-white rounded border border-[#2a2d1e] shadow-[2px_2px_0px_0px_#2a2d1e] p-8 w-[460px] max-h-[90vh] overflow-y-auto">
        {/* Beetle Icon */}
        <div className="flex justify-center mb-3">
          <div className="text-[48px]">🪲</div>
        </div>

        {/* Title */}
        <h2 className="font-['Inter'] font-extrabold text-[22px] text-[#2a2d1e] text-center mb-1 tracking-tight">
          SETUP
        </h2>
        <p className="font-['Cousine'] text-[14px] text-[#6b7a5a] text-center mb-6">
          You're Beetle #{Math.floor(Math.random() * 10000)}
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Required Section */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="bg-[#a87373] text-white px-2 py-1 rounded-full font-['Inter'] font-bold text-[9px] uppercase tracking-wide">
                Required
              </div>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-['Inter'] font-bold text-[11px] text-[#6b7a5a] uppercase tracking-wide mb-2">
                  Username
                </label>
                <BeetleInput
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Choose your name"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-['Inter'] font-bold text-[11px] text-[#6b7a5a] uppercase tracking-wide mb-2">
                    FTP (watts)
                  </label>
                  <BeetleInput
                    type="number"
                    value={ftp}
                    onChange={(e) => setFtp(e.target.value)}
                    placeholder="250"
                    required
                  />
                </div>

                <div>
                  <label className="block font-['Inter'] font-bold text-[11px] text-[#6b7a5a] uppercase tracking-wide mb-2">
                    Weight (kg)
                  </label>
                  <BeetleInput
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    placeholder="70"
                    required
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Optional Section */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="bg-[#d0d8bf] text-[#2a2d1e] px-2 py-1 rounded-full font-['Inter'] font-bold text-[9px] uppercase tracking-wide">
                Optional
              </div>
              <span className="font-['Inter'] text-[12px] text-[#6b7a5a]">— Rider Type</span>
            </div>

            <div className="space-y-2">
              {RIDER_TYPES.map((type) => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setRiderType(type.id)}
                  className={`w-full p-3 rounded border transition-all text-left flex items-center gap-3 ${
                    riderType === type.id
                      ? 'bg-[#d4c993] border-[#2a2d1e] shadow-[2px_2px_0px_0px_#2a2d1e]'
                      : 'bg-white border-[#d0d8bf] hover:border-[#2a2d1e]'
                  }`}
                >
                  <div className="text-[22px]">{type.emoji}</div>
                  <div className="flex-1">
                    <div className="font-['Inter'] font-bold text-[13px] text-[#2a2d1e]">
                      {type.name}
                    </div>
                    <div className="font-['Inter'] text-[11px] text-[#6b7a5a]">
                      {type.desc}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Submit Button */}
          <BeetleButton
            type="submit"
            variant="primary"
            className="w-full"
            style={{
              backgroundColor: '#8b9475',
              borderColor: '#2a2d1e',
            }}
          >
            Let&rsquo;s Ride &gt;
          </BeetleButton>

          {/* Skip Option */}
          <button
            type="button"
            onClick={handleSkip}
            className="w-full text-center font-['Inter'] text-[12px] text-[#6b7a5a] hover:text-[#2a2d1e] transition-colors"
          >
            Skip for now — I'll explore first
          </button>
        </form>
      </div>
    </div>
  );
}