import { useState, useMemo, useEffect } from 'react';

interface WalletConnectProps {
  onConnect: (address: string) => void;
  onBack: () => void;
}

interface WalletProvider {
  name: string;
  icon: string;
  windowKey: string;
}

const WALLET_PROVIDERS: WalletProvider[] = [
  { name: 'Phantom', icon: '👻', windowKey: 'phantom' },
  { name: 'Solflare', icon: '🔥', windowKey: 'solflare' },
  { name: 'Backpack', icon: '🎒', windowKey: 'backpack' },
  { name: 'Glow', icon: '✨', windowKey: 'glow' },
];

type Step = 'select' | 'wallets' | 'signing';

export default function WalletConnect({ onConnect, onBack }: WalletConnectProps) {
  const [step, setStep] = useState<Step>('select');
  const [selectedWallet, setSelectedWallet] = useState<WalletProvider | null>(null);
  const [countdown, setCountdown] = useState(3); // Reduced from 10 to 3 for faster demo

  // Detect installed wallets (stubbed for design)
  const installedWallets = useMemo(() => {
    // Mock detection - return first 2 wallets as "installed" for design purposes
    return WALLET_PROVIDERS.slice(0, 2);
  }, []);

  // Countdown timer for signing step
  useEffect(() => {
    if (step === 'signing') {
      if (countdown > 0) {
        const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
        return () => clearTimeout(timer);
      } else {
        // Auto-complete after countdown finishes
        handleCompleteSignature();
      }
    }
  }, [step, countdown]);

  const handleSelectWallet = (wallet: WalletProvider) => {
    setSelectedWallet(wallet);
    setStep('signing');
    setCountdown(3); // Reset countdown to 3 seconds
  };

  const handleRetry = () => {
    setCountdown(3); // Reset countdown to 3 seconds
  };

  const handleSwitchWallet = () => {
    setStep('wallets');
    setSelectedWallet(null);
  };

  const handleCompleteSignature = () => {
    // Stubbed completion - simulate successful signature
    const mockAddress = '7xK9...mP3q';
    onConnect(mockAddress);
  };

  const handleClose = () => {
    setStep('select');
    setSelectedWallet(null);
    onBack();
  };

  // STEP 1: Select Wallet Button
  if (step === 'select') {
    return (
      <>
        {/* Overlay */}
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
        
        {/* Modal */}
        <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50">
          <div className="bg-[#f9faf5] rounded border border-[#2a2d1e] shadow-[2px_2px_0px_0px_#2a2d1e] p-5 w-[420px]">
            {/* Header */}
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-[#8b6f47] rounded flex items-center justify-center text-[18px]">
                  🪲
                </div>
                <div>
                  <div className="font-['Inter'] text-[13px] text-[#2a2d1e]">
                    Sign-in with wallet
                  </div>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="w-7 h-7 bg-[#e8e4d8] border border-[#2a2d1e] rounded flex items-center justify-center hover:bg-[#d0c4a8] transition-colors"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#2a2d1e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Choose Wallet Section */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2.5">
                <span className="font-['Inter'] text-[12px] text-[#6b7a5a]">
                  Choose wallet
                </span>
                <span className="font-['Inter'] text-[11px] text-[#6b7a5a]">
                  Not connected
                </span>
              </div>

              <button
                onClick={() => setStep('wallets')}
                className="w-full bg-[#2a2d1e] hover:bg-[#3a3d2e] border border-[#2a2d1e] rounded shadow-[2px_2px_0px_0px_#1a1d14] hover:shadow-[3px_3px_0px_0px_#1a1d14] py-2.5 font-['Inter'] font-bold text-[13px] text-white transition-all"
              >
                Select Wallet
              </button>
            </div>

            {/* Hint Box */}
            <div className="mb-4 p-3 bg-[#e8e4d8] border border-[#d0c4a8] rounded">
              <p className="font-['Inter'] text-[11px] text-[#6b7a5a] leading-[1.5]">
                Select a Solana wallet to verify ownership. No transactions or fees required.
              </p>
            </div>

            {/* Connect Button - Disabled State */}
            <button
              disabled
              className="w-full bg-[#c89b5c] border border-[#2a2d1e] rounded py-2.5 font-['Inter'] font-bold text-[13px] text-white opacity-40 cursor-not-allowed mb-4"
            >
              Connect and sign
            </button>

            {/* Footer */}
            <div className="flex items-center justify-center text-[11px] text-[#6b7a5a] gap-1.5">
              <span>🪲</span>
              <span className="font-['Inter']">Chitin-grade cryptographic verification</span>
            </div>
          </div>
        </div>
      </>
    );
  }

  // STEP 2: Wallet List
  if (step === 'wallets') {
    return (
      <>
        {/* Overlay */}
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
        
        {/* Background Modal (blurred) */}
        <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-45 opacity-30 blur-sm pointer-events-none">
          <div className="bg-[#f9faf5] rounded-[12px] border-[3px] border-[#2a2d1e] shadow-[6px_6px_0px_0px_#2a2d1e] p-5 w-[420px] h-[340px]" />
        </div>

        {/* Wallet Selection Sub-Modal */}
        <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50">
          <div className="bg-[#2a2d1e] rounded-[12px] border-[3px] border-[#1a1d14] shadow-[6px_6px_0px_0px_#000000] p-5 w-[360px]">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-['Inter'] text-[13px] text-[#e8e4d8]">
                Connect wallet on Solana
              </h3>
              <button
                onClick={() => setStep('select')}
                className="w-7 h-7 bg-[#3a3d2e] hover:bg-[#4a4d3e] rounded-[6px] flex items-center justify-center transition-colors"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#e8e4d8" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Installed Wallets */}
            <div className="space-y-2 mb-3">
              {installedWallets.map((wallet) => (
                <button
                  key={wallet.name}
                  onClick={() => handleSelectWallet(wallet)}
                  className="w-full bg-[#3a3d2e] hover:bg-[#4a4d3e] border-[2px] border-[#4a4d3e] rounded-[8px] p-2.5 flex items-center justify-between transition-all group"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-[#8b6f47] rounded-[6px] flex items-center justify-center text-[16px]">
                      {wallet.icon}
                    </div>
                    <span className="font-['Inter'] font-bold text-[13px] text-[#e8e4d8]">
                      {wallet.name}
                    </span>
                  </div>
                  <span className="font-['Inter'] text-[10px] text-[#8a9a7a] group-hover:text-[#c89b5c] transition-colors">
                    Detected
                  </span>
                </button>
              ))}
            </div>

            {/* More Options */}
            <button className="w-full bg-transparent hover:bg-[#3a3d2e] border-[2px] border-[#4a4d3e] rounded-[8px] py-2 font-['Inter'] text-[12px] text-[#8a9a7a] transition-all flex items-center justify-center gap-2">
              More options
              <svg width="10" height="10" viewBox="0 0 16 16" fill="none">
                <path d="M4 6L8 10L12 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        </div>
      </>
    );
  }

  // STEP 3: Waiting for Signature
  if (step === 'signing') {
    return (
      <>
        {/* Overlay */}
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />
        
        {/* Modal */}
        <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50">
          <div className="bg-[#f9faf5] rounded-[12px] border-[3px] border-[#2a2d1e] shadow-[6px_6px_0px_0px_#2a2d1e] p-5 w-[440px]">
            {/* Header */}
            <div className="flex items-center justify-between mb-5 pb-4 border-b-[2px] border-[#d0c4a8]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-[#8b6f47] rounded-[6px] flex items-center justify-center text-[18px]">
                  🪲
                </div>
                <div>
                  <div className="font-['Inter'] text-[13px] text-[#2a2d1e]">
                    Sign-in with wallet
                  </div>
                </div>
              </div>
              <button
                onClick={handleClose}
                className="w-7 h-7 bg-[#e8e4d8] border-[2px] border-[#2a2d1e] rounded-[6px] flex items-center justify-center hover:bg-[#d0c4a8] transition-colors"
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#2a2d1e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            {/* Waiting Content */}
            <div className="mb-5">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-11 h-11 border-[2px] border-[#2a2d1e] rounded-[8px] flex items-center justify-center bg-[#e8e4d8]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2a2d1e" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="animate-spin">
                    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="font-['Inter'] font-bold text-[13px] text-[#2a2d1e] mb-1.5">
                    Waiting for signature
                  </div>
                  <p className="font-['Inter'] text-[11px] text-[#6b7a5a] leading-[1.5] mb-2">
                    Check your wallet window. This cancels after the timer so you&apos;re never stuck.
                  </p>
                  <div className="flex items-center gap-2 text-[#6b7a5a]">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </svg>
                    <span className="font-['Cousine'] text-[11px]">
                      {countdown}s remaining
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-2.5 mb-4">
              <button
                onClick={handleRetry}
                className="flex-1 bg-[#e8e4d8] hover:bg-[#d0c4a8] border-[2px] border-[#2a2d1e] rounded-[8px] shadow-[3px_3px_0px_0px_#2a2d1e] hover:shadow-[4px_4px_0px_0px_#2a2d1e] py-2 font-['Inter'] font-bold text-[12px] text-[#2a2d1e] transition-all"
              >
                Retry
              </button>
              <button
                onClick={handleSwitchWallet}
                className="flex-1 bg-[#2a2d1e] hover:bg-[#3a3d2e] border-[2px] border-[#2a2d1e] rounded-[8px] shadow-[3px_3px_0px_0px_#1a1d14] hover:shadow-[4px_4px_0px_0px_#1a1d14] py-2 font-['Inter'] font-bold text-[12px] text-white transition-all"
              >
                Switch wallet
              </button>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-center text-[11px] text-[#6b7a5a] gap-1.5">
              <span>🪲</span>
              <span className="font-['Inter']">Chitin-grade cryptographic verification</span>
            </div>
          </div>
        </div>
      </>
    );
  }

  return null;
}