import { useState } from 'react';
import WalletConnect from './WalletConnect';
import { BeetleInput } from '../ui/beetle-input';
import { BeetleButton } from '../ui/beetle-button';

interface InviteModalProps {
  onClose: () => void;
  onSuccess: (address: string) => void;
}

export default function InviteModal({ onClose, onSuccess }: InviteModalProps) {
  const [inviteCode, setInviteCode] = useState('');
  const [showWalletConnect, setShowWalletConnect] = useState(false);
  const [error, setError] = useState('');

  const handleInviteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // TODO: Verify invite code with your backend
    if (!inviteCode.trim()) {
      setError('Please enter an invite code');
      return;
    }
    
    // Show wallet connect after valid invite
    setShowWalletConnect(true);
  };

  const handleWalletConnected = (address: string) => {
    onSuccess(address);
  };

  if (showWalletConnect) {
    return (
      <WalletConnect 
        onConnect={handleWalletConnected}
        onBack={() => setShowWalletConnect(false)}
      />
    );
  }

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50">
        <div className="bg-[#f9faf5] rounded border border-[#2a2d1e] shadow-[2px_2px_0px_0px_#2a2d1e] p-8 w-[400px]">
          {/* Beetle Icon */}
          <div className="flex justify-center mb-4">
            <div className="text-[48px]">🪲</div>
          </div>

          {/* Title */}
          <h2 className="font-['Inter'] font-extrabold text-[24px] text-[#2a2d1e] text-center mb-2 tracking-tight">
            GOT AN INVITE?
          </h2>

          {/* Form */}
          <form onSubmit={handleInviteSubmit} className="mt-6 space-y-4">
            <div>
              <label className="block font-['Inter'] font-bold text-[11px] text-[#6b7a5a] uppercase tracking-wide mb-2">
                Invite Code
              </label>
              <BeetleInput
                type="text"
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value)}
                placeholder="Enter your code"
                error={!!error}
              />
              {error && (
                <p className="mt-2 text-[#a87373] text-[12px] font-['Inter']">{error}</p>
              )}
            </div>

            <BeetleButton
              type="submit"
              variant="primary"
              className="w-full"
              style={{
                backgroundColor: '#8b9475',
                borderColor: '#2a2d1e',
              }}
            >
              Enter
            </BeetleButton>
          </form>
        </div>
      </div>
    </>
  );
}