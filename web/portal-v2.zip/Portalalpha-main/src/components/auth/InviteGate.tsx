import { useState } from 'react';
import InviteModal from './InviteModal';

interface InviteGateProps {
  onInviteSuccess: (address: string) => void;
}

export default function InviteGate({ onInviteSuccess }: InviteGateProps) {
  const [clickCount, setClickCount] = useState(0);
  const [showModal, setShowModal] = useState(false);

  const handleBeetleClick = () => {
    const newCount = clickCount + 1;
    setClickCount(newCount);
    
    if (newCount === 3) {
      setShowModal(true);
      setClickCount(0);
    }
  };

  return (
    <div className="relative size-full bg-[#f9faf5] flex items-center justify-center">
      {/* Beetle - click 3x to reveal invite modal */}
      <button
        onClick={handleBeetleClick}
        className="group relative"
      >
        <div className="text-[96px] transition-transform group-hover:scale-110 group-active:scale-95">
          🪲
        </div>
        
        {/* Subtle glow effect */}
        <div className="absolute inset-0 rounded-full bg-[#8ba87a] opacity-0 group-hover:opacity-20 blur-3xl transition-opacity" />
      </button>

      {/* Footer */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <p className="font-['Inter'] text-[#6b7a5a] text-[13px] tracking-wide">
          info@boulderroller.com
        </p>
      </div>

      {/* Invite Modal */}
      {showModal && (
        <InviteModal 
          onClose={() => setShowModal(false)}
          onSuccess={onInviteSuccess}
        />
      )}
    </div>
  );
}