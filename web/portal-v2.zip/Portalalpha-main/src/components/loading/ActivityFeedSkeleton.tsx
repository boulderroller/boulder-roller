/**
 * ActivityFeedSkeleton - Instant shell that matches ActivityFeed layout
 * No spinners, no beetles - just structure to prevent layout shift
 */

export default function ActivityFeedSkeleton() {
  return (
    <div className="px-4 sm:px-6 py-6 sm:py-8">
      <div className="max-w-[1400px] mx-auto">
        {/* Three Column Layout - matches ActivityFeed structure */}
        <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr_280px] gap-6 sm:gap-8">
          
          {/* Left Sidebar Skeleton */}
          <div className="sticky top-[80px] self-start space-y-4">
            {/* Profile Card Skeleton */}
            <div 
              className="rounded border h-[200px]"
              style={{ 
                backgroundColor: 'var(--color-bg)',
                borderColor: 'var(--color-border)',
              }}
            />
            
            {/* Dung Bank Skeleton */}
            <div 
              className="rounded border h-[120px]"
              style={{ 
                backgroundColor: 'var(--color-bg)',
                borderColor: 'var(--color-border)',
              }}
            />
          </div>

          {/* Middle Column - Activity Feed Skeleton */}
          <div className="space-y-4">
            {/* Filter Skeleton */}
            <div 
              className="rounded border h-[48px]"
              style={{ 
                backgroundColor: 'var(--color-bg)',
                borderColor: 'var(--color-border)',
              }}
            />
            
            {/* Activity Cards Skeleton */}
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className="rounded border h-[140px]"
                style={{ 
                  backgroundColor: 'var(--color-bg)',
                  borderColor: 'var(--color-border)',
                }}
              />
            ))}
          </div>

          {/* Right Sidebar Skeleton */}
          <div className="sticky top-[80px] self-start space-y-4">
            {/* Streak Tracker Skeleton */}
            <div 
              className="rounded border h-[180px]"
              style={{ 
                backgroundColor: 'var(--color-bg)',
                borderColor: 'var(--color-border)',
              }}
            />
            
            {/* Trending Segments Skeleton */}
            <div 
              className="rounded border h-[300px]"
              style={{ 
                backgroundColor: 'var(--color-bg)',
                borderColor: 'var(--color-border)',
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
