import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getDivider } from '../../constants/colors';

const LapsTable = memo(() => {
  const { isDarkMode, colors } = useTheme();
  const dividerColor = getDivider(isDarkMode);

  const laps = [
    { id: 1, time: "14:02", dist: "5.0km", power: "230W", hr: "148bpm" },
    { id: 2, time: "13:55", dist: "5.0km", power: "245W", hr: "155bpm" },
    { id: 3, time: "14:10", dist: "5.0km", power: "220W", hr: "150bpm" },
    { id: 4, time: "14:05", dist: "5.0km", power: "235W", hr: "152bpm" },
  ];

  return (
    <div className="">
      <div className="grid grid-cols-5 gap-4 px-5 py-3 border-b text-[10px] font-bold uppercase tracking-wide opacity-60" style={{ borderColor: dividerColor, color: colors.text }}>
        <div>Lap</div>
        <div className="text-right">Time</div>
        <div className="text-right">Dist</div>
        <div className="text-right">Power</div>
        <div className="text-right">HR</div>
      </div>
      {laps.map((lap) => (
        <div key={lap.id} className="grid grid-cols-5 gap-4 px-5 py-3 border-b last:border-0 font-['Cousine'] text-[11px] hover:bg-muted/5 transition-colors" style={{ borderColor: dividerColor, color: colors.text }}>
          <div>{lap.id}</div>
          <div className="text-right">{lap.time}</div>
          <div className="text-right opacity-70">{lap.dist}</div>
          <div className="text-right font-bold">{lap.power}</div>
          <div className="text-right opacity-70">{lap.hr}</div>
        </div>
      ))}
    </div>
  );
});

LapsTable.displayName = 'LapsTable';

export default LapsTable;