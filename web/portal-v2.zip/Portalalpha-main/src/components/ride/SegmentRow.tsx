import { memo } from 'react';
import { getDivider, getAccentHighlight } from '../../constants/colors';

interface SegmentRowProps {
  segment: {
    id: string;
    name: string;
    time: string;
    rank: number;
    totalAttempts: number;
    prDiff: string;
  };
  isDarkMode: boolean;
  colors: {
    text: string;
    textMuted: string;
    accent: string;
  };
  onNavigate: (id: string) => void;
}

const SegmentRow = memo(({ segment, isDarkMode, colors, onNavigate }: SegmentRowProps) => {
  const borderColor = getDivider(isDarkMode);
  const hoverBg = getAccentHighlight(isDarkMode, 'subtle');

  // Generate a deterministic fake sparkline path based on ID
  const generateSparkline = (id: string) => {
    let hash = 0;
    for (let i = 0; i < id.length; i++) hash = id.charCodeAt(i) + ((hash << 5) - hash);
    
    let path = "M 0 25";
    let points = [];
    for (let i = 0; i <= 50; i += 5) {
        const h = Math.abs((hash + i * 123) % 25);
        points.push(`L ${i} ${25 - h}`);
    }
    return path + " " + points.join(" ");
  };

  return (
    <div 
      className="px-5 py-3 border-b transition-colors cursor-pointer group"
      style={{ 
        borderColor,
      }}
      onClick={() => onNavigate(segment.id)}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = hoverBg;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = 'transparent';
      }}
    >
      <div className="grid grid-cols-[2fr_60px_1fr_1fr_1fr] gap-4 items-center">
        <div>
          <div className="font-['Inter'] text-[13px] font-bold group-hover:underline truncate" style={{ color: colors.text }}>
            {segment.name}
          </div>
          <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
            {segment.totalAttempts.toLocaleString()} attempts
          </div>
        </div>
        
        {/* Sparkline */}
        <div className="h-[25px] w-[50px] opacity-50">
             <svg width="50" height="25" viewBox="0 0 50 25">
                 <path 
                    d={generateSparkline(segment.id)} 
                    fill="none" 
                    stroke={colors.accent} 
                    strokeWidth="1.5"
                    strokeLinecap="square"
                 />
             </svg>
        </div>

        <div className="font-['Cousine'] text-[14px] font-bold text-right" style={{ color: colors.text }}>
          {segment.time}
        </div>
        <div className="text-right">
          <div className="font-['Cousine'] text-[14px] font-bold" style={{ color: segment.rank <= 10 ? colors.accent : colors.text }}>
            #{segment.rank}
          </div>
        </div>
        <div className="font-['Cousine'] text-[13px] text-right" style={{ color: segment.prDiff.startsWith('-') ? '#8b9475' : colors.textMuted }}>
          {segment.prDiff}
        </div>
      </div>
    </div>
  );
});

SegmentRow.displayName = 'SegmentRow';

export default SegmentRow;