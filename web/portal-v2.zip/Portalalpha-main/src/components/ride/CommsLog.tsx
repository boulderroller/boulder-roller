import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getDivider } from '../../constants/colors';

const CommsLog = memo(() => {
  const { isDarkMode, colors } = useTheme();
  const dividerColor = getDivider(isDarkMode);

  const logs = [
    { time: "09:42:15", user: "SYSTEM", type: "INFO", message: "Ride upload completed. Checksum verified." },
    { time: "09:45:02", user: "OPERATOR_88", type: "USER", message: "Strong visual on the climb. Power output nominal." },
    { time: "10:12:33", user: "K.VANDEN", type: "USER", message: "Sector 4 surface conditions reported as gravel." },
    { time: "10:14:01", user: "SELF", type: "REPLY", message: "Copy that. Lowering tire pressure for next attempt." },
    { time: "10:15:00", user: "SYSTEM", type: "WARN", message: "Heart rate monitor signal intermittent at mile 24." },
  ];

  return (
    <div className="border border-l-4 rounded-none overflow-hidden font-['Cousine']" style={{ borderColor: dividerColor, borderLeftColor: colors.accent }}>
        <div className="bg-muted/10 px-4 py-2 border-b flex justify-between items-center" style={{ borderColor: dividerColor }}>
            <span className="text-[10px] uppercase font-bold tracking-widest opacity-70">/// COMMS_LOG_V2.0 ///</span>
            <div className="flex gap-2">
                <div className="w-2 h-2 bg-green-500 animate-pulse" />
                <span className="text-[10px] uppercase text-green-600">LIVE</span>
            </div>
        </div>
        <div className="p-0">
            {logs.map((log, index) => (
                <div 
                    key={index} 
                    className="px-4 py-2 border-b last:border-0 text-[11px] hover:bg-muted/5 transition-colors group flex flex-col sm:flex-row sm:gap-4 sm:items-baseline"
                    style={{ borderColor: 'rgba(0,0,0,0.05)' }}
                >
                    <div className="flex gap-3 shrink-0 opacity-60 w-[140px]">
                        <span className="text-[10px] font-mono">[{log.time}]</span>
                        <span className={`font-bold ${log.user === 'SYSTEM' ? 'text-yellow-600' : ''}`}>{log.user}:</span>
                    </div>
                    <div className={`break-words ${log.type === 'WARN' ? 'text-red-500' : ''} ${log.type === 'INFO' ? 'opacity-70 italic' : ''}`} style={{ color: log.type === 'USER' || log.type === 'REPLY' ? colors.text : undefined }}>
                        {log.message}
                    </div>
                </div>
            ))}
        </div>
        <div className="bg-muted/5 px-4 py-3 border-t flex gap-2" style={{ borderColor: dividerColor }}>
            <span className="text-green-500 font-bold">{'>'}</span>
            <input 
                type="text" 
                placeholder="TRANSMIT MESSAGE..." 
                className="bg-transparent border-none outline-none w-full text-[11px] font-['Cousine'] uppercase"
                style={{ color: colors.text }}
            />
        </div>
    </div>
  );
});

CommsLog.displayName = 'CommsLog';

export default CommsLog;