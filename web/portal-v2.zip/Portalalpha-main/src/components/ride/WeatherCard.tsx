import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getOverlay } from '../../constants/colors';

interface WeatherCardProps {
  embedded?: boolean;
}

const WeatherCard = memo(({ embedded = false }: WeatherCardProps) => {
  const { isDarkMode, colors } = useTheme();

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);

  const containerClasses = embedded 
    ? "p-4" 
    : "p-4 rounded-none border";
    
  const containerStyle = embedded 
    ? {} 
    : { backgroundColor: cardBg, borderColor };

  return (
    <div 
      className={containerClasses}
      style={containerStyle}
    >
      <h3 
        className="font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-3 flex items-center justify-between"
        style={{ color: colors.text }}
      >
        <span>Weather Telemetry</span>
        <span className="text-[10px] opacity-50">STN: KFO1</span>
      </h3>
      
      <div className="grid grid-cols-2 gap-4">
          {/* Main Temp */}
          <div className="flex items-center gap-3 col-span-2 pb-3 border-b border-dashed border-gray-500/20">
            <span className="text-[24px]">☀️</span>
            <div>
              <div 
                className="font-['Cousine'] text-[24px] font-bold leading-none"
                style={{ color: colors.text }}
              >
                18°C
              </div>
              <div 
                className="font-['Inter'] text-[10px] uppercase tracking-wide mt-1"
                style={{ color: colors.textMuted }}
              >
                Partly Cloudy
              </div>
            </div>
          </div>

          {/* Wind */}
          <div>
             <div className="font-['Inter'] text-[9px] uppercase tracking-wide opacity-70 mb-1" style={{ color: colors.textMuted }}>Wind</div>
             <div className="flex items-center gap-1">
                <span className="text-[14px]">↘️</span>
                <span className="font-['Cousine'] text-[14px] font-bold" style={{ color: colors.text }}>12kph</span>
             </div>
          </div>

          {/* Humidity */}
          <div>
             <div className="font-['Inter'] text-[9px] uppercase tracking-wide opacity-70 mb-1" style={{ color: colors.textMuted }}>Humidity</div>
             <div className="flex items-center gap-1">
                <span className="text-[14px]">💧</span>
                <span className="font-['Cousine'] text-[14px] font-bold" style={{ color: colors.text }}>42%</span>
             </div>
          </div>
      </div>
    </div>
  );
});

WeatherCard.displayName = 'WeatherCard';

export default WeatherCard;