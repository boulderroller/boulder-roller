import { useTheme } from '../../contexts/ThemeContext';
import { getOverlay } from '../../constants/colors';

interface MapPlaceholderProps {
  className?: string;
  style?: React.CSSProperties;
}

export default function MapPlaceholder({ className, style }: MapPlaceholderProps) {
  const { isDarkMode, colors } = useTheme();
  const borderColorStrong = getOverlay(isDarkMode, 'strong');

  return (
    <div className={className} style={style}>
      <div 
        className="h-[300px] rounded-none border relative overflow-hidden flex items-center justify-center bg-[#f0f0f0] dark:bg-[#1a1a1a]"
        style={{ borderColor: borderColorStrong }}
      >
        {/* Technical Grid Background */}
        <div 
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
                backgroundImage: `linear-gradient(to right, ${isDarkMode ? '#ffffff' : '#000000'} 1px, transparent 1px), linear-gradient(to bottom, ${isDarkMode ? '#ffffff' : '#000000'} 1px, transparent 1px)`,
                backgroundSize: '40px 40px'
            }}
        />
        
        {/* Crosshairs */}
        <div className="absolute top-4 left-4 w-4 h-4 border-l border-t border-black/50 dark:border-white/50" />
        <div className="absolute top-4 right-4 w-4 h-4 border-r border-t border-black/50 dark:border-white/50" />
        <div className="absolute bottom-4 left-4 w-4 h-4 border-l border-b border-black/50 dark:border-white/50" />
        <div className="absolute bottom-4 right-4 w-4 h-4 border-r border-b border-black/50 dark:border-white/50" />

        {/* Map Controls Overlay */}
        <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-20">
            <button className="w-8 h-8 flex items-center justify-center bg-background border border-border hover:bg-accent hover:text-accent-foreground text-xs font-bold transition-colors">
                +
            </button>
            <button className="w-8 h-8 flex items-center justify-center bg-background border border-border hover:bg-accent hover:text-accent-foreground text-xs font-bold transition-colors">
                -
            </button>
        </div>
        
        <div className="absolute left-4 bottom-4 flex gap-2 z-20">
            <div className="bg-background border border-border px-2 py-1 text-[10px] font-['Cousine'] uppercase opacity-70">
                LYR: SAT
            </div>
            <div className="bg-background border border-border px-2 py-1 text-[10px] font-['Cousine'] uppercase opacity-70">
                GRID: ON
            </div>
        </div>

        <div className="text-center relative z-10">
          <div className="text-[48px] mb-2 opacity-50">🗺️</div>
          <p 
            className="font-['Inter'] text-[12px] font-bold uppercase tracking-wide mb-1"
            style={{ color: colors.textMuted }}
          >
            Map Module Offline
          </p>
          <p className="font-['Cousine'] text-[10px] opacity-50" style={{ color: colors.textMuted }}>
            WAITING FOR GPS DATA
          </p>
        </div>
      </div>
    </div>
  );
}