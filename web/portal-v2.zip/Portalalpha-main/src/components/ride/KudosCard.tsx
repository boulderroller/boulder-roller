import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import { getOverlay } from '../../constants/colors';

interface KudosCardProps {
  embedded?: boolean;
}

const KudosCard = memo(({ embedded = false }: KudosCardProps) => {
  const { isDarkMode, colors } = useTheme();

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);

  const containerClasses = embedded 
    ? "p-4" 
    : "p-4 rounded-none border";
    
  const containerStyle = embedded 
    ? {} 
    : { backgroundColor: cardBg, borderColor };

  return (
    <div 
      className={containerClasses}
      style={containerStyle}
    >
      <BeetleButton variant="primary" className="w-full mb-3" size="sm">
        ❤️ Give Kudos
      </BeetleButton>
      <p 
        className="font-['Inter'] text-[10px] text-center"
        style={{ color: colors.textMuted }}
      >
        Be the first to give kudos!
      </p>
    </div>
  );
});

KudosCard.displayName = 'KudosCard';

export default KudosCard;