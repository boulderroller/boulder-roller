import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getOverlay, getDivider } from '../../constants/colors';

interface MachineManifestProps {
  embedded?: boolean;
}

const MachineManifest = memo(({ embedded = false }: MachineManifestProps) => {
  const { isDarkMode, colors } = useTheme();

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);
  const dividerColor = getDivider(isDarkMode);

  const containerClasses = embedded 
    ? "p-4" 
    : "p-4 rounded-none border";
    
  const containerStyle = embedded 
    ? {} 
    : { backgroundColor: cardBg, borderColor };

  const specs = [
    { label: "FRAME", value: "CANYON AEROAD CFR" },
    { label: "WHEELSET", value: "DT SWISS ARC 1100" },
    { label: "TIRES", value: "CONTI GP5000 S TR" },
    { label: "GROUPSET", value: "DURA-ACE DI2 12S" },
    { label: "WEIGHT", value: "7.24 KG (WET)" },
  ];

  return (
    <div 
      className={containerClasses}
      style={containerStyle}
    >
      <h3 
        className="font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-3 flex items-center gap-2"
        style={{ color: colors.text }}
      >
        <span>⚙️ Machine Spec</span>
      </h3>
      
      <div className="space-y-2">
        {specs.map((spec, i) => (
            <div key={spec.label} className="grid grid-cols-[80px_1fr] items-baseline gap-2">
                <div className="font-['Inter'] text-[9px] text-right opacity-60" style={{ color: colors.textMuted }}>
                    {spec.label}
                </div>
                <div className="font-['Cousine'] text-[11px] font-bold border-b border-dashed border-gray-500/20 pb-0.5 truncate" style={{ color: colors.text }}>
                    {spec.value}
                </div>
            </div>
        ))}
      </div>
      
      <div className="mt-3 pt-2 border-t border-dashed border-gray-500/30 flex justify-between items-center">
         <span className="font-['Inter'] text-[9px] opacity-50 uppercase">SERVICE INTERVAL</span>
         <span className="font-['Cousine'] text-[10px] bg-green-900/20 text-green-600 px-1">OK</span>
      </div>
    </div>
  );
});

MachineManifest.displayName = 'MachineManifest';

export default MachineManifest;