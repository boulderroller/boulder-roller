import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getOverlay } from '../../constants/colors';

interface DungBreakdownProps {
  dung: number;
  embedded?: boolean;
}

const DungBreakdown = memo(({ dung, embedded = false }: DungBreakdownProps) => {
  const { isDarkMode, colors } = useTheme();

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);

  const containerClasses = embedded 
    ? "p-4" 
    : "p-4 rounded-none border";
    
  const containerStyle = embedded 
    ? {} 
    : { backgroundColor: cardBg, borderColor };

  return (
    <div 
      className={containerClasses}
      style={containerStyle}
    >
      <div className="flex items-center justify-between mb-4">
        <h3 
          className="font-['Inter'] font-bold text-[11px] uppercase tracking-wide"
          style={{ color: colors.text }}
        >
          💩 Dung Earned
        </h3>
        <div 
          className="font-['Cousine'] text-[40px] font-bold leading-none"
          style={{ 
            color: '#c89b5c',
            textShadow: '0 0 24px rgba(200, 155, 92, 0.4)'
          }}
        >
          +{dung}
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span 
            className="font-['Inter'] text-[11px]"
            style={{ color: colors.textMuted }}
          >
            Distance
          </span>
          <span 
            className="font-['Cousine'] text-[12px] font-bold"
            style={{ color: colors.text }}
          >
            +{Math.floor(dung * 0.4)}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <span 
            className="font-['Inter'] text-[11px]"
            style={{ color: colors.textMuted }}
          >
            TSS
          </span>
          <span 
            className="font-['Cousine'] text-[12px] font-bold"
            style={{ color: colors.text }}
          >
            +{Math.floor(dung * 0.35)}
          </span>
        </div>

        <div className="flex justify-between items-center">
          <span 
            className="font-['Inter'] text-[11px]"
            style={{ color: colors.textMuted }}
          >
            Elevation
          </span>
          <span 
            className="font-['Cousine'] text-[12px] font-bold"
            style={{ color: colors.text }}
          >
            +{Math.floor(dung * 0.25)}
          </span>
        </div>
      </div>
    </div>
  );
});

DungBreakdown.displayName = 'DungBreakdown';

export default DungBreakdown;