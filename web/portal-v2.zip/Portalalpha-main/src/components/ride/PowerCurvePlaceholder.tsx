import { useTheme } from '../../contexts/ThemeContext';
import { getOverlay } from '../../constants/colors';

interface PowerCurvePlaceholderProps {
  className?: string;
  style?: React.CSSProperties;
}

export default function PowerCurvePlaceholder({ className, style }: PowerCurvePlaceholderProps) {
  const { isDarkMode, colors } = useTheme();
  const borderColorStrong = getOverlay(isDarkMode, 'strong');

  return (
    <div className={className} style={style}>
      <h3 
        className="font-['Inter'] font-bold text-[12px] uppercase tracking-wide mb-4"
        style={{ color: colors.text }}
      >
        Power Curve
      </h3>
      <div 
        className="h-[250px] rounded-none border relative overflow-hidden flex items-end justify-center bg-[#f0f0f0] dark:bg-[#1a1a1a] p-4"
        style={{ borderColor: borderColorStrong }}
      >
        {/* Technical Grid Background */}
        <div 
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
                backgroundImage: `linear-gradient(to right, ${isDarkMode ? '#ffffff' : '#000000'} 1px, transparent 1px), linear-gradient(to bottom, ${isDarkMode ? '#ffffff' : '#000000'} 1px, transparent 1px)`,
                backgroundSize: '20px 20px'
            }}
        />

        {/* Mock Chart Bars */}
        <div className="flex items-end gap-1 w-full h-full opacity-50">
           {[...Array(20)].map((_, i) => (
             <div 
                key={i} 
                className="flex-1 bg-current" 
                style={{ 
                    height: `${Math.random() * 80 + 10}%`,
                    color: colors.accent
                }} 
             />
           ))}
        </div>
        
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="bg-background/80 px-4 py-2 border backdrop-blur-sm">
                <p 
                    className="font-['Cousine'] text-[10px] font-bold uppercase tracking-wide"
                    style={{ color: colors.textMuted }}
                >
                    ANALYZING POWER DATA...
                </p>
            </div>
        </div>
      </div>
    </div>
  );
}
