import { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getOverlay, getDivider } from '../../constants/colors';

interface StatsPanelProps {
  activity: {
    distance: string;
    duration: string;
    elevation: string;
    tss: number;
    avgPower: string;
    normalizedPower: string;
    avgHeartRate: string;
    maxHeartRate: string;
    avgCadence: string;
    maxCadence: string;
    intensityFactor: number;
  };
}

const StatsPanel = memo(({ activity }: StatsPanelProps) => {
  const { isDarkMode, colors } = useTheme();

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);
  const dividerColor = getOverlay(isDarkMode);
  const subtleDivider = getDivider(isDarkMode);

  return (
    <div 
      className="rounded-none border overflow-hidden"
      style={{ 
        backgroundColor: cardBg,
        borderColor,
      }}
    >
      {/* Hero Stats - CELLULAR GRID */}
      <div className="grid grid-cols-2 md:grid-cols-4">
        {/* Distance */}
        <div 
          className="p-5 md:p-6 border-b md:border-b-0 border-r border-[#000000]/10 dark:border-[#ffffff]/10"
        >
          <div 
            className="font-['Cousine'] text-[32px] md:text-[42px] font-bold leading-none mb-2"
            style={{ color: colors.text }}
          >
            {activity.distance.split(' ')[0]}
            <span className="text-[14px] ml-1" style={{ color: colors.textMuted }}>
              {activity.distance.split(' ')[1]}
            </span>
          </div>
          <div 
            className="font-['Inter'] text-[10px] uppercase tracking-wide font-medium opacity-70"
            style={{ color: colors.textMuted }}
          >
            Distance
          </div>
        </div>

        {/* Time */}
        <div 
          className="p-5 md:p-6 border-b md:border-b-0 md:border-r border-[#000000]/10 dark:border-[#ffffff]/10"
        >
          <div 
            className="font-['Cousine'] text-[32px] md:text-[42px] font-bold leading-none mb-2"
            style={{ color: colors.text }}
          >
            {activity.duration}
          </div>
          <div 
            className="font-['Inter'] text-[10px] uppercase tracking-wide font-medium opacity-70"
            style={{ color: colors.textMuted }}
          >
            Moving Time
          </div>
        </div>

        {/* Elevation */}
        <div 
          className="p-5 md:p-6 border-r border-[#000000]/10 dark:border-[#ffffff]/10"
        >
          <div 
            className="font-['Cousine'] text-[32px] md:text-[42px] font-bold leading-none mb-2"
            style={{ color: colors.text }}
          >
            {activity.elevation.split(' ')[0]}
            <span className="text-[14px] ml-1" style={{ color: colors.textMuted }}>
              {activity.elevation.split(' ')[1]}
            </span>
          </div>
          <div 
            className="font-['Inter'] text-[10px] uppercase tracking-wide font-medium opacity-70"
            style={{ color: colors.textMuted }}
          >
            Elevation
          </div>
        </div>

        {/* TSS */}
        <div 
          className="p-5 md:p-6"
        >
          <div 
            className="font-['Cousine'] text-[32px] md:text-[42px] font-bold leading-none mb-2"
            style={{ color: colors.text }}
          >
            {activity.tss}
          </div>
          <div 
            className="font-['Inter'] text-[10px] uppercase tracking-wide font-medium opacity-70"
            style={{ color: colors.textMuted }}
          >
            TSS
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="h-[1px]" style={{ backgroundColor: dividerColor }} />

      {/* Secondary Stats - 2 Column Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2">
        <div className="p-5 md:p-6 border-b md:border-b-0 md:border-r border-[#000000]/10 dark:border-[#ffffff]/10">
          <div className="flex justify-between items-baseline mb-1">
             <div 
              className="font-['Cousine'] text-[24px] md:text-[28px] font-bold leading-none"
              style={{ color: colors.text }}
            >
              {activity.avgPower}
            </div>
            <div 
              className="font-['Inter'] text-[10px] uppercase tracking-wide opacity-70"
              style={{ color: colors.textMuted }}
            >
              Avg Power
            </div>
          </div>
        </div>

        <div className="p-5 md:p-6">
           <div className="flex justify-between items-baseline mb-1">
             <div 
              className="font-['Cousine'] text-[24px] md:text-[28px] font-bold leading-none"
              style={{ color: colors.text }}
            >
              {activity.normalizedPower}
            </div>
            <div 
              className="font-['Inter'] text-[10px] uppercase tracking-wide opacity-70"
              style={{ color: colors.textMuted }}
            >
              Normalized Power
            </div>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="h-[1px]" style={{ backgroundColor: dividerColor }} />

      {/* Detailed Stats Table - Full Width Rows */}
      <div className="text-[12px]">
        {/* Header Row */}
        <div 
           className="grid grid-cols-3 px-6 py-2 border-b border-[#000000]/5 dark:border-[#ffffff]/5 bg-[#000000]/[0.02] dark:bg-[#ffffff]/[0.02]"
        >
           <div className="font-['Inter'] font-bold uppercase tracking-wider opacity-60" style={{ color: colors.text }}>Metric</div>
           <div className="font-['Inter'] font-bold uppercase tracking-wider opacity-60 text-right" style={{ color: colors.text }}>Avg</div>
           <div className="font-['Inter'] font-bold uppercase tracking-wider opacity-60 text-right" style={{ color: colors.text }}>Max</div>
        </div>

        {/* HR Row */}
        <div className="grid grid-cols-3 px-6 py-3 border-b border-[#000000]/5 dark:border-[#ffffff]/5">
           <div className="font-['Inter'] font-medium" style={{ color: colors.text }}>Heart Rate</div>
           <div className="font-['Cousine'] font-bold text-right" style={{ color: colors.text }}>{activity.avgHeartRate}</div>
           <div className="font-['Cousine'] font-bold text-right" style={{ color: colors.textMuted }}>{activity.maxHeartRate}</div>
        </div>

        {/* Cadence Row */}
        <div className="grid grid-cols-3 px-6 py-3 border-b border-[#000000]/5 dark:border-[#ffffff]/5">
           <div className="font-['Inter'] font-medium" style={{ color: colors.text }}>Cadence</div>
           <div className="font-['Cousine'] font-bold text-right" style={{ color: colors.text }}>{activity.avgCadence}</div>
           <div className="font-['Cousine'] font-bold text-right" style={{ color: colors.textMuted }}>{activity.maxCadence}</div>
        </div>

        {/* IF Row */}
        <div className="grid grid-cols-3 px-6 py-3">
           <div className="font-['Inter'] font-medium" style={{ color: colors.text }}>Intensity Factor</div>
           <div className="font-['Cousine'] font-bold text-right col-span-2" style={{ color: colors.text }}>{activity.intensityFactor}</div>
        </div>
      </div>
    </div>
  );
});

StatsPanel.displayName = 'StatsPanel';

export default StatsPanel;