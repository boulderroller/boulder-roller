import { memo, useMemo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { getDivider, getAccentHighlight } from '../../constants/colors';

interface LeaderboardRowProps {
  user: {
    rank: number;
    wallet: string;
    riderName: string;
    totalPoints: number;
    achievements: number;
    lastActive: string;
    isCurrentUser?: boolean;
  };
}

// Helper functions (memoized outside component to avoid recreation)
const getBadge = (rank: number) => {
  if (rank === 1) return '🥇';
  if (rank === 2) return '🥈';
  if (rank === 3) return '🥉';
  return null;
};

const getRankColor = (rank: number, accentColor: string, textColor: string) => {
  if (rank === 1) return '#c89b5c'; // Gold
  if (rank === 2) return '#a8b5a0'; // Silver
  if (rank === 3) return '#8b7355'; // Bronze
  return textColor;
};

// Calculate TGE preview (memoized per row)
const calculateTGE = (points: number): string => {
  let dung = 0;
  let remaining = points;

  if (remaining > 0) {
    const chunk = Math.min(remaining, 10000);
    dung += chunk / 1000;
    remaining -= chunk;
  }

  if (remaining > 0) {
    const chunk = Math.min(remaining, 50000);
    dung += chunk / 1500;
    remaining -= chunk;
  }

  if (remaining > 0) {
    const chunk = Math.min(remaining, 200000);
    dung += chunk / 2000;
    remaining -= chunk;
  }

  if (remaining > 0) {
    dung += remaining / 3000;
  }

  return dung.toFixed(0);
};

const LeaderboardRow = memo(({ user }: LeaderboardRowProps) => {
  const { isDarkMode, colors } = useTheme();

  // Memoize TGE calculation
  const tgeAmount = useMemo(() => calculateTGE(user.totalPoints), [user.totalPoints]);

  const badge = getBadge(user.rank);
  const rankColor = getRankColor(user.rank, colors.accent, colors.text);
  
  const tabBorderColor = getDivider(isDarkMode);
  const hoverBg = getAccentHighlight(isDarkMode, 'subtle');
  const currentUserBg = getAccentHighlight(isDarkMode, 'medium');

  return (
    <div
      className="px-5 py-3 border-b transition-colors cursor-pointer"
      style={{ 
        borderColor: tabBorderColor,
        backgroundColor: user.isCurrentUser ? currentUserBg : 'transparent',
      }}
      onMouseEnter={(e) => {
        if (!user.isCurrentUser) {
          e.currentTarget.style.backgroundColor = hoverBg;
        }
      }}
      onMouseLeave={(e) => {
        if (!user.isCurrentUser) {
          e.currentTarget.style.backgroundColor = 'transparent';
        }
      }}
    >
      <div className="grid grid-cols-[60px_2fr_1fr_100px_100px_120px] gap-4 items-center">
        {/* Rank */}
        <div className="flex items-center gap-2">
          {badge && <span className="text-[16px]">{badge}</span>}
          <span 
            className="font-['Cousine'] text-[14px] font-bold"
            style={{ color: rankColor }}
          >
            #{user.rank}
          </span>
        </div>

        {/* Rider */}
        <div>
          <div className="font-['Inter'] text-[13px] font-bold" style={{ color: colors.text }}>
            {user.riderName}
            {user.isCurrentUser && (
              <span className="ml-2 text-[10px] uppercase tracking-wide" style={{ color: colors.accent }}>
                YOU
              </span>
            )}
          </div>
          <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
            {user.wallet}
          </div>
        </div>

        {/* Total Points */}
        <div 
          className="font-['Cousine'] text-[16px] font-bold text-right"
          style={{ 
            color: '#c89b5c',
            textShadow: user.rank <= 10 ? '0 0 12px rgba(200, 155, 92, 0.2)' : 'none'
          }}
        >
          {user.totalPoints.toLocaleString()}
        </div>

        {/* Last Active */}
        <div className="font-['Inter'] text-[11px] text-right" style={{ color: colors.textMuted }}>
          {user.lastActive}
        </div>

        {/* Achievements */}
        <div className="font-['Cousine'] text-[13px] font-bold text-right" style={{ color: colors.text }}>
          {user.achievements}
        </div>

        {/* Est. DUNG */}
        <div className="text-right">
          <div 
            className="font-['Cousine'] text-[13px] font-bold"
            style={{ color: colors.text }}
          >
            ≈{tgeAmount}
          </div>
          <div className="font-['Inter'] text-[9px]" style={{ color: colors.textMuted }}>
            DUNG
          </div>
        </div>
      </div>
    </div>
  );
});

LeaderboardRow.displayName = 'LeaderboardRow';

export default LeaderboardRow;