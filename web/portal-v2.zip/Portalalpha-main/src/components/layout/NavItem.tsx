import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';

interface NavItemProps {
  icon?: string;
  title: string;
  subtitle?: string;
  to: string;
  onClick?: () => void;
}

export default function NavItem({ icon, title, subtitle, to, onClick }: NavItemProps) {
  const { colors } = useTheme();
  const location = useLocation();
  const isActive = location.pathname === to;

  const handleClick = () => {
    if (onClick) onClick();
  };

  return (
    <Link 
      to={to}
      onClick={handleClick}
      className="w-full px-4 py-2 flex items-center gap-3 transition-colors duration-100"
      style={{
        backgroundColor: isActive ? `${colors.accent}10` : 'transparent',
      }}
      onMouseEnter={(e) => {
        if (!isActive) {
          e.currentTarget.style.backgroundColor = colors.accent + '08';
        }
      }}
      onMouseLeave={(e) => {
        if (!isActive) {
          e.currentTarget.style.backgroundColor = 'transparent';
        }
      }}
    >
      {icon && <span className="text-[18px]">{icon}</span>}
      <div className="flex-1">
        <div 
          className="font-['Inter'] font-bold text-[13px] text-left"
          style={{ color: isActive ? colors.accent : colors.text }}
        >
          {title}
        </div>
        {subtitle && (
          <div 
            className="font-['Inter'] text-[10px] text-left"
            style={{ color: colors.textMuted }}
          >
            {subtitle}
          </div>
        )}
      </div>
    </Link>
  );
}