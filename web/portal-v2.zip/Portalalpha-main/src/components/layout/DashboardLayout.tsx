import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { SidebarInset, SidebarProvider, SidebarTrigger } from '../ui/sidebar';
import { AppSidebar } from './AppSidebar';
import { useTheme } from '../../contexts/ThemeContext';
import { Search, Upload, Bell, ArrowLeft } from 'lucide-react';
import { BeetleButton } from '../ui/beetle-button';
import { toast } from 'sonner@2.0.3';
import UploadActivityModal from '../modals/UploadActivityModal';
import RideUploadSuccessModal from '../modals/RideUploadSuccessModal';
import SearchModal from '../modals/SearchModal';
import ProfileEditPanel from './ProfileEditPanel';
import { Separator } from '../ui/separator';

interface DashboardLayoutProps {
  children: React.ReactNode;
  isConnected: boolean;
  walletAddress: string | null;
  onDisconnect: () => void;
}

export default function DashboardLayout({ 
  children, 
  isConnected, 
  walletAddress, 
  onDisconnect 
}: DashboardLayoutProps) {
  const { colors, isDarkMode, toggleDarkMode } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  
  // Modal States
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showUploadSuccessModal, setShowUploadSuccessModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showEditPanel, setShowEditPanel] = useState(false); // Can be triggered from Settings page or Sidebar eventually
  const [uploadedFileName, setUploadedFileName] = useState('');

  // Handlers
  const handleUpload = () => setShowUploadModal(true);
  
  const handleUploadSuccess = (file: File) => {
    setUploadedFileName(file.name);
    setShowUploadSuccessModal(true);
  };

  const handleSearch = () => setShowSearchModal(true);
  
  const handleNotifications = () => {
    toast.info('Notifications coming soon! 🔔');
  };

  const handleSaveProfile = (data: any) => {
    console.log('Saving profile:', data);
    toast.success('Profile updated! 🪲');
  };

  const handleExportData = () => {
    toast.success('Data exported successfully! 📦');
  };

  const handleDeleteAccount = () => {
    if (confirm('Are you sure you want to delete your account?')) {
      toast.success('Account deleted');
      onDisconnect();
    }
  };

  // Determine Page Title based on route
  const getPageTitle = (pathname: string) => {
    if (pathname === '/') return 'Activity Feed';
    if (pathname === '/my-activities') return 'My Activities';
    if (pathname === '/my-segments') return 'Segment Registry';
    if (pathname === '/data') return 'Performance Data';
    if (pathname === '/portfolio') return 'Rider Portfolio';
    if (pathname === '/map') return 'Global Map';
    if (pathname === '/leaderboard') return 'Leaderboards';
    if (pathname === '/find-friends') return 'Find Friends';
    if (pathname === '/achievements') return 'Achievements';
    if (pathname === '/store') return 'Beetle Store';
    if (pathname === '/settings') return 'System Settings';
    if (pathname === '/docs') return 'Documentation';
    if (pathname.startsWith('/activities/')) return 'Activity Analysis';
    if (pathname.startsWith('/segments/')) return 'Segment Detail';
    if (pathname.startsWith('/rider/')) return 'Rider Profile';
    return 'Dashboard';
  };

  const showBackButton = location.pathname !== '/';

  return (
    <SidebarProvider>
      <AppSidebar 
        isConnected={isConnected} 
        walletAddress={walletAddress} 
        onDisconnect={onDisconnect}
      />
      <SidebarInset>
        {/* Industrial Header Bar */}
        <header className="flex h-16 shrink-0 items-center gap-2 border-b border-sidebar-border px-4 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-12 sticky top-0 z-10 backdrop-blur-md bg-background/90">
          <div className="flex items-center gap-2">
            <SidebarTrigger className="-ml-1 text-foreground hover:bg-accent/10 rounded-none border border-transparent hover:border-border" />
            
            <Separator orientation="vertical" className="mr-2 h-4 bg-border" />
            
            {showBackButton && (
               <button 
                 onClick={() => navigate(-1)}
                 className="flex items-center gap-1.5 px-2 py-1 rounded-none border border-transparent hover:border-border text-[11px] font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground hover:bg-accent/10 transition-none mr-2"
               >
                 <ArrowLeft size={14} />
                 <span className="hidden sm:inline font-['Cousine']">Return</span>
               </button>
            )}

            <h1 className="font-['Cousine'] font-bold text-sm tracking-wider uppercase text-foreground">
              {getPageTitle(location.pathname)}
            </h1>
          </div>

          <div className="ml-auto flex items-center gap-2">
             {/* Search */}
             <button
                onClick={handleSearch}
                className="p-2 rounded-none hover:bg-accent/10 hover:border-border border border-transparent transition-none"
                title="Search"
             >
               <Search className="w-4 h-4 text-foreground" />
             </button>

             {/* Notifications */}
             <button
                onClick={handleNotifications}
                className="p-2 rounded-none hover:bg-accent/10 hover:border-border border border-transparent transition-none relative"
                title="Notifications"
             >
               <Bell className="w-4 h-4 text-foreground" />
               <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-none bg-red-500" />
             </button>

             <Separator orientation="vertical" className="h-4 mx-1 bg-border" />

             {/* Upload Button */}
             <BeetleButton 
                variant="primary" 
                size="sm"
                onClick={handleUpload}
                className="hidden sm:flex rounded-none"
              >
                <Upload className="w-4 h-4" />
                <span className="font-['Cousine']">Upload</span>
              </BeetleButton>
              
              {/* Mobile Upload Icon */}
              <button
                 onClick={handleUpload}
                 className="sm:hidden p-2 rounded-none bg-accent text-black border border-black"
              >
                 <Upload className="w-4 h-4" />
              </button>
          </div>
        </header>

        {/* Main Content Area */}
        <div className="flex-1 p-4 pt-0">
          {children}
        </div>

        {/* Global Modals */}
        {showUploadModal && (
          <UploadActivityModal
            onClose={() => setShowUploadModal(false)}
            onUploadSuccess={handleUploadSuccess}
          />
        )}

        {showUploadSuccessModal && (
          <RideUploadSuccessModal
            fileName={uploadedFileName}
            onClose={() => setShowUploadSuccessModal(false)}
          />
        )}

        {showSearchModal && (
          <SearchModal
            onClose={() => setShowSearchModal(false)}
          />
        )}

        {showEditPanel && (
          <ProfileEditPanel
            walletAddress={walletAddress}
            isDarkMode={isDarkMode}
            onToggleDarkMode={toggleDarkMode}
            onClose={() => setShowEditPanel(false)}
            onSave={handleSaveProfile}
            onExportData={handleExportData}
            onDeleteAccount={handleDeleteAccount}
          />
        )}

      </SidebarInset>
    </SidebarProvider>
  );
}