import { useState, useRef, useEffect } from 'react';
import { useTheme } from '../../contexts/ThemeContext';

interface NavDropdownProps {
  label: string;
  isActive?: boolean;
  children: React.ReactNode;
}

export default function NavDropdown({ label, isActive, children }: NavDropdownProps) {
  const { colors } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const [shouldRender, setShouldRender] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const closeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleMouseEnter = () => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
    
    timeoutRef.current = setTimeout(() => {
      setShouldRender(true);
      setTimeout(() => setIsOpen(true), 10);
    }, 150);
  };

  const handleMouseLeave = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    
    closeTimeoutRef.current = setTimeout(() => {
      setIsOpen(false);
      setTimeout(() => setShouldRender(false), 200);
    }, 200);
  };

  const handleDropdownMouseEnter = () => {
    if (closeTimeoutRef.current) {
      clearTimeout(closeTimeoutRef.current);
      closeTimeoutRef.current = null;
    }
  };

  const handleDropdownMouseLeave = () => {
    closeTimeoutRef.current = setTimeout(() => {
      setIsOpen(false);
      setTimeout(() => setShouldRender(false), 200);
    }, 200);
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (closeTimeoutRef.current) clearTimeout(closeTimeoutRef.current);
    };
  }, []);

  return (
    <div 
      className="relative"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={dropdownRef}
    >
      {/* Dropdown Trigger */}
      <button
        className="flex items-center gap-1.5 px-2 py-2 rounded-md transition-all duration-150"
        style={{
          color: isActive ? colors.accent : colors.text,
          backgroundColor: isOpen ? colors.accent + '08' : 'transparent',
          border: 'none',
          outline: 'none',
        }}
      >
        <span className="font-['Inter'] font-bold text-[14px]">
          {label}
        </span>
        <svg 
          width="12" 
          height="12" 
          viewBox="0 0 16 16" 
          fill="none"
          className="transition-transform duration-200"
          style={{
            transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
          }}
        >
          <path 
            d="M4 6L8 10L12 6" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          />
        </svg>
      </button>

      {/* Dropdown Menu */}
      {shouldRender && (
        <div
          className="absolute top-[calc(100%+12px)] left-0 min-w-[260px] z-[55] transition-all duration-200"
          style={{
            opacity: isOpen ? 1 : 0,
            transform: isOpen ? 'translateY(0)' : 'translateY(-8px)',
            pointerEvents: isOpen ? 'auto' : 'none',
          }}
          onMouseEnter={handleDropdownMouseEnter}
          onMouseLeave={handleDropdownMouseLeave}
        >
          <div
            className="border rounded overflow-hidden"
            style={{
              backgroundColor: colors.bg,
              borderColor: colors.border,
              boxShadow: `2px 2px 4px rgba(0, 0, 0, 0.08)`,
            }}
          >
            {children}
          </div>
        </div>
      )}
    </div>
  );
}