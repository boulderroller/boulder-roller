import { useTheme } from '../../contexts/ThemeContext';
import { useNavigate } from 'react-router-dom';
import { BeetleButton } from '../ui/beetle-button';

interface ProfileDropdownProps {
  walletAddress: string | null;
  isDarkMode: boolean;
  onOpenEditPanel: () => void;
  onExportData: () => void;
  onDisconnect: () => void;
}

export default function ProfileDropdown({ 
  walletAddress, 
  isDarkMode,
  onOpenEditPanel,
  onExportData,
  onDisconnect 
}: ProfileDropdownProps) {
  const { colors } = useTheme();
  const navigate = useNavigate();
  
  // Mock user data - replace with real data from your backend
  const beetleId = 4821;
  const rank = 'C';
  const username = 'climber_420';
  const ftp = 250;
  const weight = 70;
  const riderType = 'Climber';

  const hoverBg = isDarkMode ? 'hover:bg-[#3a3d2e]' : 'hover:bg-[#f3f5ed]';

  return (
    <div 
      className="rounded border w-[280px] overflow-hidden"
      style={{ 
        backgroundColor: colors.bg, 
        borderColor: colors.border,
        boxShadow: `2px 2px 4px rgba(0, 0, 0, 0.08)`,
      }}
    >
      {/* Header - Clickable to Profile */}
      <div 
        className="block p-4 border-b transition-colors duration-150"
        style={{ borderColor: colors.border }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = isDarkMode ? '#3a3d2e' : '#f3f5ed';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = 'transparent';
        }}
        onClick={() => navigate('/profile')}
      >
        <div className="flex items-center justify-between mb-3">
          <div className="font-['Cousine'] text-[16px]" style={{ color: colors.text }}>
            Beetle #{beetleId}
          </div>
          <div className="bg-[#8b9475] text-white px-2 py-1 rounded-full font-['Inter'] font-bold text-[9px] uppercase tracking-wide">
            Rank {rank}
          </div>
        </div>
        
        <div className="font-['Inter'] font-bold text-[14px] mb-2" style={{ color: colors.text }}>
          @{username}
        </div>
        
        <div className="font-['Cousine'] text-[12px] flex items-center gap-2" style={{ color: colors.textMuted }}>
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M2.5 8.33333C2.5 8.33333 5 2.5 10 2.5C15 2.5 17.5 8.33333 17.5 8.33333C17.5 8.33333 15 14.1667 10 14.1667C5 14.1667 2.5 8.33333 2.5 8.33333Z" />
            <circle cx="10" cy="8.33333" r="2.5" />
          </svg>
          {walletAddress || '7xK9...mP3q'}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="px-4 py-3 border-b" style={{ borderColor: colors.border }}>
        <div className="flex items-center justify-between">
          <div>
            <div className="font-['Inter'] font-bold text-[10px] uppercase tracking-wide mb-1" style={{ color: colors.textMuted }}>
              FTP
            </div>
            <div className="font-['Cousine'] text-[14px]" style={{ color: colors.text }}>
              {ftp}w
            </div>
          </div>
          <div className="w-[1px] h-8" style={{ backgroundColor: isDarkMode ? '#3a3d2e' : '#d0d8bf' }} />
          <div>
            <div className="font-['Inter'] font-bold text-[10px] uppercase tracking-wide mb-1" style={{ color: colors.textMuted }}>
              Weight
            </div>
            <div className="font-['Cousine'] text-[14px]" style={{ color: colors.text }}>
              {weight}kg
            </div>
          </div>
          <div className="w-[1px] h-8" style={{ backgroundColor: isDarkMode ? '#3a3d2e' : '#d0d8bf' }} />
          <div>
            <div className="font-['Inter'] font-bold text-[10px] uppercase tracking-wide mb-1" style={{ color: colors.textMuted }}>
              Type
            </div>
            <div className="font-['Cousine'] text-[14px]" style={{ color: colors.text }}>
              {riderType}
            </div>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="py-2">
        {/* 1. EDIT PROFILE - Most common action */}
        <button
          onClick={onOpenEditPanel}
          className={`w-full px-4 py-2.5 ${hoverBg} active:bg-opacity-80 transition-all flex items-center justify-between group`}
        >
          <div className="flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }}>
              <path d="M12 20h9" />
              <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
            </svg>
            <span className="font-['Inter'] text-[13px]" style={{ color: colors.text }}>Edit Profile</span>
          </div>
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="group-hover:translate-x-0.5 transition-transform">
            <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }} />
          </svg>
        </button>

        {/* 2. SETTINGS */}
        <button
          onClick={() => navigate('/settings')}
          className={`w-full px-4 py-2.5 ${hoverBg} active:bg-opacity-80 transition-all flex items-center justify-between group`}
        >
          <div className="flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }}>
              <circle cx="12" cy="12" r="3" />
              <path d="M12 1v6m0 6v6M5.6 5.6l4.2 4.2m4.4 4.4l4.2 4.2M1 12h6m6 0h6M5.6 18.4l4.2-4.2m4.4-4.4l4.2-4.2" />
            </svg>
            <span className="font-['Inter'] text-[13px]" style={{ color: colors.text }}>Settings</span>
          </div>
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="group-hover:translate-x-0.5 transition-transform">
            <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }} />
          </svg>
        </button>

        {/* 3. DOCS - New */}
        <button
          onClick={() => navigate('/docs')}
          className={`w-full px-4 py-2.5 ${hoverBg} active:bg-opacity-80 transition-all flex items-center justify-between group`}
        >
          <div className="flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }}>
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <line x1="16" y1="13" x2="8" y2="13" />
              <line x1="16" y1="17" x2="8" y2="17" />
              <polyline points="10 9 9 9 8 9" />
            </svg>
            <span className="font-['Inter'] text-[13px]" style={{ color: colors.text }}>Docs</span>
          </div>
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="group-hover:translate-x-0.5 transition-transform">
            <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }} />
          </svg>
        </button>

        {/* 4. EXPORT DATA */}
        <button
          onClick={onExportData}
          className={`w-full px-4 py-2.5 ${hoverBg} active:bg-opacity-80 transition-all flex items-center justify-between group`}
        >
          <div className="flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }}>
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            <span className="font-['Inter'] text-[13px]" style={{ color: colors.text }}>Export Data</span>
          </div>
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" className="group-hover:translate-x-0.5 transition-transform">
            <path d="M6 12L10 8L6 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.textMuted }} />
          </svg>
        </button>
      </div>

      {/* Disconnect Button */}
      <div className="p-3 border-t" style={{ borderColor: colors.border }}>
        <BeetleButton
          onClick={onDisconnect}
          variant="secondary"
          size="sm"
          className="w-full"
        >
          Disconnect
        </BeetleButton>
      </div>
    </div>
  );
}