import { useState, useEffect } from 'react';
import { useTheme } from '../../contexts/ThemeContext';

/**
 * ScrollProgress Component
 * Subtle progress bar at top showing scroll position (PWA polish)
 */
export default function ScrollProgress() {
  const [scrollProgress, setScrollProgress] = useState(0);
  const { colors } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      const mainElement = document.querySelector('main');
      if (!mainElement) return;

      const scrollTop = mainElement.scrollTop;
      const scrollHeight = mainElement.scrollHeight - mainElement.clientHeight;
      const progress = scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0;
      
      setScrollProgress(progress);
    };

    const mainElement = document.querySelector('main');
    if (mainElement) {
      mainElement.addEventListener('scroll', handleScroll, { passive: true });
      return () => mainElement.removeEventListener('scroll', handleScroll);
    }
  }, []);

  // Only show when scrolled past 5%
  if (scrollProgress < 5) return null;

  return (
    <div 
      className="fixed top-[64px] left-0 right-0 h-[2px] z-[45] transition-opacity duration-300"
      style={{
        backgroundColor: 'rgba(200, 155, 92, 0.15)',
      }}
    >
      <div 
        className="h-full transition-all duration-150 ease-out"
        style={{ 
          width: `${scrollProgress}%`,
          backgroundColor: '#c89b5c',
          boxShadow: '0 0 8px rgba(200, 155, 92, 0.4)',
        }}
      />
    </div>
  );
}