import { useState } from 'react';
import { useTheme, THEMES, ThemeId } from '../../contexts/ThemeContext';
import { BeetleInput } from '../ui/beetle-input';
import { BeetleButton } from '../ui/beetle-button';
import { toast } from 'sonner';

interface ProfileEditPanelProps {
  walletAddress: string | null;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  onClose: () => void;
  onSave: (data: any) => void;
  onExportData: () => void;
  onDeleteAccount: () => void;
}

export default function ProfileEditPanel({ 
  walletAddress,
  isDarkMode,
  onToggleDarkMode,
  onClose,
  onSave,
  onExportData,
  onDeleteAccount
}: ProfileEditPanelProps) {
  const { themeId, setThemeId, colors } = useTheme();
  const [username, setUsername] = useState('climber_420');
  const [ftp, setFtp] = useState('250');
  const [weight, setWeight] = useState('70');
  const [riderType, setRiderType] = useState('climber');
  const [units, setUnits] = useState<'metric' | 'imperial'>('metric');

  const inputBg = isDarkMode ? 'bg-[#3a3d2e]' : 'bg-white';

  const handleSave = () => {
    onSave({ username, ftp: parseInt(ftp), weight: parseInt(weight), riderType, units, theme: themeId });
    onClose();
    toast.success('Profile saved successfully!');
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 animate-fadeIn"
        onClick={onClose}
      />
      
      {/* Panel - Slide in from right */}
      <div 
        className="fixed right-0 top-0 h-full w-[400px] border-l-[3px] shadow-xl z-50 overflow-y-auto animate-slideInRight"
        style={{ 
          backgroundColor: colors.bg, 
          borderColor: colors.border 
        }}
      >
        {/* Header */}
        <div 
          className="sticky top-0 p-6 border-b-[3px] flex items-center justify-between z-10"
          style={{ 
            backgroundColor: colors.bg, 
            borderColor: colors.border 
          }}
        >
          <h2 className={`font-['Inter'] font-bold text-[18px] uppercase tracking-wide`} style={{ color: colors.text }}>
            Edit Profile
          </h2>
          <button
            onClick={onClose}
            className="transition-colors"
            style={{ color: colors.textMuted }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Username */}
          <div>
            <label className={`block font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-2`} style={{ color: colors.textMuted }}>
              Username
            </label>
            <BeetleInput
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className={`w-full px-3 py-2.5 ${inputBg} border-[2px] rounded-[8px] font-['Inter'] text-[14px] focus:outline-none transition-all`}
              style={{ 
                borderColor: colors.border, 
                color: colors.text 
              }}
            />
          </div>

          {/* Training Section */}
          <div className="pb-6 border-b-[2px]" style={{ borderColor: isDarkMode ? '#3a3d2e' : '#d0d8bf' }}>
            <h3 className={`font-['Inter'] font-bold text-[13px] uppercase tracking-wide mb-4`} style={{ color: colors.text }}>
              Training
            </h3>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={`block font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-2`} style={{ color: colors.textMuted }}>
                    FTP (watts)
                  </label>
                  <BeetleInput
                    type="number"
                    value={ftp}
                    onChange={(e) => setFtp(e.target.value)}
                    className={`w-full px-3 py-2.5 ${inputBg} border-[2px] rounded-[8px] font-['Cousine'] text-[14px] focus:outline-none transition-all`}
                    style={{ 
                      borderColor: colors.border, 
                      color: colors.text 
                    }}
                  />
                </div>
                <div>
                  <label className={`block font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-2`} style={{ color: colors.textMuted }}>
                    Weight (kg)
                  </label>
                  <BeetleInput
                    type="number"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value)}
                    className={`w-full px-3 py-2.5 ${inputBg} border-[2px] rounded-[8px] font-['Cousine'] text-[14px] focus:outline-none transition-all`}
                    style={{ 
                      borderColor: colors.border, 
                      color: colors.text 
                    }}
                  />
                </div>
              </div>
              <div>
                <label className={`block font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-2`} style={{ color: colors.textMuted }}>
                  Rider Type
                </label>
                <select
                  value={riderType}
                  onChange={(e) => setRiderType(e.target.value)}
                  className={`w-full px-3 py-2.5 ${inputBg} border-[2px] rounded-[8px] font-['Inter'] text-[14px] focus:outline-none transition-all`}
                  style={{ 
                    borderColor: colors.border, 
                    color: colors.text 
                  }}
                >
                  <option value="sprinter">Sprinter</option>
                  <option value="tt">Time Trialist</option>
                  <option value="climber">Climber</option>
                  <option value="allrounder">All-Rounder</option>
                  <option value="diesel">Diesel</option>
                </select>
              </div>
            </div>
          </div>

          {/* Display Section */}
          <div className="pb-6 border-b-[2px]" style={{ borderColor: isDarkMode ? '#3a3d2e' : '#d0d8bf' }}>
            <h3 className={`font-['Inter'] font-bold text-[13px] uppercase tracking-wide mb-4`} style={{ color: colors.text }}>
              Display
            </h3>
            
            {/* Units Toggle */}
            <div className="mb-4">
              <label className={`block font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-2`} style={{ color: colors.textMuted }}>
                Units
              </label>
              <div className="flex gap-2">
                <button
                  onClick={() => setUnits('metric')}
                  className={`flex-1 px-3 py-2 rounded-[8px] border-[2px] font-['Inter'] text-[11px] font-bold uppercase tracking-wide transition-all ${
                    units === 'metric'
                      ? `text-[#2a2d1e]`
                      : ``
                  }`}
                  style={{
                    backgroundColor: units === 'metric' ? '#d4c993' : inputBg,
                    borderColor: units === 'metric' ? '#2a2d1e' : colors.border,
                    color: units === 'metric' ? '#2a2d1e' : colors.text,
                  }}
                >
                  Metric
                </button>
                <button
                  onClick={() => setUnits('imperial')}
                  className={`flex-1 px-3 py-2 rounded-[8px] border-[2px] font-['Inter'] text-[11px] font-bold uppercase tracking-wide transition-all`}
                  style={{
                    backgroundColor: units === 'imperial' ? '#d4c993' : inputBg,
                    borderColor: units === 'imperial' ? '#2a2d1e' : colors.border,
                    color: units === 'imperial' ? '#2a2d1e' : colors.text,
                  }}
                >
                  Imperial
                </button>
              </div>
            </div>

            {/* Theme Grid */}
            <div className="mb-4">
              <label className={`block font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-3`} style={{ color: colors.textMuted }}>
                Theme
              </label>
              <div className="grid grid-cols-3 gap-2">
                {Object.values(THEMES).map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => setThemeId(theme.id)}
                    className={`p-3 rounded-[8px] border-[2px] transition-all ${
                      themeId === theme.id
                        ? 'border-[#2a2d1e] shadow-[3px_3px_0px_0px_#2a2d1e]'
                        : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{ 
                      backgroundColor: theme.light.accent,
                      borderColor: themeId === theme.id ? '#2a2d1e' : colors.border,
                    }}
                  >
                    <div className="text-[20px] mb-1">{theme.emoji}</div>
                    <div className="font-['Inter'] text-[9px] font-bold text-white uppercase text-center leading-tight">
                      {theme.name}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Dark Mode Toggle */}
            <div className="flex items-center justify-between">
              <span className={`font-['Inter'] font-bold text-[11px] uppercase tracking-wide`} style={{ color: colors.textMuted }}>
                Dark Mode
              </span>
              <button
                onClick={onToggleDarkMode}
                className="w-11 h-6 rounded-full border-[2px] relative transition-all"
                style={{
                  backgroundColor: isDarkMode ? colors.accent : '#d0d8bf',
                  borderColor: colors.border,
                }}
              >
                <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                  isDarkMode ? 'translate-x-5' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          </div>

          {/* Sessions Section */}
          <div className="pb-6 border-b-[2px]" style={{ borderColor: isDarkMode ? '#3a3d2e' : '#d0d8bf' }}>
            <h3 className={`font-['Inter'] font-bold text-[13px] uppercase tracking-wide mb-3`} style={{ color: colors.text }}>
              Sessions
            </h3>
            <div 
              className={`p-3 ${inputBg} rounded-[8px] border-[2px]`}
              style={{ borderColor: colors.border }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className={`font-['Inter'] text-[11px] font-bold`} style={{ color: colors.text }}>
                    Desktop • Chrome
                  </div>
                  <div className={`font-['Inter'] text-[10px]`} style={{ color: colors.textMuted }}>
                    San Francisco, CA
                  </div>
                </div>
                <div className="bg-[#8ba87a] text-white px-2 py-1 rounded-full font-['Inter'] font-bold text-[8px] uppercase tracking-wide">
                  Current
                </div>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3 pb-6">
            <BeetleButton
              onClick={handleSave}
              className="w-full border-[3px] rounded-[10px] py-3 font-['Inter'] font-bold text-[13px] text-white uppercase tracking-wide transition-all"
              style={{
                backgroundColor: colors.accent,
                borderColor: '#2a2d1e',
                boxShadow: '4px 4px 0px 0px #2a2d1e',
              }}
            >
              Save Changes
            </BeetleButton>
            
            <div className="flex gap-2">
              <BeetleButton
                onClick={onExportData}
                className={`flex-1 ${inputBg} border-[2px] rounded-[8px] py-2.5 font-['Inter'] font-bold text-[11px] uppercase tracking-wide transition-all`}
                style={{
                  borderColor: colors.border,
                  color: colors.text,
                }}
              >
                Export
              </BeetleButton>
              <BeetleButton
                onClick={onDeleteAccount}
                className="flex-1 bg-[#a87373] hover:bg-[#985d5d] border-[2px] border-[#2a2d1e] rounded-[8px] py-2.5 font-['Inter'] font-bold text-[11px] text-white uppercase tracking-wide transition-all"
              >
                Delete
              </BeetleButton>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}