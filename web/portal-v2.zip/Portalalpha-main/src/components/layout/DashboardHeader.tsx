import { Link } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';

interface DashboardHeaderProps {
  beetleNumber: number;
  rank: 'C' | 'B' | 'A' | 'S' | 'SS';
  dung: number;
  rideCount: number;
  onClick?: () => void;
}

export default function DashboardHeader({ 
  beetleNumber, 
  rank, 
  dung, 
  rideCount,
  onClick 
}: DashboardHeaderProps) {
  const { colors, isDarkMode } = useTheme();

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'SS': return '#d4af37';
      case 'S': return '#c89b5c';
      case 'A': return '#8ba87a';
      case 'B': return '#7a8a7a';
      case 'C': return '#5a6a5a';
      default: return '#5a6a5a';
    }
  };

  return (
    <Link
      to="/"
      onClick={onClick}
      className="block px-5 py-4 transition-all duration-100"
      style={{
        borderBottom: `1px solid ${isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'}`,
        backgroundColor: colors.bg,
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.backgroundColor = isDarkMode ? 'rgba(139, 168, 122, 0.08)' : 'rgba(139, 168, 122, 0.04)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.backgroundColor = colors.bg;
      }}
    >
      {/* Beetle Identity */}
      <div className="flex items-center gap-2">
        <span className="text-[20px]">🪲</span>
        <span 
          className="font-['Inter'] font-black text-[15px]"
          style={{ color: colors.text }}
        >
          Beetle #{beetleNumber}
        </span>
        <div 
          className="px-2 py-0.5 rounded-[4px] border-[2px]"
          style={{ 
            backgroundColor: getTierColor(rank),
            borderColor: getTierColor(rank),
            boxShadow: `1px 1px 0px 0px ${colors.border}`,
          }}
        >
          <span 
            className="font-['Inter'] text-[12px] font-black"
            style={{ color: isDarkMode ? '#1a1d14' : colors.bg }}
          >
            {rank}
          </span>
        </div>
      </div>
    </Link>
  );
}