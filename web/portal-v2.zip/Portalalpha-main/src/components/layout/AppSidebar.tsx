import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
  useSidebar,
} from "../ui/sidebar";
import { 
  Home, 
  Activity, 
  MapPin, 
  BarChart2, 
  Briefcase, 
  Map as MapIcon, 
  Trophy, 
  Users, 
  Award, 
  ShoppingBag,
  Settings,
  FileText,
  LogOut,
  User
} from "lucide-react";
import { Link, useLocation } from "react-router-dom";
import { useTheme } from "../../contexts/ThemeContext";
import { BeetleButton } from "../ui/beetle-button";

interface AppSidebarProps extends React.ComponentProps<typeof Sidebar> {
  isConnected: boolean;
  walletAddress: string | null;
  onDisconnect: () => void;
  userRank?: string; // Optional rank to display
}

export function AppSidebar({ 
  isConnected, 
  walletAddress, 
  onDisconnect, 
  userRank = "S",
  ...props 
}: AppSidebarProps) {
  const location = useLocation();
  const { colors, isDarkMode } = useTheme();
  const { state } = useSidebar();

  const isActive = (path: string) => location.pathname === path;

  const dashboardItems = [
    { title: "Feed", url: "/", icon: Home },
    { title: "My Activities", url: "/my-activities", icon: Activity },
    { title: "My Segments", url: "/my-segments", icon: MapPin },
    { title: "Data", url: "/data", icon: BarChart2 },
    { title: "Portfolio", url: "/portfolio", icon: Briefcase },
  ];

  const exploreItems = [
    { title: "Map", url: "/map", icon: MapIcon },
    { title: "Leaderboards", url: "/leaderboard", icon: Trophy },
    { title: "Find Friends", url: "/find-friends", icon: Users },
    { title: "Achievements", url: "/achievements", icon: Award },
    { title: "Beetle Store", url: "/store", icon: ShoppingBag },
  ];

  return (
    <Sidebar collapsible="icon" {...props} className="border-r border-sidebar-border bg-sidebar">
      <SidebarHeader className="h-[64px] flex justify-center px-4 border-b border-sidebar-border bg-sidebar rounded-none">
         {/* Industrial Logo Area */}
         <div className="flex items-center gap-2 overflow-hidden transition-all duration-200">
            <div className="flex-shrink-0 w-8 h-8 bg-sidebar-primary flex items-center justify-center rounded-none border border-sidebar-foreground">
              <span className="font-['Cousine'] font-bold text-sidebar-primary-foreground text-xs">BR</span>
            </div>
            {state === "expanded" && (
              <span className="font-['Inter'] font-black text-[18px] tracking-tight whitespace-nowrap text-sidebar-foreground uppercase">
                Boulder Roller
              </span>
            )}
         </div>
      </SidebarHeader>

      <SidebarContent className="bg-sidebar rounded-none">
        {isConnected ? (
          <>
            <SidebarGroup>
              <SidebarGroupLabel className="font-['Cousine'] text-[10px] uppercase tracking-widest text-sidebar-foreground/70 mb-2">Dashboard</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {dashboardItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        isActive={isActive(item.url)}
                        tooltip={item.title}
                        className="transition-none rounded-none border-l-2 border-transparent hover:border-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[active=true]:border-sidebar-primary data-[active=true]:bg-sidebar-accent data-[active=true]:font-bold"
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className={`w-4 h-4 ${isActive(item.url) ? 'text-sidebar-primary' : 'text-sidebar-foreground/70'}`} />
                          <span className={`font-['Inter'] uppercase text-xs tracking-wide ${isActive(item.url) ? "font-bold text-sidebar-foreground" : "font-medium text-sidebar-foreground/80"}`}>
                            {item.title}
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarSeparator className="mx-0 opacity-100 bg-sidebar-border h-[1px]" />

            <SidebarGroup>
              <SidebarGroupLabel className="font-['Cousine'] text-[10px] uppercase tracking-widest text-sidebar-foreground/70 mb-2">Explore</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {exploreItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        isActive={isActive(item.url)}
                        tooltip={item.title}
                        className="transition-none rounded-none border-l-2 border-transparent hover:border-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[active=true]:border-sidebar-primary data-[active=true]:bg-sidebar-accent data-[active=true]:font-bold"
                      >
                        <Link to={item.url} className="flex items-center gap-3">
                          <item.icon className={`w-4 h-4 ${isActive(item.url) ? 'text-sidebar-primary' : 'text-sidebar-foreground/70'}`} />
                          <span className={`font-['Inter'] uppercase text-xs tracking-wide ${isActive(item.url) ? "font-bold text-sidebar-foreground" : "font-medium text-sidebar-foreground/80"}`}>
                            {item.title}
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
            
            <SidebarGroup className="mt-auto">
               <SidebarGroupLabel className="font-['Cousine'] text-[10px] uppercase tracking-widest text-sidebar-foreground/70 mb-2">System</SidebarGroupLabel>
               <SidebarGroupContent>
                 <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Documentation" className="transition-none rounded-none border-l-2 border-transparent hover:border-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
                        <Link to="/docs">
                          <FileText className="w-4 h-4 text-sidebar-foreground/70" />
                          <span className="font-['Inter'] uppercase text-xs tracking-wide font-medium text-sidebar-foreground/80">Docs</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton asChild tooltip="Settings" className="transition-none rounded-none border-l-2 border-transparent hover:border-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground">
                        <Link to="/settings">
                          <Settings className="w-4 h-4 text-sidebar-foreground/70" />
                          <span className="font-['Inter'] uppercase text-xs tracking-wide font-medium text-sidebar-foreground/80">Settings</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                 </SidebarMenu>
               </SidebarGroupContent>
            </SidebarGroup>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-4 text-center opacity-50">
             <div className="w-12 h-12 rounded-none border-2 border-dashed flex items-center justify-center mb-2 border-sidebar-border">
               <Users className="w-6 h-6 text-sidebar-foreground" />
             </div>
             {state === "expanded" && (
                <p className="font-['Cousine'] text-xs text-sidebar-foreground uppercase tracking-wider">Connect Wallet</p>
             )}
          </div>
        )}
      </SidebarContent>

      <SidebarFooter className="p-3 border-t border-sidebar-border bg-sidebar rounded-none">
        {isConnected && walletAddress ? (
          <div className="flex items-center gap-3 p-2 rounded-none border border-transparent hover:border-sidebar-foreground transition-none hover:bg-sidebar-accent cursor-pointer group">
             {/* Avatar / Rank */}
             <div className="w-8 h-8 rounded-none bg-sidebar-accent/50 flex items-center justify-center border border-sidebar-border group-hover:border-sidebar-foreground">
                <span className="font-['Cousine'] font-bold text-xs text-sidebar-primary">{userRank}</span>
             </div>
             
             {state === "expanded" && (
                <div className="flex-1 min-w-0">
                   <div className="font-['Cousine'] text-xs font-bold truncate text-sidebar-foreground">
                      {walletAddress.slice(0, 4)}...{walletAddress.slice(-4)}
                   </div>
                   <div className="text-[10px] uppercase opacity-50 flex items-center gap-1 text-sidebar-foreground font-['Cousine']">
                      <div className="w-1.5 h-1.5 rounded-none bg-green-500 animate-pulse"></div>
                      ONLINE
                   </div>
                </div>
             )}
             
             {state === "expanded" && (
                <button 
                  onClick={onDisconnect}
                  className="p-1.5 rounded-none hover:bg-red-500/10 hover:text-red-500 transition-none border border-transparent hover:border-red-500"
                  title="Disconnect"
                >
                   <LogOut className="w-4 h-4" />
                </button>
             )}
          </div>
        ) : (
          state === "expanded" && (
            <div className="p-1">
               <div className="text-[10px] font-['Cousine'] text-center mb-2 opacity-50 text-sidebar-foreground">NO SIGNAL</div>
            </div>
          )
        )}
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  );
}