import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from '../ui/beetle-button';
import ProfileDropdown from './ProfileDropdown';
import ProfileEditPanel from './ProfileEditPanel';
import NavDropdown from './NavDropdown';
import NavItem from './NavItem';
import { toast } from 'sonner@2.0.3';
import UploadActivityModal from '../modals/UploadActivityModal';
import RideUploadSuccessModal from '../modals/RideUploadSuccessModal';
import SearchModal from '../modals/SearchModal';
import { Search, Bell, Upload } from 'lucide-react';

interface TopNavProps {
  isConnected: boolean;
  walletAddress: string | null;
  onDisconnect: () => void;
}

export default function TopNav({ isConnected, walletAddress, onDisconnect }: TopNavProps) {
  const { colors, isDarkMode, toggleDarkMode } = useTheme();
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [showEditPanel, setShowEditPanel] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showUploadSuccessModal, setShowUploadSuccessModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');

  // Mock user data - wire up to backend
  const userData = {
    beetleNumber: 4207,
    rank: 'S' as const,
    dung: 38456,
    rideCount: 287,
  };

  const handleExportData = () => {
    console.log('Exporting data...');
    toast.success('Data exported successfully! 📦');
    // TODO: Implement export
  };

  const handleSaveProfile = (data: any) => {
    console.log('Saving profile:', data);
    toast.success('Profile updated! 🪲');
    // TODO: Save to backend
  };

  const handleDeleteAccount = () => {
    if (confirm('Are you sure you want to delete your account?')) {
      console.log('Deleting account...');
      toast.success('Account deleted');
      onDisconnect();
      // TODO: Delete account
    }
  };

  const handleUpload = () => {
    setShowUploadModal(true);
  };

  const handleUploadSuccess = (file: File) => {
    setUploadedFileName(file.name);
    setShowUploadSuccessModal(true);
  };

  const handleSearch = () => {
    setShowSearchModal(true);
  };

  const handleNotifications = () => {
    toast.info('Notifications coming soon! 🔔');
    // TODO: Open notifications dropdown
  };

  // Check if current path matches dropdown sections
  const location = useLocation();
  const isDashboardActive = ['/', '/profile', '/my-activities', '/my-segments', '/data', '/portfolio'].includes(location.pathname);
  const isExploreActive = ['/map', '/leaderboard', '/find-friends', '/achievements', '/store'].includes(location.pathname);

  return (
    <>
      <nav 
        className="fixed top-0 left-0 right-0 z-50 border-b h-[64px] px-4 flex items-center justify-between"
        style={{ 
          backgroundColor: colors.bg, 
          borderColor: colors.border 
        }}
      >
        {/* Left: Logo + Nav */}
        <div className="flex items-center gap-3">
          {/* Logo - goes to Feed */}
          <Link to="/" className="flex items-center gap-2.5 transition-opacity duration-150 hover:opacity-80">
            <h1 className="font-['Inter'] font-black text-[20px] tracking-tight" style={{ color: colors.text }}>
              BOULDER ROLLER
            </h1>
          </Link>

          {/* Navigation: Search + Dropdowns */}
          {isConnected && (
            <div className="flex items-center gap-1">
              {/* Search Icon */}
              <button
                onClick={handleSearch}
                className="p-2 rounded-md transition-all duration-100"
                aria-label="Search activities and riders"
                style={{ 
                  color: colors.text,
                  border: 'none',
                  outline: 'none',
                  backgroundColor: 'transparent',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = colors.accent + '08';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Dashboard Dropdown */}
              <NavDropdown label="Dashboard" isActive={isDashboardActive}>
                <div className="py-2">
                  <NavItem 
                    title="Feed" 
                    to="/" 
                  />
                  <NavItem 
                    title="My Activities" 
                    to="/my-activities" 
                  />
                  <NavItem 
                    title="My Segments" 
                    to="/my-segments" 
                  />
                  <NavItem 
                    title="Data" 
                    to="/data" 
                  />
                  <NavItem 
                    title="Portfolio" 
                    to="/portfolio" 
                  />
                </div>
              </NavDropdown>

              {/* Explore Dropdown */}
              <NavDropdown label="Explore" isActive={isExploreActive}>
                <div className="py-2">
                  <NavItem 
                    title="Map" 
                    to="/map" 
                  />
                  <NavItem 
                    title="Leaderboards" 
                    to="/leaderboard" 
                  />
                  <NavItem 
                    title="Find Friends" 
                    to="/find-friends" 
                  />
                  <NavItem 
                    title="Achievements" 
                    to="/achievements" 
                  />
                  <NavItem 
                    title="Beetle Store" 
                    to="/store" 
                  />
                </div>
              </NavDropdown>
            </div>
          )}
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-2">
          {isConnected ? (
            <>
              {/* Upload Button */}
              <BeetleButton 
                variant="primary" 
                size="sm"
                onClick={handleUpload}
              >
                <Upload className="w-4 h-4" />
                <span>Upload</span>
              </BeetleButton>

              {/* Notifications Icon */}
              <button
                onClick={handleNotifications}
                className="p-2 rounded-md transition-all duration-100 relative"
                aria-label="View notifications"
                style={{ 
                  color: colors.text,
                  border: 'none',
                  outline: 'none',
                  backgroundColor: 'transparent',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = colors.accent + '08';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'transparent';
                }}
              >
                <Bell className="w-5 h-5" />
                {/* Notification badge (mock - wire up to backend) */}
                <div 
                  className="absolute top-1 right-1 w-2 h-2 rounded-full"
                  style={{ backgroundColor: colors.accent }}
                />
              </button>

              {/* Profile Dropdown */}
              <div className="relative">
                <button
                  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                  className="beetle-button border rounded px-4 py-2 flex items-center gap-2.5 cursor-pointer"
                  style={{
                    backgroundColor: isDarkMode ? '#3a3d2e' : 'white',
                    borderColor: colors.border,
                    boxShadow: 'none',
                    transform: 'translateY(0)',
                    transition: 'all 120ms ease-out',
                  } as React.CSSProperties}
                >
                  <div className="flex items-center gap-2">
                    <svg width="18" height="18" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: colors.text }}>
                      <path d="M2.5 8.33333C2.5 8.33333 5 2.5 10 2.5C15 2.5 17.5 8.33333 17.5 8.33333C17.5 8.33333 15 14.1667 10 14.1667C5 14.1667 2.5 8.33333 2.5 8.33333Z" />
                      <circle cx="10" cy="8.33333" r="2.5" />
                    </svg>
                    <span className="font-['Cousine'] text-[14px]" style={{ color: colors.text }}>
                      {walletAddress ? `${walletAddress.slice(0, 4)}...${walletAddress.slice(-4)}` : '7xK9...mP3q'}
                    </span>
                  </div>
                  <svg 
                    width="14" 
                    height="14" 
                    viewBox="0 0 16 16" 
                    fill="none" 
                    className={`transition-transform ${showProfileDropdown ? 'rotate-180' : ''}`}
                  >
                    <path 
                      d="M4 6L8 10L12 6" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      style={{ color: colors.text }}
                    />
                  </svg>
                </button>

                {/* Profile Dropdown */}
                {showProfileDropdown && (
                  <>
                    <div 
                      className="fixed inset-0 z-30"
                      onClick={() => setShowProfileDropdown(false)}
                    />
                    <div className="absolute right-0 top-[calc(100%+12px)] z-40">
                      <ProfileDropdown
                        walletAddress={walletAddress}
                        isDarkMode={isDarkMode}
                        onOpenEditPanel={() => {
                          setShowProfileDropdown(false);
                          setShowEditPanel(true);
                        }}
                        onExportData={handleExportData}
                        onDisconnect={onDisconnect}
                      />
                    </div>
                  </>
                )}
              </div>
            </>
          ) : (
            <BeetleButton variant="primary" size="md">
              Connect
            </BeetleButton>
          )}
        </div>
      </nav>

      {/* Profile Edit Panel */}
      {showEditPanel && (
        <ProfileEditPanel
          walletAddress={walletAddress}
          isDarkMode={isDarkMode}
          onToggleDarkMode={toggleDarkMode}
          onClose={() => setShowEditPanel(false)}
          onSave={handleSaveProfile}
          onExportData={handleExportData}
          onDeleteAccount={handleDeleteAccount}
        />
      )}

      {/* Upload Modal */}
      {showUploadModal && (
        <UploadActivityModal
          onClose={() => setShowUploadModal(false)}
          onUploadSuccess={handleUploadSuccess}
        />
      )}

      {/* Upload Success Modal */}
      {showUploadSuccessModal && (
        <RideUploadSuccessModal
          fileName={uploadedFileName}
          onClose={() => setShowUploadSuccessModal(false)}
        />
      )}

      {/* Search Modal */}
      {showSearchModal && (
        <SearchModal
          onClose={() => setShowSearchModal(false)}
        />
      )}
    </>
  );
}