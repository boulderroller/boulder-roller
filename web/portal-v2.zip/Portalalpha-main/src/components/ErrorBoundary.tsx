import { Component, ErrorInfo, ReactNode } from 'react';
import { BeetleButton } from './ui/beetle-button';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

/**
 * ErrorBoundary - Catches React errors and shows fallback UI
 * Prevents entire app from crashing when a component fails
 */
export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo);
    // TODO: Send to error tracking service (Sentry, etc.)
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default error UI - Beetle themed
      return (
        <div className="min-h-screen flex items-center justify-center p-6" style={{ backgroundColor: '#f9faf5' }}>
          <div 
            className="max-w-md w-full rounded border p-8 text-center"
            style={{ 
              backgroundColor: 'white',
              borderColor: '#2a2d1e',
            }}
          >
            {/* Beetle Error Icon */}
            <div className="text-[64px] mb-4 animate-pulse">🪲💥</div>
            
            <h1 className="font-['Inter'] font-bold text-[24px] mb-2" style={{ color: '#2a2d1e' }}>
              Oops! Something Went Wrong
            </h1>
            
            <p className="font-['Inter'] text-[14px] mb-6" style={{ color: '#6b7a5a' }}>
              The beetle hit a wall. Don't worry, your data is safe.
            </p>

            {/* Error details (only in development) */}
            {process.env.NODE_ENV === 'development' && this.state.error && (
              <div 
                className="mb-6 p-4 rounded border text-left overflow-auto max-h-[200px]"
                style={{ 
                  backgroundColor: '#f3f5ed',
                  borderColor: '#d45d5d',
                }}
              >
                <div className="font-['Cousine'] text-[11px] mb-2" style={{ color: '#8b3a3a' }}>
                  {this.state.error.name}
                </div>
                <div className="font-['Cousine'] text-[10px]" style={{ color: '#2a2d1e' }}>
                  {this.state.error.message}
                </div>
              </div>
            )}

            <div className="flex gap-3 justify-center">
              <BeetleButton 
                variant="primary" 
                size="md"
                onClick={this.handleReset}
              >
                Try Again
              </BeetleButton>
              
              <BeetleButton 
                variant="secondary" 
                size="md"
                onClick={() => window.location.href = '/'}
              >
                Go Home
              </BeetleButton>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
