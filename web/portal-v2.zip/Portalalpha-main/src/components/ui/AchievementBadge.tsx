import { useTheme } from '../../contexts/ThemeContext';

export type AchievementCategory = 'Distance' | 'SegmentChallenges' | 'Streak' | 'Leaderboard' | 'TSS' | 'WattsPerKg';

interface Achievement {
  id: string;
  type: AchievementCategory;
  name: string;
  description: string;
  threshold: number;
  progress: number;
  unlocked: boolean;
  unlockedAt?: string;
  gatesLevel?: number;
  emoji: string;
}

interface AchievementBadgeProps {
  achievement: Achievement;
  size?: 'sm' | 'md' | 'lg';
  showProgress?: boolean;
  onClick?: () => void;
}

export default function AchievementBadge({ 
  achievement, 
  size = 'md', 
  showProgress = true,
  onClick 
}: AchievementBadgeProps) {
  const { isDarkMode, colors } = useTheme();

  const sizeClasses = {
    sm: 'w-20 h-24',
    md: 'w-28 h-32',
    lg: 'w-36 h-40'
  };

  const emojiSizes = {
    sm: 'text-[24px]',
    md: 'text-[32px]',
    lg: 'text-[40px]'
  };

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const progressBg = isDarkMode ? 'rgba(0, 0, 0, 0.2)' : 'rgba(0, 0, 0, 0.05)';
  
  const progressPct = achievement.unlocked ? 100 : Math.min(100, (achievement.progress / achievement.threshold) * 100);

  return (
    <div
      className={`${sizeClasses[size]} rounded border p-3 flex flex-col items-center justify-between transition-all ${onClick ? 'cursor-pointer hover:scale-105' : ''}`}
      style={{
        backgroundColor: cardBg,
        borderColor: achievement.unlocked ? colors.accent : borderColor,
        opacity: achievement.unlocked ? 1 : 0.5,
        filter: achievement.unlocked ? 'none' : 'grayscale(0.8)',
      }}
      onClick={onClick}
    >
      {/* Emoji */}
      <div className={emojiSizes[size]} style={{ opacity: achievement.unlocked ? 1 : 0.4 }}>
        {achievement.emoji}
      </div>

      {/* Name */}
      <div className="text-center flex-1 flex items-center justify-center px-1">
        <div 
          className="font-['Inter'] font-bold text-[10px] leading-tight"
          style={{ color: achievement.unlocked ? colors.text : colors.textMuted }}
        >
          {achievement.name}
        </div>
      </div>

      {/* Progress or Gate Info */}
      {showProgress && (
        <div className="w-full">
          {achievement.unlocked ? (
            <div className="text-center">
              <div className="font-['Inter'] text-[8px] uppercase tracking-wide" style={{ color: colors.accent }}>
                ✓ Unlocked
              </div>
              {achievement.gatesLevel && (
                <div className="font-['Inter'] text-[7px] mt-0.5" style={{ color: colors.textMuted }}>
                  Gates L{achievement.gatesLevel}
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Progress Bar */}
              <div 
                className="h-1 rounded-full overflow-hidden mb-1"
                style={{ backgroundColor: progressBg }}
              >
                <div 
                  className="h-full transition-all duration-300"
                  style={{ 
                    width: `${progressPct}%`,
                    backgroundColor: colors.accent,
                  }}
                />
              </div>
              {/* Progress Text */}
              <div className="font-['Cousine'] text-[8px] text-center" style={{ color: colors.textMuted }}>
                {achievement.progress.toLocaleString()}/{achievement.threshold.toLocaleString()}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
