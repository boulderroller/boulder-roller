import { useTheme } from '../../contexts/ThemeContext';
import { BeetleButton } from './beetle-button';
import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon?: string | LucideIcon;
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  variant?: 'default' | 'compact';
}

export function EmptyState({ 
  icon, 
  title, 
  description, 
  actionLabel, 
  onAction,
  variant = 'default'
}: EmptyStateProps) {
  const { colors, isDarkMode } = useTheme();

  const IconComponent = icon && typeof icon !== 'string' ? icon : null;

  return (
    <div
      className={`border-[1px] rounded-[6px] text-center ${variant === 'compact' ? 'p-8' : 'p-12'}`}
      style={{
        backgroundColor: colors.bg,
        borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
      }}
    >
      {/* Icon */}
      <div className={variant === 'compact' ? 'mb-3' : 'mb-4'}>
        {IconComponent ? (
          <IconComponent 
            size={variant === 'compact' ? 40 : 48} 
            strokeWidth={1.5}
            style={{ 
              color: colors.textMuted,
              margin: '0 auto'
            }} 
          />
        ) : (
          <div 
            className={`${variant === 'compact' ? 'text-[40px]' : 'text-[64px]'}`}
          >
            {icon || '🪲'}
          </div>
        )}
      </div>

      {/* Title */}
      <h3 
        className={`font-['Inter'] font-bold ${variant === 'compact' ? 'text-[14px] mb-2' : 'text-[16px] mb-3'}`}
        style={{ color: colors.text }}
      >
        {title}
      </h3>

      {/* Description */}
      <p 
        className={`font-['Inter'] ${variant === 'compact' ? 'text-[12px] max-w-sm' : 'text-[13px] max-w-md'} mx-auto ${actionLabel ? 'mb-5' : ''}`}
        style={{ color: colors.textMuted }}
      >
        {description}
      </p>

      {/* Action Button */}
      {actionLabel && onAction && (
        <BeetleButton onClick={onAction} variant="primary">
          {actionLabel}
        </BeetleButton>
      )}
    </div>
  );
}
