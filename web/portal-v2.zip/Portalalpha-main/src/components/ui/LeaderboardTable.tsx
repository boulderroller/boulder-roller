import { useTheme } from '../../contexts/ThemeContext';
import { useNavigate } from 'react-router-dom';

interface LeaderboardEntry {
  rank: number;
  wallet: string;
  riderName: string;
  time: string;
  date: string;
  tss?: number;
  calDistributed?: number;
  isCurrentUser?: boolean;
}

interface LeaderboardTableProps {
  entries: LeaderboardEntry[];
  showCAL?: boolean;
  showTSS?: boolean;
  compact?: boolean;
}

export default function LeaderboardTable({ 
  entries, 
  showCAL = true, 
  showTSS = true,
  compact = false 
}: LeaderboardTableProps) {
  const { isDarkMode, colors } = useTheme();
  const navigate = useNavigate();

  const getBadge = (rank: number) => {
    if (rank === 1) return '🥇';
    if (rank === 2) return '🥈';
    if (rank === 3) return '🥉';
    return null;
  };

  const getRankColor = (rank: number) => {
    if (rank === 1) return '#c89b5c'; // Gold
    if (rank === 2) return '#a8b5a0'; // Silver
    if (rank === 3) return '#8b7355'; // Bronze
    return colors.text;
  };

  const getDistributionPct = (rank: number) => {
    // 70% to top 10: 30/20/15/10/8/6/5/3/2/1%
    const pcts = [30, 20, 15, 10, 8, 6, 5, 3, 2, 1];
    return rank <= 10 ? pcts[rank - 1] : 0;
  };

  const headerBg = isDarkMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.02)';
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.06)';
  const hoverBg = isDarkMode ? 'rgba(200, 155, 92, 0.05)' : 'rgba(200, 155, 92, 0.03)';
  const currentUserBg = isDarkMode ? 'rgba(200, 155, 92, 0.1)' : 'rgba(200, 155, 92, 0.08)';
  const cardBg = isDarkMode ? '#2a2d1e' : '#f5f3ed';

  return (
    <div className="overflow-hidden rounded-none border" style={{ borderColor, backgroundColor: cardBg }}>
      {/* Header */}
      <div 
        className={`px-5 ${compact ? 'py-2' : 'py-3'} border-b`}
        style={{ borderColor, backgroundColor: headerBg }}
      >
        <div className={`grid ${showCAL && showTSS ? 'grid-cols-[60px_2fr_1fr_100px_100px_120px]' : showCAL ? 'grid-cols-[60px_2fr_1fr_100px_120px]' : 'grid-cols-[60px_2fr_1fr_100px]'} gap-4 items-center`}>
          <div className="font-['Inter'] text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
            Rank
          </div>
          <div className="font-['Inter'] text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
            Rider
          </div>
          <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
            Time
          </div>
          <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
            Date
          </div>
          {showTSS && (
            <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
              TSS
            </div>
          )}
          {showCAL && (
            <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
              CAL
            </div>
          )}
        </div>
      </div>

      {/* Rows */}
      {entries.map((entry) => {
        const pct = getDistributionPct(entry.rank);
        const badge = getBadge(entry.rank);
        const rankColor = getRankColor(entry.rank);

        return (
          <div
            key={`${entry.wallet}-${entry.rank}`}
            className={`px-5 ${compact ? 'py-2' : 'py-3'} border-b transition-colors cursor-pointer`}
            style={{ 
              borderColor,
              backgroundColor: entry.isCurrentUser ? currentUserBg : 'transparent',
            }}
            onMouseEnter={(e) => {
              if (!entry.isCurrentUser) {
                e.currentTarget.style.backgroundColor = hoverBg;
              }
            }}
            onMouseLeave={(e) => {
              if (!entry.isCurrentUser) {
                e.currentTarget.style.backgroundColor = 'transparent';
              }
            }}
            onClick={() => navigate(`/rider/${entry.wallet}`)}
          >
            <div className={`grid ${showCAL && showTSS ? 'grid-cols-[60px_2fr_1fr_100px_100px_120px]' : showCAL ? 'grid-cols-[60px_2fr_1fr_100px_120px]' : 'grid-cols-[60px_2fr_1fr_100px]'} gap-4 items-center`}>
              {/* Rank */}
              <div className="flex items-center gap-2">
                {badge && <span className="text-[16px]">{badge}</span>}
                <span 
                  className="font-['Cousine'] text-[14px] font-bold"
                  style={{ color: rankColor }}
                >
                  #{entry.rank}
                </span>
              </div>

              {/* Rider */}
              <div>
                <div className="font-['Inter'] text-[13px] font-bold" style={{ color: colors.text }}>
                  {entry.riderName}
                  {entry.isCurrentUser && (
                    <span className="ml-2 text-[10px] uppercase tracking-wide" style={{ color: colors.accent }}>
                      YOU
                    </span>
                  )}
                </div>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  {entry.wallet.slice(0, 4)}...{entry.wallet.slice(-4)}
                </div>
              </div>

              {/* Time */}
              <div className="font-['Cousine'] text-[14px] font-bold text-right" style={{ color: colors.text }}>
                {entry.time}
              </div>

              {/* Date */}
              <div className="font-['Inter'] text-[11px] text-right" style={{ color: colors.textMuted }}>
                {entry.date}
              </div>

              {/* TSS */}
              {showTSS && entry.tss !== undefined && (
                <div className="font-['Cousine'] text-[13px] font-bold text-right" style={{ color: colors.text }}>
                  {entry.tss}
                </div>
              )}

              {/* CAL */}
              {showCAL && entry.calDistributed !== undefined && (
                <div className="text-right">
                  <div 
                    className="font-['Cousine'] text-[13px] font-bold"
                    style={{ 
                      color: '#c89b5c',
                      textShadow: '0 0 12px rgba(200, 155, 92, 0.2)'
                    }}
                  >
                    {entry.calDistributed.toLocaleString()}
                  </div>
                  {pct > 0 && (
                    <div className="font-['Inter'] text-[9px]" style={{ color: colors.textMuted }}>
                      {pct}% of pot
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}