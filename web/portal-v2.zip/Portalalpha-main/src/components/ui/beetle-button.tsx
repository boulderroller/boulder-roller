import { ButtonHTMLAttributes, forwardRef } from 'react';
import { useTheme } from '../../contexts/ThemeContext';

/**
 * BeetleButton - Brutalist button with proper interaction states
 * 
 * Key principles from the knowledge dump:
 * 1. Every interaction gets fast acknowledgment (<100ms)
 * 2. Shadow literally depresses on click (physical feedback)
 * 3. Hover lifts, active presses, disabled stays put
 * 4. Transitions are tight: 100-150ms
 */

interface BeetleButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}

export const BeetleButton = forwardRef<HTMLButtonElement, BeetleButtonProps>(
  ({ 
    variant = 'primary', 
    size = 'md', 
    isLoading = false,
    className = '',
    children,
    disabled,
    ...props 
  }, ref) => {
    const { isDarkMode, colors } = useTheme();

    // Size variants
    const sizeClasses = {
      sm: 'px-3 py-1.5 text-[12px]',
      md: 'px-4 py-2 text-[14px]',
      lg: 'px-6 py-2.5 text-[16px]',
    };

    // Base styles - always brutalist
    const baseClasses = `
      relative
      inline-flex items-center justify-center gap-2
      border rounded-none
      font-['Inter'] font-bold uppercase tracking-wide
      cursor-pointer
      transition-all duration-75 ease-out
      disabled:opacity-40 disabled:cursor-not-allowed
      ${sizeClasses[size]}
    `;

    // Variant-specific styles
    const getVariantStyles = () => {
      const borderColor = colors.border;
      
      switch (variant) {
        case 'primary':
          return {
            backgroundColor: colors.accent,
            borderColor: borderColor,
            color: 'white',
            // Resting shadow
            boxShadow: `2px 2px 0px 0px ${borderColor}`,
            // Hover: lift 1px, shadow grows slightly but sharp
            '--hover-shadow': `3px 3px 0px 0px ${borderColor}`,
            '--hover-transform': 'translateY(-1px)',
            '--hover-filter': 'brightness(1.05)',
            // Active: Full mechanical depression
            '--active-shadow': `0px 0px 0px 0px transparent`,
            '--active-transform': 'translateY(2px)',
            '--active-filter': 'brightness(0.95)',
          } as React.CSSProperties;

        case 'secondary':
          return {
            backgroundColor: isDarkMode ? '#3a3d2e' : 'white',
            borderColor: borderColor,
            color: colors.text,
            boxShadow: `2px 2px 0px 0px ${isDarkMode ? '#1a1d14' : borderColor}`,
            '--hover-shadow': `3px 3px 0px 0px ${isDarkMode ? '#1a1d14' : borderColor}`,
            '--hover-transform': 'translateY(-1px)',
            '--hover-filter': 'brightness(1.02)',
            // Active: Full depression
            '--active-shadow': `0px 0px 0px 0px transparent`,
            '--active-transform': 'translateY(2px)',
            '--active-filter': 'brightness(0.98)',
          } as React.CSSProperties;

        case 'danger':
          return {
            backgroundColor: '#d45d5d',
            borderColor: '#8b3a3a',
            color: 'white',
            boxShadow: `2px 2px 0px 0px #8b3a3a`,
            '--hover-shadow': `3px 3px 0px 0px #8b3a3a`,
            '--hover-transform': 'translateY(-1px)',
            '--hover-filter': 'brightness(1.05)',
            '--active-shadow': `0px 0px 0px 0px transparent`,
            '--active-transform': 'translateY(2px)',
            '--active-filter': 'brightness(0.95)',
          } as React.CSSProperties;

        case 'ghost':
          return {
            backgroundColor: 'transparent',
            borderColor: 'transparent',
            color: colors.text,
            boxShadow: 'none',
            '--hover-shadow': 'none',
            '--hover-transform': 'none',
            '--hover-filter': 'brightness(0.9)',
            '--active-shadow': 'none',
            '--active-transform': 'translateY(1px)',
            '--active-filter': 'brightness(0.8)',
          } as React.CSSProperties;
      }
    };

    const variantStyles = getVariantStyles();

    return (
      <button
        ref={ref}
        disabled={disabled || isLoading}
        className={`${baseClasses} ${className} beetle-button`}
        style={variantStyles}
        {...props}
      >
        {isLoading ? (
          <span className="font-mono text-xs tracking-tighter flex items-center gap-1">
            CALIBRATING<span className="animate-pulse">_</span>
          </span>
        ) : (
          children
        )}
      </button>
    );
  }
);

BeetleButton.displayName = 'BeetleButton';

// Add CSS for hover/active states
// This goes in globals.css or inline style tag
export const BEETLE_BUTTON_CSS = `
.beetle-button:not(:disabled):hover {
  box-shadow: var(--hover-shadow) !important;
  transform: var(--hover-transform) !important;
  filter: var(--hover-filter) !important;
}

.beetle-button:not(:disabled):active {
  box-shadow: var(--active-shadow) !important;
  transform: var(--active-transform) !important;
  filter: var(--active-filter) !important;
}

.beetle-button:disabled {
  transform: translateY(0) !important;
}
`;