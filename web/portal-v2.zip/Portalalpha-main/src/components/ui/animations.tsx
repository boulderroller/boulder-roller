import { ReactNode } from 'react';

interface FadeInProps {
  children: ReactNode;
  delay?: number;
  duration?: number;
  className?: string;
}

export function FadeIn({ children, delay = 0, duration = 0.3, className = '' }: FadeInProps) {
  return (
    <div
      className={className}
      style={{
        opacity: 0,
        transform: 'translateY(10px)',
        animation: `fadeIn ${duration}s ease-out ${delay}s forwards`,
      }}
    >
      {children}
    </div>
  );
}

interface SlideInProps {
  children: ReactNode;
  delay?: number;
  direction?: 'left' | 'right' | 'up' | 'down';
  className?: string;
}

export function SlideIn({ children, delay = 0, direction = 'up', className = '' }: SlideInProps) {
  const directionMap = {
    left: { x: -20, y: 0 },
    right: { x: 20, y: 0 },
    up: { x: 0, y: 20 },
    down: { x: 0, y: -20 },
  };

  return (
    <div
      className={className}
      style={{
        opacity: 0,
        transform: `translate(${directionMap[direction].x}px, ${directionMap[direction].y}px)`,
        animation: `slideIn ${0.4}s ease-out ${delay}s forwards`,
      }}
    >
      {children}
    </div>
  );
}

interface DungGlowProps {
  children: ReactNode;
  isActive?: boolean;
  className?: string;
}

export function DungGlow({ children, isActive = true, className = '' }: DungGlowProps) {
  return (
    <span
      className={`inline-block ${className}`}
      style={{
        filter: isActive ? 'drop-shadow(0 0 8px rgba(200, 155, 92, 0.4))' : 'none',
        animation: isActive ? 'dungPulse 2s ease-in-out infinite' : 'none',
      }}
    >
      {children}
    </span>
  );
}

interface PulseScaleProps {
  children: ReactNode;
  isActive?: boolean;
  className?: string;
}

export function PulseScale({ children, isActive = true, className = '' }: PulseScaleProps) {
  return (
    <div
      className={className}
      style={{
        animation: isActive ? 'pulseScale 2s ease-in-out infinite' : 'none',
      }}
    >
      {children}
    </div>
  );
}

interface StaggerChildrenProps {
  children: ReactNode;
  staggerDelay?: number;
  className?: string;
}

export function StaggerChildren({ children, staggerDelay = 0.05, className = '' }: StaggerChildrenProps) {
  return (
    <div
      className={className}
      style={{
        animation: `staggerChildren ${staggerDelay}s ease-out forwards`,
      }}
    >
      {children}
    </div>
  );
}

interface StaggerItemProps {
  children: ReactNode;
  className?: string;
}

export function StaggerItem({ children, className = '' }: StaggerItemProps) {
  return (
    <div
      className={className}
      style={{
        opacity: 0,
        transform: 'translateY(10px)',
        animation: `staggerItem 0.3s ease-out forwards`,
      }}
    >
      {children}
    </div>
  );
}

interface CountUpProps {
  value: number;
  duration?: number;
  className?: string;
  prefix?: string;
  suffix?: string;
}

export function CountUp({ value, duration = 0.8, className = '', prefix = '', suffix = '' }: CountUpProps) {
  return (
    <div
      className={className}
      style={{
        opacity: 0,
        animation: `countUp ${duration}s ease-out forwards`,
      }}
    >
      <div
        className={className}
        style={{
          innerText: 0,
          animation: `countUpValue ${duration}s ease-out forwards`,
        }}
        onUpdate={(latest: any) => {
          if (typeof latest.innerText === 'number') {
            return `${prefix}${Math.round(latest.innerText)}${suffix}`;
          }
        }}
      >
        {prefix}{value}{suffix}
      </div>
    </div>
  );
}

interface ShakeProps {
  children: ReactNode;
  trigger?: boolean;
  className?: string;
}

export function Shake({ children, trigger = false, className = '' }: ShakeProps) {
  return (
    <div
      className={className}
      style={{
        animation: trigger ? 'shake 0.4s' : 'none',
      }}
    >
      {children}
    </div>
  );
}

interface ModalFadeProps {
  children: ReactNode;
  className?: string;
}

export function ModalFade({ children, className = '' }: ModalFadeProps) {
  return (
    <div
      className={className}
      style={{
        opacity: 0,
        transform: 'scale(0.95)',
        animation: `modalFade 0.2s ease-out forwards`,
      }}
    >
      {children}
    </div>
  );
}