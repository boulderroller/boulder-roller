import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { useTheme } from '../../contexts/ThemeContext';

interface PointsCounterProps {
  value: number;
  delta?: number;
  label?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showDelta?: boolean;
  animated?: boolean;
}

export default function PointsCounter({ 
  value, 
  delta = 0,
  label,
  size = 'lg',
  showDelta = false,
  animated = true
}: PointsCounterProps) {
  const { colors } = useTheme();
  const [displayValue, setDisplayValue] = useState(value);
  const [showDeltaAnim, setShowDeltaAnim] = useState(false);

  const sizeClasses = {
    sm: 'text-[24px]',
    md: 'text-[36px]',
    lg: 'text-[52px]',
    xl: 'text-[72px]'
  };

  const labelSizes = {
    sm: 'text-[9px]',
    md: 'text-[10px]',
    lg: 'text-[11px]',
    xl: 'text-[12px]'
  };

  useEffect(() => {
    if (animated && value !== displayValue) {
      // Animate counting up
      const duration = 1000;
      const steps = 30;
      const increment = (value - displayValue) / steps;
      let current = displayValue;
      
      const interval = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= value) || (increment < 0 && current <= value)) {
          setDisplayValue(value);
          clearInterval(interval);
        } else {
          setDisplayValue(Math.round(current));
        }
      }, duration / steps);

      return () => clearInterval(interval);
    } else {
      setDisplayValue(value);
    }
  }, [value, displayValue, animated]);

  useEffect(() => {
    if (showDelta && delta > 0) {
      setShowDeltaAnim(true);
      const timeout = setTimeout(() => setShowDeltaAnim(false), 2000);
      return () => clearTimeout(timeout);
    }
  }, [delta, showDelta]);

  return (
    <div className="relative inline-flex flex-col items-center">
      <motion.div
        className={`font-['Cousine'] ${sizeClasses[size]} font-bold leading-none`}
        style={{ 
          color: '#c89b5c',
          textShadow: '0 0 24px rgba(200, 155, 92, 0.4)'
        }}
        animate={animated ? { scale: [1, 1.05, 1] } : {}}
        transition={{ duration: 0.3 }}
        key={displayValue}
      >
        {displayValue.toLocaleString()}
      </motion.div>
      
      {label && (
        <div 
          className={`font-['Inter'] ${labelSizes[size]} uppercase tracking-wide mt-1`}
          style={{ color: colors.textMuted }}
        >
          {label}
        </div>
      )}

      {/* Delta Animation */}
      {showDelta && showDeltaAnim && delta > 0 && (
        <motion.div
          className="absolute top-0 right-0 font-['Cousine'] text-[18px] font-bold"
          style={{ color: '#8b9475' }}
          initial={{ opacity: 1, y: 0, x: 0 }}
          animate={{ opacity: 0, y: -20, x: 10 }}
          transition={{ duration: 2 }}
        >
          +{delta.toLocaleString()}
        </motion.div>
      )}
    </div>
  );
}
