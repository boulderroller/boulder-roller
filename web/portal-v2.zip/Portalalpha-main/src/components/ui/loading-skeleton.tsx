import { useTheme } from '../../contexts/ThemeContext';
import { getDivider, getOverlay } from '../../constants/colors';

interface LoadingSkeletonProps {
  variant?: 'card' | 'table-row' | 'stat' | 'activity-card' | 'activity-feed-item' | 'ride-view' | 'map' | 'chart';
  count?: number;
  height?: number;
}

export function LoadingSkeleton({ variant = 'card', count = 1, height }: LoadingSkeletonProps) {
  const { colors, isDarkMode } = useTheme();

  const skeletonBg = isDarkMode 
    ? 'rgba(208, 216, 191, 0.08)' 
    : 'rgba(42, 45, 30, 0.06)';

  const skeletonHighlight = isDarkMode 
    ? 'rgba(208, 216, 191, 0.12)' 
    : 'rgba(42, 45, 30, 0.1)';

  const baseClasses = "rounded-[4px] animate-pulse";

  // New: Map Skeleton (for lazy loaded map)
  if (variant === 'map') {
    return (
      <div className="rounded border" style={{ borderColor: getOverlay(isDarkMode) }}>
        <div 
          className="animate-pulse" 
          style={{ 
            backgroundColor: skeletonBg,
            height: height || 300
          }}
        />
      </div>
    );
  }

  // New: Chart Skeleton (for lazy loaded charts)
  if (variant === 'chart') {
    return (
      <div className="rounded border" style={{ borderColor: getOverlay(isDarkMode) }}>
        <div 
          className="animate-pulse" 
          style={{ 
            backgroundColor: skeletonBg,
            height: height || 250
          }}
        />
      </div>
    );
  }

  // New: Full RideView Skeleton (for loading state)
  if (variant === 'ride-view') {
    const borderColor = getOverlay(isDarkMode);
    const dividerColor = getDivider(isDarkMode);

    return (
      <div className="max-w-[1200px] mx-auto p-6 space-y-5">
        {/* Header Skeleton */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-7 h-7 rounded animate-pulse" style={{ backgroundColor: skeletonBg }} />
            <div className="h-7 w-48 rounded animate-pulse" style={{ backgroundColor: skeletonHighlight }} />
          </div>
          <div className="h-3 w-32 rounded animate-pulse" style={{ backgroundColor: skeletonBg }} />
        </div>

        <div className="grid grid-cols-[1fr_300px] gap-5">
          {/* Left Column */}
          <div className="space-y-5">
            {/* Hero Stats Skeleton */}
            <div className="rounded border p-6" style={{ backgroundColor: colors.bg, borderColor }}>
              <div className="grid grid-cols-4 gap-8">
                {[1,2,3,4].map(i => (
                  <div key={i}>
                    <div className="h-[42px] w-[100px] rounded mb-1 animate-pulse" style={{ backgroundColor: skeletonHighlight }} />
                    <div className="h-[11px] w-[60px] rounded animate-pulse" style={{ backgroundColor: skeletonBg }} />
                  </div>
                ))}
              </div>
            </div>

            {/* Map Skeleton */}
            <div className="rounded border p-5" style={{ backgroundColor: colors.bg, borderColor }}>
              <div className="h-3 w-20 rounded mb-4 animate-pulse" style={{ backgroundColor: skeletonBg }} />
              <div className="h-[300px] rounded animate-pulse" style={{ backgroundColor: skeletonBg }} />
            </div>
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            {[1,2,3].map(i => (
              <div key={i} className="rounded border p-4" style={{ backgroundColor: colors.bg, borderColor }}>
                <div className="h-3 w-20 rounded mb-3 animate-pulse" style={{ backgroundColor: skeletonBg }} />
                <div className="h-6 w-full rounded animate-pulse" style={{ backgroundColor: skeletonHighlight }} />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // New: Activity Feed Item Skeleton (matches ActivityFeed list items)
  if (variant === 'activity-feed-item') {
    const dividerColor = getDivider(isDarkMode);
    
    return (
      <>
        {Array.from({ length: count }).map((_, index) => (
          <div
            key={index}
            className="px-5 py-4 border-t-[1px]"
            style={{ borderColor: dividerColor }}
          >
            <div className="flex items-start gap-3">
              {/* Icon skeleton */}
              <div 
                className="w-10 h-10 rounded-[8px] animate-pulse flex-shrink-0"
                style={{ backgroundColor: skeletonBg }}
              />
              
              {/* Content skeleton */}
              <div className="flex-1 min-w-0 space-y-2">
                <div 
                  className={`h-4 w-48 ${baseClasses}`}
                  style={{ backgroundColor: skeletonHighlight }}
                />
                <div className="flex items-center gap-2">
                  <div 
                    className={`h-3 w-20 ${baseClasses}`}
                    style={{ backgroundColor: skeletonBg }}
                  />
                  <div 
                    className={`h-2 w-2 rounded-full ${baseClasses}`}
                    style={{ backgroundColor: skeletonBg }}
                  />
                  <div 
                    className={`h-3 w-16 ${baseClasses}`}
                    style={{ backgroundColor: skeletonBg }}
                  />
                </div>
              </div>
              
              {/* Dung badge skeleton */}
              <div 
                className="px-3 py-1.5 rounded-[6px] flex-shrink-0 animate-pulse"
                style={{ 
                  backgroundColor: skeletonBg,
                  width: '48px',
                  height: '32px'
                }}
              />
            </div>
          </div>
        ))}
      </>
    );
  }

  if (variant === 'activity-card') {
    return (
      <>
        {Array.from({ length: count }).map((_, index) => (
          <div
            key={index}
            className="border-[1px] rounded-[6px] p-6"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div 
                  className={`h-4 w-32 mb-2 ${baseClasses}`}
                  style={{ backgroundColor: skeletonBg }}
                />
                <div 
                  className={`h-5 w-64 ${baseClasses}`}
                  style={{ backgroundColor: skeletonHighlight }}
                />
              </div>
              <div 
                className={`h-8 w-16 ${baseClasses}`}
                style={{ backgroundColor: skeletonBg }}
              />
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i}>
                  <div 
                    className={`h-3 w-16 mb-2 ${baseClasses}`}
                    style={{ backgroundColor: skeletonBg }}
                  />
                  <div 
                    className={`h-6 w-12 ${baseClasses}`}
                    style={{ backgroundColor: skeletonHighlight }}
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </>
    );
  }

  if (variant === 'table-row') {
    return (
      <>
        {Array.from({ length: count }).map((_, index) => (
          <div
            key={index}
            className="grid grid-cols-8 gap-4 px-5 py-4 border-b-[1px]"
            style={{
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.08)`,
            }}
          >
            <div className="col-span-1">
              <div 
                className={`h-4 w-16 ${baseClasses}`}
                style={{ backgroundColor: skeletonBg }}
              />
            </div>
            <div className="col-span-3">
              <div 
                className={`h-4 w-full mb-2 ${baseClasses}`}
                style={{ backgroundColor: skeletonHighlight }}
              />
              <div 
                className={`h-3 w-32 ${baseClasses}`}
                style={{ backgroundColor: skeletonBg }}
              />
            </div>
            <div className="col-span-1">
              <div 
                className={`h-4 w-12 ${baseClasses}`}
                style={{ backgroundColor: skeletonBg }}
              />
            </div>
            <div className="col-span-1">
              <div 
                className={`h-4 w-16 ${baseClasses}`}
                style={{ backgroundColor: skeletonBg }}
              />
            </div>
            <div className="col-span-1">
              <div 
                className={`h-4 w-12 ${baseClasses}`}
                style={{ backgroundColor: skeletonBg }}
              />
            </div>
            <div className="col-span-1">
              <div 
                className={`h-6 w-14 ${baseClasses}`}
                style={{ backgroundColor: skeletonHighlight }}
              />
            </div>
          </div>
        ))}
      </>
    );
  }

  if (variant === 'stat') {
    return (
      <>
        {Array.from({ length: count }).map((_, index) => (
          <div
            key={index}
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className={`h-3 w-20 mb-2 ${baseClasses}`}
              style={{ backgroundColor: skeletonBg }}
            />
            <div 
              className={`h-8 w-16 ${baseClasses}`}
              style={{ backgroundColor: skeletonHighlight }}
            />
          </div>
        ))}
      </>
    );
  }

  // Default: card variant
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <div
          key={index}
          className="border-[1px] rounded-[6px] p-6"
          style={{
            backgroundColor: colors.bg,
            borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
          }}
        >
          <div 
            className={`h-5 w-48 mb-4 ${baseClasses}`}
            style={{ backgroundColor: skeletonHighlight }}
          />
          <div 
            className={`h-4 w-full mb-2 ${baseClasses}`}
            style={{ backgroundColor: skeletonBg }}
          />
          <div 
            className={`h-4 w-3/4 mb-2 ${baseClasses}`}
            style={{ backgroundColor: skeletonBg }}
          />
          <div 
            className={`h-4 w-5/6 ${baseClasses}`}
            style={{ backgroundColor: skeletonBg }}
          />
        </div>
      ))}
    </>
  );
}