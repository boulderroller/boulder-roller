import { useTheme } from '../../contexts/ThemeContext';

interface StatPillProps {
  label: string;
  value: string | number;
  icon?: string;
  variant?: 'default' | 'accent' | 'muted';
  size?: 'sm' | 'md' | 'lg';
}

export default function StatPill({ 
  label, 
  value, 
  icon, 
  variant = 'default',
  size = 'md' 
}: StatPillProps) {
  const { isDarkMode, colors } = useTheme();

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';

  const getValueColor = () => {
    if (variant === 'accent') return colors.accent;
    if (variant === 'muted') return colors.textMuted;
    return colors.text;
  };

  const getValueStyle = () => {
    if (variant === 'accent') {
      return {
        color: '#c89b5c',
        textShadow: '0 0 16px rgba(200, 155, 92, 0.3)'
      };
    }
    return { color: getValueColor() };
  };

  const sizeClasses = {
    sm: {
      value: 'text-[20px]',
      label: 'text-[9px]',
      padding: 'px-3 py-2'
    },
    md: {
      value: 'text-[28px]',
      label: 'text-[10px]',
      padding: 'px-4 py-3'
    },
    lg: {
      value: 'text-[36px]',
      label: 'text-[11px]',
      padding: 'px-5 py-4'
    }
  };

  const { value: valueClass, label: labelClass, padding } = sizeClasses[size];

  return (
    <div 
      className={`rounded-none border ${padding} flex flex-col items-center justify-center text-center`}
      style={{ backgroundColor: cardBg, borderColor }}
    >
      {icon && <div className="text-[20px] mb-1">{icon}</div>}
      <div 
        className={`font-['Cousine'] ${valueClass} font-bold leading-none mb-1`}
        style={getValueStyle()}
      >
        {typeof value === 'number' ? value.toLocaleString() : value}
      </div>
      <div 
        className={`font-['Inter'] ${labelClass} uppercase tracking-wide`}
        style={{ color: colors.textMuted }}
      >
        {label}
      </div>
    </div>
  );
}
