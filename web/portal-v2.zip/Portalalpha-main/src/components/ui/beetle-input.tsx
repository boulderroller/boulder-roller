import { InputHTMLAttributes, forwardRef, TextareaHTMLAttributes } from 'react';
import { useTheme } from '../../contexts/ThemeContext';

/**
 * BeetleInput - Form input with proper focus/hover states
 * 
 * Key principles:
 * 1. Hover advertises interactivity (border color shift)
 * 2. Focus gets clear ring (WCAG 2.1 compliant)
 * 3. Never just remove outline without replacement
 * 4. Transitions are fast (120ms)
 */

interface BeetleInputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
}

export const BeetleInput = forwardRef<HTMLInputElement, BeetleInputProps>(
  ({ error = false, className = '', ...props }, ref) => {
    const { isDarkMode, colors } = useTheme();

    const inputBg = isDarkMode ? '#3a3d2e' : 'white';
    const borderColor = error ? '#d45d5d' : colors.border;
    const hoverBorder = error ? '#8b3a3a' : '#8b6f47';
    const focusBorder = error ? '#d45d5d' : '#c89b5c';

    return (
      <input
        ref={ref}
        className={`
          w-full px-3 py-2.5
          border-[2px] rounded-[8px]
          font-['Inter'] text-[14px]
          transition-all duration-[120ms] ease-out
          placeholder:opacity-50
          disabled:opacity-40 disabled:cursor-not-allowed
          ${className}
        `}
        style={{
          backgroundColor: inputBg,
          borderColor: borderColor,
          color: colors.text,
          // Custom properties for hover/focus
          '--hover-border': hoverBorder,
          '--focus-border': focusBorder,
          '--focus-ring': `${focusBorder}33`, // 20% opacity
        } as React.CSSProperties}
        {...props}
      />
    );
  }
);

BeetleInput.displayName = 'BeetleInput';

// Textarea variant
interface BeetleTextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean;
}

export const BeetleTextarea = forwardRef<HTMLTextAreaElement, BeetleTextareaProps>(
  ({ error = false, className = '', ...props }, ref) => {
    const { isDarkMode, colors } = useTheme();

    const inputBg = isDarkMode ? '#3a3d2e' : 'white';
    const borderColor = error ? '#d45d5d' : colors.border;
    const hoverBorder = error ? '#8b3a3a' : '#8b6f47';
    const focusBorder = error ? '#d45d5d' : '#c89b5c';

    return (
      <textarea
        ref={ref}
        className={`
          w-full px-3 py-2.5
          border-[2px] rounded-[8px]
          font-['Inter'] text-[14px]
          transition-all duration-[120ms] ease-out
          placeholder:opacity-50
          disabled:opacity-40 disabled:cursor-not-allowed
          resize-none
          ${className}
        `}
        style={{
          backgroundColor: inputBg,
          borderColor: borderColor,
          color: colors.text,
          '--hover-border': hoverBorder,
          '--focus-border': focusBorder,
          '--focus-ring': `${focusBorder}33`,
        } as React.CSSProperties}
        {...props}
      />
    );
  }
);

BeetleTextarea.displayName = 'BeetleTextarea';

// CSS for hover/focus states
export const BEETLE_INPUT_CSS = `
.beetle-input:not(:disabled):hover,
input:not(:disabled):hover,
textarea:not(:disabled):hover {
  border-color: var(--hover-border) !important;
}

.beetle-input:focus,
input:focus,
textarea:focus {
  outline: none;
  border-color: var(--focus-border) !important;
  box-shadow: 0 0 0 3px var(--focus-ring) !important;
}

/* High contrast focus for accessibility */
.beetle-input:focus-visible,
input:focus-visible,
textarea:focus-visible {
  outline: 2px solid var(--focus-border);
  outline-offset: 2px;
}
`;
