import { HTMLAttributes, forwardRef } from 'react';
import { useTheme } from '../../contexts/ThemeContext';

/**
 * BeetleCard - Interactive card surface
 * 
 * Key principles:
 * 1. If clickable, whole surface responds (not mystery meat)
 * 2. Hover lifts 2px (more than buttons for surface hierarchy)
 * 3. Active returns to resting (subtle press)
 * 4. Non-interactive variant for static content
 */

interface BeetleCardProps extends HTMLAttributes<HTMLButtonElement | HTMLDivElement> {
  interactive?: boolean;
  onClick?: () => void;
  variant?: 'default' | 'flat';
}

export const BeetleCard = forwardRef<HTMLButtonElement | HTMLDivElement, BeetleCardProps>(
  ({ 
    interactive = false, 
    variant = 'default',
    className = '', 
    children, 
    onClick,
    ...props 
  }, ref) => {
    const { isDarkMode, colors } = useTheme();

    const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
    const shadowColor = isDarkMode ? '#0a0d04' : colors.border;

    const baseClasses = `
      rounded-none border-[3px]
      transition-all duration-[150ms] ease-out
      ${className}
    `;

    const baseStyles: React.CSSProperties = {
      backgroundColor: cardBg,
      borderColor: colors.border,
    };

    // Interactive card (clickable)
    if (interactive && onClick) {
      return (
        <button
          ref={ref as React.Ref<HTMLButtonElement>}
          onClick={onClick}
          className={`
            ${baseClasses}
            cursor-pointer
            text-left
            w-full
          `}
          style={{
            ...baseStyles,
            boxShadow: variant === 'default' ? `4px 4px 0px 0px ${shadowColor}` : 'none',
            transform: 'translateY(0)',
            // Hover: lift 2px
            '--hover-shadow': variant === 'default' ? `5px 5px 0px 0px ${shadowColor}` : `0 8px 24px rgba(0,0,0,0.12)`,
            '--hover-transform': 'translateY(-2px)',
            '--hover-bg': isDarkMode ? '#3a3d2e' : '#f3f5ed',
            // Active: return to resting
            '--active-shadow': variant === 'default' ? `4px 4px 0px 0px ${shadowColor}` : `0 2px 8px rgba(0,0,0,0.08)`,
            '--active-transform': 'translateY(0)',
          } as React.CSSProperties}
          {...(props as HTMLAttributes<HTMLButtonElement>)}
        >
          {children}
        </button>
      );
    }

    // Static card (non-interactive)
    return (
      <div
        ref={ref as React.Ref<HTMLDivElement>}
        className={baseClasses}
        style={{
          ...baseStyles,
          boxShadow: variant === 'default' ? `4px 4px 0px 0px ${shadowColor}` : 'none',
        }}
        {...(props as HTMLAttributes<HTMLDivElement>)}
      >
        {children}
      </div>
    );
  }
);

BeetleCard.displayName = 'BeetleCard';

// CSS for interactive cards
export const BEETLE_CARD_CSS = `
button.beetle-card:hover {
  box-shadow: var(--hover-shadow) !important;
  transform: var(--hover-transform) !important;
  background-color: var(--hover-bg) !important;
}

button.beetle-card:active {
  box-shadow: var(--active-shadow) !important;
  transform: var(--active-transform) !important;
}
`;
