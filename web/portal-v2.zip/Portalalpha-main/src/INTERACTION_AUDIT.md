# BoulderRoller Interactive States Audit
**Philosophy:** "Nothing feels dead. Everything responds within 100ms."

---

## ✅ WHAT'S WORKING

### InviteGate.tsx
- ✅ Beetle button has hover scale (110%) and active scale (95%)
- ✅ Glow effect on hover (opacity transition)
- ✅ Clear affordance: "this is clickable"

### WalletConnect.tsx (all 3 steps)
- ✅ Close buttons have hover states
- ✅ Wallet selection buttons hover properly
- ✅ "Retry"/"Switch wallet" buttons functional
- ✅ Countdown timer provides live feedback
- ✅ Auto-completes after 10s (no dead spin)
- ✅ Color palette unified (beetle amber/brown system)

### ProfileEditPanel.tsx
- ✅ Theme buttons: active state (border + shadow), hover opacity change
- ✅ Dark mode toggle: smooth translation animation
- ✅ Units toggle: clear active state (amber bg)
- ✅ Menu arrows translate on hover (Edit Profile, Export Data)
- ✅ Input focus states exist (outline transition)

### ThemeContext.tsx
- ✅ Theme system provides consistent colors

---

## ❌ WHAT NEEDS FIXING

### 1. **TopNav.tsx - Critical Issues**

#### Profile Dropdown Button (line 60-94)
**Current state:**
```tsx
<button
  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
  className="border-[2px] rounded-[10px] px-4 py-2 flex items-center gap-2.5 transition-all"
  style={{
    backgroundColor: isDarkMode ? '#3a3d2e' : 'white',
    borderColor: colors.border,
    boxShadow: `3px 3px 0px 0px ${isDarkMode ? '#1a1d14' : colors.border}`,
  }}
>
```

**Problems:**
- ❌ No hover state (background, shadow lift)
- ❌ No active/pressed state (shadow depress)
- ❌ Has brutalist shadow but doesn't use it for feedback
- ❌ transition-all is lazy (specify what transitions)
- ❌ No cursor: pointer

**Fix needed:**
```css
/* Resting */
box-shadow: 3px 3px 0px 0px;

/* Hover */
box-shadow: 4px 4px 0px 0px;
transform: translateY(-1px);
filter: brightness(1.02);

/* Active */
box-shadow: 1px 1px 0px 0px;
transform: translateY(2px);

/* Transition */
transition: box-shadow 120ms ease-out, transform 120ms ease-out, filter 120ms ease-out;
```

#### Connect Button (line 119-129)
**Current state:**
```tsx
<button
  className="border-[2px] rounded-[10px] px-6 py-2 font-['Inter'] font-bold text-[14px] uppercase tracking-wide transition-all"
  style={{
    backgroundColor: colors.accent,
    borderColor: colors.border,
    color: 'white',
    boxShadow: `3px 3px 0px 0px ${colors.border}`,
  }}
>
  Connect
</button>
```

**Problems:**
- ❌ No hover state
- ❌ No active/pressed state
- ❌ Has shadow but doesn't respond
- ❌ No cursor: pointer

**Same fix pattern applies**

---

### 2. **ActivityFeed.tsx - Mystery Meat Cards**

#### Activity Cards (line 110)
**Current state:**
```tsx
<div key={activity.id} className="p-4 hover:bg-[#f3f5ed]/30 transition-colors">
```

**Problems:**
- ❌ Hover color change is too subtle (30% opacity tan on tan bg)
- ❌ No cursor change (doesn't advertise clickability)
- ❌ No active state
- ⚠️ Cards probably should be clickable but aren't buttons/links
- ❌ If they're not clickable, remove hover state entirely

**Decision needed:** Should activity cards be clickable?
- If YES → make them `<button>` with proper states
- If NO → remove hover state (dead hover is worse than no hover)

**If clickable, fix:**
```tsx
<button 
  key={activity.id} 
  className="w-full p-4 transition-all text-left cursor-pointer"
  style={{
    backgroundColor: cardBg,
  }}
  onMouseEnter={(e) => {
    e.currentTarget.style.backgroundColor = isDarkMode ? '#3a3d2e' : '#f3f5ed';
    e.currentTarget.style.transform = 'translateY(-1px)';
  }}
  onMouseLeave={(e) => {
    e.currentTarget.style.backgroundColor = cardBg;
    e.currentTarget.style.transform = 'translateY(0)';
  }}
  onMouseDown={(e) => {
    e.currentTarget.style.transform = 'translateY(1px)';
  }}
  onMouseUp={(e) => {
    e.currentTarget.style.transform = 'translateY(-1px)';
  }}
  onClick={() => handleActivityClick(activity.id)}
>
```

#### Dung Badges (line 160-167)
**Current state:**
```tsx
<div 
  className="px-3 py-1.5 rounded-[8px] border-[2px] border-[#2a2d1e] shadow-[3px_3px_0px_0px_#2a2d1e] flex-shrink-0"
  style={{ backgroundColor: activity.color }}
>
```

**Problems:**
- ❌ Static despite having brutalist shadow
- ⚠️ Should these be clickable for "view dung details"?
- ❌ If interactive, needs states
- ✅ If purely informational, keep as-is

---

### 3. **ProfileDropdown.tsx - Incomplete Interactions**

#### Disconnect Button (line 149-159)
**Current state:**
```tsx
<button
  onClick={onDisconnect}
  className="w-full px-4 py-2 border-[2px] rounded-[8px] font-['Inter'] font-bold text-[12px] uppercase tracking-wide transition-all"
  style={{
    backgroundColor: isDarkMode ? '#3a3d2e' : 'white',
    borderColor: colors.border,
    color: colors.text,
  }}
>
  Disconnect
</button>
```

**Problems:**
- ❌ No hover state
- ❌ No active/pressed state
- ❌ Critical action (disconnect) should have visual weight
- ❌ Could use red accent on hover for danger action

**Fix:**
```tsx
/* Add hover/active handlers or CSS classes */
hover:bg-[#d4c993] hover:border-[#2a2d1e]
active:shadow-[1px_1px_0px_0px_#2a2d1e] active:translate-y-[2px]
```

#### Menu Items (lines 96-144)
**Current state:**
```tsx
<button
  onClick={onOpenEditPanel}
  className={`w-full px-4 py-2.5 ${hoverBg} transition-colors flex items-center justify-between group`}
>
```

**Problems:**
- ✅ Hover background works
- ✅ Arrow translates on hover (nice!)
- ❌ No active/pressed state when clicking
- ❌ transition-colors only (should also transition transform for arrow)

**Fix:**
```tsx
className={`... active:bg-opacity-80`}
/* Arrow already has group-hover:translate-x-0.5, add active state */
```

---

### 4. **ProfileEditPanel.tsx - Form Inputs**

#### Text Inputs (lines 83-92, 106-115, etc.)
**Current state:**
```tsx
<input
  className={`w-full px-3 py-2.5 ${inputBg} border-[2px] rounded-[8px] font-['Inter'] text-[14px] focus:outline-none transition-all`}
  style={{ 
    borderColor: colors.border, 
    color: colors.text 
  }}
/>
```

**Problems:**
- ⚠️ focus:outline-none removes native focus (accessibility issue)
- ❌ No visible focus state replacement
- ❌ No hover state

**Fix:**
```tsx
focus:border-[#c89b5c] focus:shadow-[0_0_0_3px_rgba(200,155,92,0.2)]
hover:border-[#8b6f47]
transition: border-color 120ms ease-out, box-shadow 120ms ease-out
```

#### Save Button (needs to be added - currently implicit in handleSave)
**Missing:** No primary "Save" button at bottom of panel
**Needs:** Brutalist button with full state treatment

#### Close X Button (line 64-73)
**Current state:**
```tsx
<button
  onClick={onClose}
  className="transition-colors"
  style={{ color: colors.textMuted }}
>
```

**Problems:**
- ❌ No hover state
- ❌ Should be in a button-shaped container (like WalletConnect close)
- ❌ No active state

**Fix:** Match WalletConnect close button style

---

### 5. **SetupModal.tsx** (need to read)
- Need to audit form inputs and submit button

### 6. **InviteModal.tsx** (need to read)
- Need to audit invite code input and submit

---

## 🎯 INTERACTION PATTERN SYSTEM

### **Brutalist Button States (3px shadow)**
```css
.btn-beetle {
  /* Resting */
  box-shadow: 3px 3px 0px 0px #2a2d1e;
  transform: translateY(0);
  transition: box-shadow 120ms ease-out, transform 120ms ease-out;
  cursor: pointer;
}

.btn-beetle:hover {
  box-shadow: 4px 4px 0px 0px #2a2d1e;
  transform: translateY(-1px);
}

.btn-beetle:active {
  box-shadow: 1px 1px 0px 0px #2a2d1e;
  transform: translateY(2px);
}

.btn-beetle:disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: 3px 3px 0px 0px #2a2d1e; /* stays at resting */
  transform: translateY(0);
}
```

### **Card Hover (2px lift)**
```css
.card-beetle {
  transform: translateY(0);
  transition: transform 150ms ease-out, box-shadow 150ms ease-out;
  cursor: pointer;
}

.card-beetle:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.12);
}

.card-beetle:active {
  transform: translateY(0);
}
```

### **Input Focus**
```css
.input-beetle {
  border: 2px solid #d0d8bf;
  transition: border-color 120ms ease-out, box-shadow 120ms ease-out;
}

.input-beetle:hover {
  border-color: #8b6f47;
}

.input-beetle:focus {
  border-color: #c89b5c;
  box-shadow: 0 0 0 3px rgba(200,155,92,0.2);
  outline: none;
}
```

### **Link States**
```css
.link-beetle {
  color: #2a2d1e;
  transition: color 120ms ease-out;
  cursor: pointer;
}

.link-beetle:hover {
  color: #c89b5c;
}

.link-beetle:active {
  color: #8b6f47;
}
```

---

## 📋 PRIORITY FIX LIST

### **P0 - Critical (Dead Interactive Elements)**
1. TopNav profile button - add hover/active states
2. TopNav connect button - add hover/active states
3. ProfileDropdown disconnect button - add hover/active states
4. ProfileEditPanel close button - match WalletConnect style
5. ProfileEditPanel inputs - add focus states (accessibility!)

### **P1 - High (Mystery Meat)**
6. ActivityFeed cards - decide if clickable, fix accordingly
7. ProfileDropdown menu items - add active states
8. ProfileEditPanel save button - needs to exist with full states

### **P2 - Polish**
9. Dung badges - consider hover acknowledgment if they'll be interactive
10. Theme selector buttons - active state could depress shadow
11. Units toggle buttons - active state could depress
12. Dark mode toggle - could have hover state

---

## 🧪 TESTING CHECKLIST

For each interactive element, verify:
- [ ] **Resting state** - clear affordance (looks clickable)
- [ ] **Hover state** - immediate feedback (<100ms)
- [ ] **Active/pressed state** - tactile depression
- [ ] **Focus state** - keyboard navigation works
- [ ] **Disabled state** - clearly non-interactive
- [ ] **Loading state** - if async (spinners, shimmer)
- [ ] **Transition timings** - 100-150ms for fast feedback
- [ ] **Cursor** - pointer on interactive, default on static
- [ ] **Semantic HTML** - `<button>` for actions, `<a>` for nav
- [ ] **Accessibility** - focus visible, screen reader friendly

---

## 🎨 DESIGN TOKENS TO CREATE

```tsx
// /styles/interactions.ts
export const TRANSITIONS = {
  fast: '100ms ease-out',
  standard: '150ms ease-out',
  slow: '250ms ease-out',
} as const;

export const SHADOWS = {
  brutalist: {
    sm: '2px 2px 0px 0px',
    md: '3px 3px 0px 0px',
    lg: '4px 4px 0px 0px',
    active: '1px 1px 0px 0px',
  },
  soft: {
    sm: '0 2px 8px rgba(0,0,0,0.06)',
    md: '0 8px 24px rgba(0,0,0,0.12)',
    lg: '0 16px 40px rgba(0,0,0,0.16)',
  },
} as const;

export const TRANSFORMS = {
  lift: {
    sm: 'translateY(-1px)',
    md: 'translateY(-2px)',
    lg: 'translateY(-4px)',
  },
  press: {
    sm: 'translateY(1px)',
    md: 'translateY(2px)',
    lg: 'translateY(4px)',
  },
  scale: {
    grow: 'scale(1.05)',
    shrink: 'scale(0.95)',
  },
} as const;
```

---

**Next Steps:**
1. Read SetupModal.tsx and InviteModal.tsx
2. Create reusable button components with built-in states
3. Systematically fix P0 items
4. Add state management for loading/async actions
5. Test with keyboard navigation
6. Verify focus indicators meet WCAG 2.1 standards
