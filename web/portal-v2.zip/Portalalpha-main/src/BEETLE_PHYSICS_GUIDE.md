# Beetle Brutalist Button Physics - Visual Guide

## The Core Principle: Physical Shadow Depression

Every button in BoulderRoller should feel like a **physical button that moves**.

---

## State Progression (ASCII Art)

```
┌─────────────────────────────────────────────────────────┐
│  RESTING STATE                                          │
│  ┌─────────────┐                                        │
│  │   CONNECT   │                                        │
│  └─────────────┘                                        │
│      ▓▓▓▓▓▓▓▓▓   ← 3px shadow (resting)                │
│                                                          │
│  transform: translateY(0)                               │
│  box-shadow: 3px 3px 0px 0px                            │
└─────────────────────────────────────────────────────────┘

         ↓ (User hovers)

┌─────────────────────────────────────────────────────────┐
│  HOVER STATE                                            │
│  ┌─────────────┐                                        │
│  │   CONNECT   │ ← lifts 1px                            │
│  └─────────────┘                                        │
│       ▓▓▓▓▓▓▓▓▓▓  ← 4px shadow (grows)                 │
│                                                          │
│  transform: translateY(-1px)                            │
│  box-shadow: 4px 4px 0px 0px                            │
│  filter: brightness(1.05) ← slightly lighter            │
└─────────────────────────────────────────────────────────┘

         ↓ (User clicks)

┌─────────────────────────────────────────────────────────┐
│  ACTIVE STATE (PRESSED)                                 │
│  ┌─────────────┐                                        │
│  │   CONNECT   │ ← depresses 2px                        │
│  └─────────────┘                                        │
│   ▓▓            ← 1px shadow (compressed!)              │
│                                                          │
│  transform: translateY(2px)                             │
│  box-shadow: 1px 1px 0px 0px                            │
│  filter: brightness(0.95) ← slightly darker             │
└─────────────────────────────────────────────────────────┘

         ↓ (User releases)

┌─────────────────────────────────────────────────────────┐
│  Returns to RESTING STATE                               │
│  (Springs back via transition)                          │
└─────────────────────────────────────────────────────────┘
```

---

## Side-by-Side Comparison

```
RESTING (3px)     HOVER (4px)      ACTIVE (1px)     DISABLED (3px locked)
┌──────────┐      ┌──────────┐     ┌──────────┐     ┌──────────┐
│  BUTTON  │      │  BUTTON  │↑    │  BUTTON  │↓    │  BUTTON  │
└──────────┘      └──────────┘     └──────────┘     └──────────┘
   ▓▓▓▓▓▓            ▓▓▓▓▓▓▓▓        ▓▓              ▓▓▓▓▓▓
    ↑                  ↑               ↑                ↑
 normal            shadow grows    compressed       stuck
 position          button lifts    (tactile!)      (no move)
```

---

## Timing Breakdown (from Knowledge Dump)

```
User hovers
   ↓
0ms ─────► Browser detects :hover
   ↓
< 16ms ───► CSS applies transition
   ↓         (120ms duration starts)
~ 120ms ──► Button visually at hover state
   ↓
User clicks
   ↓
0ms ─────► Browser detects :active
   ↓
< 16ms ───► CSS applies active state
   ↓         (button compresses)
~ 120ms ──► Button fully depressed
```

**Total feedback time: < 150ms**  
**Perceived as: INSTANT** ✨

---

## Code Implementation

### CSS Custom Properties Pattern

```tsx
style={{
  // Resting state
  boxShadow: `3px 3px 0px 0px ${borderColor}`,
  transform: 'translateY(0)',
  transition: 'all 120ms ease-out',
  
  // Hover state (CSS reads these)
  '--hover-shadow': `4px 4px 0px 0px ${borderColor}`,
  '--hover-transform': 'translateY(-1px)',
  '--hover-filter': 'brightness(1.05)',
  
  // Active state
  '--active-shadow': `1px 1px 0px 0px ${borderColor}`,
  '--active-transform': 'translateY(2px)',
  '--active-filter': 'brightness(0.95)',
} as React.CSSProperties}
```

### Global CSS Picks Up Variables

```css
.beetle-button:not(:disabled):hover {
  box-shadow: var(--hover-shadow) !important;
  transform: var(--hover-transform) !important;
  filter: var(--hover-filter) !important;
}

.beetle-button:not(:disabled):active {
  box-shadow: var(--active-shadow) !important;
  transform: var(--active-transform) !important;
  filter: var(--active-filter) !important;
}
```

**Why this pattern?**
- Theme-aware (border colors change with theme)
- Inline styles for dynamic values
- Global CSS for interaction logic
- Separation of concerns

---

## Input Focus States (Different Pattern)

Inputs don't depress - they **glow** to show focus:

```
RESTING              HOVER               FOCUS
┌──────────┐        ┌──────────┐        ┌──────────┐
│          │        │          │        │  ╔══════╗ │ ← focus ring
│  Input   │        │  Input   │        │  ║Input ║ │   (3px)
│          │        │          │        │  ╚══════╝ │
└──────────┘        └──────────┘        └──────────┘
border: #d0d8bf     border: #8b6f47     border: #c89b5c
                    (darker)             + ring shadow
```

**Focus Ring Details:**
```css
box-shadow: 0 0 0 3px rgba(200, 155, 92, 0.2);
outline: 2px solid #c89b5c;  /* WCAG 2.1 fallback */
outline-offset: 2px;
```

---

## Card Interactions (Subtle)

Cards lift more than buttons (hierarchy):

```
RESTING             HOVER               ACTIVE
┌────────────┐      ┌────────────┐      ┌────────────┐
│  Activity  │      │  Activity  │↑     │  Activity  │
│  Card      │      │  Card      │      │  Card      │
└────────────┘      └────────────┘      └────────────┘
 ▓▓▓▓                 ▓▓▓▓▓               ▓▓▓▓
shadow: 4px          shadow: 5px         shadow: 4px
translateY(0)        translateY(-2px)    translateY(0)
                     ↑                    ↑
                  lifts 2px            returns
```

**Rationale:** Cards are larger surfaces, so they need more movement to feel responsive.

---

## The "Gulf of Execution" Solved

From the knowledge dump:

> **Gulf of execution:** "Can I figure out what to do?"  
> **Gulf of evaluation:** "Can I tell what happened?"

### Before Our Fix:
```
User sees button with shadow
  ↓
User hovers → nothing happens 😕
  ↓
User clicks → shadow stays same 😕😕
  ↓
Gulf = WIDE (user uncertain)
```

### After Our Fix:
```
User sees button with shadow
  ↓
User hovers → button lifts, shadow grows! ✓
  ↓
"Ah, this is clickable"
  ↓
User clicks → button DEPRESSES! ✓✓
  ↓
"I know I clicked it"
  ↓
Gulf = NARROW (user confident)
```

---

## Variant Shadow Colors

Different button types use different shadow colors:

```tsx
Primary (accent color):
  shadow-color: colors.border (theme-aware)
  
Secondary (neutral):
  shadow-color: isDarkMode ? '#1a1d14' : colors.border
  
Danger (red):
  shadow-color: '#8b3a3a' (fixed dark red)
  
Ghost (transparent):
  shadow: none (no physical metaphor)
```

---

## Accessibility: Focus-Visible

Keyboard users get extra clear focus:

```
Mouse user clicks:          Keyboard user tabs:
┌──────────┐                ┌──────────┐
│  BUTTON  │                │ ┏━━━━━━┓ │ ← thicker outline
└──────────┘                │ ┃BUTTON┃ │   (2px, high contrast)
   ▓▓▓▓                     │ ┗━━━━━━┛ │
   ↑                        └──────────┘
regular shadow              outline-offset: 2px
```

**Code:**
```css
button:focus-visible {
  outline: 2px solid #c89b5c;
  outline-offset: 2px;
}
```

**Why?**
- `:focus` = all focus (mouse + keyboard)
- `:focus-visible` = keyboard only
- Mouse users don't see outline pollution
- Keyboard users get crystal clear indicator

---

## Loading State (Bonus)

Buttons in loading state:

```
LOADING
┌──────────────────┐
│  ⟳  Loading...   │ ← spinner rotates
└──────────────────┘
   ▓▓▓▓▓▓
   ↑
Shadow at resting (no hover)
Pointer: not-allowed
Opacity: normal (not dimmed)
```

**Philosophy:** "I'm working, not disabled"

```tsx
<BeetleButton isLoading>
  Submit
</BeetleButton>
```

Renders:
```tsx
{isLoading ? (
  <>
    <Spinner />
    <span>Loading...</span>
  </>
) : children}
```

---

## Real-World Physics Analogy

Think of the button as a **beetle exoskeleton**:

```
🪲 Beetle at rest → hard shell, shadow underneath

👆 Finger hovers → beetle lifts slightly (alert)

👇 Finger presses → shell compresses (tactile click!)

🎉 Finger releases → shell springs back
```

The shadow is literally the **distance from the ground**.

---

## Why This Matters (from Knowledge Dump)

> "Your nervous system is trained on this loop:  
> **Intention → Action → Sensory Feedback → Interpretation**"

Flat UI breaks this loop. Our brutalist system **restores it**:

1. **Intention:** User wants to click  
2. **Action:** User hovers (testing)  
3. **Sensory Feedback:** Button lifts, shadow grows  
4. **Interpretation:** "This will work"  
5. **Action:** User clicks  
6. **Sensory Feedback:** Button depresses, shadow shrinks  
7. **Interpretation:** "It worked!"

---

## Checklist for Every New Interactive Element

When adding a new button/input/card:

- [ ] Does it have a **resting state** that looks clickable?
- [ ] Does it **respond to hover** within 100ms?
- [ ] Does it have a **distinct active state**?
- [ ] Does it have a **focus state** for keyboard users?
- [ ] Is the **transition timing** 100-150ms?
- [ ] Does the **cursor change** to pointer?
- [ ] Is it using **semantic HTML** (`<button>` not `<div>`)?
- [ ] Is it **keyboard accessible**?

**If any answer is "no", it's not beetle-worthy.** 🪲

---

**Remember:** Every interactive element is a tiny contract with the user. Honor that contract with proper physics!
