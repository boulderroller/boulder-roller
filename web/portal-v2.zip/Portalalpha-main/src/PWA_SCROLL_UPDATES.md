# PWA Scroll Architecture Updates

## ✅ COMPLETED - Full Option A Conversion!

We've implemented the complete Strava-style PWA scroll behavior where the nav stays fixed and the entire app scrolls as one unified container with iOS bounce effects.

### 1. Fixed Navigation Header
- **TopNav** uses `fixed top-0 left-0 right-0 z-50`
- Never scrolls away, always visible at top
- Z-index ensures it's above modal backdrops (z-40)

### 2. Modal Positioning
Updated all 10 modals to position **below the nav**:

#### Backdrops Changed:
```tsx
// OLD
<div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" />

// NEW  
<div 
  className="fixed left-0 right-0 bottom-0 bg-black/40 backdrop-blur-sm z-40"
  style={{ top: '64px' }}
/>
```

#### Modals Updated:
1. ✅ ActivityDetailModal
2. ✅ SearchModal
3. ✅ UploadActivityModal
4. ✅ RideUploadSuccessModal
5. ✅ DeleteConfirmModal
6. ✅ AchievementUnlockModal
7. ✅ StoreConfirmModal
8. ✅ InviteFriendModal
9. ✅ EditActivityModal
10. ✅ ShareModal
11. ✅ SegmentDetailModal
12. ✅ SettingsModal

**Skipped** (intentionally):
- InviteModal (full screen auth flow)
- SetupModal (full screen onboarding)

### 3. iOS Bounce Scrolling
Added new CSS utility in `/styles/globals.css`:

```css
.scroll-bounce {
  overflow-y: auto;
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch; /* iOS momentum */
  overscroll-behavior-y: contain; /* Prevent scroll chaining */
}
```

Applied to modal content containers for natural bounce feel.

### 4. Unified App Scroll Container
**App.tsx changes:**
```tsx
// OLD
<main className="h-[calc(100vh-64px)] overflow-hidden">

// NEW - Single scroll container for entire app!
<main className="pt-[64px] min-h-screen overflow-y-auto scroll-bounce">
```

### 5. Page-Level Changes - Removed Internal Scroll
All 13 pages updated from internal scroll to content-only:

#### Updated Pages:
1. ✅ **ActivityFeed** - Already used `min-h-full` (no scroll) ✓
2. ✅ **BeetleView** - `h-full overflow-y-auto` → `min-h-full`
3. ✅ **RideView** - `h-full overflow-y-auto` → `min-h-full`  
4. ✅ **MyActivities** - `h-full overflow-y-auto` → `min-h-full`
5. ✅ **MySegments** - `h-full overflow-y-auto` → `min-h-full`
6. ✅ **Data** - `h-full overflow-y-auto` → `min-h-full`
7. ✅ **Portfolio** - `h-full overflow-y-auto` → `min-h-full`
8. ✅ **Leaderboard** - `h-full overflow-y-auto` → `min-h-full`
9. ✅ **FindFriends** - `h-full overflow-y-auto` → `min-h-full`
10. ✅ **Map** - `h-full` → `min-h-screen` (special case - fullscreen map)
11. ✅ **Achievements** - Already used `min-h-full` ✓
12. ✅ **BeetleStore** - Already used `min-h-full` ✓
13. ✅ **RiderView** - Already used `min-h-full` ✓
14. ✅ **ItemDetail** - Already used `min-h-full` ✓

**Pattern Change:**
```tsx
// ❌ OLD PATTERN (page manages own scroll)
<div className="h-full overflow-y-auto p-8">
  {/* content */}
</div>

// ✅ NEW PATTERN (parent scrolls, page just flows)
<div className="min-h-full p-8">
  {/* content */}
</div>
```

## Final Architecture

```
┌─────────────────────────────────────┐
│   TopNav (fixed top-0, z-50)       │ ← PINNED (64px)
├─────────────────────────────────────┤
│                                     │ ↕
│   <main> SCROLLS HERE              │ ↕ scroll-bounce
│   pt-[64px] overflow-y-auto        │ ↕ iOS momentum
│                                     │ ↕
│   ┌─────────────────────────┐      │ ↕
│   │  Page Content           │      │ ↕
│   │  (min-h-full)           │      │ ↕
│   │  No internal scroll     │      │ ↕
│   └─────────────────────────┘      │ ↕
│                                     │ ↕
│   ┌─────────────────────────┐      │
│   │ Modal (z-50, top-64px)  │      │ ← Positioned in scroll
│   │ Backdrop (z-40)         │      │
│   └─────────────────────────┘      │
│                                     │
└─────────────────────────────────────┘
```

### Key Benefits:
1. **True PWA feel** - Nav stays fixed like native apps
2. **Single source of truth** - Only `<main>` controls scroll
3. **iOS bounce everywhere** - Natural mobile feel
4. **Cleaner code** - Pages don't manage overflow
5. **Strava-like hierarchy** - Modals within scroll context
6. **Better performance** - Single scroll listener

## Testing Checklist

✅ **Navigation:**
- Logo click → navigates without scroll jump
- Nav dropdowns → work above everything
- Route changes → scroll resets to top

✅ **Scrolling:**
- Page scroll → smooth with bounce effect
- Long content → scrolls naturally
- Modal open → page scroll locked (no scroll behind modal)
- iOS → momentum scrolling works

✅ **Modals:**
- Open modal → backdrop starts below nav
- Modal content → can scroll if needed
- Close modal → page scroll position preserved
- Nav visible → always on top

✅ **Pages:**
- All 14 pages → render correctly
- No broken layouts → content flows
- Responsive → works on all screen sizes

## What Changed vs Option B

**Option B (Hybrid):**
- Kept page-level scroll containers
- `<main>` had `overflow-hidden`
- Each page managed `overflow-y-auto`
- Modals positioned below nav ✓

**Option A (Full - CURRENT):**
- Removed ALL page-level scroll
- `<main>` is single scroll container
- Pages just flow with `min-h-full`
- Modals positioned below nav ✓
- **True Strava PWA architecture**