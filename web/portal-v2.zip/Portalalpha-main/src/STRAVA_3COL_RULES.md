# Strava 3-Column Layout Rules

## The Sacred Rules of Strava's Dashboard Layout

### 1. Column Proportions & Behavior

```tsx
// Grid structure - NEVER deviate from this
<div className="grid grid-cols-1 lg:grid-cols-[280px_1fr_280px] gap-6 sm:gap-8">
```

**Rules:**
- ✅ Left sidebar: **280px fixed width**
- ✅ Center column: **1fr (fluid, takes remaining space)**
- ✅ Right sidebar: **280px fixed width**
- ✅ Gap between columns: **32px (gap-8)** on desktop, **24px (gap-6)** on mobile
- ❌ NEVER make sidebars wider than 280px
- ❌ NEVER use fixed width for center column

**Breakpoint:**
```tsx
// Below lg (1024px): Stack vertically
// At lg+ (1024px+): Show 3 columns
```

---

### 2. Sticky Sidebar Behavior

**Both sidebars MUST be sticky:**

```tsx
<div 
  className="lg:sticky lg:top-[80px] lg:self-start" 
  style={{ maxHeight: 'calc(100vh - 96px)', overflowY: 'auto' }}
>
```

**Rules:**
- ✅ `sticky` positioning on desktop only (`lg:sticky`)
- ✅ Stick at `80px` from top (accounts for 64px nav + 16px breathing room)
- ✅ Max height: `calc(100vh - 96px)` (full viewport minus nav and margins)
- ✅ `overflowY: auto` - sidebars scroll independently when content exceeds height
- ✅ `self-start` - aligns to top of grid row
- ❌ NEVER make sidebars position: fixed (breaks document flow)
- ❌ NEVER let sidebars exceed viewport height without scroll

---

### 3. Container & Spacing Hierarchy

**Outer container:**
```tsx
<div className="p-6 sm:p-8" style={{ backgroundColor: colors.bgSecondary }}>
  <div className="max-w-[1400px] mx-auto">
```

**Rules:**
- ✅ Outer padding: **24px mobile (p-6)**, **32px desktop (sm:p-8)**
- ✅ Max width: **1400px** (prevents ultra-wide on big screens)
- ✅ Centered with `mx-auto`
- ❌ NEVER go below 24px outer padding
- ❌ NEVER exceed 1400px max-width

---

### 4. Card Structure (The Widget Template)

**Every widget follows this exact pattern:**

```tsx
<div 
  className="rounded border overflow-hidden"
  style={{ 
    backgroundColor: cardBg,
    borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
  }}
>
  {/* Header - Always present */}
  <div 
    className="px-5 py-4 border-b" 
    style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' }}
  >
    <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
      Widget Title
    </h2>
  </div>

  {/* Content - List items or data */}
  <div className="divide-y" style={{ borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.06)' }}>
    <div className="px-5 py-3">
      {/* Item content */}
    </div>
  </div>
</div>
```

**Rules:**
- ✅ Card background: **cardBg** (`#2a2d1e` dark, `#f5f3ed` light)
- ✅ Card border: **1px**, subtle opacity border
- ✅ Card border-radius: **rounded** (default, 8px in our system)
- ✅ Header padding: **px-5 py-4** (20px horizontal, 16px vertical)
- ✅ Header has **bottom border** separating from content
- ✅ Content items: **px-5 py-3** (20px horizontal, 12px vertical)
- ✅ List items separated by **1px dividers** (not borders)
- ✅ Use `divide-y` for list dividers
- ❌ NEVER use shadows on cards (quiet containers!)
- ❌ NEVER use different padding values
- ❌ NEVER skip the header

---

### 5. Typography Scale (Enforced)

**Widget headers:**
```tsx
className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide"
```

**Big display numbers:**
```tsx
className="font-['Cousine'] text-[36px] font-bold"
// OR for mega emphasis:
className="font-['Cousine'] text-[48px] font-bold"
```

**List item primary text:**
```tsx
className="font-['Inter'] text-[13px] font-bold"
```

**List item secondary text:**
```tsx
className="font-['Inter'] text-[11px]"
```

**Tiny labels:**
```tsx
className="font-['Inter'] text-[10px] uppercase tracking-wide"
```

**Rules:**
- ✅ Headers: Always 13px, bold, uppercase, tracking-wide
- ✅ Big numbers: Always Cousine, 36-48px, bold
- ✅ Body text: Inter, 11-13px
- ✅ Labels: 10-11px, uppercase, tracking-wide
- ❌ NEVER use text-sm, text-lg, etc. (use pixel values)
- ❌ NEVER use font-sizes outside this scale

---

### 6. Color Rules (Quiet Containers, Loud Content)

**Container colors (QUIET):**
```tsx
// Page background
backgroundColor: colors.bgSecondary

// Card background
backgroundColor: cardBg

// Borders (whisper)
borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'

// Dividers (even quieter)
borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.06)'
```

**Content colors (LOUD):**
```tsx
// Dung/CAL (glows)
color: '#c89b5c' // or '#d4a574'
textShadow: '0 0 12px rgba(200, 155, 92, 0.2)'

// Rank 1 / Gold
color: '#c89b5c'

// Accent green
color: '#8ba87a'

// Regular text (still visible)
color: colors.text
```

**Rules:**
- ✅ Containers: 1px borders, no shadows, neutral backgrounds
- ✅ Content: Bold numbers, glowing dung, colorful accents
- ✅ Text hierarchy: accent > text > textMuted
- ❌ NEVER add shadows to containers
- ❌ NEVER make borders heavier than 1px
- ❌ NEVER use colors outside the defined palette

---

### 7. Interaction States

**Hover states for list items:**
```tsx
<div 
  className="px-5 py-3 cursor-pointer transition-colors"
  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = hoverBg}
  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
  onClick={() => navigate('/somewhere')}
>
```

**Where:**
```tsx
const hoverBg = isDarkMode ? 'rgba(200, 155, 92, 0.05)' : 'rgba(200, 155, 92, 0.03)';
```

**Rules:**
- ✅ Use inline style for hover (React state, not CSS)
- ✅ Hover color: Subtle accent tint (5% dark, 3% light)
- ✅ Transition: `transition-colors` class
- ✅ Cursor: `cursor-pointer` on clickable items
- ❌ NEVER use CSS :hover (breaks with inline styles)
- ❌ NEVER use strong hover colors
- ❌ NEVER add borders/shadows on hover

---

### 8. Spacing Between Widgets

**Vertical spacing between widgets in sidebars:**
```tsx
// Left sidebar
<div className="space-y-4">
  <Widget1 />
  <Widget2 />
  <Widget3 />
</div>
```

**Rules:**
- ✅ Use `space-y-4` (16px gap) between widgets in same sidebar
- ✅ First widget has no top margin
- ✅ Each widget is self-contained (no external margins)
- ❌ NEVER use mb-4 on individual widgets
- ❌ NEVER use different spacing values

---

### 9. Responsive Collapse Behavior

```tsx
// Desktop (lg+): 3 columns side-by-side
lg:grid-cols-[280px_1fr_280px]

// Mobile/Tablet: Stack vertically
grid-cols-1
```

**Stacking order on mobile:**
1. Left sidebar (Your stats)
2. Center column (Main feed)
3. Right sidebar (Community)

**Rules:**
- ✅ All widgets full width on mobile
- ✅ Maintain same internal padding on mobile
- ✅ Remove sticky behavior on mobile
- ✅ Remove maxHeight scroll on mobile
- ❌ NEVER hide widgets on mobile
- ❌ NEVER change widget order arbitrarily

---

### 10. Widget Height Management

**Short widgets (single card):**
- Natural height, no constraints
- Example: Dung Bank (fixed content)

**Medium widgets (small list):**
- Natural height up to ~400px
- No scroll needed

**Tall widgets (long list):**
- Let sidebar scroll handle it
- Don't put internal scroll on widget
- Example: Leaderboard with 20+ items

**Rules:**
- ✅ Let widgets be natural height
- ✅ Sidebar scrolls when content exceeds viewport
- ✅ No internal scrolling on individual widgets
- ❌ NEVER put max-height on individual widgets
- ❌ NEVER use overflow-y on widgets (sidebar handles scroll)

---

### 11. Loading & Empty States

**Loading (use LoadingSkeleton):**
```tsx
{isLoading && <LoadingSkeleton variant="activity-feed-item" count={5} />}
```

**Empty state:**
```tsx
<div className="py-12 text-center px-5">
  <p className="font-['Inter'] text-[13px]" style={{ color: colors.textMuted }}>
    No data available
  </p>
</div>
```

**Rules:**
- ✅ Loading: Use skeleton component
- ✅ Empty: Center text, generous padding, muted color
- ✅ Maintain widget structure during loading
- ❌ NEVER show raw "Loading..." text
- ❌ NEVER collapse widget height when empty

---

### 12. Widget Priority & Ordering

**Left sidebar (top to bottom):**
1. Most important personal metric (Dung Bank)
2. Secondary stats (Streak, Training Load)
3. Visual showcase (NFT Beetle, Achievement)
4. Least critical (Goals, etc.)

**Right sidebar (top to bottom):**
1. Social proof (Weekly Leaderboard)
2. Discovery/FOMO (Trending Segments, Challenges)
3. Recommendations (Segment Opportunities)
4. Peripheral (Weather, Store)

**Rules:**
- ✅ Most actionable/important widgets at top
- ✅ Decrease importance as you scroll down
- ✅ Balance visual weight (big numbers at top)
- ❌ NEVER put critical info at bottom
- ❌ NEVER put 3+ tall widgets in one sidebar

---

### 13. Data Density

**Strava's sweet spot:**
- List items: **5-10 visible** without scroll
- Big numbers: **1-3 per widget**
- Text lines: **2-3 max** per list item

**Rules:**
- ✅ Show enough to be useful (top 5-10)
- ✅ Link to "View all" for more
- ✅ Prioritize scanability over completeness
- ❌ NEVER show 50+ items in a sidebar widget
- ❌ NEVER cram multiple metrics into one line

---

### 14. Widget Construction Checklist

Before adding a widget, verify:
- [ ] Uses exact card structure (header + content)
- [ ] Header: px-5 py-4, 13px uppercase bold
- [ ] Content: px-5 py-3 per item
- [ ] cardBg background, 1px border
- [ ] Dividers between list items (not borders)
- [ ] Hover states on clickable items
- [ ] Typography uses approved scale
- [ ] Colors follow quiet/loud principle
- [ ] Loading state implemented
- [ ] Empty state implemented
- [ ] Mobile responsive (full width, no sticky)
- [ ] Natural height (no max-height on widget itself)

---

### 15. The Golden Rule

> **"Containers whisper, content shouts"**

Strava's entire design language is built on this:
- Borders, backgrounds, structure = nearly invisible
- Numbers, dung, achievements, rankings = impossible to miss

Every widget must follow this principle:
- Infrastructure fades away
- Data demands attention

---

## Quick Reference: Widget Anatomy

```tsx
{/* SIDEBAR CONTAINER */}
<div className="lg:sticky lg:top-[80px] lg:self-start" style={{ maxHeight: 'calc(100vh - 96px)', overflowY: 'auto' }}>
  <div className="space-y-4">
    
    {/* WIDGET */}
    <div 
      className="rounded border overflow-hidden"
      style={{ backgroundColor: cardBg, borderColor }}
    >
      {/* HEADER */}
      <div className="px-5 py-4 border-b" style={{ borderColor }}>
        <h2 className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide" style={{ color: colors.text }}>
          Widget Title
        </h2>
      </div>

      {/* CONTENT */}
      <div className="divide-y" style={{ borderColor: dividerColor }}>
        {/* LIST ITEM */}
        <div 
          className="px-5 py-3 cursor-pointer transition-colors"
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = hoverBg}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
        >
          <div className="flex items-center justify-between">
            {/* LABEL (quiet) */}
            <span className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>
              Label
            </span>
            {/* VALUE (loud) */}
            <span className="font-['Cousine'] text-[16px] font-bold" style={{ color: colors.text }}>
              123
            </span>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
```

---

## Common Mistakes to Avoid

❌ Making sidebars wider than 280px
❌ Using fixed width for center column
❌ Adding shadows to cards
❌ Using thick borders (>1px)
❌ Inconsistent padding (always px-5 py-4 header, px-5 py-3 items)
❌ Missing widget headers
❌ Using CSS :hover instead of inline style hover
❌ Adding max-height to individual widgets
❌ Showing 50+ items in a sidebar list
❌ Using font sizes outside the approved scale
❌ Making containers visually heavy
❌ Making content visually quiet

---

## The Layout Formula

```
Page Container (p-6 sm:p-8, max-w-[1400px])
  └─ Grid (grid-cols-1 lg:grid-cols-[280px_1fr_280px] gap-6 sm:gap-8)
      ├─ Left Sidebar (sticky, 280px, scrollable)
      │   └─ Widgets (space-y-4)
      │       └─ Card (rounded, border, cardBg)
      │           ├─ Header (px-5 py-4, border-b)
      │           └─ Content (divide-y, px-5 py-3 items)
      │
      ├─ Center Column (1fr, fluid)
      │   └─ Main content (Activity feed, etc.)
      │
      └─ Right Sidebar (sticky, 280px, scrollable)
          └─ Widgets (space-y-4)
              └─ Card (rounded, border, cardBg)
                  ├─ Header (px-5 py-4, border-b)
                  └─ Content (divide-y, px-5 py-3 items)
```
