# Boulder Roller - Component Specification

## Overview
Boulder Roller is a Solana-native cycling data tracker with invite-only access, gamified "dung economy", and Strava-inspired proportions.

## Design Philosophy
- **Oink.me/What.CD aesthetic** - Boutique exclusivity, playful but serious
- **Strava proportions** - Clean, light theme, information-dense
- **Neo-brutalist UI** - Bold borders, strong shadows, confident typography
- **Web3-native** - Solana wallet auth, on-chain beetle identities

---

## 🎨 Design System

### Colors
- **Primary Background (Light):** `#f3f5ed` / `#f9faf5`
- **Primary Background (Dark):** `#1a1d14` / `#2a2d1e`
- **Text (Light):** `#2a2d1e`
- **Text (Dark):** `#f9faf5`
- **Muted Text:** `#6b7a5a`
- **Accent Green:** `#8b9475`
- **Accent Gold:** `#d4c993`
- **Accent Bronze:** `#c7a76f`
- **Accent Moss:** `#8ba87a`
- **Error Red:** `#a87373`
- **Border:** `#2a2d1e` (always dark, even in dark mode)

### Typography
- **Display/Headers:** `Inter` (Extra Bold, Black)
- **Body/UI:** `Inter` (Bold, Regular)
- **Monospace/Data:** `Cousine` (Bold) - for numbers, wallet addresses, FTP, etc.

### Spacing & Proportions
- **Top Nav Height:** `80px`
- **Border Width:** `2px` (inputs) / `3px` (buttons, cards)
- **Border Radius:** `8px` (inputs) / `12px` (buttons) / `16px` (cards)
- **Shadow Style:** `[4px_4px_0px_0px_#2a2d1e]` (neo-brutalist offset shadow)

---

## 📁 Component Structure

```
/App.tsx                          # Main router & auth state
/components/
  /auth/
    InviteGate.tsx               # Landing page with 3x beetle click easter egg
    InviteModal.tsx              # Invite code entry
    WalletConnect.tsx            # Solana wallet selection dropdown
    SetupModal.tsx               # First-time user setup (username, FTP, weight, rider type)
  /layout/
    MainLayout.tsx               # Main app wrapper with nav + content
    TopNav.tsx                   # Horizontal top navigation bar
    ProfileSheet.tsx             # User profile dropdown (top-right)
  /feed/
    ActivityFeed.tsx             # Community activity feed with 3-column layout
```

---

## 🔄 User Flow

### 1. Invite Gate (`/`)
- Light theme, centered beetle emoji 🪲
- Click beetle 3x → InviteModal appears
- Footer: "Boulder Roller • Optimism Network"

### 2. Invite Modal
- User enters invite code
- Click "ENTER" → validates code (TODO: backend check)
- Success → WalletConnect dropdown

### 3. Wallet Connect
- Top-right dropdown (matches ProfileSheet position)
- Shows Solana wallet options: Phantom, Solflare, Backpack, Glow
- Click wallet → triggers Solana wallet connection
- Success → SetupModal

### 4. Setup Modal
- Beetle emoji + "You're Beetle #XXXX"
- **REQUIRED:** Username, FTP, Weight
- **OPTIONAL:** Rider Type (Sprinter, TT, Climber, All-Rounder, Diesel)
- "LET'S RIDE >" → Main app
- "Skip for now" option available

### 5. Main App
- Top nav with logo + wallet/profile dropdown
- Activity feed with:
  - Left panel: User stats (locked until connected)
  - Center panel: Community activity feed
  - Right panel: Leaderboards (locked until connected)
- Dark mode toggle available in ProfileSheet

---

## 🔌 Backend Integration TODOs

### Auth Flow
- [ ] Validate invite codes against backend
- [ ] Connect Solana wallet (Phantom, Solflare, etc.)
- [ ] Sign message to prove ownership
- [ ] Create user profile on-chain or in DB

### Profile Management
- [ ] Save user settings (FTP, weight, rider type, units, theme)
- [ ] Export user data endpoint
- [ ] Delete account endpoint
- [ ] Session management (show active sessions)

### Activity Feed
- [ ] Fetch real community activities
- [ ] Real-time updates (WebSocket or polling)
- [ ] Activity types: RIDE, ACHIEVEMENT, REWARD
- [ ] Dung economy calculations

### Data to Track
- Rides (GPX/FIT file uploads)
- Training Stress Score (TSS)
- Segments/climbs ("Piles")
- Rankings (beetle grades: A, B, C, etc.)
- Dung earned (gamification currency)

---

## 🎮 Gamification Mechanics

### Beetle Identity
- Each user = unique beetle with # ID
- Rank system: A, B, C, etc. (based on activity/performance)
- Wallet-based identity (Solana address)

### Dung Economy
- Earn "dung" for:
  - Completing rides
  - Achieving PRs on segments
  - Hitting training milestones
  - Weekly/monthly goals
- Dung = on-chain points/tokens?
- Use cases TBD (unlock features, compete, trade?)

### Energy System
- Daily energy bar (resets daily?)
- Energy = capacity for rides/activities
- Shown in top nav and home dashboard

---

## 🎨 Themes

Users can select from 6 color themes:
1. **Hoo-Breddin** (default) - `#8b9475`
2. **Water** - `#6ba8d4`
3. **Safari** - `#c7a76f`
4. **Honey** - `#d4c993`
5. **Moss** - `#8ba87a`
6. **Foundries** - `#6b7a5a`

Themes change accent colors throughout the app.

---

## 🚧 Remaining Components to Build

### Priority 1 - Core Features
- [ ] Rides page (list of user's rides)
- [ ] Individual ride detail view (map, elevation, power, HR)
- [ ] Upload ride flow (drag-drop GPX/FIT files)
- [ ] User stats dashboard (instead of locked placeholder)

### Priority 2 - Social Features
- [ ] Leaderboards (segment rankings)
- [ ] Segment/climb detail pages ("Piles")
- [ ] Portfolio page (achievements, badges, long-term stats)
- [ ] Follow/unfollow riders
- [ ] Activity comments/kudos

### Priority 3 - Advanced
- [ ] Strava integration (import rides)
- [ ] Device connections (Garmin, Wahoo, etc.)
- [ ] Training plans
- [ ] Power analysis tools
- [ ] Route builder

---

## 📝 Notes

- Keep it **tight and communicative** - no unnecessary backend complexity
- Invite-only creates scarcity and value (like private trackers)
- Serious about data, playful about presentation
- Solana-native from day one (no multi-chain complexity)
- Mobile-responsive but desktop-first (serious riders use desktops for data analysis)

---

## 🤝 Collaboration Notes

This spec is based on screenshots and design iterations. Components are **functionally blank** but properly harnessed - ready to wire up with your backend/CLI work.

**Source of truth:** Top nav screenshots > Figma imports
**Aesthetic inspiration:** Oink.me / What.CD vibes over generic dark themes
**Tech stack:** React + Tailwind + Solana Web3.js

Ready to spec out the next components together! 🚀
