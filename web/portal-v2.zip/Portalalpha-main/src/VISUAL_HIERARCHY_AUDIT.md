# 🎨 **VISUAL HIERARCHY AUDIT**
**Date:** December 9, 2024  
**Philosophy:** "Quiet containers, loud content" - Strava visual hierarchy

---

## 📋 **CURRENT STATE ANALYSIS**

### **✅ CORRECT PATTERN (Activity Feed & Profile)**

#### **Activity Feed:**
```
✅ Container: 1px border, no shadow, transparent bg
✅ Content: Bold type icons (brutalist shadows), dung glows
✅ Hover: Subtle bg change (rgba overlay)
✅ Hierarchy: Icons → action text → metadata
```

**Code Example (ActivityFeed):**
```tsx
// ✅ Container whispers
<div className="px-5 py-4 transition-colors cursor-pointer" 
  style={{ backgroundColor: 'transparent' }}
  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = hoverBg}
>
  
  // ✅ Content shouts - Icon with brutalist shadow
  <div className="w-10 h-10 rounded-[8px] border-[2px] 
    shadow-[2px_2px_0px_0px_#2a2d1e]"
    style={{ backgroundColor: activity.color }}
  >
    <BikeIcon />
  </div>
  
  // ✅ Text hierarchy: Bold action → muted metadata
  <div className="font-bold text-[14px]">{activity.action}</div>
  <span className="text-[12px] text-muted">{activity.user}</span>
</div>
```

---

#### **Profile View:**
```
✅ Container: 1px border (rgba), no shadow, cardBg
✅ Content: Large avatar (3px border + glow), bold stats
✅ Hierarchy: Avatar → username → rank badge → bio → stats
```

**Code Example (Profile):**
```tsx
// ✅ Container whispers
<div className="p-6 rounded border mb-6"
  style={{ backgroundColor: cardBg, borderColor }}
>
  
  // ✅ Content shouts - Avatar with accent border
  <div className="w-24 h-24 rounded-full border-[3px]"
    style={{ 
      borderColor: colors.accent,
      backgroundColor: 'rgba(200, 155, 92, 0.1)'
    }}
  >
    🪲
  </div>
  
  // ✅ Bold hierarchy
  <h1 className="font-black text-[24px]">@{username}</h1>
  <div className="font-bold text-[10px] uppercase">Rank {rank}</div>
</div>
```

---

#### **Settings:**
```
✅ Container: 1px border, cardBg, no shadow
✅ Content: Emojis + bold labels, BeetleButtons
✅ Hierarchy: Section header → form fields → action buttons
```

**Code Example (Settings):**
```tsx
// ✅ Container whispers
<div className="p-6 rounded border"
  style={{ backgroundColor: cardBg, borderColor }}
>
  
  // ✅ Content shouts - Emoji + bold text
  <h2 className="font-bold text-[16px]">
    🪲 Profile
  </h2>
  
  // ✅ Form elements get visual weight
  <BeetleInput label="Username" />
  <BeetleButton>Save Changes</BeetleButton>
</div>
```

---

## ❌ **PROBLEM AREAS**

### **1. RideView Header - TOO LOUD**

**Current State:**
```tsx
// ❌ Container is shouting when it should whisper
<div className="flex items-start justify-between mb-6">
  <div>
    <div className="flex items-center gap-3 mb-2">
      <span className="text-[28px]">🚴</span>  // ⚠️ Too big
      <h1 className="font-extrabold text-[28px]">  // ⚠️ TOO BOLD
        {activity.title}
      </h1>
    </div>
    <p className="font-['Cousine'] text-[13px]">{activity.date}</p>
  </div>

  <div className="flex gap-2">
    <BeetleButton variant="secondary" size="sm">Edit</BeetleButton>
    <BeetleButton variant="secondary" size="sm">Delete</BeetleButton>
  </div>
</div>
```

**Problems:**
- ❌ Icon is 28px (should be 20-24px like Profile)
- ❌ Title is `font-extrabold text-[28px]` (too heavy)
- ❌ Missing visual separation between header and content
- ❌ Buttons compete with title for attention

**Should Be:**
```tsx
// ✅ Container whispers, content gets subtle emphasis
<div className="mb-8">
  <div className="flex items-center gap-2.5 mb-1.5">
    <span className="text-[20px]">🚴</span>  // ✅ Smaller, quieter
    <h1 className="font-bold text-[20px]">  // ✅ Bold, not extrabold
      {activity.title}
    </h1>
  </div>
  <div className="flex items-center justify-between">
    <p className="font-['Cousine'] text-[12px]">{activity.date}</p>
    <div className="flex gap-2">
      <BeetleButton variant="ghost" size="sm">Edit</BeetleButton>
      <BeetleButton variant="ghost" size="sm">Delete</BeetleButton>
    </div>
  </div>
</div>
```

---

### **2. StatsPanel - Cards Too Prominent**

**Current State:**
```tsx
// ❌ Each stat card has border + shadow
<div className="grid grid-cols-4 gap-8">
  {stats.map(stat => (
    <div className="border rounded p-4">  // ⚠️ Too loud
      <div className="font-bold text-[42px]">{stat.value}</div>
      <div className="text-[11px]">{stat.label}</div>
    </div>
  ))}
</div>
```

**Problems:**
- ❌ Individual stat boxes create visual clutter
- ❌ Borders compete with content

**Should Be:**
```tsx
// ✅ One container, loud numbers inside
<div className="p-6 rounded border" style={{ backgroundColor: cardBg, borderColor }}>
  <div className="grid grid-cols-4 gap-8">
    {stats.map(stat => (
      <div>  // ✅ No border, just content
        <div className="font-['Cousine'] text-[42px]">{stat.value}</div>
        <div className="font-['Inter'] text-[11px] uppercase tracking-wide text-muted">
          {stat.label}
        </div>
      </div>
    ))}
  </div>
</div>
```

**Current Implementation Status:**
- ✅ StatsPanel already uses this pattern! (Good)
- ⚠️ But check if it has any extra borders inside

---

### **3. Upload Modal - MASSIVELY OVER-EMPHASIZED**

**Current State:**
```tsx
// ❌ Way too heavy
<div className="rounded-[8px] border-[2px] p-8"  // ⚠️ 2px border
  style={{
    backgroundColor: colors.bg,
    borderColor: colors.border,
    boxShadow: `4px 4px 0px 0px ${colors.border}`,  // ⚠️ HUGE shadow
  }}
>
  <h2 className="font-black text-[20px]">  // ⚠️ font-black
    📤 Upload Ride
  </h2>
  
  <div className="text-center py-12 mb-6">
    <div className="text-[64px] mb-4">📁</div>  // ⚠️ MASSIVE icon
    <p className="font-bold text-[16px]">Upload your ride file</p>
  </div>
</div>
```

**Problems:**
- ❌ `border-[2px]` should be `border-[1px]`
- ❌ `boxShadow: 4px 4px` is too heavy (should be 2px 2px or none)
- ❌ Icon is 64px (should be 48px max)
- ❌ `font-black` title (should be `font-bold`)
- ❌ Too much padding everywhere

**Should Be:**
```tsx
// ✅ Lighter, cleaner
<div className="rounded border p-6"  // ✅ 1px border, less padding
  style={{
    backgroundColor: colors.bg,
    borderColor: colors.border,
    // No shadow, or subtle: boxShadow: '2px 2px 0px 0px rgba(42, 45, 30, 0.08)'
  }}
>
  <h2 className="font-bold text-[16px] mb-6">  // ✅ font-bold, smaller
    📤 Upload Ride
  </h2>
  
  <div className="text-center py-8 mb-6">  // ✅ Less padding
    <div className="text-[48px] mb-3">📁</div>  // ✅ Smaller icon
    <p className="font-['Inter'] text-[14px] mb-1">{/* ... */}</p>
  </div>
</div>
```

---

### **4. ProfileDropdown - Order + Visual Weight Issues**

**Current Order:**
1. Settings ⚙️
2. Edit Profile ✏️
3. Sessions 🔒 (disabled)
4. Export Data 📥

**Problems:**
- ❌ Settings is most prominent action (should be 2nd)
- ❌ Edit Profile should be #1 (most common action)
- ❌ Missing "Docs" link
- ❌ Export is too high (should be last before Disconnect)

**Should Be:**
1. ✏️ Edit Profile (most common)
2. ⚙️ Settings (secondary)
3. 📚 Docs (tertiary)
4. 📥 Export Data (least common)
5. [Divider]
6. 🔌 Disconnect (danger action)

**Visual Weight Issues:**
```tsx
// Current: All items have equal weight
<button className="w-full px-4 py-2.5 hover:bg">
  <span className="text-[13px]">Settings</span>
</button>
```

**Should Consider:**
- Make "Edit Profile" slightly bolder or have accent color on icon
- Group related items (profile actions vs system actions)

---

## 🔍 **MORE INSTANCES TO AUDIT**

### **5. Leaderboard**
**Status:** ✅ **CORRECT**
```tsx
// Container whispers
<div className="rounded border" style={{ backgroundColor: cardBg, borderColor }}>
  // Content shouts
  <LeaderboardRow>
    <div className="font-['Cousine'] text-[18px] font-bold">{rank}</div>
    <div className="text-[14px]">{username}</div>
  </LeaderboardRow>
</div>
```
**Verdict:** Already follows pattern - 1px borders, bold content.

---

### **6. BeetleView Modal**
Need to check: ActivityDetailModal

<function_calls>
<invoke name="read">
<parameter name="path">/components/feed/ActivityDetailModal.tsx