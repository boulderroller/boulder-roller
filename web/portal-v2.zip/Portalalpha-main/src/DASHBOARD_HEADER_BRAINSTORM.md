# Dashboard Header Redesign - Space Optimization

## Current Problem
The header takes up massive vertical space (120-140px) for just 2 lines of text:
- "Good morning" 
- "Ready to ride • Energy at 40%"

This pushes the valuable 3-column content below the fold on many screens.

---

## Strava's Approach
Strava keeps headers **compact and functional**:
- Header text is minimal
- Horizontal layout uses full width
- Quick actions/filters in same row
- Typically 60-80px total height
- Get to the content FAST

---

## Option 1: Compact Header + Quick Actions (Strava-style)

```
┌─────────────────────────────────────────────────────────────┐
│ Good morning, rider              [Upload Ride] [Invite]      │
│ 7 day streak • 342 dung this week                           │
└─────────────────────────────────────────────────────────────┘
```

**Layout:**
- Left: Greeting + quick stats
- Right: Action buttons
- Height: ~60px
- Simple, functional, gets out of the way

**Pros:**
- Minimal vertical space
- Quick access to upload
- Shows key context (streak, dung)

**Cons:**
- Less dramatic/welcoming
- Doesn't showcase achievements

---

## Option 2: Horizontal Stats Bar

```
┌─────────────────────────────────────────────────────────────┐
│ Good morning                                                │
│ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌──────────────┐│
│ │ 7 DAYS    │ │ 342 DUNG  │ │ 6 RIDES   │ │ UPLOAD RIDE  ││
│ │ Streak 🔥 │ │ This Week │ │ This Week │ │   [Button]   ││
│ └───────────┘ └───────────┘ └───────────┘ └──────────────┘│
└─────────────────────────────────────────────────────────────┘
```

**Layout:**
- Row 1: Greeting (small)
- Row 2: 3 stat pills + CTA button
- Height: ~100px
- Horizontal use of space

**Pros:**
- Shows key metrics at a glance
- Prominent upload CTA
- Visual interest with cards

**Cons:**
- Still takes vertical space
- Duplicates some sidebar info

---

## Option 3: Split Header (Greeting + Context)

```
┌─────────────────────────────────────────────────────────────┐
│ Good morning                    Week 49 • Dec 2-8, 2024     │
│ 7 day streak 🔥 • 3 rides to unlock "Consistency Beetle"    │
└─────────────────────────────────────────────────────────────┘
```

**Layout:**
- Left: Greeting + contextual nudge
- Right: Current epoch/week info
- Height: ~50px
- Dense, informative

**Pros:**
- Minimal space
- Motivational context
- Shows epoch timing

**Cons:**
- Lots of text to parse
- Might feel cramped

---

## Option 4: Minimal Header Only

```
┌─────────────────────────────────────────────────────────────┐
│ Activity Feed                                               │
└─────────────────────────────────────────────────────────────┘
```

**Layout:**
- Just page title
- Height: ~40px
- Ultra minimal

**Pros:**
- Maximum space for content
- Clean, brutalist
- Content is the hero

**Cons:**
- No personalization
- Misses opportunity for context
- Less welcoming

---

## Option 5: Dynamic Header (Changes based on context)

**Morning (no rides today):**
```
Good morning • No rides yet today
[Upload Ride] or browse [Trending Segments]
```

**After a ride:**
```
Great ride! +87 dung earned
View your [Latest Activity] or [Compare Segments]
```

**Near a milestone:**
```
3 more days for 10-day streak! 🔥
Keep it going • [Upload Ride]
```

**Layout:**
- Contextual message (2 lines)
- Height: ~60px
- Changes based on user state

**Pros:**
- Personal and engaging
- Drives action
- Always relevant

**Cons:**
- More complex logic
- Needs state management

---

## Option 6: Embedded in Nav Bar (Zero space)

Move greeting into the top nav itself, no dedicated header section.

```
┌─────────────────────────────────────────────────────────────┐
│ [BR Logo] Dashboard Explore  Good morning, 7🔥 [Profile]    │
└─────────────────────────────────────────────────────────────┘
│                                                              │
│ [3-COLUMN LAYOUT STARTS IMMEDIATELY]                        │
```

**Pros:**
- Zero vertical space cost
- Maximum content visibility
- Very clean

**Cons:**
- Nav bar gets crowded
- Less prominent greeting
- Less space for context

---

## Recommended Approach

### **Option 1 + Elements of Option 3**

```tsx
<div className="mb-6 px-2 sm:px-0">
  <div className="flex items-center justify-between">
    {/* Left: Greeting + Context */}
    <div>
      <h1 className="font-['Inter'] font-bold text-[20px] tracking-tight" style={{ color: colors.text }}>
        Good morning
      </h1>
      <p className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>
        7 day streak 🔥 • 342 dung this week • Epoch ending in 2 days
      </p>
    </div>
    
    {/* Right: Quick Actions */}
    <div className="flex items-center gap-2">
      <BeetleButton variant="secondary" size="sm">
        Invite Friend
      </BeetleButton>
      <BeetleButton variant="primary" size="sm">
        Upload Ride
      </BeetleButton>
    </div>
  </div>
</div>
```

**Height:** ~50-60px (vs current 120-140px)  
**Space saved:** ~60-80px  

### Why This Works:
- ✅ **Compact** - Gets to content fast
- ✅ **Functional** - Upload button always visible
- ✅ **Contextual** - Shows streak, dung, epoch
- ✅ **Balanced** - Uses horizontal space efficiently
- ✅ **Strava-like** - Matches their header philosophy
- ✅ **Elegant** - Not cluttered, clean hierarchy

---

## Measurements

**Current header:**
- Desktop: pt-12 + pb-10 + mb-8 + content = ~140px
- Mobile: pt-8 + pb-8 + mb-8 + content = ~120px

**Proposed header:**
- Desktop: mb-6 + content = ~60px
- Mobile: mb-6 + content = ~60px

**Result:** ~60-80px more space for the 3-column content!

---

## Alternative: Progressive Disclosure

**On scroll down:** Header compacts/disappears  
**On scroll up:** Header reappears

This is advanced but Strava does this with filters. Could be Phase 2.

---

## Decision Points

1. **Do we want personalization?** (Good morning vs just "Activity Feed")
2. **Do we want quick actions?** (Upload button in header vs always in nav)
3. **Do we show contextual info?** (Streak, epoch, goals)
4. **How minimal?** (Just title vs title + context)

My vote: **Option 1 + 3 hybrid** - compact, functional, contextual, Strava-aligned.
