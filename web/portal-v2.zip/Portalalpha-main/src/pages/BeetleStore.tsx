import { useTheme } from '../contexts/ThemeContext';
import { useState } from 'react';

interface StoreItem {
  id: string;
  emoji: string;
  name: string;
  description: string;
  price: number;
  category: 'equipment' | 'badge' | 'boost';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  owned?: boolean;
}

// Mock store items
const mockStoreItems: StoreItem[] = [
  {
    id: '1',
    emoji: '🚴',
    name: 'Carbon Frame',
    description: '+2% speed boost on all rides',
    price: 2500,
    category: 'equipment',
    rarity: 'legendary'
  },
  {
    id: '2',
    emoji: '⚙️',
    name: 'Aero Wheels',
    description: 'Reduce drag by 5% on flat terrain',
    price: 1800,
    category: 'equipment',
    rarity: 'epic'
  },
  {
    id: '3',
    emoji: '👕',
    name: 'Pro Jersey',
    description: 'Look fast, feel fast',
    price: 800,
    category: 'equipment',
    rarity: 'rare',
    owned: true
  },
  {
    id: '4',
    emoji: '🏆',
    name: 'Champion Badge',
    description: 'Display your dominance',
    price: 500,
    category: 'badge',
    rarity: 'epic'
  },
  {
    id: '5',
    emoji: '⚡',
    name: '2x Dung Boost',
    description: 'Double dung earnings for 24h',
    price: 1200,
    category: 'boost',
    rarity: 'rare'
  },
  {
    id: '6',
    emoji: '🔋',
    name: 'Energy Tank',
    description: 'Reduce fatigue by 10% for one week',
    price: 1500,
    category: 'boost',
    rarity: 'epic'
  },
  {
    id: '7',
    emoji: '🎨',
    name: 'Custom Colors',
    description: 'Unlock beetle color customization',
    price: 600,
    category: 'badge',
    rarity: 'rare'
  },
  {
    id: '8',
    emoji: '💎',
    name: 'Diamond Saddle',
    description: '+5% comfort on climbs',
    price: 3200,
    category: 'equipment',
    rarity: 'legendary'
  },
];

export default function BeetleStore() {
  const { colors, isDarkMode } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'equipment' | 'badge' | 'boost'>('all');

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const userBalance = 2847; // Mock balance

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return '#d4af37';
      case 'epic': return '#8a4ff5';
      case 'rare': return '#4a90e2';
      case 'common': return '#7a8a7a';
      default: return colors.text;
    }
  };

  const filteredItems = mockStoreItems.filter(item => 
    selectedCategory === 'all' || item.category === selectedCategory
  );

  const canAfford = (price: number) => price <= userBalance;

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[1200px] mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 
            className="font-['Inter'] font-black text-[28px] mb-1"
            style={{ color: colors.text }}
          >
            🪲 Beetle Store
          </h1>
          <p 
            className="font-['Inter'] text-[12px]"
            style={{ color: colors.textMuted }}
          >
            Redeem dung for equipment, badges, and boosts
          </p>
        </div>

        {/* Balance Panel */}
        <div 
          className="rounded-[6px] border-[1px] overflow-hidden mb-6"
          style={{ 
            backgroundColor: cardBg,
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          <div className="px-6 py-5">
            <div className="flex items-end justify-between">
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ 
                    color: '#c89b5c',
                    textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
                  }}
                >
                  {userBalance.toLocaleString()}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Your Balance 🪲
                </div>
              </div>
              <div className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>
                Spend wisely • Items are permanent
              </div>
            </div>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex gap-2 mb-4">
          {(['all', 'equipment', 'badge', 'boost'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className="px-4 py-2 rounded-[4px] border-[1px] transition-colors"
              style={{
                backgroundColor: selectedCategory === cat ? (isDarkMode ? 'rgba(139, 168, 122, 0.15)' : 'rgba(139, 168, 122, 0.1)') : 'transparent',
                borderColor: selectedCategory === cat ? colors.accent : (isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'),
                color: selectedCategory === cat ? colors.accent : colors.textMuted,
              }}
            >
              <span className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide">
                {cat}
              </span>
            </button>
          ))}
        </div>

        {/* Store Grid */}
        <div className="grid grid-cols-2 gap-4">
          {filteredItems.map((item) => {
            const affordable = canAfford(item.price);
            
            return (
              <div 
                key={item.id}
                className="rounded-[6px] border-[2px] p-5"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: getRarityColor(item.rarity),
                  boxShadow: `3px 3px 0px 0px ${getRarityColor(item.rarity)}`,
                  opacity: item.owned ? 0.6 : 1,
                }}
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div 
                    className="w-16 h-16 rounded-[6px] border-[2px] flex items-center justify-center flex-shrink-0"
                    style={{ 
                      backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)',
                      borderColor: getRarityColor(item.rarity),
                    }}
                  >
                    <span className="text-[32px]">{item.emoji}</span>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-1">
                      <div>
                        <div className="flex items-center gap-2 mb-0.5">
                          <h3 
                            className="font-['Inter'] text-[16px] font-bold"
                            style={{ color: colors.text }}
                          >
                            {item.name}
                          </h3>
                          {item.owned && (
                            <span className="font-['Inter'] text-[10px] px-2 py-0.5 rounded-[4px] border-[1px]" style={{
                              borderColor: colors.accent,
                              color: colors.accent,
                            }}>
                              OWNED
                            </span>
                          )}
                        </div>
                        <p 
                          className="font-['Inter'] text-[11px] mb-2"
                          style={{ color: colors.textMuted }}
                        >
                          {item.description}
                        </p>
                        <div 
                          className="inline-block px-2 py-0.5 rounded-[4px] border-[1px]"
                          style={{ 
                            backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)',
                            borderColor: getRarityColor(item.rarity),
                          }}
                        >
                          <span 
                            className="font-['Inter'] text-[9px] font-bold uppercase tracking-wide"
                            style={{ color: getRarityColor(item.rarity) }}
                          >
                            {item.rarity}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Price and Purchase */}
                    <div className="flex items-center justify-between mt-3">
                      {/* Price - LOOT emphasis */}
                      <div>
                        <div 
                          className="font-['Cousine'] text-[22px] font-bold leading-none mb-0.5"
                          style={{ 
                            color: affordable ? '#c89b5c' : colors.textMuted,
                          }}
                        >
                          {item.price.toLocaleString()}
                        </div>
                        <div 
                          className="font-['Inter'] text-[9px]"
                          style={{ color: colors.textMuted }}
                        >
                          Dung Cost
                        </div>
                      </div>

                      {/* Buy Button */}
                      <button
                        disabled={!affordable || item.owned}
                        className="px-4 py-2 rounded-[4px] border-[2px] transition-all"
                        style={{
                          backgroundColor: (affordable && !item.owned) ? colors.accent : 'transparent',
                          borderColor: (affordable && !item.owned) ? colors.accent : (isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'),
                          color: (affordable && !item.owned) ? colors.bg : colors.textMuted,
                          boxShadow: (affordable && !item.owned) ? `2px 2px 0px 0px ${colors.border}` : 'none',
                          cursor: (affordable && !item.owned) ? 'pointer' : 'not-allowed',
                          opacity: (affordable && !item.owned) ? 1 : 0.5,
                        }}
                      >
                        <span className="font-['Inter'] text-[12px] font-bold">
                          {item.owned ? 'OWNED' : affordable ? 'BUY' : 'LOCKED'}
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
