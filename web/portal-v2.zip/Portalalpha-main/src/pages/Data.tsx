import { useTheme } from '../contexts/ThemeContext';

export default function Data() {
  const { colors, isDarkMode } = useTheme();

  // Mock fitness data
  const fitnessData = {
    ftp: 285,
    ctl: 68.4, // Chronic Training Load (Fitness)
    atl: 72.1, // Acute Training Load (Fatigue)
    tsb: -3.7, // Training Stress Balance (Form)
    weeklyTss: 542,
    vo2max: 58.2,
  };

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  // Calculate form status
  const formStatus = fitnessData.tsb > 5 ? 'Fresh' : fitnessData.tsb < -10 ? 'Fatigued' : 'Optimal';
  const formColor = fitnessData.tsb > 5 ? '#8ba87a' : fitnessData.tsb < -10 ? '#c89b5c' : colors.accent;

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[1200px] mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 
            className="font-['Inter'] font-black text-[28px] mb-1"
            style={{ color: colors.text }}
          >
            📊 Training Data
          </h1>
          <p 
            className="font-['Inter'] text-[12px]"
            style={{ color: colors.textMuted }}
          >
            Performance metrics and fitness tracking
          </p>
        </div>

        {/* Hero Stats - Terminal Panel */}
        <div 
          className="rounded-[6px] border-[1px] overflow-hidden mb-6"
          style={{ 
            backgroundColor: cardBg,
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          <div className="px-6 py-5">
            <div className="grid grid-cols-4 gap-8">
              {/* FTP */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {fitnessData.ftp}
                  <span className="text-[16px] ml-1" style={{ color: colors.textMuted }}>
                    W
                  </span>
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  FTP
                </div>
              </div>

              {/* CTL */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: '#8ba87a' }}
                >
                  {fitnessData.ctl}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Fitness (CTL)
                </div>
              </div>

              {/* ATL */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: '#c89b5c' }}
                >
                  {fitnessData.atl}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Fatigue (ATL)
                </div>
              </div>

              {/* TSB */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: formColor }}
                >
                  {fitnessData.tsb > 0 ? '+' : ''}{fitnessData.tsb}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Form (TSB)
                </div>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div 
            className="h-[1px]" 
            style={{ 
              backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' 
            }} 
          />

          {/* Secondary Stats */}
          <div className="px-6 py-4">
            <div className="grid grid-cols-2 gap-8">
              {/* Weekly TSS */}
              <div>
                <div 
                  className="font-['Cousine'] text-[28px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {fitnessData.weeklyTss}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Weekly TSS
                </div>
              </div>

              {/* VO2 Max */}
              <div>
                <div 
                  className="font-['Cousine'] text-[28px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {fitnessData.vo2max}
                  <span className="text-[11px] ml-1" style={{ color: colors.textMuted }}>
                    ml/kg/min
                  </span>
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  VO₂ Max (Estimated)
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-2 gap-6">
          {/* Power Zones */}
          <div 
            className="rounded-[6px] border-[1px] overflow-hidden"
            style={{ 
              backgroundColor: cardBg,
              borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
            }}
          >
            <div className="px-6 py-4">
              <div className="font-['Inter'] text-[11px] uppercase tracking-wide mb-4" style={{ color: colors.textMuted }}>
                Power Zones (FTP: {fitnessData.ftp}W)
              </div>
              
              <div className="space-y-2.5">
                {[
                  { zone: 'Z1', name: 'Active Recovery', range: `< ${Math.floor(fitnessData.ftp * 0.55)}W`, percent: '< 55%' },
                  { zone: 'Z2', name: 'Endurance', range: `${Math.floor(fitnessData.ftp * 0.55)}-${Math.floor(fitnessData.ftp * 0.75)}W`, percent: '56-75%' },
                  { zone: 'Z3', name: 'Tempo', range: `${Math.floor(fitnessData.ftp * 0.76)}-${Math.floor(fitnessData.ftp * 0.90)}W`, percent: '76-90%' },
                  { zone: 'Z4', name: 'Threshold', range: `${Math.floor(fitnessData.ftp * 0.91)}-${Math.floor(fitnessData.ftp * 1.05)}W`, percent: '91-105%' },
                  { zone: 'Z5', name: 'VO2 Max', range: `${Math.floor(fitnessData.ftp * 1.06)}-${Math.floor(fitnessData.ftp * 1.20)}W`, percent: '106-120%' },
                  { zone: 'Z6', name: 'Anaerobic', range: `> ${Math.floor(fitnessData.ftp * 1.20)}W`, percent: '> 120%' },
                ].map((zone, index) => (
                  <div key={zone.zone}>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span 
                          className="font-['Cousine'] text-[13px] font-bold"
                          style={{ color: colors.text }}
                        >
                          {zone.zone}
                        </span>
                        <span 
                          className="font-['Inter'] text-[12px]"
                          style={{ color: colors.textMuted }}
                        >
                          {zone.name}
                        </span>
                      </div>
                      <div className="text-right">
                        <span 
                          className="font-['Cousine'] text-[13px] font-bold"
                          style={{ color: colors.text }}
                          dangerouslySetInnerHTML={{ __html: zone.range }}
                        />
                        <span 
                          className="font-['Cousine'] text-[10px] ml-2"
                          style={{ color: colors.textMuted }}
                          dangerouslySetInnerHTML={{ __html: zone.percent }}
                        />
                      </div>
                    </div>
                    {index < 5 && (
                      <div 
                        className="h-[1px] mt-2.5" 
                        style={{ 
                          backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.06)' : 'rgba(42, 45, 30, 0.04)' 
                        }} 
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Heart Rate Zones */}
          <div 
            className="rounded-[6px] border-[1px] overflow-hidden"
            style={{ 
              backgroundColor: cardBg,
              borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
            }}
          >
            <div className="px-6 py-4">
              <div className="font-['Inter'] text-[11px] uppercase tracking-wide mb-4" style={{ color: colors.textMuted }}>
                Heart Rate Zones (Max: 188 bpm)
              </div>
              
              <div className="space-y-2.5">
                {[
                  { zone: 'Z1', name: 'Recovery', range: '< 132 bpm', percent: '< 70%' },
                  { zone: 'Z2', name: 'Aerobic', range: '132-151 bpm', percent: '70-80%' },
                  { zone: 'Z3', name: 'Tempo', range: '151-169 bpm', percent: '81-90%' },
                  { zone: 'Z4', name: 'Threshold', range: '169-179 bpm', percent: '91-95%' },
                  { zone: 'Z5', name: 'Anaerobic', range: '> 179 bpm', percent: '> 95%' },
                ].map((zone, index) => (
                  <div key={zone.zone}>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2">
                        <span 
                          className="font-['Cousine'] text-[13px] font-bold"
                          style={{ color: colors.text }}
                        >
                          {zone.zone}
                        </span>
                        <span 
                          className="font-['Inter'] text-[12px]"
                          style={{ color: colors.textMuted }}
                        >
                          {zone.name}
                        </span>
                      </div>
                      <div className="text-right">
                        <span 
                          className="font-['Cousine'] text-[13px] font-bold"
                          style={{ color: colors.text }}
                          dangerouslySetInnerHTML={{ __html: zone.range }}
                        />
                        <span 
                          className="font-['Cousine'] text-[10px] ml-2"
                          style={{ color: colors.textMuted }}
                          dangerouslySetInnerHTML={{ __html: zone.percent }}
                        />
                      </div>
                    </div>
                    {index < 4 && (
                      <div 
                        className="h-[1px] mt-2.5" 
                        style={{ 
                          backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.06)' : 'rgba(42, 45, 30, 0.04)' 
                        }} 
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Form Advice Panel */}
        <div 
          className="mt-6 rounded-[6px] border-[1px] overflow-hidden"
          style={{ 
            backgroundColor: cardBg,
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          <div className="px-6 py-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-['Inter'] text-[11px] uppercase tracking-wide mb-1" style={{ color: colors.textMuted }}>
                  Training Status
                </div>
                <div className="font-['Inter'] text-[16px] font-bold" style={{ color: colors.text }}>
                  {formStatus === 'Fresh' && 'You\'re fresh and ready to race! Consider a breakthrough workout.'}
                  {formStatus === 'Optimal' && 'Optimal training state. Balance maintained between fitness and fatigue.'}
                  {formStatus === 'Fatigued' && 'Building fitness but accumulating fatigue. Recovery soon recommended.'}
                </div>
              </div>
              <div 
                className="px-4 py-2 rounded-[4px] border-[2px]"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: formColor,
                  boxShadow: `2px 2px 0px 0px ${formColor}`,
                }}
              >
                <span 
                  className="font-['Inter'] text-[14px] font-black"
                  style={{ color: formColor }}
                >
                  {formStatus.toUpperCase()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}