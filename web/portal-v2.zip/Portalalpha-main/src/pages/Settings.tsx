import { useState, useEffect } from 'react';
import { useTheme, THEMES } from '../contexts/ThemeContext';
import { BeetleButton } from '../components/ui/beetle-button';
import { toast } from 'sonner@2.0.3';
import { User, Zap, Monitor, Lock, Link as LinkIcon, Save, RefreshCw, Power } from 'lucide-react';

export default function Settings() {
  const { themeId, setThemeId, colors, isDarkMode, toggleDarkMode } = useTheme();
  
  // -- State Management --
  const [activeTab, setActiveTab] = useState('profile');
  const [isSaving, setIsSaving] = useState(false);

  // Profile
  const [formData, setFormData] = useState({
    username: 'climber_420',
    bio: 'Pushing watts up mountains. Allez allez.',
    location: 'San Francisco, CA',
    ftp: '250',
    weight: '70',
    riderType: 'climber',
    units: 'metric',
    visibility: 'public'
  });

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      toast.success('CONFIGURATION SAVED');
    }, 800);
  };

  const navItems = [
    { id: 'profile', label: 'Identity', icon: User },
    { id: 'performance', label: 'Performance', icon: Zap },
    { id: 'display', label: 'Interface', icon: Monitor },
    { id: 'privacy', label: 'Security', icon: Lock },
    { id: 'connections', label: 'Links', icon: LinkIcon },
  ];

  // -- Components --

  const SectionHeader = ({ title, subtitle }: { title: string, subtitle: string }) => (
    <div className="mb-8 border-b border-border pb-4">
      <h2 className="font-['Inter'] font-black text-2xl uppercase tracking-tight">{title}</h2>
      <p className="font-['Cousine'] text-xs text-muted-foreground mt-1 uppercase tracking-widest">{subtitle}</p>
    </div>
  );

  const FormGroup = ({ label, children }: { label: string, children: React.ReactNode }) => (
    <div className="space-y-2 mb-6">
      <label className="block font-['Inter'] text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground">
        {label}
      </label>
      {children}
    </div>
  );

  const Input = ({ ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
    <input 
      className="w-full bg-transparent border border-border p-4 font-['Cousine'] text-sm focus:border-foreground focus:border-2 focus:outline-none transition-all placeholder:text-muted-foreground/30 rounded-none hover:border-accent"
      {...props}
    />
  );

  const Select = ({ children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement>) => (
    <div className="relative">
      <select 
        className="w-full appearance-none bg-transparent border border-border p-4 font-['Cousine'] text-sm focus:border-foreground focus:border-2 focus:outline-none transition-all cursor-pointer rounded-none hover:border-accent uppercase"
        {...props}
      >
        {children}
      </select>
      <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none opacity-50">
        <div className="h-0 w-0 border-x-4 border-x-transparent border-t-[6px] border-t-foreground"></div>
      </div>
    </div>
  );

  // -- Render --

  return (
    <div className="min-h-screen bg-background text-foreground animate-in fade-in duration-500">
      <div className="max-w-6xl mx-auto px-4 py-8">
        
        {/* Top Actions Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4 border-b border-border pb-6">
          <div className="flex items-center gap-3">
             <div className="w-2 h-2 bg-green-500 animate-pulse" />
             <span className="font-['Cousine'] text-xs text-muted-foreground tracking-widest">SYSTEM ONLINE // {formData.username.toUpperCase()}</span>
          </div>
          
          <div className="flex gap-4">
            <BeetleButton 
              variant="outline" 
              size="sm"
              className="hidden md:flex h-10 rounded-none border-border"
              onClick={() => toast('Config reset to default')}
            >
               <RefreshCw size={14} className="mr-2" />
               RESET
            </BeetleButton>
            <BeetleButton 
              variant="primary" 
              size="sm"
              onClick={handleSave}
              disabled={isSaving}
              className="w-full md:w-auto h-10 rounded-none shadow-[4px_4px_0px_0px_var(--foreground)] hover:translate-x-[-2px] hover:translate-y-[-2px] transition-all active:shadow-none active:translate-x-0 active:translate-y-0"
            >
               {isSaving ? 'SAVING...' : (
                 <>
                   <Save size={14} className="mr-2" />
                   SAVE CHANGES
                 </>
               )}
            </BeetleButton>
          </div>
        </div>

        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-0 md:gap-12">
           
           {/* Left Navigation (Desktop) / Top Nav (Mobile) */}
           <div className="md:col-span-3 lg:col-span-3 mb-8 md:mb-0">
              <nav className="flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-visible pb-4 md:pb-0 scroll-bounce">
                {navItems.map((item) => {
                  const isActive = activeTab === item.id;
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveTab(item.id)}
                      className={`
                        flex items-center gap-3 px-4 py-3 md:py-4 transition-all duration-200 border whitespace-nowrap
                        ${isActive 
                           ? 'bg-foreground text-background border-foreground translate-x-1' 
                           : 'bg-transparent text-muted-foreground border-transparent hover:border-border hover:bg-accent/30 hover:text-foreground'
                        }
                      `}
                    >
                      <Icon size={16} strokeWidth={isActive ? 3 : 2} />
                      <span className={`font-['Inter'] text-xs font-bold uppercase tracking-widest ${isActive ? 'opacity-100' : 'opacity-70'}`}>
                        {item.label}
                      </span>
                      {isActive && <div className="ml-auto w-1.5 h-1.5 bg-background hidden md:block" />}
                    </button>
                  );
                })}
              </nav>
              
              {/* User Summary Widget (Desktop Only) */}
              <div className="hidden md:block mt-12 p-6 border border-border bg-accent/5">
                 <div className="font-['Cousine'] text-[10px] text-muted-foreground mb-4">CURRENT SESSION</div>
                 <div className="font-['Cousine'] text-sm mb-1">{formData.username}</div>
                 <div className="font-['Cousine'] text-xs opacity-50">ID: #8832</div>
                 <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
                    <span className="font-['Inter'] text-[10px] font-bold">VER 2.0.4</span>
                    <div className="w-2 h-2 rounded-full bg-green-500" />
                 </div>
              </div>
           </div>

           {/* Right Content Area */}
           <div className="md:col-span-9 lg:col-span-8 min-h-[500px]">
              
              {/* PROFILE TAB */}
              {activeTab === 'profile' && (
                 <div className="animate-in slide-in-from-right-4 duration-300 fade-in">
                    <SectionHeader title="Rider Identity" subtitle="Public facing profile configuration" />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <FormGroup label="Username">
                          <Input 
                             value={formData.username} 
                             onChange={(e) => setFormData({...formData, username: e.target.value})} 
                          />
                       </FormGroup>
                       <FormGroup label="Base Location">
                          <Input 
                             value={formData.location} 
                             onChange={(e) => setFormData({...formData, location: e.target.value})} 
                          />
                       </FormGroup>
                    </div>

                    <FormGroup label="Rider Bio">
                       <textarea 
                          className="w-full h-32 bg-transparent border border-border p-4 font-['Cousine'] text-sm focus:border-foreground focus:border-2 focus:outline-none transition-all placeholder:text-muted-foreground/30 resize-none rounded-none hover:border-accent"
                          value={formData.bio}
                          onChange={(e) => setFormData({...formData, bio: e.target.value})} 
                       />
                       <div className="text-right font-['Cousine'] text-[10px] text-muted-foreground mt-1">
                          {formData.bio.length} / 150 CHARS
                       </div>
                    </FormGroup>
                 </div>
              )}

              {/* PERFORMANCE TAB */}
              {activeTab === 'performance' && (
                 <div className="animate-in slide-in-from-right-4 duration-300 fade-in">
                    <SectionHeader title="Physics Engine" subtitle="Biometrics and power data configuration" />
                    
                    <div className="p-6 border border-accent bg-accent/5 mb-8 flex items-start gap-4">
                       <div className="p-2 bg-foreground text-background">
                          <Zap size={16} />
                       </div>
                       <div>
                          <h4 className="font-['Inter'] font-bold text-sm uppercase mb-1">Warning</h4>
                          <p className="font-['Cousine'] text-xs text-muted-foreground leading-relaxed">
                             Changing these values will recalculate all historical stress scores. Proceed with caution.
                          </p>
                       </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                       <FormGroup label="FTP (Watts)">
                          <Input 
                             type="number"
                             value={formData.ftp} 
                             onChange={(e) => setFormData({...formData, ftp: e.target.value})} 
                          />
                       </FormGroup>
                       <FormGroup label="Weight (Kg)">
                          <Input 
                             type="number"
                             value={formData.weight} 
                             onChange={(e) => setFormData({...formData, weight: e.target.value})} 
                          />
                       </FormGroup>
                       <FormGroup label="Class">
                          <Select 
                             value={formData.riderType}
                             onChange={(e) => setFormData({...formData, riderType: e.target.value})}
                          >
                             <option value="climber">CLIMBER</option>
                             <option value="sprinter">SPRINTER</option>
                             <option value="tt">TIME TRIAL</option>
                             <option value="rouleur">ROULEUR</option>
                          </Select>
                       </FormGroup>
                    </div>

                    <div className="mt-8 pt-8 border-t border-border">
                       <div className="grid grid-cols-6 gap-0.5 bg-border/20 border border-border/20">
                          {[55, 75, 90, 105, 120, 150].map((limit, i) => (
                             <div key={i} className="bg-background p-3 text-center hover:bg-accent/20 transition-colors">
                                <div className="font-['Inter'] text-[10px] font-bold text-muted-foreground mb-1">Z{i+1}</div>
                                <div className="font-['Cousine'] text-xs font-bold">{Math.round(parseInt(formData.ftp) * (limit/100))}w</div>
                             </div>
                          ))}
                       </div>
                       <p className="mt-2 font-['Cousine'] text-[10px] text-muted-foreground text-center">CALCULATED POWER ZONES BASED ON CURRENT FTP</p>
                    </div>
                 </div>
              )}

              {/* DISPLAY TAB */}
              {activeTab === 'display' && (
                 <div className="animate-in slide-in-from-right-4 duration-300 fade-in">
                    <SectionHeader title="Visual System" subtitle="Interface customization" />
                    
                    <div className="grid grid-cols-1 gap-8">
                       <FormGroup label="System Mode">
                          <div className="flex w-full border border-border">
                             <button 
                                onClick={() => !isDarkMode && toggleDarkMode()}
                                className={`flex-1 py-8 flex flex-col items-center gap-3 transition-colors ${isDarkMode ? 'bg-foreground text-background' : 'hover:bg-accent'}`}
                             >
                                <div className={`w-4 h-4 rounded-full border border-current ${isDarkMode ? 'bg-background' : ''}`} />
                                <span className="font-['Inter'] text-xs font-bold uppercase tracking-widest">Dark Protocol</span>
                             </button>
                             <div className="w-[1px] bg-border" />
                             <button 
                                onClick={() => isDarkMode && toggleDarkMode()}
                                className={`flex-1 py-8 flex flex-col items-center gap-3 transition-colors ${!isDarkMode ? 'bg-foreground text-background' : 'hover:bg-accent'}`}
                             >
                                <div className={`w-4 h-4 rounded-full border border-current ${!isDarkMode ? 'bg-background' : ''}`} />
                                <span className="font-['Inter'] text-xs font-bold uppercase tracking-widest">Light Protocol</span>
                             </button>
                          </div>
                       </FormGroup>

                       <FormGroup label="Accent Color">
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                             {Object.values(THEMES).map((theme) => (
                                <button
                                   key={theme.id}
                                   onClick={() => setThemeId(theme.id)}
                                   className={`
                                      group relative h-24 border transition-all
                                      ${themeId === theme.id 
                                         ? 'border-foreground shadow-[4px_4px_0px_0px_var(--foreground)] -translate-y-1' 
                                         : 'border-border hover:border-foreground/50 hover:bg-accent/10'
                                      }
                                   `}
                                >
                                   <div className="absolute top-2 left-3 font-['Cousine'] text-[10px] uppercase">
                                      {theme.name}
                                   </div>
                                   <div 
                                      className="absolute bottom-3 right-3 w-8 h-8 rounded-full border border-border"
                                      style={{ backgroundColor: theme.light.accent }} 
                                   />
                                </button>
                             ))}
                          </div>
                       </FormGroup>

                       <FormGroup label="Measurement Units">
                          <div className="flex gap-4">
                             <label className="flex items-center gap-3 cursor-pointer group">
                                <div className={`w-5 h-5 border border-border flex items-center justify-center ${formData.units === 'metric' ? 'bg-foreground text-background' : 'group-hover:border-foreground'}`}>
                                   {formData.units === 'metric' && <div className="w-2 h-2 bg-current" />}
                                </div>
                                <input type="radio" className="hidden" checked={formData.units === 'metric'} onChange={() => setFormData({...formData, units: 'metric'})} />
                                <span className="font-['Inter'] text-xs font-bold uppercase tracking-wide">Metric (KM/KG)</span>
                             </label>
                             <label className="flex items-center gap-3 cursor-pointer group">
                                <div className={`w-5 h-5 border border-border flex items-center justify-center ${formData.units === 'imperial' ? 'bg-foreground text-background' : 'group-hover:border-foreground'}`}>
                                   {formData.units === 'imperial' && <div className="w-2 h-2 bg-current" />}
                                </div>
                                <input type="radio" className="hidden" checked={formData.units === 'imperial'} onChange={() => setFormData({...formData, units: 'imperial'})} />
                                <span className="font-['Inter'] text-xs font-bold uppercase tracking-wide">Imperial (MI/LB)</span>
                             </label>
                          </div>
                       </FormGroup>
                    </div>
                 </div>
              )}

              {/* CONNECTIONS TAB */}
              {activeTab === 'connections' && (
                 <div className="animate-in slide-in-from-right-4 duration-300 fade-in">
                    <SectionHeader title="External Links" subtitle="Third-party integrations" />
                    
                    <div className="space-y-4">
                       {/* Connection Item */}
                       <div className="border border-border p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:border-foreground transition-colors group">
                          <div className="flex items-start gap-4">
                             <div className="p-3 bg-accent/20">
                                <LinkIcon size={20} />
                             </div>
                             <div>
                                <h3 className="font-['Inter'] font-bold text-sm uppercase">Strava</h3>
                                <p className="font-['Cousine'] text-xs text-muted-foreground mt-1">SYNC ACTIVITIES AND SEGMENTS</p>
                             </div>
                          </div>
                          <BeetleButton variant="outline" size="sm" className="opacity-50 group-hover:opacity-100">
                             CONNECT
                          </BeetleButton>
                       </div>

                       {/* Connection Item */}
                       <div className="border border-foreground bg-accent/5 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                          <div className="flex items-start gap-4">
                             <div className="p-3 bg-foreground text-background">
                                <Lock size={20} />
                             </div>
                             <div>
                                <h3 className="font-['Inter'] font-bold text-sm uppercase">Solana Wallet</h3>
                                <p className="font-['Cousine'] text-xs text-muted-foreground mt-1">7xKX...9Qm2</p>
                             </div>
                          </div>
                          <BeetleButton variant="ghost" size="sm" className="text-red-500 hover:text-red-600 hover:bg-red-50">
                             DISCONNECT
                          </BeetleButton>
                       </div>
                    </div>
                 </div>
              )}

              {/* PRIVACY TAB */}
              {activeTab === 'privacy' && (
                 <div className="animate-in slide-in-from-right-4 duration-300 fade-in">
                    <SectionHeader title="Security Protocol" subtitle="Data management and visibility" />
                    
                    <FormGroup label="Profile Visibility">
                       <Select 
                          value={formData.visibility}
                          onChange={(e) => setFormData({...formData, visibility: e.target.value})}
                       >
                          <option value="public">PUBLIC (RECOMMENDED)</option>
                          <option value="followers">FOLLOWERS ONLY</option>
                          <option value="private">PRIVATE (GHOST MODE)</option>
                       </Select>
                    </FormGroup>

                    <div className="mt-12 pt-8 border-t border-red-200">
                       <h4 className="font-['Inter'] font-bold text-sm uppercase text-red-600 mb-4">Danger Zone</h4>
                       <div className="border border-red-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-red-50/50">
                          <div>
                             <h5 className="font-['Inter'] font-bold text-xs uppercase">Delete Account</h5>
                             <p className="font-['Cousine'] text-[10px] text-red-400 mt-1">THIS ACTION IS IRREVERSIBLE. ALL DUNG WILL BE BURNED.</p>
                          </div>
                          <button className="px-4 py-2 bg-red-600 text-white font-['Inter'] font-bold text-[10px] uppercase hover:bg-red-700 transition-colors">
                             TERMINATE
                          </button>
                       </div>
                    </div>
                 </div>
              )}

           </div>
        </div>
      </div>
    </div>
  );
}