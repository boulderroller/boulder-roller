import { useTheme } from '../contexts/ThemeContext';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BeetleButton } from '../components/ui/beetle-button';
import { Search, Star, TrendingUp, Crown } from 'lucide-react';
import SegmentDetailModal from '../components/modals/SegmentDetailModal';

interface Segment {
  id: string;
  name: string;
  location: string;
  distance: number;
  elevation: number;
  grade: number;
  attempts: number;
  personalRecord: {
    time: string;
    date: string;
    avgPower: number;
    dung: number;
    rank?: number;
  } | null;
  kom: {
    time: string;
    holder: string;
    beetleNumber: number;
  };
  isStarred: boolean;
  hasKOM: boolean;
}

// Mock data - matches the segments from SegmentView
const mockSegments: Segment[] = [
  {
    id: 'hawk-hill-climb',
    name: 'Hawk Hill Climb',
    location: 'Marin Headlands, CA',
    distance: 2.1,
    elevation: 210,
    grade: 9.8,
    attempts: 24,
    personalRecord: {
      time: '8:42',
      date: 'Dec 5, 2024',
      avgPower: 312,
      dung: 85,
      rank: 14
    },
    kom: {
      time: '7:58',
      holder: 'velo_crusher',
      beetleNumber: 89
    },
    isStarred: true,
    hasKOM: false
  },
  {
    id: 'golden-gate-sprint',
    name: 'Golden Gate Sprint',
    location: 'San Francisco, CA',
    distance: 0.8,
    elevation: 45,
    grade: 5.2,
    attempts: 42,
    personalRecord: {
      time: '2:18',
      date: 'Nov 28, 2024',
      avgPower: 385,
      dung: 32,
      rank: 45
    },
    kom: {
      time: '1:52',
      holder: 'sprint_king',
      beetleNumber: 247
    },
    isStarred: true,
    hasKOM: false
  },
  {
    id: 'paradise-loop',
    name: 'Paradise Loop',
    location: 'Tiburon, CA',
    distance: 11.4,
    elevation: 285,
    grade: 2.5,
    attempts: 18,
    personalRecord: {
      time: '24:51',
      date: 'Dec 1, 2024',
      avgPower: 265,
      dung: 142,
      rank: 8
    },
    kom: {
      time: '22:14',
      holder: 'endurance_beast',
      beetleNumber: 521
    },
    isStarred: true,
    hasKOM: false
  },
  {
    id: 'diablo-summit',
    name: 'Diablo Summit',
    location: 'Mount Diablo, CA',
    distance: 17.4,
    elevation: 1120,
    grade: 6.4,
    attempts: 9,
    personalRecord: {
      time: '1:02:18',
      date: 'Oct 14, 2024',
      avgPower: 268,
      dung: 385,
      rank: 22
    },
    kom: {
      time: '58:42',
      holder: 'gravel_goblin',
      beetleNumber: 142
    },
    isStarred: true,
    hasKOM: false
  },
  {
    id: 'grizzly-peak',
    name: 'Grizzly Peak',
    location: 'Berkeley Hills, CA',
    distance: 4.3,
    elevation: 320,
    grade: 7.4,
    attempts: 22,
    personalRecord: {
      time: '16:45',
      date: 'Nov 12, 2024',
      avgPower: 285,
      dung: 118,
      rank: 11
    },
    kom: {
      time: '15:32',
      holder: 'threshold_boss',
      beetleNumber: 378
    },
    isStarred: true,
    hasKOM: false
  },
  {
    id: 'alpine-dam',
    name: 'Alpine Dam',
    location: 'Marin County, CA',
    distance: 3.2,
    elevation: 245,
    grade: 7.6,
    attempts: 15,
    personalRecord: {
      time: '12:28',
      date: 'Sep 22, 2024',
      avgPower: 302,
      dung: 96,
      rank: 7
    },
    kom: {
      time: '11:15',
      holder: 'velo_crusher',
      beetleNumber: 89
    },
    isStarred: false,
    hasKOM: false
  }
];

export default function MySegments() {
  const { colors, isDarkMode } = useTheme();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStarred, setFilterStarred] = useState(false);
  const [filterKOM, setFilterKOM] = useState(false);
  const [selectedSegment, setSelectedSegment] = useState<Segment | null>(null);

  const filteredSegments = mockSegments.filter(segment => {
    const matchesSearch = segment.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         segment.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStarred = !filterStarred || segment.isStarred;
    const matchesKOM = !filterKOM || segment.hasKOM;
    return matchesSearch && matchesStarred && matchesKOM;
  });

  const totalAttempts = mockSegments.reduce((sum, seg) => sum + seg.attempts, 0);
  const totalKOMs = mockSegments.filter(seg => seg.hasKOM).length;
  const starredCount = mockSegments.filter(seg => seg.isStarred).length;

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-6xl mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 
            className="font-['Inter'] font-black text-[28px] mb-1"
            style={{ color: colors.text }}
          >
            My Segments
          </h1>
          <p 
            className="font-['Inter'] text-[12px]"
            style={{ color: colors.textMuted }}
          >
            Starred segments, attempts, and personal records
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className="font-['Inter'] uppercase tracking-wide text-[9px] mb-1"
              style={{ color: colors.textMuted }}
            >
              Starred
            </div>
            <div 
              className="font-['Cousine'] text-[28px]"
              style={{ color: colors.text }}
            >
              {starredCount}
            </div>
          </div>

          <div
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className="font-['Inter'] uppercase tracking-wide text-[9px] mb-1"
              style={{ color: colors.textMuted }}
            >
              Total Attempts
            </div>
            <div 
              className="font-['Cousine'] text-[28px]"
              style={{ color: colors.text }}
            >
              {totalAttempts}
            </div>
          </div>

          <div
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className="font-['Inter'] uppercase tracking-wide text-[9px] mb-1"
              style={{ color: colors.textMuted }}
            >
              KOMs/QOMs
            </div>
            <div 
              className="font-['Cousine'] text-[28px] flex items-center gap-2"
              style={{ color: '#d4af37' }}
            >
              {totalKOMs}
              <Crown size={20} style={{ color: '#d4af37' }} />
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1">
            <Search 
              size={16} 
              className="absolute left-3 top-1/2 -translate-y-1/2"
              style={{ color: colors.textMuted }}
            />
            <input
              type="text"
              placeholder="Search segments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-[6px] border-[1px] font-['Inter'] text-[13px] transition-all duration-150"
              style={{
                backgroundColor: colors.bg,
                borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
                color: colors.text,
              }}
            />
          </div>

          <BeetleButton
            variant={filterStarred ? 'primary' : 'secondary'}
            onClick={() => setFilterStarred(!filterStarred)}
            className="flex items-center gap-2"
          >
            <Star size={14} fill={filterStarred ? '#c89b5c' : 'none'} />
            Starred
          </BeetleButton>

          <BeetleButton
            variant={filterKOM ? 'primary' : 'secondary'}
            onClick={() => setFilterKOM(!filterKOM)}
            className="flex items-center gap-2"
          >
            <Crown size={14} fill={filterKOM ? '#d4af37' : 'none'} />
            KOMs Only
          </BeetleButton>
        </div>

        {/* Segments Table */}
        <div
          className="border-[1px] rounded-[6px] overflow-hidden"
          style={{
            backgroundColor: colors.bg,
            borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
          }}
        >
          {/* Table Header */}
          <div
            className="grid grid-cols-12 gap-4 px-5 py-3 border-b-[1px]"
            style={{
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
              backgroundColor: isDarkMode ? 'rgba(42, 45, 30, 0.3)' : 'rgba(243, 245, 237, 0.5)',
            }}
          >
            <div className="col-span-1">
              <div className="font-['Inter'] uppercase tracking-wide text-[9px]" style={{ color: colors.textMuted }}>
                Star
              </div>
            </div>
            <div className="col-span-3">
              <div className="font-['Inter'] uppercase tracking-wide text-[9px]" style={{ color: colors.textMuted }}>
                Segment
              </div>
            </div>
            <div className="col-span-2">
              <div className="font-['Inter'] uppercase tracking-wide text-[9px]" style={{ color: colors.textMuted }}>
                Stats
              </div>
            </div>
            <div className="col-span-2">
              <div className="font-['Inter'] uppercase tracking-wide text-[9px]" style={{ color: colors.textMuted }}>
                Your PR
              </div>
            </div>
            <div className="col-span-2">
              <div className="font-['Inter'] uppercase tracking-wide text-[9px]" style={{ color: colors.textMuted }}>
                KOM/QOM
              </div>
            </div>
            <div className="col-span-2">
              <div className="font-['Inter'] uppercase tracking-wide text-[9px]" style={{ color: colors.textMuted }}>
                Dung
              </div>
            </div>
          </div>

          {/* Table Body */}
          {filteredSegments.length === 0 ? (
            <div className="px-5 py-12 text-center">
              <p className="font-['Inter'] text-[14px]" style={{ color: colors.textMuted }}>
                No segments found
              </p>
            </div>
          ) : (
            filteredSegments.map((segment, index) => (
              <div
                key={segment.id}
                className="grid grid-cols-12 gap-4 px-5 py-4 border-b-[1px] last:border-b-0 hover:bg-opacity-50 transition-colors cursor-pointer"
                style={{
                  borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.08)`,
                  backgroundColor: index % 2 === 0 ? 'transparent' : (isDarkMode ? 'rgba(42, 45, 30, 0.15)' : 'rgba(243, 245, 237, 0.3)'),
                }}
                onClick={() => setSelectedSegment(segment)}
              >
                {/* Star */}
                <div className="col-span-1 flex items-center">
                  <Star 
                    size={16} 
                    fill={segment.isStarred ? '#c89b5c' : 'none'}
                    style={{ color: segment.isStarred ? '#c89b5c' : colors.textMuted }}
                  />
                </div>

                {/* Segment Name & Location */}
                <div className="col-span-3">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="font-['Inter'] font-bold text-[13px]" style={{ color: colors.text }}>
                      {segment.name}
                    </div>
                    {segment.hasKOM && (
                      <Crown size={14} style={{ color: '#d4af37' }} fill="#d4af37" />
                    )}
                  </div>
                  <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                    {segment.location}
                  </div>
                </div>

                {/* Stats */}
                <div className="col-span-2 flex flex-col gap-1">
                  <div className="font-['Cousine'] text-[13px]" style={{ color: colors.text }}>
                    {segment.distance}km • {segment.elevation}m
                  </div>
                  <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                    {segment.grade}% • {segment.attempts} attempts
                  </div>
                </div>

                {/* Your PR */}
                <div className="col-span-2 flex flex-col gap-1">
                  {segment.personalRecord ? (
                    <>
                      <div className="font-['Cousine'] text-[14px]" style={{ color: colors.text }}>
                        {segment.personalRecord.time}
                      </div>
                      <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                        {segment.personalRecord.avgPower}w avg
                      </div>
                    </>
                  ) : (
                    <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                      No PR yet
                    </div>
                  )}
                </div>

                {/* KOM/QOM */}
                <div className="col-span-2 flex flex-col gap-1">
                  <div className="font-['Cousine'] text-[13px]" style={{ color: segment.hasKOM ? '#d4af37' : colors.text }}>
                    {segment.kom.time}
                  </div>
                  <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                    🪲 {segment.kom.beetleNumber}
                  </div>
                </div>

                {/* Dung */}
                <div className="col-span-2 flex items-center">
                  {segment.personalRecord && (
                    <div
                      className="px-3 py-1 rounded-[4px] font-['Cousine'] text-[13px]"
                      style={{
                        backgroundColor: isDarkMode ? 'rgba(200, 155, 92, 0.15)' : 'rgba(200, 155, 92, 0.1)',
                        color: '#c89b5c',
                        boxShadow: isDarkMode ? '0 0 8px rgba(200, 155, 92, 0.2)' : '0 0 8px rgba(200, 155, 92, 0.15)',
                      }}
                    >
                      +{segment.personalRecord.dung}
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Segment Detail Modal */}
      {selectedSegment && (
        <SegmentDetailModal
          segment={selectedSegment}
          onClose={() => setSelectedSegment(null)}
          onViewFull={() => {
            navigate(`/segments/${selectedSegment.id}`);
            setSelectedSegment(null);
          }}
        />
      )}
    </div>
  );
}