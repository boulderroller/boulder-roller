import { useTheme } from '../contexts/ThemeContext';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BeetleButton } from '../components/ui/beetle-button';
import { BeetleInput } from '../components/ui/beetle-input';
import { Search, UserPlus, Users, TrendingUp, MapPin } from 'lucide-react';

interface Rider {
  beetleNumber: number;
  username: string;
  tier: 'C' | 'B' | 'A' | 'S' | 'SS';
  location: string;
  ftp: number;
  totalDung: number;
  rideCount: number;
  bio: string;
  isFollowing: boolean;
  mutualFriends: number;
}

// Mock data - riders you might know
const suggestedRiders: Rider[] = [
  {
    beetleNumber: 89,
    username: 'velo_crusher',
    tier: 'SS',
    location: 'San Francisco, CA',
    ftp: 345,
    totalDung: 45892,
    rideCount: 324,
    bio: 'Cat 2 racer, KOM hunter, coffee addict ☕',
    isFollowing: false,
    mutualFriends: 3
  },
  {
    beetleNumber: 142,
    username: 'gravel_goblin',
    tier: 'S',
    location: 'Oakland, CA',
    ftp: 298,
    totalDung: 41203,
    rideCount: 298,
    bio: 'Dirt roads > pavement. Adventure > racing.',
    isFollowing: false,
    mutualFriends: 5
  },
  {
    beetleNumber: 521,
    username: 'power_meter_addict',
    tier: 'A',
    location: 'Berkeley, CA',
    ftp: 312,
    totalDung: 29847,
    rideCount: 245,
    bio: 'Data nerd. Structured training. Zone 2 evangelist.',
    isFollowing: false,
    mutualFriends: 2
  },
  {
    beetleNumber: 378,
    username: 'threshold_boss',
    tier: 'A',
    location: 'Marin County, CA',
    ftp: 305,
    totalDung: 33521,
    rideCount: 268,
    bio: 'Living at FTP. Suffering is optional (not really).',
    isFollowing: true,
    mutualFriends: 4
  },
  {
    beetleNumber: 612,
    username: 'zwift_racer',
    tier: 'B',
    location: 'San Jose, CA',
    ftp: 268,
    totalDung: 24890,
    rideCount: 212,
    bio: 'Indoor training year-round. Watopia resident.',
    isFollowing: false,
    mutualFriends: 1
  },
  {
    beetleNumber: 734,
    username: 'weekend_warrior',
    tier: 'B',
    location: 'Palo Alto, CA',
    ftp: 245,
    totalDung: 22456,
    rideCount: 198,
    bio: 'Work hard, ride harder (on weekends).',
    isFollowing: false,
    mutualFriends: 2
  },
  {
    beetleNumber: 892,
    username: 'climb_repeat_cry',
    tier: 'A',
    location: 'Santa Cruz, CA',
    ftp: 290,
    totalDung: 31245,
    rideCount: 256,
    bio: 'Masochist. Hill repeats are my therapy.',
    isFollowing: false,
    mutualFriends: 3
  },
  {
    beetleNumber: 456,
    username: 'espresso_and_watts',
    tier: 'S',
    location: 'San Francisco, CA',
    ftp: 318,
    totalDung: 38920,
    rideCount: 289,
    bio: 'Fueled by caffeine and Zone 5 intervals.',
    isFollowing: false,
    mutualFriends: 6
  }
];

export default function FindFriends() {
  const { colors, isDarkMode } = useTheme();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTier, setFilterTier] = useState<string | null>(null);
  const [filterLocation, setFilterLocation] = useState<string | null>(null);
  const [followingState, setFollowingState] = useState<{[key: number]: boolean}>(
    suggestedRiders.reduce((acc, rider) => ({ ...acc, [rider.beetleNumber]: rider.isFollowing }), {})
  );

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'SS': return '#d4af37';
      case 'S': return '#c89b5c';
      case 'A': return '#8ba87a';
      case 'B': return '#7a8a7a';
      case 'C': return '#5a6a5a';
      default: return '#5a6a5a';
    }
  };

  const handleFollow = (beetleNumber: number) => {
    setFollowingState(prev => ({
      ...prev,
      [beetleNumber]: !prev[beetleNumber]
    }));
  };

  const filteredRiders = suggestedRiders.filter(rider => {
    const matchesSearch = rider.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         rider.beetleNumber.toString().includes(searchQuery) ||
                         rider.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTier = !filterTier || rider.tier === filterTier;
    const matchesLocation = !filterLocation || rider.location.includes(filterLocation);
    return matchesSearch && matchesTier && matchesLocation;
  });

  const totalFollowing = Object.values(followingState).filter(Boolean).length;
  const avgFTP = Math.round(suggestedRiders.reduce((sum, r) => sum + r.ftp, 0) / suggestedRiders.length);

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-6xl mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 
            className="font-['Inter'] font-black text-[28px] mb-2"
            style={{ color: colors.text }}
          >
            👥 Find Friends
          </h1>
          <p 
            className="font-['Inter'] text-[14px]"
            style={{ color: colors.textMuted }}
          >
            Discover and connect with riders in your area
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className="font-['Inter'] uppercase tracking-wide text-[9px] mb-1"
              style={{ color: colors.textMuted }}
            >
              Following
            </div>
            <div 
              className="font-['Cousine'] text-[28px]"
              style={{ color: colors.text }}
            >
              {totalFollowing}
            </div>
          </div>

          <div
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className="font-['Inter'] uppercase tracking-wide text-[9px] mb-1"
              style={{ color: colors.textMuted }}
            >
              Suggested
            </div>
            <div 
              className="font-['Cousine'] text-[28px]"
              style={{ color: colors.text }}
            >
              {suggestedRiders.length}
            </div>
          </div>

          <div
            className="border-[1px] rounded-[6px] p-5"
            style={{
              backgroundColor: colors.bg,
              borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
            }}
          >
            <div 
              className="font-['Inter'] uppercase tracking-wide text-[9px] mb-1"
              style={{ color: colors.textMuted }}
            >
              Avg FTP
            </div>
            <div 
              className="font-['Cousine'] text-[28px]"
              style={{ color: colors.text }}
            >
              {avgFTP}w
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search 
              size={16} 
              className="absolute left-3 top-1/2 -translate-y-1/2"
              style={{ color: colors.textMuted }}
            />
            <input
              type="text"
              placeholder="Search by username, beetle #, or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-[6px] border-[1px] font-['Inter'] text-[13px] transition-all duration-150"
              style={{
                backgroundColor: colors.bg,
                borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.12)`,
                color: colors.text,
              }}
            />
          </div>
        </div>

        {/* Filter Tags */}
        <div className="flex items-center gap-2 mb-6">
          <div className="font-['Inter'] text-[11px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
            Filter by tier:
          </div>
          {['SS', 'S', 'A', 'B', 'C'].map(tier => (
            <button
              key={tier}
              onClick={() => setFilterTier(filterTier === tier ? null : tier)}
              className="px-3 py-1 rounded-[4px] border-[1px] font-['Inter'] text-[11px] font-bold transition-all duration-150"
              style={{
                backgroundColor: filterTier === tier ? getTierColor(tier) : colors.bg,
                borderColor: getTierColor(tier),
                color: filterTier === tier ? '#000' : getTierColor(tier),
              }}
            >
              {tier}
            </button>
          ))}
        </div>

        {/* Riders Grid */}
        <div className="grid grid-cols-2 gap-4">
          {filteredRiders.length === 0 ? (
            <div className="col-span-2 text-center py-12">
              <p className="font-['Inter'] text-[14px]" style={{ color: colors.textMuted }}>
                No riders found matching your search
              </p>
            </div>
          ) : (
            filteredRiders.map((rider) => (
              <div 
                key={rider.beetleNumber}
                className="rounded-[6px] border-[1px] p-5 transition-all hover:border-[#8ba87a]"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                }}
              >
                {/* Avatar + Tier Badge */}
                <div className="flex items-start gap-4 mb-4">
                  <div 
                    className="w-16 h-16 rounded-full border-[2px] flex items-center justify-center flex-shrink-0 cursor-pointer"
                    style={{ 
                      backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.1)' : 'rgba(42, 45, 30, 0.05)',
                      borderColor: getTierColor(rider.tier),
                    }}
                    onClick={() => navigate(`/rider/${rider.beetleNumber}`)}
                  >
                    <span className="text-[28px]">🪲</span>
                  </div>

                  <div className="flex-1">
                    {/* Tier + Number */}
                    <div className="flex items-center gap-2 mb-2">
                      <div 
                        className="px-2 py-0.5 rounded-[4px] border-[2px]"
                        style={{ 
                          backgroundColor: getTierColor(rider.tier),
                          borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
                        }}
                      >
                        <span 
                          className="font-['Inter'] text-[10px] font-black"
                          style={{ color: 'white' }}
                        >
                          {rider.tier}
                        </span>
                      </div>
                      <span 
                        className="font-['Cousine'] text-[10px]"
                        style={{ color: colors.textMuted }}
                      >
                        #{rider.beetleNumber}
                      </span>
                    </div>

                    {/* Username - clickable */}
                    <div 
                      className="font-['Inter'] font-bold text-[16px] mb-2 cursor-pointer hover:underline"
                      style={{ color: colors.text }}
                      onClick={() => navigate(`/rider/${rider.beetleNumber}`)}
                    >
                      {rider.username}
                    </div>

                    {/* Location */}
                    <div className="flex items-center gap-1.5 mb-3">
                      <MapPin size={12} style={{ color: colors.textMuted }} />
                      <div 
                        className="font-['Inter'] text-[11px]"
                        style={{ color: colors.textMuted }}
                      >
                        {rider.location}
                      </div>
                    </div>

                    {/* Bio */}
                    <p 
                      className="font-['Inter'] text-[12px] mb-4 line-clamp-2"
                      style={{ color: colors.text }}
                    >
                      {rider.bio}
                    </p>

                    {/* Stats Row */}
                    <div className="grid grid-cols-3 gap-3 pt-3 border-t-[1px]" style={{ borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.08)` }}>
                      <div>
                        <div 
                          className="font-['Inter'] uppercase tracking-wide text-[8px] mb-0.5"
                          style={{ color: colors.textMuted }}
                        >
                          FTP
                        </div>
                        <div 
                          className="font-['Cousine'] text-[13px]"
                          style={{ color: colors.text }}
                        >
                          {rider.ftp}w
                        </div>
                      </div>

                      <div>
                        <div 
                          className="font-['Inter'] uppercase tracking-wide text-[8px] mb-0.5"
                          style={{ color: colors.textMuted }}
                        >
                          Dung
                        </div>
                        <div 
                          className="font-['Cousine'] text-[13px]"
                          style={{ color: '#c89b5c' }}
                        >
                          {(rider.totalDung / 1000).toFixed(1)}k
                        </div>
                      </div>

                      <div>
                        <div 
                          className="font-['Inter'] uppercase tracking-wide text-[8px] mb-0.5"
                          style={{ color: colors.textMuted }}
                        >
                          Rides
                        </div>
                        <div 
                          className="font-['Cousine'] text-[13px]"
                          style={{ color: colors.text }}
                        >
                          {rider.rideCount}
                        </div>
                      </div>
                    </div>

                    {/* Mutual Friends */}
                    {rider.mutualFriends > 0 && (
                      <div 
                        className="mt-3 pt-3 border-t-[1px] font-['Inter'] text-[10px]"
                        style={{ 
                          borderColor: `rgba(${isDarkMode ? '208, 216, 191' : '42, 45, 30'}, 0.08)`,
                          color: colors.textMuted 
                        }}
                      >
                        {rider.mutualFriends} mutual {rider.mutualFriends === 1 ? 'friend' : 'friends'}
                      </div>
                    )}
                  </div>
                </div>

                {/* Follow Button */}
                <BeetleButton
                  variant={followingState[rider.beetleNumber] ? 'secondary' : 'primary'}
                  onClick={() => handleFollow(rider.beetleNumber)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-[11px]"
                >
                  {followingState[rider.beetleNumber] ? (
                    <>
                      <Users size={12} />
                      Following
                    </>
                  ) : (
                    <>
                      <UserPlus size={12} />
                      Follow
                    </>
                  )}
                </BeetleButton>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}