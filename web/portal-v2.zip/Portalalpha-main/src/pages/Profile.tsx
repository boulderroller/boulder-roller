import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import { BeetleButton } from '../components/ui/beetle-button';
import { Trophy, TrendingUp, Calendar, Award, Map, Activity, Zap, Cpu, Bike } from 'lucide-react';
import { getOverlay, getDivider, getHoverBg } from '../constants/colors';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';

export default function Profile() {
  const { beetleNumber } = useParams();
  const navigate = useNavigate();
  const { colors, isDarkMode } = useTheme();
  const [activeTab, setActiveTab] = useState('overview');
  
  // Determine if this is the user's own profile
  const isOwnProfile = !beetleNumber || beetleNumber === '4821'; 
  
  const [isFollowing, setIsFollowing] = useState(false); 

  // Mock user data
  const profile = {
    beetleNumber: beetleNumber || '4821',
    username: isOwnProfile ? 'climber_420' : 'descent_master',
    rank: 'C',
    bio: 'Pushing watts up mountains. Seeking elevation gain in all sectors.',
    location: 'San Francisco, CA',
    ftp: 250,
    weight: 70,
    riderType: 'Climber',
    joinedDate: '2024-01-15',
    stats: {
      followers: 342,
      following: 189,
      activities: 127,
      totalDistance: 3847,
      totalElevation: 45821,
      totalDung: 12847,
    }
  };

  // Machine Specification Mock
  const machineSpec = {
    chassis: 'S-WORKS TARMAC SL8',
    groupset: 'DURA-ACE DI2 12SPD',
    wheels: 'ROVAL RAPIDE CLX',
    tires: 'S-WORKS TURBO 28MM',
    computer: 'HAMMERHEAD KAROO 2',
    weight: '6.85 KG',
    status: 'OPTIMAL'
  };

  // Performance Data Mock
  const performanceData = [
    { subject: 'END', A: 120, fullMark: 150 }, // Endurance
    { subject: 'SPR', A: 85, fullMark: 150 },  // Sprint
    { subject: 'CLM', A: 140, fullMark: 150 }, // Climbing
    { subject: 'REC', A: 110, fullMark: 150 }, // Recovery
    { subject: 'VO2', A: 130, fullMark: 150 }, // VO2 Max
    { subject: 'TEC', A: 90, fullMark: 150 },  // Technical
  ];

  const borderColor = getOverlay(isDarkMode);
  const dividerColor = getDivider(isDarkMode);
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  
  const tabs = [
    { id: 'overview', label: 'Overview', icon: <Activity size={14} /> },
    { id: 'activities', label: 'Activity Log', icon: <Map size={14} /> },
    { id: 'segments', label: 'Segment History', icon: <Trophy size={14} /> },
    { id: 'beetle-card', label: 'ID Card', icon: <Award size={14} /> },
  ];

  // Helper to generate a simple SVG path for sparklines
  const generateSparkline = (points: number[], width: number, height: number) => {
    const max = Math.max(...points);
    const min = Math.min(...points);
    const range = max - min || 1;
    const step = width / (points.length - 1);

    const pathPoints = points.map((p, i) => {
      const x = i * step;
      const y = height - ((p - min) / range) * height;
      return `${x},${y}`;
    });

    return `M0,${height} L${pathPoints.join(' L')} L${width},${height} Z`;
  };

  const recentActivities = [
    { id: 1, name: 'Morning Climb', date: '2 days ago', distance: 42.3, elevation: 1247, dung: 187, type: 'RIDE', profile: [10, 40, 60, 80, 50, 20, 10] },
    { id: 2, name: 'Recovery Spin', date: '4 days ago', distance: 28.1, elevation: 342, dung: 94, type: 'RIDE', profile: [10, 12, 15, 12, 10, 8, 10] },
    { id: 3, name: 'Hawk Hill Repeats', date: '6 days ago', distance: 35.7, elevation: 982, dung: 156, type: 'RIDE', profile: [10, 80, 10, 80, 10, 80, 10] },
    { id: 4, name: 'Sausalito Cruise', date: '1 week ago', distance: 18.2, elevation: 120, dung: 45, type: 'RIDE', profile: [10, 20, 15, 20, 15, 10, 10] },
    { id: 5, name: 'Mt. Diablo Assault', date: '2 weeks ago', distance: 64.5, elevation: 2100, dung: 340, type: 'RIDE', profile: [10, 30, 50, 70, 90, 100, 20] },
  ];

  const segmentPRs = [
    { id: 1, name: 'Hawk Hill', time: '5:42', rank: 12, attempts: 47, pr: true, gradient: '5.2%' },
    { id: 2, name: 'Old La Honda', time: '18:34', rank: 8, attempts: 23, pr: true, gradient: '7.1%' },
    { id: 3, name: 'Marin Headlands', time: '32:18', rank: 34, attempts: 12, pr: false, gradient: '3.4%' },
  ];

  const achievements = [
    { id: 1, emoji: '🏆', name: 'Century Rider', earned: true, date: '2024-02-10' },
    { id: 2, emoji: '⛰️', name: 'Climbing Master', earned: true, date: '2024-03-15' },
    { id: 3, emoji: '💨', name: 'Speed Demon', earned: true, date: '2024-04-01' },
    { id: 4, emoji: '📅', name: '30 Day Streak', earned: true, date: '2024-05-20' },
    { id: 5, emoji: '🎯', name: 'Segment Hunter', earned: false, date: '-' },
    { id: 6, emoji: '🔥', name: 'Fire Starter', earned: false, date: '-' },
  ];

  return (
    <div className="min-h-full pb-12" style={{ backgroundColor: colors.bgSecondary }}>
      <div className="max-w-[1200px] mx-auto p-4 sm:p-8">
        
        {/* HEADER: Rider Record */}
        <div className="mb-8">
           <div className="flex items-center gap-2 mb-2 opacity-60">
              <span className="w-2 h-2 bg-primary"></span>
              <h4 className="font-['Cousine'] text-[10px] font-bold uppercase tracking-widest" style={{ color: colors.text }}>Rider Record // {profile.beetleNumber}</h4>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-[200px_1fr] gap-6 md:gap-8">
              {/* ID Photo & Basic Class */}
              <div className="flex flex-col gap-2">
                 <div 
                    className="aspect-square w-full border-2 relative group overflow-hidden"
                    style={{ borderColor: colors.text }}
                 >
                    {/* Corner Marks */}
                    <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2" style={{ borderColor: colors.accent }}></div>
                    <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2" style={{ borderColor: colors.accent }}></div>
                    <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2" style={{ borderColor: colors.accent }}></div>
                    <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2" style={{ borderColor: colors.accent }}></div>
                    
                    <div className="w-full h-full flex items-center justify-center bg-muted/10">
                       <span className="text-[64px]">🪲</span>
                    </div>

                    {/* Scanline Overlay */}
                    <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%),linear-gradient(90deg,rgba(255,0,0,0.03),rgba(0,255,0,0.01),rgba(0,0,255,0.03))] z-10 pointer-events-none bg-[length:100%_2px,3px_100%] opacity-20"></div>
                 </div>
                 
                 <div className="flex items-center justify-between border px-2 py-1" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                    <span className="font-['Inter'] text-[10px] uppercase font-bold text-muted-foreground">Class</span>
                    <span className="font-['Cousine'] text-[12px] font-bold" style={{ color: colors.text }}>LEVEL {profile.rank}</span>
                 </div>
              </div>

              {/* Bio & Details */}
              <div className="flex flex-col justify-between">
                 <div>
                    <h1 className="font-['Inter'] text-[32px] font-black uppercase tracking-tight leading-none mb-1" style={{ color: colors.text }}>
                       {profile.username}
                    </h1>
                    <div className="flex items-center gap-4 mb-6">
                       <span className="font-['Cousine'] text-[12px]" style={{ color: colors.accent }}>ID: #{profile.beetleNumber}</span>
                       <span className="font-['Cousine'] text-[12px] opacity-50" style={{ color: colors.text }}>LOC: {profile.location.toUpperCase()}</span>
                       <span className="font-['Cousine'] text-[12px] opacity-50" style={{ color: colors.text }}>MEMBER SINCE: {profile.joinedDate}</span>
                    </div>

                    <div className="border-l-2 pl-4 mb-6" style={{ borderColor: colors.accent }}>
                       <h3 className="font-['Inter'] text-[10px] font-bold uppercase tracking-wide mb-1 opacity-60" style={{ color: colors.text }}>Rider Notes</h3>
                       <p className="font-['Cousine'] text-[13px] leading-relaxed max-w-[600px]" style={{ color: colors.text }}>
                          {profile.bio}
                       </p>
                    </div>
                 </div>

                 {/* Action Bar */}
                 <div className="flex gap-3">
                    {isOwnProfile ? (
                        <BeetleButton 
                           className="font-['Cousine'] text-[11px] h-8 rounded-none border-2 hover:bg-muted/10" 
                           variant="outline"
                           onClick={() => navigate('/settings')}
                           style={{ borderColor: colors.text, color: colors.text }}
                        >
                           EDIT PROFILE
                        </BeetleButton>
                    ) : (
                        <BeetleButton 
                           className={`font-['Cousine'] text-[11px] h-8 rounded-none border-2 ${isFollowing ? 'bg-primary text-primary-foreground' : 'hover:bg-muted/10'}`}
                           variant={isFollowing ? 'primary' : 'outline'}
                           onClick={() => setIsFollowing(!isFollowing)}
                           style={{ borderColor: colors.text, color: isFollowing ? colors.bg : colors.text }}
                        >
                           {isFollowing ? 'STATUS: FOLLOWING' : 'FOLLOW RIDER'}
                        </BeetleButton>
                    )}
                 </div>
              </div>
           </div>
        </div>

        {/* METRICS GRID */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 border-t border-l" style={{ borderColor: dividerColor }}>
           {[
              { label: 'Followers', value: profile.stats.followers, unit: 'USR' },
              { label: 'Following', value: profile.stats.following, unit: 'USR' },
              { label: 'Activities', value: profile.stats.activities, unit: 'CNT' },
              { label: 'Distance', value: profile.stats.totalDistance.toLocaleString(), unit: 'KM' },
              { label: 'Elevation', value: profile.stats.totalElevation.toLocaleString(), unit: 'M' },
              { label: 'Total Output', value: profile.stats.totalDung.toLocaleString(), unit: 'CAL', highlight: true }
           ].map((stat, i) => (
              <div 
                 key={i} 
                 className="border-r border-b p-4 flex flex-col justify-between h-24 hover:bg-muted/5 transition-colors group"
                 style={{ borderColor: dividerColor, backgroundColor: cardBg }}
              >
                 <span className="font-['Inter'] text-[9px] uppercase font-bold tracking-wider opacity-50 mb-1" style={{ color: colors.text }}>{stat.label}</span>
                 <div className="flex items-baseline gap-1">
                    <span 
                       className="font-['Cousine'] text-[20px] font-bold group-hover:scale-105 transition-transform origin-left" 
                       style={{ color: stat.highlight ? colors.accent : colors.text }}
                    >
                       {stat.value}
                    </span>
                    <span className="font-['Inter'] text-[9px] font-bold opacity-40" style={{ color: colors.text }}>{stat.unit}</span>
                 </div>
              </div>
           ))}
        </div>

        {/* TABS */}
        <div className="mt-12 mb-6 flex border-b" style={{ borderColor: dividerColor }}>
           {tabs.map((tab) => (
              <button
                 key={tab.id}
                 onClick={() => setActiveTab(tab.id)}
                 className={`
                    px-6 py-3 font-['Inter'] text-[11px] font-bold uppercase tracking-wide flex items-center gap-2
                    transition-all duration-150 relative top-[1px]
                    ${activeTab === tab.id ? 'border-b-2' : 'opacity-50 hover:opacity-100 hover:bg-muted/5'}
                 `}
                 style={{ 
                    borderColor: activeTab === tab.id ? colors.accent : 'transparent',
                    color: activeTab === tab.id ? colors.text : colors.textMuted
                 }}
              >
                 {tab.icon}
                 {tab.label}
              </button>
           ))}
        </div>

        {/* CONTENT AREA */}
        <div className="min-h-[400px]">
           {activeTab === 'overview' && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                 {/* Left Column: Calibration & Specs */}
                 <div className="space-y-8">
                    
                    {/* Performance Data (Radar) */}
                    <div className="border p-1" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                       <div className="bg-muted/10 p-2 mb-4 border-b flex items-center justify-between" style={{ borderColor: dividerColor }}>
                          <h3 className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide flex items-center gap-2" style={{ color: colors.text }}>
                             <Zap size={12} /> Performance Data
                          </h3>
                          <span className="font-['Cousine'] text-[9px] opacity-50">TYPE: {profile.riderType.toUpperCase()}</span>
                       </div>
                       
                       <div className="flex flex-col sm:flex-row gap-4">
                           {/* Chart */}
                           <div className="w-full sm:w-1/2 h-[200px] relative">
                               <ResponsiveContainer width="100%" height="100%">
                                   <RadarChart cx="50%" cy="50%" outerRadius="70%" data={performanceData}>
                                       <PolarGrid gridType="polygon" stroke={dividerColor} strokeDasharray="3 3" />
                                       <PolarAngleAxis 
                                          dataKey="subject" 
                                          tick={{ fill: colors.textMuted, fontSize: 10, fontFamily: 'Courier Prime, monospace', fontWeight: 'bold' }} 
                                       />
                                       <Radar
                                           name="Rider"
                                           dataKey="A"
                                           stroke={colors.accent}
                                           strokeWidth={2}
                                           fill={colors.accent}
                                           fillOpacity={0.2}
                                           isAnimationActive={false}
                                       />
                                   </RadarChart>
                               </ResponsiveContainer>
                           </div>

                           {/* Metrics */}
                           <div className="w-full sm:w-1/2 p-2 flex flex-col justify-center space-y-4">
                              <div className="flex justify-between items-end border-b border-dashed pb-2" style={{ borderColor: dividerColor }}>
                                 <div>
                                    <div className="text-[9px] uppercase font-bold opacity-50 mb-1" style={{ color: colors.text }}>FTP</div>
                                    <div className="font-['Cousine'] text-[24px] font-bold" style={{ color: colors.text }}>{profile.ftp} <span className="text-[12px] opacity-50">W</span></div>
                                 </div>
                              </div>
                              <div className="flex justify-between items-end border-b border-dashed pb-2" style={{ borderColor: dividerColor }}>
                                 <div>
                                    <div className="text-[9px] uppercase font-bold opacity-50 mb-1" style={{ color: colors.text }}>W/KG</div>
                                    <div className="font-['Cousine'] text-[24px] font-bold" style={{ color: colors.text }}>{(profile.ftp / profile.weight).toFixed(1)}</div>
                                 </div>
                              </div>
                              <div>
                                 <div className="text-[9px] uppercase font-bold opacity-50 mb-1" style={{ color: colors.text }}>Weight</div>
                                 <div className="font-['Cousine'] text-[16px]" style={{ color: colors.textMuted }}>{profile.weight} KG</div>
                              </div>
                           </div>
                       </div>
                    </div>

                    {/* Machine Specification */}
                    <div className="border p-1" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                       <div className="bg-muted/10 p-2 mb-4 border-b flex items-center justify-between" style={{ borderColor: dividerColor }}>
                          <h3 className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide flex items-center gap-2" style={{ color: colors.text }}>
                             <Bike size={12} /> Equipment Specification
                          </h3>
                          <span className="font-['Cousine'] text-[9px] text-green-500 font-bold tracking-wider">CONDITION: {machineSpec.status}</span>
                       </div>
                       
                       <div className="p-3 space-y-3">
                           {Object.entries(machineSpec).filter(([k]) => k !== 'status').map(([key, value]) => (
                               <div key={key} className="flex items-center justify-between border-b border-dashed pb-1 last:border-0" style={{ borderColor: dividerColor }}>
                                   <span className="font-['Inter'] text-[10px] uppercase font-bold opacity-60" style={{ color: colors.text }}>{key}</span>
                                   <span className="font-['Cousine'] text-[12px] font-bold" style={{ color: colors.text }}>{value}</span>
                               </div>
                           ))}
                       </div>
                    </div>

                    {/* Achievements */}
                    <div className="border p-1" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                       <div className="bg-muted/10 p-2 mb-4 border-b" style={{ borderColor: dividerColor }}>
                          <h3 className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide flex items-center gap-2" style={{ color: colors.text }}>
                             <Award size={12} /> Achievements
                          </h3>
                       </div>
                       <div className="grid grid-cols-3 gap-2 p-2">
                          {achievements.map((ach) => (
                             <div 
                                key={ach.id} 
                                className={`
                                   aspect-square border flex flex-col items-center justify-center p-2 text-center relative group cursor-help
                                   ${ach.earned ? 'bg-muted/5' : 'bg-transparent opacity-40 grayscale'}
                                `}
                                style={{ borderColor: ach.earned ? colors.accent : dividerColor }}
                             >
                                <span className="text-[24px] mb-2 drop-shadow-md">{ach.emoji}</span>
                                <span className="font-['Inter'] text-[9px] font-bold uppercase leading-tight" style={{ color: colors.text }}>{ach.name}</span>
                                
                                {ach.earned && (
                                   <div className="absolute top-1 right-1 w-1.5 h-1.5 bg-green-500 rounded-none"></div>
                                )}
                                
                                <div className="absolute bottom-full mb-2 bg-black text-white text-[9px] px-2 py-1 border border-zinc-700 opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-10 font-mono">
                                   EARNED: {ach.date}
                                </div>
                             </div>
                          ))}
                       </div>
                    </div>
                 </div>

                 {/* Right Column: Recent Activities Log */}
                 <div className="border h-full" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                    <div className="bg-muted/10 p-2 border-b flex justify-between items-center" style={{ borderColor: dividerColor }}>
                       <h3 className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide flex items-center gap-2" style={{ color: colors.text }}>
                          <Map size={12} /> Recent Activities
                       </h3>
                       <button onClick={() => setActiveTab('activities')} className="text-[9px] uppercase hover:underline" style={{ color: colors.accent }}>View Log</button>
                    </div>
                    <div>
                       {recentActivities.slice(0, 5).map((activity, idx) => (
                          <div 
                             key={activity.id}
                             onClick={() => navigate(`/activities/${activity.id}`)}
                             className="p-4 border-b last:border-0 hover:bg-muted/5 cursor-pointer group transition-colors"
                             style={{ borderColor: dividerColor }}
                          >
                             <div className="flex justify-between mb-2">
                                <span className="font-['Cousine'] text-[10px] opacity-50" style={{ color: colors.textMuted }}>{activity.date.toUpperCase()}</span>
                                <span className="font-['Inter'] text-[9px] font-bold uppercase px-1 border" style={{ color: colors.text, borderColor: dividerColor }}>{activity.type}</span>
                             </div>
                             
                             <div className="flex items-center gap-4 mb-2">
                                <div className="flex-1">
                                    <div className="font-['Inter'] text-[13px] font-bold uppercase tracking-tight group-hover:text-primary transition-colors" style={{ color: colors.text }}>{activity.name}</div>
                                </div>
                                {/* SPARKLINE INSERTION */}
                                <div className="w-[60px] h-[24px]">
                                    <svg width="60" height="24" viewBox="0 0 60 24" className="overflow-visible">
                                        <path 
                                            d={generateSparkline(activity.profile, 60, 24)} 
                                            fill={colors.text} 
                                            fillOpacity="0.1" 
                                            stroke={colors.text} 
                                            strokeWidth="1" 
                                            vectorEffect="non-scaling-stroke"
                                        />
                                    </svg>
                                </div>
                             </div>

                             <div className="font-['Cousine'] text-[11px] mt-1 flex justify-between opacity-70" style={{ color: colors.textMuted }}>
                                <div className="flex gap-3">
                                    <span>{activity.distance}km</span>
                                    <span>{activity.elevation}m</span>
                                </div>
                                <span className="font-bold" style={{ color: colors.accent }}>+{activity.dung} CAL</span>
                             </div>
                          </div>
                       ))}
                    </div>
                 </div>
              </div>
           )}

           {activeTab === 'activities' && (
              <div className="border" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                 <div className="grid grid-cols-[100px_1fr_100px_100px_100px] gap-4 p-3 border-b text-[10px] font-bold uppercase tracking-wide opacity-50" style={{ borderColor: dividerColor, color: colors.text }}>
                    <div>Date</div>
                    <div>Activity</div>
                    <div className="text-right">Dist (KM)</div>
                    <div className="text-right">Elev (M)</div>
                    <div className="text-right">Output</div>
                 </div>
                 {recentActivities.map((activity) => (
                    <div 
                       key={activity.id}
                       className="grid grid-cols-[100px_1fr_100px_100px_100px] gap-4 p-4 border-b last:border-0 font-['Cousine'] text-[12px] hover:bg-muted/5 transition-colors cursor-pointer"
                       onClick={() => navigate(`/activities/${activity.id}`)}
                       style={{ borderColor: dividerColor, color: colors.text }}
                    >
                       <div className="opacity-60 text-[10px]">{activity.date}</div>
                       <div className="font-bold truncate pr-4">{activity.name.toUpperCase()}</div>
                       <div className="text-right opacity-80">{activity.distance}</div>
                       <div className="text-right opacity-80">{activity.elevation}</div>
                       <div className="text-right font-bold" style={{ color: colors.accent }}>+{activity.dung}</div>
                    </div>
                 ))}
                 <div className="p-4 text-center border-t border-dashed" style={{ borderColor: dividerColor }}>
                    <button className="font-['Cousine'] text-[10px] hover:underline" style={{ color: colors.textMuted }}>LOAD ARCHIVED LOGS...</button>
                 </div>
              </div>
           )}

           {activeTab === 'segments' && (
              <div className="border" style={{ borderColor: dividerColor, backgroundColor: cardBg }}>
                 <div className="p-3 border-b flex justify-between items-center" style={{ borderColor: dividerColor }}>
                     <span className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide" style={{ color: colors.text }}>Known Segments</span>
                 </div>
                 <div className="divide-y" style={{ borderColor: dividerColor }}>
                    {segmentPRs.map((segment) => (
                       <div key={segment.id} className="p-4 hover:bg-muted/5 group cursor-pointer">
                          <div className="flex justify-between items-start mb-2">
                             <div>
                                <h3 className="font-['Inter'] text-[13px] font-bold uppercase tracking-tight group-hover:text-primary transition-colors" style={{ color: colors.text }}>{segment.name}</h3>
                                <span className="font-['Cousine'] text-[10px] opacity-60" style={{ color: colors.textMuted }}>GRADIENT: {segment.gradient}</span>
                             </div>
                             <div className="flex flex-col items-end">
                                <span className="font-['Cousine'] text-[14px] font-bold" style={{ color: colors.text }}>{segment.time}</span>
                                {segment.pr && <span className="text-[9px] bg-accent text-accent-foreground px-1 font-bold">PR</span>}
                             </div>
                          </div>
                          <div className="flex justify-between items-center mt-3 pt-2 border-t border-dashed opacity-70" style={{ borderColor: dividerColor }}>
                             <div className="flex gap-4 text-[10px] font-['Inter'] font-bold uppercase" style={{ color: colors.textMuted }}>
                                <span>Rank: #{segment.rank}</span>
                                <span>Attempts: {segment.attempts}</span>
                             </div>
                             <button className="text-[10px] hover:underline" style={{ color: colors.accent }}>ANALYZE</button>
                          </div>
                       </div>
                    ))}
                 </div>
              </div>
           )}

           {activeTab === 'beetle-card' && (
              <div className="flex items-center justify-center py-12">
                 <div 
                    className="w-[350px] border-2 p-6 relative bg-white dark:bg-zinc-900" 
                    style={{ 
                       borderColor: colors.text,
                       boxShadow: `12px 12px 0px 0px ${isDarkMode ? '#000' : 'rgba(0,0,0,0.2)'}`
                    }}
                 >
                    <div className="absolute top-4 right-4 w-12 h-12 border border-black dark:border-white flex items-center justify-center opacity-20">
                       <span className="font-['Cousine'] font-bold text-[32px] rotate-[-10deg]">C</span>
                    </div>
                    <div className="text-center mb-6">
                       <h2 className="font-['Inter'] font-black text-[24px] uppercase tracking-tighter mb-1">Official ID</h2>
                       <p className="font-['Cousine'] text-[10px] uppercase tracking-widest opacity-60">Boulder Roller Federation</p>
                    </div>
                    <div className="aspect-square bg-muted/20 mb-6 border border-dashed flex items-center justify-center">
                       <span className="text-[64px] grayscale">🪲</span>
                    </div>
                    <div className="space-y-4 font-['Cousine'] text-[12px]">
                       <div className="flex justify-between border-b border-dashed pb-1">
                          <span className="opacity-50">RIDER</span>
                          <span className="font-bold">{profile.username.toUpperCase()}</span>
                       </div>
                       <div className="flex justify-between border-b border-dashed pb-1">
                          <span className="opacity-50">ID NUMBER</span>
                          <span className="font-bold">{profile.beetleNumber}</span>
                       </div>
                       <div className="flex justify-between border-b border-dashed pb-1">
                          <span className="opacity-50">CLASS</span>
                          <span className="font-bold">LEVEL {profile.rank}</span>
                       </div>
                       <div className="flex justify-between border-b border-dashed pb-1">
                          <span className="opacity-50">ISSUED</span>
                          <span className="font-bold">{profile.joinedDate}</span>
                       </div>
                    </div>
                    <div className="mt-8 pt-4 border-t-2 border-black dark:border-white text-center">
                       <div className="font-['Cousine'] text-[8px] tracking-[0.2em] opacity-40">AUTHORIZED MEMBER</div>
                    </div>
                 </div>
              </div>
           )}
        </div>

      </div>
    </div>
  );
}