import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, TrendingUp, Users, Trophy } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { BeetleButton } from '../components/ui/beetle-button';
import LeaderboardTable from '../components/ui/LeaderboardTable';
import StatPill from '../components/ui/StatPill';

// Mock segment data
const mockSegments: Record<string, any> = {
  'hawk-hill-climb': {
    id: 'hawk-hill-climb',
    name: 'Hawk Hill Climb',
    location: 'Marin Headlands, CA',
    distance: '2.4 km',
    elevation: '180 m',
    grade: '7.5%',
    weeklyPotCAL: 45280,
    weeklyPotDUNG: 45.28,
    totalAttempts: 1847,
    avgTime: '9:24',
    komHolder: 'Alex_Climber',
    komTime: '7:58',
    komWallet: '4rXY...9kLm',
    createdBy: 'TrailMapper',
    createdAt: 'Nov 15, 2024',
    leaderboard: [
      { rank: 1, wallet: '4rXY...9kLm', riderName: 'Alex_Climber', time: '7:58', date: 'Dec 8', tss: 142, calDistributed: 9502 },
      { rank: 2, wallet: '7sQw...2pVn', riderName: 'Sarah_Watts', time: '8:12', date: 'Dec 7', tss: 138, calDistributed: 6335 },
      { rank: 3, wallet: '2mKp...8hRt', riderName: 'Chris_FTP300', time: '8:24', date: 'Dec 6', tss: 135, calDistributed: 4752 },
      { rank: 4, wallet: '9xLm...4jWq', riderName: 'Emma_VAM', time: '8:35', date: 'Dec 5', tss: 132, calDistributed: 3168 },
      { rank: 5, wallet: '3vNp...7cXs', riderName: 'Tyler_Gravel', time: '8:47', date: 'Dec 4', tss: 128, calDistributed: 2534 },
      { rank: 6, wallet: '8kQr...1mZt', riderName: 'Rachel_Power', time: '8:58', date: 'Dec 3', tss: 125, calDistributed: 1901 },
      { rank: 7, wallet: '5wJp...6nYu', riderName: 'Mike_Crusher', time: '9:12', date: 'Dec 2', tss: 121, calDistributed: 1584 },
      { rank: 8, wallet: '1tGh...3pLk', riderName: 'Lisa_Strong', time: '9:28', date: 'Dec 1', tss: 118, calDistributed: 951 },
      { rank: 9, wallet: '6hRt...9mCv', riderName: 'David_Zwift', time: '9:45', date: 'Nov 30', tss: 115, calDistributed: 634 },
      { rank: 10, wallet: '4nBm...2qZx', riderName: 'Kate_Enduro', time: '10:02', date: 'Nov 29', tss: 112, calDistributed: 317 },
    ],
  },
  'golden-gate-sprint': {
    id: 'golden-gate-sprint',
    name: 'Golden Gate Sprint',
    location: 'San Francisco, CA',
    distance: '0.8 km',
    elevation: '5 m',
    grade: '0.6%',
    weeklyPotCAL: 28950,
    weeklyPotDUNG: 28.95,
    totalAttempts: 3201,
    avgTime: '2:35',
    komHolder: 'Sprint_King',
    komTime: '1:58',
    komWallet: '7mQw...4kLp',
    createdBy: 'CityRider',
    createdAt: 'Oct 22, 2024',
    leaderboard: [
      { rank: 1, wallet: '7mQw...4kLp', riderName: 'Sprint_King', time: '1:58', date: 'Dec 8', tss: 85, calDistributed: 6084 },
      { rank: 2, wallet: '3pVn...8hZx', riderName: 'Watt_Bazuka', time: '2:02', date: 'Dec 7', tss: 82, calDistributed: 4063 },
      { rank: 3, wallet: '9kLm...2qRt', riderName: 'Fast_Finish', time: '2:06', date: 'Dec 6', tss: 80, calDistributed: 3047 },
      { rank: 4, wallet: '5jWq...7cMn', riderName: 'Lead_Out', time: '2:11', date: 'Dec 5', tss: 78, calDistributed: 2031 },
      { rank: 5, wallet: '1cXs...3mYu', riderName: 'Power_Surge', time: '2:15', date: 'Dec 4', tss: 75, calDistributed: 1626 },
      { rank: 6, wallet: '8mZt...6nKp', riderName: 'Crit_Racer', time: '2:20', date: 'Dec 3', tss: 73, calDistributed: 1219 },
      { rank: 7, wallet: '4nYu...9pLk', riderName: 'Track_Star', time: '2:24', date: 'Dec 2', tss: 71, calDistributed: 1016 },
      { rank: 8, wallet: '2pLk...1mCv', riderName: 'Aero_Beast', time: '2:29', date: 'Dec 1', tss: 68, calDistributed: 610 },
      { rank: 9, wallet: '6mCv...4qZx', riderName: 'Chain_Gang', time: '2:33', date: 'Nov 30', tss: 66, calDistributed: 406 },
      { rank: 10, wallet: '3qZx...8rBm', riderName: 'Flat_Liner', time: '2:38', date: 'Nov 29', tss: 64, calDistributed: 203 },
    ],
  },
};

export default function SegmentView() {
  const { segmentId } = useParams<{ segmentId: string }>();
  const navigate = useNavigate();
  const { isDarkMode, colors } = useTheme();

  const segment = segmentId ? mockSegments[segmentId] : null;
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';

  // Mock personal stats
  const personalStats = {
    yourBestTime: '8:42',
    yourRank: 14,
    attempts: 8,
    lastRidden: 'Dec 5, 2024',
    pr: true,
    calEarned: 1247,
  };

  if (!segment) {
    return (
      <div className="max-w-[1200px] mx-auto p-8">
        <div className="text-center py-12">
          <h2 className="font-['Inter'] font-bold text-[24px] mb-2" style={{ color: colors.text }}>
            Segment not found
          </h2>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full" style={{ backgroundColor: colors.bgSecondary }}>
      <div className="max-w-[1400px] mx-auto p-6">
        {/* Header */}
        <div className="mb-5">
          <div className="flex items-start justify-between">
            <div>
              <h1 
                className="font-['Inter'] font-extrabold text-[28px] tracking-tight mb-1"
                style={{ color: colors.text }}
              >
                {segment.name}
              </h1>
              <p 
                className="font-['Inter'] text-[12px] flex items-center gap-2"
                style={{ color: colors.textMuted }}
              >
                📍 {segment.location} • Created by {segment.createdBy}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <BeetleButton variant="secondary" size="sm">
                Star Segment
              </BeetleButton>
              <BeetleButton variant="primary" size="sm">
                Upload Effort
              </BeetleButton>
            </div>
          </div>
        </div>

        {/* MAP PANE - BIG */}
        <div 
          className="w-full h-[400px] rounded-none border mb-5 flex items-center justify-center"
          style={{ 
            backgroundColor: cardBg,
            borderColor 
          }}
        >
          <div className="text-center">
            <div className="text-[48px] mb-2">🗺️</div>
            <div className="font-['Inter'] text-[13px] font-bold mb-1" style={{ color: colors.text }}>
              Segment Route Map
            </div>
            <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
              Interactive map showing segment start, end, and elevation profile
            </div>
          </div>
        </div>

        {/* Two-column: Stats/Leaderboard | Sidebar */}
        <div className="grid grid-cols-[1fr_320px] gap-5">
          {/* LEFT COLUMN */}
          <div className="space-y-5">
            {/* GLOBAL STATS */}
            <div 
              className="p-5 rounded-none border"
              style={{ backgroundColor: cardBg, borderColor }}
            >
              <div className="font-['Inter'] text-[11px] uppercase tracking-wide mb-4 flex items-center gap-2" style={{ color: colors.textMuted }}>
                <TrendingUp className="w-3.5 h-3.5" />
                Segment Stats
              </div>
              <div className="grid grid-cols-5 gap-6">
                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {segment.distance.split(' ')[0]}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Distance ({segment.distance.split(' ')[1]})
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {segment.elevation.split(' ')[0]}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Elevation ({segment.elevation.split(' ')[1]})
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {segment.grade.split('%')[0]}%
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Avg Grade
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {(segment.totalAttempts / 1000).toFixed(1)}k
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Total Efforts
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.accent }}
                  >
                    {segment.komTime}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    KOM Time
                  </div>
                </div>
              </div>
            </div>

            {/* PERSONAL STATS */}
            <div 
              className="p-5 rounded-none border"
              style={{ 
                backgroundColor: cardBg,
                borderColor: colors.accent 
              }}
            >
              <div className="font-['Inter'] text-[11px] uppercase tracking-wide mb-4 flex items-center gap-2" style={{ color: colors.accent }}>
                <Users className="w-3.5 h-3.5" />
                Your Stats
              </div>
              <div className="grid grid-cols-5 gap-6">
                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {personalStats.yourBestTime}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Your Best Time
                    {personalStats.pr && (
                      <span className="ml-1 text-[9px] font-bold" style={{ color: colors.accent }}>PR!</span>
                    )}
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    #{personalStats.yourRank}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Your Rank
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {personalStats.attempts}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Your Attempts
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Cousine'] text-[32px] font-bold leading-none mb-1"
                    style={{ 
                      color: '#c89b5c',
                      textShadow: '0 0 12px rgba(200, 155, 92, 0.2)'
                    }}
                  >
                    {personalStats.calEarned}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    CAL Earned
                  </div>
                </div>

                <div>
                  <div 
                    className="font-['Inter'] text-[11px] font-bold leading-none mb-1"
                    style={{ color: colors.textMuted }}
                  >
                    {personalStats.lastRidden}
                  </div>
                  <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Last Ridden
                  </div>
                </div>
              </div>
            </div>

            {/* LEADERBOARD */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 
                  className="font-['Inter'] font-bold text-[13px] uppercase tracking-wide flex items-center gap-2"
                  style={{ color: colors.text }}
                >
                  <Trophy className="w-4 h-4" />
                  Weekly Leaderboard
                </h2>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  Epoch: Dec 2-8, 2024
                </div>
              </div>
              <LeaderboardTable 
                entries={segment.leaderboard.map(entry => ({
                  ...entry,
                  isCurrentUser: entry.rank === personalStats.yourRank
                }))} 
              />
            </div>
          </div>

          {/* RIGHT SIDEBAR */}
          <div className="space-y-4">
            {/* Weekly Pot */}
            <div 
              className="p-5 rounded-none border"
              style={{ backgroundColor: cardBg, borderColor }}
            >
              <h3 
                className="font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-4"
                style={{ color: colors.text }}
              >
                🪲 Weekly Pot
              </h3>
              
              <div className="text-center mb-4">
                <div 
                  className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
                  style={{ 
                    color: '#c89b5c',
                    textShadow: '0 0 24px rgba(200, 155, 92, 0.4)'
                  }}
                >
                  {segment.weeklyPotCAL.toLocaleString()}
                </div>
                <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                  CAL Accumulated
                </div>
              </div>

              <div className="p-3 rounded-none" style={{ backgroundColor: isDarkMode ? 'rgba(0, 0, 0, 0.2)' : 'rgba(0, 0, 0, 0.03)' }}>
                <div className="font-['Inter'] text-[9px] uppercase tracking-wide mb-2" style={{ color: colors.textMuted }}>
                  Converts to
                </div>
                <div 
                  className="font-['Cousine'] text-[20px] font-bold"
                  style={{ color: colors.text }}
                >
                  ≈ {segment.weeklyPotDUNG} DUNG
                </div>
                <div className="font-['Inter'] text-[9px] mt-1" style={{ color: colors.textMuted }}>
                  @ 1000:1 ratio
                </div>
              </div>

              <div className="mt-4 pt-4 border-t space-y-2" style={{ borderColor }}>
                <div className="flex justify-between items-center">
                  <span className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Top 10 (70%)
                  </span>
                  <span className="font-['Cousine'] text-[11px] font-bold" style={{ color: colors.text }}>
                    {(segment.weeklyPotDUNG * 0.7).toFixed(2)} DUNG
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Stakers (20%)
                  </span>
                  <span className="font-['Cousine'] text-[11px] font-bold" style={{ color: colors.text }}>
                    {(segment.weeklyPotDUNG * 0.2).toFixed(2)} DUNG
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                    Swannys (10%)
                  </span>
                  <span className="font-['Cousine'] text-[11px] font-bold" style={{ color: colors.text }}>
                    {(segment.weeklyPotDUNG * 0.1).toFixed(2)} DUNG
                  </span>
                </div>
              </div>
            </div>

            {/* How It Works */}
            <div 
              className="p-4 rounded-none border"
              style={{ backgroundColor: cardBg, borderColor }}
            >
              <h3 
                className="font-['Inter'] font-bold text-[11px] uppercase tracking-wide mb-3"
                style={{ color: colors.text }}
              >
                How It Works
              </h3>
              <div className="space-y-3">
                <div>
                  <div className="font-['Inter'] text-[11px] font-bold mb-1" style={{ color: colors.text }}>
                    1. Ride the Segment
                  </div>
                  <div className="font-['Inter'] text-[10px] leading-relaxed" style={{ color: colors.textMuted }}>
                    Your ride burns CAL to this segment based on time × intensity factor
                  </div>
                </div>
                <div>
                  <div className="font-['Inter'] text-[11px] font-bold mb-1" style={{ color: colors.text }}>
                    2. Compete for Top 10
                  </div>
                  <div className="font-['Inter'] text-[10px] leading-relaxed" style={{ color: colors.textMuted }}>
                    Get fastest time to earn 70% of weekly pot (30/20/15/10/8/6/5/3/2/1%)
                  </div>
                </div>
                <div>
                  <div className="font-['Inter'] text-[11px] font-bold mb-1" style={{ color: colors.text }}>
                    3. Stake for Yield
                  </div>
                  <div className="font-['Inter'] text-[10px] leading-relaxed" style={{ color: colors.textMuted }}>
                    Stake DUNG in segment to earn 20% of pot (post-TGE)
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              <BeetleButton variant="primary" className="w-full">
                Upload Effort
              </BeetleButton>
              <BeetleButton variant="secondary" className="w-full">
                Stake DUNG (Soon)
              </BeetleButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}