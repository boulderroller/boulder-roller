import { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { Trophy, TrendingUp } from 'lucide-react';
import LeaderboardTable from '../components/ui/LeaderboardTable';
import LeaderboardRow from '../components/leaderboard/LeaderboardRow';
import { BeetleButton } from '../components/ui/beetle-button';
import { getOverlay, getDivider } from '../constants/colors';

// Mock global leaderboard data
const mockLeaderboard = Array.from({ length: 100 }, (_, i) => ({
  rank: i + 1,
  wallet: `${Math.random().toString(36).substring(2, 6)}...${Math.random().toString(36).substring(2, 6)}`,
  riderName: `Rider_${Math.random().toString(36).substring(2, 8)}`,
  time: '', // Not used for global
  date: '',
  totalPoints: Math.floor(Math.random() * 50000) + 5000,
  achievements: Math.floor(Math.random() * 15) + 1,
  lastActive: `${Math.floor(Math.random() * 7) + 1}d ago`,
  isCurrentUser: i === 486, // Mock current user at rank 487
}));

export default function Leaderboard() {
  const { isDarkMode, colors } = useTheme();
  const [activeTab, setActiveTab] = useState<'all-time' | 'month' | 'week'>('all-time');
  const [currentPage, setCurrentPage] = useState(1);
  
  const ROWS_PER_PAGE = 25;

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);
  const tabBorderColor = getDivider(isDarkMode);

  // Pagination calculations
  const totalPages = Math.ceil(mockLeaderboard.length / ROWS_PER_PAGE);
  const startIndex = (currentPage - 1) * ROWS_PER_PAGE;
  const endIndex = startIndex + ROWS_PER_PAGE;
  const visibleRows = mockLeaderboard.slice(startIndex, endIndex);
  
  // Find current user's page for "Jump to My Rank"
  const userIndex = mockLeaderboard.findIndex(u => u.isCurrentUser);
  const userPage = userIndex >= 0 ? Math.ceil((userIndex + 1) / ROWS_PER_PAGE) : null;

  // Convert to leaderboard format
  const leaderboardEntries = mockLeaderboard.map(user => ({
    rank: user.rank,
    wallet: user.wallet,
    riderName: user.riderName,
    time: user.totalPoints.toLocaleString(),
    date: user.lastActive,
    tss: user.achievements,
    calDistributed: undefined,
    isCurrentUser: user.isCurrentUser,
  }));

  const tabs = [
    { id: 'all-time' as const, label: 'All-Time', icon: Trophy },
    { id: 'month' as const, label: 'This Month', icon: TrendingUp },
    { id: 'week' as const, label: 'This Week', icon: TrendingUp },
  ];

  return (
    <div className="min-h-full" style={{ backgroundColor: colors.bgSecondary }}>
      <div className="max-w-[1200px] mx-auto p-8">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <Trophy className="w-7 h-7" style={{ color: colors.accent }} />
            <h1 
              className="font-['Inter'] font-black text-[28px]"
              style={{ color: colors.text }}
            >
              Leaderboard
            </h1>
          </div>
          <p 
            className="font-['Inter'] text-[12px]"
            style={{ color: colors.textMuted }}
          >
            Period rankings • Top riders competing for DUNG at TGE
          </p>
        </div>

        {/* Stats Banner */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div 
            className="p-5 rounded border"
            style={{ backgroundColor: cardBg, borderColor }}
          >
            <div 
              className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
              style={{ 
                color: '#c89b5c',
                textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
              }}
            >
              10,482
            </div>
            <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
              Active Riders
            </div>
          </div>

          <div 
            className="p-5 rounded border"
            style={{ backgroundColor: cardBg, borderColor }}
          >
            <div 
              className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
              style={{ color: colors.text }}
            >
              12.4M
            </div>
            <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
              Total Points Earned
            </div>
          </div>

          <div 
            className="p-5 rounded border"
            style={{ backgroundColor: cardBg, borderColor }}
          >
            <div 
              className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
              style={{ color: colors.text }}
            >
              127d
            </div>
            <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
              Until TGE (Estimated)
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-5">
          <div 
            className="inline-flex rounded border overflow-hidden"
            style={{ borderColor }}
          >
            {tabs.map((tab, index) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-5 py-2.5 font-['Inter'] text-[12px] font-bold uppercase tracking-wide transition-all flex items-center gap-2 ${
                    index > 0 ? 'border-l' : ''
                  }`}
                  style={{
                    backgroundColor: isActive 
                      ? (isDarkMode ? 'rgba(200, 155, 92, 0.15)' : 'rgba(200, 155, 92, 0.1)')
                      : 'transparent',
                    borderLeftColor: index > 0 ? tabBorderColor : 'transparent',
                    color: isActive ? colors.accent : colors.textMuted,
                  }}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Leaderboard Table */}
        <div 
          className="rounded border overflow-hidden"
          style={{ backgroundColor: cardBg, borderColor }}
        >
          {/* Table Header - Custom for global */}
          <div 
            className="px-5 py-3 border-b"
            style={{ borderColor, backgroundColor: isDarkMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.02)' }}
          >
            <div className="grid grid-cols-[60px_2fr_1fr_100px_100px_120px] gap-4 items-center">
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
                Rank
              </div>
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
                Rider
              </div>
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
                Total Points
              </div>
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
                Last Active
              </div>
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
                Achievements
              </div>
              <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>
                Est. DUNG
              </div>
            </div>
          </div>

          {/* Rows */}
          {visibleRows.map((user) => (
            <LeaderboardRow key={`${user.wallet}-${user.rank}`} user={user} />
          ))}
        </div>

        {/* Pagination */}
        <div className="mt-5 flex justify-between items-center">
          <div className="flex gap-2">
            <BeetleButton
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              variant="secondary"
              size="sm"
            >
              ← Previous
            </BeetleButton>
            <BeetleButton
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              variant="secondary"
              size="sm"
            >
              Next →
            </BeetleButton>
          </div>
          
          <div className="font-['Cousine'] text-[13px] font-bold" style={{ color: colors.text }}>
            Page {currentPage} of {totalPages}
          </div>
          
          {userPage && currentPage !== userPage && (
            <BeetleButton
              onClick={() => setCurrentPage(userPage)}
              variant="primary"
              size="sm"
            >
              Jump to My Rank (#{userIndex + 1})
            </BeetleButton>
          )}
          {(!userPage || currentPage === userPage) && <div style={{ width: '180px' }} />}
        </div>

        {/* Footer Note */}
        <div className="mt-4 text-center">
          <p className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
            Rankings update every 5 minutes • TGE conversion uses tiered ratios (1000:1 → 1500:1 → 2000:1 → 3000:1)
          </p>
        </div>
      </div>
    </div>
  );
}