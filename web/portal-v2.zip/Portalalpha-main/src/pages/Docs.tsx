import { useTheme } from '../contexts/ThemeContext';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Book, Zap, Users, Trophy, Coins, Shield } from 'lucide-react';

export default function Docs() {
  const { colors, isDarkMode } = useTheme();
  const navigate = useNavigate();
  
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  const sections = [
    {
      id: 'getting-started',
      icon: Zap,
      title: 'Getting Started',
      items: [
        { title: 'Upload Your First Ride', description: 'Learn how to upload .fit, .tcx, or .gpx files' },
        { title: 'Understanding TSS', description: 'What is Training Stress Score and how it works' },
        { title: 'Earning Dung', description: 'How dung rewards are calculated from your activities' },
      ]
    },
    {
      id: 'features',
      icon: Book,
      title: 'Features',
      items: [
        { title: 'Activity Feed', description: 'Follow your friends and see their achievements' },
        { title: 'Segments', description: 'Compete on popular climbs and routes' },
        { title: 'Power Analysis', description: 'Analyze your power curve and critical power' },
        { title: 'Leaderboards', description: 'See how you rank against other beetles' },
      ]
    },
    {
      id: 'community',
      icon: Users,
      title: 'Community',
      items: [
        { title: 'Finding Riders', description: 'Connect with other cyclists in your area' },
        { title: 'Invite System', description: 'How to get and share invite codes' },
        { title: 'Beetle Ranks', description: 'Understanding the ranking system (C → B → A → Pro)' },
      ]
    },
    {
      id: 'achievements',
      icon: Trophy,
      title: 'Achievements',
      items: [
        { title: 'Types of Achievements', description: 'Distance, climbing, speed, and consistency badges' },
        { title: 'Dung Rewards', description: 'Earn bonus dung for unlocking achievements' },
        { title: 'Sharing', description: 'Share your achievements on social media' },
      ]
    },
    {
      id: 'blockchain',
      icon: Coins,
      title: 'Web3 & Solana',
      items: [
        { title: 'Wallet Connection', description: 'How to connect your Phantom wallet' },
        { title: 'Dung Token', description: 'Understanding your dung balance and portfolio' },
        { title: 'Beetle NFTs', description: 'Your unique beetle number and profile' },
      ]
    },
    {
      id: 'privacy',
      icon: Shield,
      title: 'Privacy & Data',
      items: [
        { title: 'Activity Privacy', description: 'Control who can see your rides' },
        { title: 'Profile Visibility', description: 'Public, followers-only, or private profiles' },
        { title: 'Export Your Data', description: 'Download all your activities and stats anytime' },
      ]
    },
  ];

  return (
    <div className="min-h-full" style={{ backgroundColor: colors.bgSecondary }}>
      <div className="max-w-[1000px] mx-auto p-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 group"
            style={{ color: colors.textMuted }}
          >
            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
            <span className="font-['Inter'] text-[12px] font-bold uppercase tracking-wide group-hover:underline">
              Back
            </span>
          </button>
        </div>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2.5 mb-1.5">
            <span className="text-[20px]">📚</span>
            <h1 
              className="font-['Inter'] font-bold text-[20px]"
              style={{ color: colors.text }}
            >
              Documentation
            </h1>
          </div>
          <p 
            className="font-['Inter'] text-[13px]"
            style={{ color: colors.textMuted }}
          >
            Everything you need to know about BoulderRoller
          </p>
        </div>

        {/* Sections Grid */}
        <div className="space-y-6">
          {sections.map((section) => {
            const Icon = section.icon;
            return (
              <div
                key={section.id}
                className="rounded border p-6"
                style={{ backgroundColor: cardBg, borderColor }}
              >
                {/* Section Header */}
                <div className="flex items-center gap-2.5 mb-4">
                  <Icon 
                    className="w-5 h-5" 
                    style={{ color: colors.accent }} 
                    strokeWidth={2}
                  />
                  <h2 
                    className="font-['Inter'] font-bold text-[16px]"
                    style={{ color: colors.text }}
                  >
                    {section.title}
                  </h2>
                </div>

                {/* Items */}
                <div className="space-y-3">
                  {section.items.map((item, idx) => (
                    <button
                      key={idx}
                      className="w-full text-left p-3 rounded transition-colors"
                      style={{
                        backgroundColor: 'transparent',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = isDarkMode 
                          ? 'rgba(208, 216, 191, 0.05)' 
                          : 'rgba(42, 45, 30, 0.03)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'transparent';
                      }}
                    >
                      <div 
                        className="font-['Inter'] text-[14px] mb-1"
                        style={{ color: colors.text }}
                      >
                        {item.title}
                      </div>
                      <div 
                        className="font-['Inter'] text-[12px]"
                        style={{ color: colors.textMuted }}
                      >
                        {item.description}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Help Footer */}
        <div 
          className="mt-8 p-6 rounded border text-center"
          style={{ backgroundColor: cardBg, borderColor }}
        >
          <div className="text-[32px] mb-2">🪲</div>
          <h3 
            className="font-['Inter'] font-bold text-[14px] mb-1"
            style={{ color: colors.text }}
          >
            Need More Help?
          </h3>
          <p 
            className="font-['Inter'] text-[12px] mb-4"
            style={{ color: colors.textMuted }}
          >
            Join our Discord community or check out the GitHub repo
          </p>
          <div className="flex gap-3 justify-center">
            <a
              href="#"
              className="px-4 py-2 rounded border transition-colors font-['Inter'] text-[12px] font-bold"
              style={{ 
                borderColor: colors.border,
                color: colors.text,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = isDarkMode 
                  ? 'rgba(208, 216, 191, 0.05)' 
                  : 'rgba(42, 45, 30, 0.03)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              Discord
            </a>
            <a
              href="#"
              className="px-4 py-2 rounded border transition-colors font-['Inter'] text-[12px] font-bold"
              style={{ 
                borderColor: colors.border,
                color: colors.text,
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = isDarkMode 
                  ? 'rgba(208, 216, 191, 0.05)' 
                  : 'rgba(42, 45, 30, 0.03)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              GitHub
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
