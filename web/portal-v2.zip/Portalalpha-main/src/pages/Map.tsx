import { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { BeetleInput } from '../components/ui/beetle-input';
import { BeetleButton } from '../components/ui/beetle-button';

export default function Map() {
  const { colors, isDarkMode } = useTheme();
  const [activeFilters, setActiveFilters] = useState<string[]>(['yours', 'community', 'segment']);
  const [searchQuery, setSearchQuery] = useState('');

  const toggleFilter = (filter: string) => {
    if (activeFilters.includes(filter)) {
      setActiveFilters(activeFilters.filter(f => f !== filter));
    } else {
      setActiveFilters([...activeFilters, filter]);
    }
  };

  // Theme-aware route colors (for when Mapbox is integrated)
  const routeColorYours = isDarkMode ? '#8ba87a' : '#6b8a5a';
  const routeColorCommunity = isDarkMode ? 'rgba(139, 168, 122, 0.4)' : 'rgba(107, 138, 90, 0.5)';
  const routeColorSegment = isDarkMode ? '#c89b5c' : '#a87a3c';

  return (
    <div className="relative w-full min-h-screen overflow-hidden">
      {/* Mapbox container - will replace this placeholder */}
      <div 
        className="absolute inset-0 flex items-center justify-center"
        style={{ 
          backgroundColor: isDarkMode ? '#1a1d14' : '#e8f0dd',
        }}
      >
        <div className="text-center">
          <div className="text-[64px] mb-4">🗺️</div>
          <p 
            className="font-['Inter'] font-bold text-[16px] mb-2"
            style={{ color: colors.text }}
          >
            Mapbox integration placeholder
          </p>
          <p 
            className="font-['Inter'] text-[12px] max-w-[400px]"
            style={{ color: colors.textMuted }}
          >
            Routes will render with theme-aware colors: Your routes ({routeColorYours}), 
            Community routes (muted), Segments (golden {routeColorSegment})
          </p>
        </div>
      </div>

      {/* Top-left: Search */}
      <div className="absolute top-6 left-6 z-10 w-[320px]">
        <BeetleInput
          placeholder="Search locations, segments..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={{
            backgroundColor: isDarkMode ? 'rgba(42, 45, 30, 0.95)' : 'rgba(255, 255, 255, 0.95)',
            backdropFilter: 'blur(8px)',
            borderWidth: '1px',
          }}
        />
      </div>

      {/* Top-right: Filter pills */}
      <div className="absolute top-6 right-6 z-10 flex gap-2">
        {[
          { key: 'yours', label: 'Your Routes', color: routeColorYours },
          { key: 'community', label: 'Community', color: routeColorCommunity },
          { key: 'segment', label: 'Segments', color: routeColorSegment },
        ].map((filter) => (
          <button
            key={filter.key}
            onClick={() => toggleFilter(filter.key)}
            className="px-3 py-2 rounded-[6px] border-[1px] font-['Inter'] text-[11px] font-bold uppercase tracking-wide transition-all"
            style={{
              backgroundColor: activeFilters.includes(filter.key)
                ? isDarkMode ? 'rgba(42, 45, 30, 0.95)' : 'rgba(255, 255, 255, 0.95)'
                : isDarkMode ? 'rgba(42, 45, 30, 0.6)' : 'rgba(255, 255, 255, 0.6)',
              borderColor: activeFilters.includes(filter.key) ? filter.color : colors.border,
              color: activeFilters.includes(filter.key) ? colors.text : colors.textMuted,
              backdropFilter: 'blur(8px)',
              boxShadow: activeFilters.includes(filter.key) 
                ? `0 0 8px ${filter.color}40` 
                : 'none',
            }}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Bottom-right: Zoom controls */}
      <div className="absolute bottom-6 right-6 z-10 flex flex-col gap-2">
        <button
          className="w-10 h-10 rounded-[6px] border-[2px] font-['Inter'] text-[20px] font-bold transition-all"
          style={{
            backgroundColor: isDarkMode ? 'rgba(42, 45, 30, 0.95)' : 'rgba(255, 255, 255, 0.95)',
            borderColor: colors.border,
            color: colors.text,
            boxShadow: `2px 2px 0px 0px ${colors.border}`,
            backdropFilter: 'blur(8px)',
          }}
          onMouseDown={(e) => {
            e.currentTarget.style.transform = 'translate(2px, 2px)';
            e.currentTarget.style.boxShadow = 'none';
          }}
          onMouseUp={(e) => {
            e.currentTarget.style.transform = 'translate(0, 0)';
            e.currentTarget.style.boxShadow = `2px 2px 0px 0px ${colors.border}`;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translate(0, 0)';
            e.currentTarget.style.boxShadow = `2px 2px 0px 0px ${colors.border}`;
          }}
        >
          +
        </button>
        <button
          className="w-10 h-10 rounded-[6px] border-[2px] font-['Inter'] text-[20px] font-bold transition-all"
          style={{
            backgroundColor: isDarkMode ? 'rgba(42, 45, 30, 0.95)' : 'rgba(255, 255, 255, 0.95)',
            borderColor: colors.border,
            color: colors.text,
            boxShadow: `2px 2px 0px 0px ${colors.border}`,
            backdropFilter: 'blur(8px)',
          }}
          onMouseDown={(e) => {
            e.currentTarget.style.transform = 'translate(2px, 2px)';
            e.currentTarget.style.boxShadow = 'none';
          }}
          onMouseUp={(e) => {
            e.currentTarget.style.transform = 'translate(0, 0)';
            e.currentTarget.style.boxShadow = `2px 2px 0px 0px ${colors.border}`;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = 'translate(0, 0)';
            e.currentTarget.style.boxShadow = `2px 2px 0px 0px ${colors.border}`;
          }}
        >
          −
        </button>
      </div>
    </div>
  );
}