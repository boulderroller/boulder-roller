import { useState, lazy, Suspense } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { BeetleButton } from '../components/ui/beetle-button';
import { BeetleCard } from '../components/ui/beetle-card';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import DeleteConfirmModal from '../components/modals/DeleteConfirmModal';
import { toast } from 'sonner@2.0.3';
import StatsPanel from '../components/ride/StatsPanel';
import DungBreakdown from '../components/ride/DungBreakdown';
import KudosCard from '../components/ride/KudosCard';
import WeatherCard from '../components/ride/WeatherCard';
import SegmentRow from '../components/ride/SegmentRow';
import MachineManifest from '../components/ride/MachineManifest';
import CommsLog from '../components/ride/CommsLog';
import LapsTable from '../components/ride/LapsTable';
import { getOverlay, getDivider } from '../constants/colors';
import { LoadingSkeleton } from '../components/ui/loading-skeleton';

// Lazy load heavy components (when we add real map/charts)
// For now, these are just placeholders but the pattern is ready
const MapPlaceholder = lazy(() => import('../components/ride/MapPlaceholder'));
const PowerCurvePlaceholder = lazy(() => import('../components/ride/PowerCurvePlaceholder'));

// Mock data - will be replaced with API call
const mockActivities: Record<string, any> = {
  'morning-ride-dec-8': {
    id: 'morning-ride-dec-8',
    type: 'ride',
    title: 'Morning Ride',
    date: 'Dec 8, 2024 • 7:30 AM',
    distance: '45.2 km',
    duration: '1:42:30',
    elevation: '823 m',
    avgPower: '245 W',
    normalizedPower: '258 W',
    avgHeartRate: '152 bpm',
    maxHeartRate: '178 bpm',
    avgCadence: '87 rpm',
    maxCadence: '112 rpm',
    tss: 120,
    intensityFactor: 0.85,
    dung: 45,
  },
  'afternoon-climb-dec-7': {
    id: 'afternoon-climb-dec-7',
    type: 'ride',
    title: 'Afternoon Climb',
    date: 'Dec 7, 2024 • 2:15 PM',
    distance: '32.1 km',
    duration: '1:28:15',
    elevation: '1240 m',
    avgPower: '268 W',
    normalizedPower: '285 W',
    avgHeartRate: '165 bpm',
    maxHeartRate: '185 bpm',
    avgCadence: '82 rpm',
    maxCadence: '105 rpm',
    tss: 145,
    intensityFactor: 0.92,
    dung: 62,
  },
  'recovery-spin-dec-6': {
    id: 'recovery-spin-dec-6',
    type: 'ride',
    title: 'Recovery Spin',
    date: 'Dec 6, 2024 • 9:00 AM',
    distance: '25.5 km',
    duration: '0:58:20',
    elevation: '180 m',
    avgPower: '165 W',
    normalizedPower: '172 W',
    avgHeartRate: '125 bpm',
    maxHeartRate: '145 bpm',
    avgCadence: '90 rpm',
    maxCadence: '102 rpm',
    tss: 45,
    intensityFactor: 0.55,
    dung: 18,
  },
};

// Mock segment data
const mockSegments = [
  {
    id: 'hawk-hill-climb',
    name: 'Hawk Hill Climb',
    time: '8:42',
    rank: 12,
    totalAttempts: 1847,
    prDiff: '+0:14',
  },
  {
    id: 'golden-gate-sprint',
    name: 'Golden Gate Sprint',
    time: '2:18',
    rank: 45,
    totalAttempts: 3201,
    prDiff: '-0:03',
  },
  {
    id: 'paradise-loop',
    name: 'Paradise Loop',
    time: '24:51',
    rank: 8,
    totalAttempts: 892,
    prDiff: '-0:22',
  },
];

export default function RideView() {
  const { activityId } = useParams<{ activityId: string }>();
  const navigate = useNavigate();
  const { isDarkMode, colors } = useTheme();
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'segments' | 'laps'>('segments');

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const borderColor = getOverlay(isDarkMode);
  const borderColorStrong = getOverlay(isDarkMode, 'strong');
  const dividerColor = getDivider(isDarkMode);

  // Get activity data (mock for now) - generate data if not found
  const activity = activityId 
    ? (mockActivities[activityId] || {
        id: activityId,
        type: 'ride',
        title: 'Morning Ride',
        date: 'Dec 9, 2024 • 7:30 AM',
        distance: '45.2 km',
        duration: '1:42:30',
        elevation: '823 m',
        avgPower: '245 W',
        normalizedPower: '258 W',
        avgHeartRate: '152 bpm',
        maxHeartRate: '178 bpm',
        avgCadence: '87 rpm',
        maxCadence: '112 rpm',
        tss: 120,
        intensityFactor: 0.85,
        dung: 45,
      })
    : null;

  if (!activity) {
    return (
      <div className="max-w-[1200px] mx-auto p-8">
        <div className="text-center py-12">
          <h2 className="font-['Inter'] font-bold text-[24px] mb-2" style={{ color: colors.text }}>
            Activity not found
          </h2>
        </div>
      </div>
    );
  }

  const handleDelete = () => {
    // Mock delete logic
    console.log('Deleting activity:', activityId);
    toast.success('Activity deleted');
    navigate('/');
  };

  return (
    <div className="min-h-full" style={{ backgroundColor: colors.bgSecondary }}>
      {/* Telemetry Header Strip */}
      <div 
        className="w-full border-b px-6 py-1.5 flex justify-between items-center overflow-x-auto"
        style={{ 
            backgroundColor: isDarkMode ? '#1a1d14' : '#e0e0e0',
            borderColor: getOverlay(isDarkMode) 
        }}
      >
        <div className="flex gap-6 font-['Cousine'] text-[10px] tracking-wider whitespace-nowrap opacity-70" style={{ color: colors.text }}>
            <span>ID: {activity?.id.toUpperCase()}</span>
            <span>TYPE: {activity?.type.toUpperCase()}</span>
            <span>DEVICE: GARMIN_EDGE_830</span>
            <span>FIRMWARE: v9.42</span>
        </div>
        <div className="font-['Cousine'] text-[10px] tracking-wider opacity-50 hidden sm:block" style={{ color: colors.text }}>
            SYNCED: {new Date().toLocaleTimeString()}
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 pb-6 border-b" style={{ borderColor: dividerColor }}>
             <div className="flex items-center gap-4">
                 <Avatar className="h-12 w-12 rounded-none border" style={{ borderColor: dividerColor }}>
                    <AvatarImage src="https://github.com/shadcn.png" />
                    <AvatarFallback className="rounded-none bg-muted font-['Cousine'] text-xs">OP</AvatarFallback>
                 </Avatar>
                 <div>
                    <div className="flex items-center gap-3">
                        <h1 className="font-['Inter'] font-bold text-[20px]" style={{ color: colors.text }}>
                          {activity.title}
                        </h1>
                        <span className="px-1.5 py-0.5 border text-[9px] font-['Cousine'] font-bold uppercase tracking-wider bg-muted/20" style={{ borderColor: dividerColor, color: colors.text }}>
                            OP-ID: 8842
                        </span>
                    </div>
                    <div className="flex gap-4 mt-1 font-['Cousine'] text-[11px] opacity-60" style={{ color: colors.text }}>
                        <span>{activity.date}</span>
                        <span>•</span>
                        <span>SAN FRANCISCO, CA</span>
                    </div>
                 </div>
             </div>
             
             <div className="flex gap-2">
                 <BeetleButton variant="outline" size="sm" className="h-8 font-['Cousine'] text-[10px]">EDIT</BeetleButton>
                 <BeetleButton variant="outline" size="sm" className="h-8 font-['Cousine'] text-[10px] text-red-500 hover:text-red-600 border-red-900/20 hover:bg-red-900/10" onClick={() => setShowDeleteModal(true)}>DELETE</BeetleButton>
             </div>
        </div>

        {/* Two-column layout - 65/35 split like Strava */}
        <div className="grid grid-cols-[1fr_300px] gap-5">
          {/* LEFT COLUMN: Main Content */}
          <div className="space-y-5">
            {/* Single Stats Panel */}
            <StatsPanel activity={activity} />

            {/* Map Placeholder */}
            <Suspense fallback={<LoadingSkeleton variant="map" height={300} />}>
              <MapPlaceholder 
                className="p-5 rounded-none border"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor,
                }}
              />
            </Suspense>

            {/* Segments & Laps Toggle */}
            <div className="flex items-center gap-6 mb-4 mt-8">
                <button 
                  onClick={() => setActiveTab('segments')}
                  className={`font-['Inter'] font-bold text-[12px] uppercase tracking-wide border-b-2 pb-1 transition-colors ${activeTab === 'segments' ? 'border-primary text-primary' : 'border-transparent opacity-50 hover:opacity-100'}`}
                  style={{ color: activeTab === 'segments' ? colors.text : colors.textMuted, borderColor: activeTab === 'segments' ? colors.text : 'transparent' }}
                >
                  Segments
                </button>
                <button 
                  onClick={() => setActiveTab('laps')}
                  className={`font-['Inter'] font-bold text-[12px] uppercase tracking-wide border-b-2 pb-1 transition-colors ${activeTab === 'laps' ? 'border-primary text-primary' : 'border-transparent opacity-50 hover:opacity-100'}`}
                  style={{ color: activeTab === 'laps' ? colors.text : colors.textMuted, borderColor: activeTab === 'laps' ? colors.text : 'transparent' }}
                >
                  Laps
                </button>
            </div>

            {/* Content Container */}
            <div 
              className="rounded-none border overflow-hidden"
              style={{ 
                backgroundColor: cardBg,
                borderColor,
              }}
            >
              {activeTab === 'segments' ? (
                <>
                  <div className="px-5 py-4 border-b" style={{ borderColor }}>
                    <h3 
                      className="font-['Inter'] font-bold text-[12px] uppercase tracking-wide"
                      style={{ color: colors.text }}
                    >
                      Segments ({mockSegments.length})
                    </h3>
                  </div>
                  
                  {/* Table Header */}
                  <div className="px-5 py-3 border-b" style={{ borderColor: dividerColor, backgroundColor: isDarkMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.02)' }}>
                    <div className="grid grid-cols-[2fr_60px_1fr_1fr_1fr] gap-4">
                      <div className="font-['Inter'] text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>Segment</div>
                      <div className="font-['Inter'] text-[10px] uppercase tracking-wide" style={{ color: colors.textMuted }}>Profile</div>
                      <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>Time</div>
                      <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>Rank</div>
                      <div className="font-['Inter'] text-[10px] uppercase tracking-wide text-right" style={{ color: colors.textMuted }}>vs PR</div>
                    </div>
                  </div>
    
                  {/* Table Rows */}
                  {mockSegments.map((segment) => (
                    <SegmentRow 
                      key={segment.id}
                      segment={segment}
                      onNavigate={(id) => navigate(`/segments/${id}`)}
                      isDarkMode={isDarkMode}
                      colors={colors}
                    />
                  ))}
                </>
              ) : (
                <LapsTable />
              )}
            </div>

            {/* Power Curve Placeholder */}
            <Suspense fallback={<LoadingSkeleton variant="chart" height={250} />}>
              <PowerCurvePlaceholder 
                className="p-5 rounded-none border"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor,
                }}
              />
            </Suspense>
          </div>

          {/* RIGHT COLUMN: Sidebar - Mission Log */}
          <div className="space-y-4">
             <div 
                className="rounded-none border overflow-hidden"
                style={{ 
                    backgroundColor: cardBg,
                    borderColor,
                }}
             >
                {/* Mission Log Header */}
                <div 
                    className="px-4 py-2 border-b flex items-center justify-between"
                    style={{ 
                        borderColor, 
                        backgroundColor: isDarkMode ? 'rgba(0,0,0,0.2)' : 'rgba(0,0,0,0.05)'
                    }}
                >
                    <div className="font-['Cousine'] text-[11px] font-bold uppercase tracking-wider flex items-center gap-2" style={{ color: colors.text }}>
                        <span>📋 Mission Log</span>
                    </div>
                    <div className="w-2 h-2 bg-green-500 animate-pulse" />
                </div>

                {/* Dung Breakdown */}
                <DungBreakdown dung={activity.dung} embedded />
                
                <div className="h-[1px] mx-4" style={{ backgroundColor: dividerColor }} />
                
                {/* Machine Manifest */}
                <MachineManifest embedded />

                <div className="h-[1px] mx-4" style={{ backgroundColor: dividerColor }} />

                {/* Weather */}
                <WeatherCard embedded />

                <div className="h-[1px] mx-4" style={{ backgroundColor: dividerColor }} />

                {/* Kudos */}
                <KudosCard embedded />
             </div>

             {/* Data Export */}
             <div className="grid grid-cols-2 gap-2 pt-2">
                <BeetleButton variant="outline" className="h-8 font-['Cousine'] text-[10px] rounded-none border border-dashed hover:bg-muted/10" style={{ borderColor: dividerColor, color: colors.text }}>DOWNLOAD .FIT</BeetleButton>
                <BeetleButton variant="outline" className="h-8 font-['Cousine'] text-[10px] rounded-none border border-dashed hover:bg-muted/10" style={{ borderColor: dividerColor, color: colors.text }}>EXPORT .GPX</BeetleButton>
                <BeetleButton variant="outline" className="col-span-2 h-8 font-['Cousine'] text-[10px] rounded-none border border-dashed hover:bg-muted/10" style={{ borderColor: dividerColor, color: colors.accent }}>TRANSMIT TELEMETRY</BeetleButton>
             </div>
          </div>
        </div>

        {/* Comms Log */}
        <div className="mt-8">
            <CommsLog />
        </div>

        {/* Delete Confirmation Modal */}
        {showDeleteModal && activity && (
          <DeleteConfirmModal
            activity={{
              id: activity.id,
              title: activity.title,
              date: activity.date,
              distance: activity.distance,
              dung: activity.dung,
            }}
            onClose={() => setShowDeleteModal(false)}
            onConfirm={handleDelete}
          />
        )}
      </div>
    </div>
  );
}