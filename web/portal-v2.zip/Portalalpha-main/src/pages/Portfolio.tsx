import { useTheme } from '../contexts/ThemeContext';
import { useState } from 'react';

interface Transaction {
  id: string;
  type: 'EARN' | 'SPEND' | 'REWARD';
  description: string;
  amount: number;
  date: string;
  source: string;
}

// Mock transactions
const mockTransactions: Transaction[] = [
  {
    id: '1',
    type: 'EARN',
    description: 'Saturday Gravel Adventure',
    amount: 612,
    date: 'Dec 6',
    source: 'Activity'
  },
  {
    id: '2',
    type: 'EARN',
    description: 'Hill Repeats - Suffer Fest',
    amount: 428,
    date: 'Dec 3',
    source: 'Activity'
  },
  {
    id: '3',
    type: 'REWARD',
    description: 'Mountain Goat Achievement',
    amount: 250,
    date: 'Dec 6',
    source: 'Achievement'
  },
  {
    id: '4',
    type: 'SPEND',
    description: 'Carbon Wheels (Equipment)',
    amount: -500,
    date: 'Dec 5',
    source: 'Store'
  },
  {
    id: '5',
    type: 'EARN',
    description: 'Morning Intervals',
    amount: 385,
    date: 'Dec 8',
    source: 'Activity'
  },
  {
    id: '6',
    type: 'REWARD',
    description: 'Weekly Streak Bonus',
    amount: 150,
    date: 'Dec 2',
    source: 'Bonus'
  },
];

export default function Portfolio() {
  const { colors, isDarkMode } = useTheme();
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  const totalBalance = 2847;
  const weeklyEarnings = mockTransactions
    .filter(t => t.type === 'EARN' || t.type === 'REWARD')
    .reduce((sum, t) => sum + t.amount, 0);
  const allTimeEarnings = 38456;

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;
  const hoverBg = isDarkMode ? 'rgba(139, 168, 122, 0.08)' : 'rgba(139, 168, 122, 0.04)';

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'EARN': return '#8ba87a';
      case 'REWARD': return '#c89b5c';
      case 'SPEND': return '#7a8a7a';
      default: return colors.text;
    }
  };

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[1200px] mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 
            className="font-['Inter'] font-black text-[28px] mb-1"
            style={{ color: colors.text }}
          >
            💼 Portfolio
          </h1>
          <p 
            className="font-['Inter'] text-[12px]"
            style={{ color: colors.textMuted }}
          >
            Your dung balance and transaction history
          </p>
        </div>

        {/* Balance Stats - Terminal Panel */}
        <div 
          className="rounded-none border-[1px] overflow-hidden mb-6"
          style={{ 
            backgroundColor: cardBg,
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          <div className="px-6 py-5">
            <div className="grid grid-cols-3 gap-8">
              {/* Current Balance - HERO */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ 
                    color: '#c89b5c',
                    textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
                  }}
                >
                  {totalBalance.toLocaleString()}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Current Balance 🪲
                </div>
              </div>

              {/* Weekly Earnings */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  +{weeklyEarnings.toLocaleString()}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  This Week
                </div>
              </div>

              {/* All-Time */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {allTimeEarnings.toLocaleString()}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  All-Time Earned
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Transaction History - Terminal Style */}
        <div 
          className="rounded-none border-[1px] overflow-hidden"
          style={{ 
            backgroundColor: cardBg,
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          {/* Table Header */}
          <div 
            className="px-6 py-3"
            style={{ 
              borderBottom: `1px solid ${isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'}`,
            }}
          >
            <div className="grid grid-cols-[100px_1fr_160px_140px_120px] gap-4">
              <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                DATE
              </div>
              <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                DESCRIPTION
              </div>
              <div className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                SOURCE
              </div>
              <div className="font-['Inter'] text-[10px] text-right" style={{ color: colors.textMuted }}>
                TYPE
              </div>
              <div className="font-['Inter'] text-[10px] text-right" style={{ color: colors.textMuted }}>
                AMOUNT
              </div>
            </div>
          </div>

          {/* Table Rows */}
          <div>
            {mockTransactions.map((transaction, index) => (
              <div key={transaction.id}>
                <div 
                  className="px-6 py-3 transition-colors"
                  style={{ 
                    backgroundColor: hoveredRow === transaction.id ? hoverBg : 'transparent',
                  }}
                  onMouseEnter={() => setHoveredRow(transaction.id)}
                  onMouseLeave={() => setHoveredRow(null)}
                >
                  <div className="grid grid-cols-[100px_1fr_160px_140px_120px] gap-4 items-center">
                    {/* Date */}
                    <div className="font-['Cousine'] text-[12px]" style={{ color: colors.textMuted }}>
                      {transaction.date}
                    </div>

                    {/* Description */}
                    <div className="font-['Inter'] text-[14px] font-bold" style={{ color: colors.text }}>
                      {transaction.description}
                    </div>

                    {/* Source */}
                    <div className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>
                      {transaction.source}
                    </div>

                    {/* Type Badge */}
                    <div className="flex justify-end">
                      <div 
                        className="inline-block px-2 py-1 rounded-none border-[1px]"
                        style={{ 
                          backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)',
                          borderColor: getTypeColor(transaction.type),
                        }}
                      >
                        <span 
                          className="font-['Inter'] text-[10px] font-bold"
                          style={{ color: getTypeColor(transaction.type) }}
                        >
                          {transaction.type}
                        </span>
                      </div>
                    </div>

                    {/* Amount */}
                    <div className="text-right">
                      <span 
                        className="font-['Cousine'] text-[16px] font-bold"
                        style={{ 
                          color: transaction.amount > 0 ? '#c89b5c' : colors.textMuted 
                        }}
                      >
                        {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Row Divider */}
                {index < mockTransactions.length - 1 && (
                  <div 
                    className="h-[1px]" 
                    style={{ 
                      backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.06)' 
                    }} 
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Solana Integration Note */}
        <div 
          className="mt-6 rounded-none border-[1px] p-4"
          style={{ 
            backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)',
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          <div className="flex items-start gap-3">
            <div className="text-[20px]">⚡</div>
            <div>
              <div className="font-['Inter'] text-[13px] font-bold mb-1" style={{ color: colors.text }}>
                Web3 Integration Coming Soon
              </div>
              <div className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>
                Withdraw dung tokens to your Solana wallet, trade on-chain, and view NFT equipment.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}