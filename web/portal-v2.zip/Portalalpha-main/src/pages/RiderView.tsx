import { useTheme } from '../contexts/ThemeContext';
import { DungGlow } from '../components/ui/animations';
import { BeetleButton } from '../components/ui/beetle-button';
import { UserPlus, UserCheck, MessageCircle } from 'lucide-react';
import { useState } from 'react';

export default function RiderView() {
  const { colors, isDarkMode } = useTheme();
  const [isFollowing, setIsFollowing] = useState(false);

  // Mock other user data
  const riderData = {
    beetleNumber: 142,
    username: 'alpine_crusher',
    tier: 'SS',
    totalDung: 62847,
    rideCount: 512,
    achievementCount: 68,
    ftp: 312,
    joinedDate: 'Jan 2024',
    // Social stats
    followers: 847,
    following: 203,
    kudos: 4205,
    // Profile info
    location: 'Boulder, CO',
    bio: 'Crushing cols and collecting dung since 2024. SS tier beetle. FTP obsessed.',
    lastActive: '2 hours ago'
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'SS': return '#d4af37';
      case 'S': return '#c89b5c';
      case 'A': return '#8ba87a';
      case 'B': return '#7a8a7a';
      case 'C': return '#5a6a5a';
      default: return '#5a6a5a';
    }
  };

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  // Mock recent activities
  const recentActivities = [
    { id: '1', name: 'Morning Alpine Grind', type: 'Ride', date: 'Dec 7', distance: '87km', elevation: '2,140m', dungEarned: 342 },
    { id: '2', name: 'Flagstaff Repeats', type: 'Ride', date: 'Dec 6', distance: '42km', elevation: '1,280m', dungEarned: 198 },
    { id: '3', name: 'Recovery Spin', type: 'Ride', date: 'Dec 5', distance: '28km', elevation: '420m', dungEarned: 76 },
  ];

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[1000px] mx-auto">
        <div className="grid grid-cols-[280px,1fr] gap-6">
          {/* Left Column - Rider Beetle Card */}
          <div>
            <div 
              className="rounded-none border-[2px] overflow-hidden"
              style={{ 
                backgroundColor: cardBg,
                borderColor: getTierColor(riderData.tier),
                boxShadow: `4px 4px 0px 0px ${getTierColor(riderData.tier)}`,
              }}
            >
              <div className="p-6">
                {/* Beetle Number Badge - Top */}
                <div className="flex justify-between items-start mb-4">
                  <div 
                    className="px-2.5 py-1 rounded-none border-[2px]"
                    style={{ 
                      backgroundColor: getTierColor(riderData.tier),
                      borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
                    }}
                  >
                    <span 
                      className="font-['Cousine'] text-[11px] font-bold"
                      style={{ color: 'white' }}
                    >
                      #{riderData.beetleNumber}
                    </span>
                  </div>
                  <div 
                    className="px-2.5 py-1 rounded-none border-[2px]"
                    style={{ 
                      backgroundColor: getTierColor(riderData.tier),
                      borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
                    }}
                  >
                    <span 
                      className="font-['Inter'] text-[11px] font-black"
                      style={{ color: 'white' }}
                    >
                      {riderData.tier}
                    </span>
                  </div>
                </div>

                {/* Giant Beetle */}
                <div 
                  className="rounded-none border-[1px] aspect-square flex items-center justify-center mb-4"
                  style={{ 
                    backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)',
                    borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                  }}
                >
                  <div className="text-center">
                    <div className="text-[96px]">🪲</div>
                  </div>
                </div>

                {/* Username */}
                <div className="text-center mb-4">
                  <div 
                    className="font-['Inter'] text-[18px] font-black mb-0.5"
                    style={{ color: colors.text }}
                  >
                    @{riderData.username}
                  </div>
                  {riderData.location && (
                    <div 
                      className="font-['Inter'] text-[10px] mb-1"
                      style={{ color: colors.textMuted }}
                    >
                      📍 {riderData.location}
                    </div>
                  )}
                  <div 
                    className="font-['Cousine'] text-[9px]"
                    style={{ color: colors.textMuted }}
                  >
                    Last active {riderData.lastActive}
                  </div>
                </div>

                {/* Bio */}
                {riderData.bio && (
                  <div 
                    className="mb-4 pb-4"
                    style={{ 
                      borderBottom: `1px solid ${isDarkMode ? 'rgba(208, 216, 191, 0.1)' : 'rgba(42, 45, 30, 0.08)'}` 
                    }}
                  >
                    <p 
                      className="font-['Inter'] text-[11px] leading-relaxed text-center"
                      style={{ color: colors.textMuted }}
                    >
                      {riderData.bio}
                    </p>
                  </div>
                )}

                {/* Action Buttons - Inline */}
                <div className="flex gap-2 justify-center mb-4">
                  <BeetleButton
                    onClick={() => setIsFollowing(!isFollowing)}
                    variant={isFollowing ? 'secondary' : 'primary'}
                  >
                    <div className="flex items-center gap-1.5">
                      {isFollowing ? (
                        <>
                          <UserCheck size={12} />
                          <span className="text-[11px]">Following</span>
                        </>
                      ) : (
                        <>
                          <UserPlus size={12} />
                          <span className="text-[11px]">Follow</span>
                        </>
                      )}
                    </div>
                  </BeetleButton>
                  <BeetleButton
                    variant="secondary"
                  >
                    <div className="flex items-center gap-1.5">
                      <MessageCircle size={12} />
                      <span className="text-[11px]">Message</span>
                    </div>
                  </BeetleButton>
                </div>

                {/* Member Since */}
                <div 
                  className="pt-4 text-center"
                  style={{ 
                    borderTop: `1px solid ${isDarkMode ? 'rgba(208, 216, 191, 0.1)' : 'rgba(42, 45, 30, 0.08)'}` 
                  }}
                >
                  <div 
                    className="font-['Inter'] text-[9px] uppercase tracking-wide"
                    style={{ color: colors.textMuted }}
                  >
                    Rolling since {riderData.joinedDate}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Stats & Activities */}
          <div className="space-y-6">
            {/* Social Stats - Compact */}
            <div 
              className="rounded-none border-[1px] p-4"
              style={{ 
                backgroundColor: cardBg,
                borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
              }}
            >
              <div className="grid grid-cols-3 gap-6">
                {/* Followers */}
                <div className="text-center">
                  <div 
                    className="font-['Cousine'] text-[28px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {riderData.followers}
                  </div>
                  <div 
                    className="font-['Inter'] text-[9px] uppercase tracking-wide"
                    style={{ color: colors.textMuted }}
                  >
                    Followers
                  </div>
                </div>

                {/* Following */}
                <div className="text-center">
                  <div 
                    className="font-['Cousine'] text-[28px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {riderData.following}
                  </div>
                  <div 
                    className="font-['Inter'] text-[9px] uppercase tracking-wide"
                    style={{ color: colors.textMuted }}
                  >
                    Following
                  </div>
                </div>

                {/* Kudos */}
                <div className="text-center">
                  <div 
                    className="font-['Cousine'] text-[28px] font-bold leading-none mb-1"
                    style={{ color: colors.text }}
                  >
                    {riderData.kudos}
                  </div>
                  <div 
                    className="font-['Inter'] text-[9px] uppercase tracking-wide"
                    style={{ color: colors.textMuted }}
                  >
                    Kudos
                  </div>
                </div>
              </div>
            </div>

            {/* Stats Grid - 2x2 Compact Boxes */}
            <div className="grid grid-cols-2 gap-4">
              {/* Total Dung */}
              <div 
                className="rounded-none border-[1px] p-5"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                }}
              >
                <div 
                  className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
                  style={{ 
                    color: '#c89b5c',
                    textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
                  }}
                >
                  <DungGlow>
                    {riderData.totalDung.toLocaleString()}
                  </DungGlow>
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Total Dung 🪲
                </div>
              </div>

              {/* Rides */}
              <div 
                className="rounded-none border-[1px] p-5"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                }}
              >
                <div 
                  className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
                  style={{ color: colors.text }}
                >
                  {riderData.rideCount}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Total Rides
                </div>
              </div>

              {/* Achievements */}
              <div 
                className="rounded-none border-[1px] p-5"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                }}
              >
                <div 
                  className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
                  style={{ color: colors.text }}
                >
                  {riderData.achievementCount}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Achievements
                </div>
              </div>

              {/* FTP */}
              <div 
                className="rounded-none border-[1px] p-5"
                style={{ 
                  backgroundColor: cardBg,
                  borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                }}
              >
                <div 
                  className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
                  style={{ color: colors.accent }}
                >
                  {riderData.ftp}
                  <span className="text-[14px] ml-1" style={{ color: colors.textMuted }}>W</span>
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  FTP
                </div>
              </div>
            </div>

            {/* Recent Activities */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 
                  className="font-['Inter'] text-[12px] font-bold uppercase tracking-wide"
                  style={{ color: colors.textMuted }}
                >
                  Recent Activities
                </h3>
              </div>

              <div className="space-y-2">
                {recentActivities.map((activity) => (
                  <div 
                    key={activity.id}
                    className="rounded-none border-[1px] p-3 cursor-pointer transition-all hover:border-[#8ba87a]"
                    style={{ 
                      backgroundColor: cardBg,
                      borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 
                            className="font-['Inter'] text-[12px] font-bold"
                            style={{ color: colors.text }}
                          >
                            {activity.name}
                          </h4>
                          <span 
                            className="font-['Inter'] text-[10px]"
                            style={{ color: colors.textMuted }}
                          >
                            • {activity.date}
                          </span>
                        </div>

                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <span 
                              className="font-['Cousine'] text-[11px] font-bold"
                              style={{ color: colors.text }}
                            >
                              {activity.distance}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span 
                              className="font-['Cousine'] text-[11px] font-bold"
                              style={{ color: colors.text }}
                            >
                              ↗ {activity.elevation}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Dung Earned */}
                      <div 
                        className="px-2 py-0.5 rounded-none border-[2px] flex-shrink-0"
                        style={{ 
                          backgroundColor: '#c89b5c',
                          borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
                          boxShadow: '1px 1px 0px 0px rgba(42, 45, 30, 0.3)',
                        }}
                      >
                        <span 
                          className="font-['Cousine'] text-[11px] font-bold"
                          style={{ color: 'white' }}
                        >
                          +{activity.dungEarned}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}