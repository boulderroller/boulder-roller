import { useState, useMemo } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { ActivityFeedItem } from '../components/feed/ActivityFeedItem';
import { ActivityFeedItem as ActivityFeedItemType } from '../types';
import { LayoutGrid, List, Search, Calendar, ChevronDown, Filter } from 'lucide-react';
import { cn } from '../components/ui/utils';

// --- Mock Data Generator (Reused for Consistency) ---
const generateActivity = (id: number): ActivityFeedItemType => {
  const types = ['ROAD', 'GRAVEL', 'MTB', 'INDOOR', 'COMMUTE'];
  const titles = ['Morning Interval Session', 'Zone 2 Endurance', 'Recovery Spin', 'Hill Repeats', 'FTP Test', 'Commute', 'Gravel Grind', 'Sunday Long Ride'];
  const locations = ['Marin County, CA', 'San Francisco, CA', 'Boulder, CO', 'Watopia', 'Oakland, CA'];
  
  // Reliable Unsplash IDs
  const imageIds = [
      '1517649763962-0c623066013b', 
      '1559166631-ef208440c75a', 
      '1628191014330-db33b345a55b', 
      '1596727147705-54a9d0c2067d'
  ];

  const type = types[Math.floor(Math.random() * types.length)];
  const location = locations[Math.floor(Math.random() * locations.length)];
  const color = '#8ba87a'; // User's color
  
  const daysAgo = Math.floor(Math.random() * 30);
  const dateObj = new Date();
  dateObj.setDate(dateObj.getDate() - daysAgo);
  const dateStr = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  // Visuals Logic
  let visualType: 'map' | 'image' | 'none' = 'none';
  let visualUrl = '';
  
  if (type === 'ROAD' || type === 'GRAVEL' || type === 'MTB') {
    const r = Math.random();
    if (r > 0.7) {
        visualType = 'image';
        const imgId = imageIds[Math.floor(Math.random() * imageIds.length)];
        visualUrl = `https://images.unsplash.com/photo-${imgId}?auto=format&fit=crop&w=1000&q=80`;
    } else {
        visualType = 'map';
    }
  }

  const distanceVal = Math.floor(Math.random() * 80 + 10);
  const dungVal = Math.floor(Math.random() * 80 + 10);

  return {
    id: `my-activity-${id}`,
    type: 'ride',
    title: titles[Math.floor(Math.random() * titles.length)],
    date: dateStr,
    distance: `${distanceVal}km`,
    duration: `${Math.floor(Math.random() * 3)}:${String(Math.floor(Math.random() * 60)).padStart(2, '0')}`,
    elevation: `${Math.floor(Math.random() * 1500 + 100)}m`,
    avgPower: `${Math.floor(Math.random() * 150 + 150)}w`,
    location,
    tss: Math.floor(Math.random() * 150 + 30),
    dung: dungVal,
    displayType: type as any,
    user: 'currentUser', // Identifying as self
    action: 'Ride',
    time: `${daysAgo}d ago`,
    dungDisplay: `+${dungVal}`,
    color,
    visualType,
    visualUrl,
    claps: Math.floor(Math.random() * 20)
  };
};

// Generate 20 activities
const MOCK_ACTIVITIES = Array.from({ length: 20 }, (_, i) => generateActivity(i));

// --- Components ---

const UptimeMatrix = () => {
    // Generate 365 days of "uptime"
    const weeks = 52;
    const days = 7;
    
    return (
        <div className="mb-8 p-4 bg-muted/10 overflow-hidden relative">
            <div className="flex items-center justify-between mb-2">
                 <span className="font-['Cousine'] text-[10px] uppercase tracking-widest text-muted-foreground">ANNUAL ACTIVITY RECORD // 365 DAYS</span>
                 <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                    <span>INACTIVE</span>
                    <div className="flex gap-0.5">
                        <div className="w-2 h-2 bg-zinc-800" />
                        <div className="w-2 h-2 bg-[#8ba87a]/30" />
                        <div className="w-2 h-2 bg-[#8ba87a]" />
                        <div className="w-2 h-2 bg-yellow-500" />
                    </div>
                    <span>HIGH INTENSITY</span>
                 </div>
            </div>
            
            <div className="flex gap-[2px] overflow-x-auto pb-1 scrollbar-hide opacity-80 hover:opacity-100 transition-opacity">
                {Array.from({ length: weeks }).map((_, w) => (
                    <div key={w} className="flex flex-col gap-[2px]">
                        {Array.from({ length: days }).map((_, d) => {
                            const val = Math.random();
                            let bg = 'bg-zinc-200 dark:bg-zinc-800'; // Idle
                            if (val > 0.6) bg = 'bg-[#8ba87a]/40'; // Low
                            if (val > 0.8) bg = 'bg-[#8ba87a]'; // Active
                            if (val > 0.95) bg = 'bg-yellow-500'; // Hazard/Overclock

                            return (
                                <div 
                                    key={d} 
                                    className={`w-2.5 h-2.5 ${bg} rounded-[1px] hover:scale-125 transition-transform duration-75`}
                                    title={`Week ${w}, Day ${d}`}
                                />
                            );
                        })}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default function MyActivities() {
  const { colors, isDarkMode } = useTheme();
  const [viewMode, setViewMode] = useState<'visual' | 'data'>('visual');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  // Filter activities
  const filteredActivities = useMemo(() => {
      return MOCK_ACTIVITIES.filter(act => {
          const matchesSearch = act.title.toLowerCase().includes(searchQuery.toLowerCase());
          const matchesType = filterType === 'ALL' || act.displayType === filterType;
          return matchesSearch && matchesType;
      });
  }, [searchQuery, filterType]);

  const stats = useMemo(() => {
      const dist = filteredActivities.reduce((acc, curr) => acc + parseInt(curr.distance), 0);
      const dung = filteredActivities.reduce((acc, curr) => acc + curr.dung, 0);
      const rides = filteredActivities.length;
      return { dist, dung, rides };
  }, [filteredActivities]);

  return (
    <div className="min-h-screen bg-background text-foreground animate-in fade-in duration-500">
      <div className="max-w-[1400px] mx-auto p-4 md:p-8">
        
        {/* Header Area */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4 border-b border-border pb-6">
           <div>
              <div className="flex items-center gap-3 mb-2">
                 <div className="w-2 h-2 bg-green-500 animate-pulse" />
                 <span className="font-['Cousine'] text-xs text-muted-foreground tracking-widest">USER ID: 1247 // ACTIVITY HISTORY</span>
              </div>
              <h1 className="text-3xl font-bold tracking-tight">ACTIVITY LOG</h1>
           </div>
           
           {/* Stats Summary (Compact) */}
           <div className="flex gap-6 md:gap-12">
               <div>
                   <span className="block font-['Cousine'] text-2xl font-bold">{stats.rides}</span>
                   <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Rides</span>
               </div>
               <div>
                   <span className="block font-['Cousine'] text-2xl font-bold">{stats.dist}km</span>
                   <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Distance</span>
               </div>
               <div>
                   <span className="block font-['Cousine'] text-2xl font-bold text-[#c89b5c]">{stats.dung}</span>
                   <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Dung</span>
               </div>
           </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-8">
            
            {/* Left Sidebar: Timeline & Filters */}
            <div className="space-y-8">
                 {/* Filter Deck */}
                 <div className="space-y-4">
                     <div className="relative">
                         <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={14} />
                         <input 
                            type="text" 
                            placeholder="SEARCH ACTIVITIES..." 
                            className="w-full h-10 bg-transparent border border-border pl-9 pr-4 text-xs font-['Cousine'] focus:border-foreground outline-none transition-colors placeholder:text-muted-foreground/50"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                         />
                     </div>
                     
                     <div className="flex flex-col gap-1">
                         {['ALL', 'ROAD', 'GRAVEL', 'MTB', 'INDOOR', 'COMMUTE'].map(type => (
                             <button
                                key={type}
                                onClick={() => setFilterType(type)}
                                className={cn(
                                    "text-left px-3 py-2 text-xs font-['Cousine'] transition-all",
                                    filterType === type 
                                        ? "bg-foreground text-background font-bold" 
                                        : "text-muted-foreground hover:bg-muted hover:text-foreground"
                                )}
                             >
                                 [{filterType === type ? 'x' : ' '}] {type}
                             </button>
                         ))}
                     </div>
                 </div>

                 {/* Timeline Tree */}
                 <div className="pt-4 border-t border-border">
                     <h3 className="font-['Cousine'] text-[10px] uppercase tracking-widest mb-4 text-muted-foreground">DATE INDEX</h3>
                     <div className="space-y-1">
                         <div className="flex items-center gap-2 text-sm font-bold">
                             <ChevronDown size={14} />
                             2025
                         </div>
                         <div className="pl-6 flex flex-col gap-1 text-xs text-muted-foreground font-['Cousine']">
                             <div className="text-foreground cursor-pointer hover:underline">DECEMBER [20]</div>
                             <div className="cursor-pointer hover:text-foreground">NOVEMBER [42]</div>
                             <div className="cursor-pointer hover:text-foreground">OCTOBER [31]</div>
                         </div>
                     </div>
                 </div>
            </div>

            {/* Main Content Area */}
            <div>
                {/* Uptime Matrix */}
                <UptimeMatrix />

                {/* View Toggles & Sort */}
                <div className="flex justify-between items-center mb-6">
                    <div className="flex gap-2">
                        <button 
                            onClick={() => setViewMode('visual')}
                            className={cn(
                                "flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase border transition-all",
                                viewMode === 'visual' ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:border-foreground"
                            )}
                        >
                            <LayoutGrid size={14} />
                            Visual
                        </button>
                        <button 
                            onClick={() => setViewMode('data')}
                            className={cn(
                                "flex items-center gap-2 px-4 py-2 text-xs font-bold uppercase border transition-all",
                                viewMode === 'data' ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:border-foreground"
                            )}
                        >
                            <List size={14} />
                            Data
                        </button>
                    </div>
                    
                    <button className="flex items-center gap-2 text-xs font-['Cousine'] text-muted-foreground hover:text-foreground">
                        SORT: DATE (DESC) <ChevronDown size={12} />
                    </button>
                </div>

                {/* Content Render */}
                {viewMode === 'visual' ? (
                    <div className="space-y-6">
                        {filteredActivities.map(activity => (
                            <ActivityFeedItem
                                key={activity.id}
                                activity={activity}
                                hoverBg={isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)'}
                                textColor={isDarkMode ? '#fff' : '#000'}
                                textMuted={isDarkMode ? '#999' : '#666'}
                                isDarkMode={isDarkMode}
                                cardBg={isDarkMode ? '#000' : '#fff'}
                                borderColor={isDarkMode ? '#333' : '#e5e5e5'}
                                onClick={() => {}}
                                onDoubleClick={() => {}}
                            />
                        ))}
                    </div>
                ) : (
                    // Data View (High Density Table)
                    <div className="border-t border-b border-border">
                        {/* Table Header */}
                        <div className="grid grid-cols-[1fr_100px_100px_100px_100px] gap-4 p-3 bg-muted/20 border-b border-border text-[10px] font-['Cousine'] text-muted-foreground uppercase tracking-wider">
                            <div>Activity</div>
                            <div className="text-right">Date</div>
                            <div className="text-right">Dist</div>
                            <div className="text-right">Pwr</div>
                            <div className="text-right">Dung</div>
                        </div>
                        {/* Rows */}
                        {filteredActivities.map((activity, idx) => (
                            <div 
                                key={activity.id}
                                className={cn(
                                    "grid grid-cols-[1fr_100px_100px_100px_100px] gap-4 p-3 text-xs font-['Cousine'] hover:bg-muted/10 cursor-pointer transition-colors items-center",
                                    idx !== filteredActivities.length - 1 ? "border-b border-border" : ""
                                )}
                            >
                                <div className="font-bold truncate">{activity.title}</div>
                                <div className="text-right text-muted-foreground">{activity.date}</div>
                                <div className="text-right">{activity.distance}</div>
                                <div className="text-right text-muted-foreground">{activity.avgPower}</div>
                                <div className="text-right text-[#c89b5c] font-bold">+{activity.dung}</div>
                            </div>
                        ))}
                    </div>
                )}
            </div>

        </div>
      </div>
    </div>
  );
}