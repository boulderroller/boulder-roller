import { useTheme } from '../contexts/ThemeContext';
import { DungGlow } from '../components/ui/animations';
import { BeetleButton } from '../components/ui/beetle-button';
import { Zap, Calendar, TrendingUp, Activity } from 'lucide-react';

export default function ItemDetail() {
  const { colors, isDarkMode } = useTheme();

  // Mock item data
  const itemData = {
    id: 'wheels_001',
    emoji: '🎡',
    name: 'Carbon Aero Wheels',
    rarity: 'Epic',
    slot: 'Wheels',
    dungCost: 2500,
    owned: true,
    equippedDate: 'Dec 1, 2025',
    // Stats
    stats: {
      power: '+5%',
      aero: '+8%',
      comfort: '-2%',
    },
    // Bonuses
    bonuses: [
      { type: 'Speed', value: '+2 km/h avg on flat terrain' },
      { type: 'Dung', value: '+3% dung earned on rides over 50km' },
    ],
    // Usage stats
    ridesUsed: 47,
    dungEarned: 1842,
    kmRidden: 2156,
    description: 'Legendary carbon wheels forged in the fires of Mount Beetle. These babies slice through the wind like a dung beetle through... well, you know.',
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Legendary': return '#d4af37';
      case 'Epic': return '#a855f7';
      case 'Rare': return '#3b82f6';
      case 'Uncommon': return '#8ba87a';
      case 'Common': return '#6b7280';
      default: return '#6b7280';
    }
  };

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  // Mock recent sessions with this item
  const recentSessions = [
    { id: '1', name: 'Morning Alpine Grind', date: 'Dec 7', distance: '87km', dungEarned: 142 },
    { id: '2', name: 'Flagstaff Repeats', date: 'Dec 6', distance: '42km', dungEarned: 78 },
    { id: '3', name: 'Recovery Spin', date: 'Dec 5', distance: '28km', dungEarned: 34 },
  ];

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[900px] mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <span 
              className="font-['Inter'] text-[10px] uppercase tracking-wide"
              style={{ color: colors.textMuted }}
            >
              Equipment
            </span>
            <span style={{ color: colors.textMuted }}>→</span>
            <span 
              className="font-['Inter'] text-[10px] uppercase tracking-wide"
              style={{ color: colors.text }}
            >
              {itemData.slot}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-[380px,1fr] gap-6">
          {/* Left Column - Item Card */}
          <div className="space-y-6">
            {/* Main Item Card */}
            <div 
              className="rounded-[6px] border-[3px] overflow-hidden"
              style={{ 
                backgroundColor: cardBg,
                borderColor: getRarityColor(itemData.rarity),
                boxShadow: `5px 5px 0px 0px ${getRarityColor(itemData.rarity)}`,
              }}
            >
              <div className="p-6">
                {/* Item Icon */}
                <div className="flex flex-col items-center mb-5">
                  <div 
                    className="w-40 h-40 rounded-[8px] border-[3px] flex items-center justify-center mb-3"
                    style={{ 
                      backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.05)',
                      borderColor: getRarityColor(itemData.rarity),
                    }}
                  >
                    <span className="text-[96px]">{itemData.emoji}</span>
                  </div>

                  {/* Rarity Badge */}
                  <div 
                    className="px-3 py-1 rounded-[4px] border-[2px] mb-2"
                    style={{ 
                      backgroundColor: getRarityColor(itemData.rarity),
                      borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
                    }}
                  >
                    <span 
                      className="font-['Inter'] text-[11px] font-black uppercase tracking-wide"
                      style={{ color: 'white' }}
                    >
                      {itemData.rarity}
                    </span>
                  </div>

                  {/* Item Name */}
                  <h1 
                    className="font-['Inter'] text-[22px] font-black text-center mb-1"
                    style={{ color: colors.text }}
                  >
                    {itemData.name}
                  </h1>

                  {/* Slot */}
                  <div 
                    className="font-['Inter'] text-[11px]"
                    style={{ color: colors.textMuted }}
                  >
                    {itemData.slot} Slot
                  </div>
                </div>

                {/* Description */}
                <div 
                  className="mb-5 pb-5"
                  style={{ 
                    borderBottom: `1px solid ${isDarkMode ? 'rgba(208, 216, 191, 0.1)' : 'rgba(42, 45, 30, 0.08)'}` 
                  }}
                >
                  <p 
                    className="font-['Inter'] text-[12px] leading-relaxed text-center"
                    style={{ color: colors.textMuted }}
                  >
                    {itemData.description}
                  </p>
                </div>

                {/* Stats */}
                <div className="mb-5">
                  <div 
                    className="font-['Inter'] text-[10px] uppercase tracking-wide mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Base Stats
                  </div>
                  <div className="space-y-2">
                    {Object.entries(itemData.stats).map(([stat, value]) => (
                      <div key={stat} className="flex items-center justify-between">
                        <span 
                          className="font-['Inter'] text-[12px] capitalize"
                          style={{ color: colors.text }}
                        >
                          {stat}
                        </span>
                        <span 
                          className="font-['Cousine'] text-[13px] font-bold"
                          style={{ 
                            color: value.toString().startsWith('+') ? '#8ba87a' : value.toString().startsWith('-') ? '#d4183d' : colors.text 
                          }}
                        >
                          {value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bonuses */}
                <div>
                  <div 
                    className="font-['Inter'] text-[10px] uppercase tracking-wide mb-3"
                    style={{ color: colors.textMuted }}
                  >
                    Special Bonuses
                  </div>
                  <div className="space-y-2">
                    {itemData.bonuses.map((bonus, idx) => (
                      <div 
                        key={idx}
                        className="rounded-[4px] border-[1px] p-2"
                        style={{ 
                          backgroundColor: isDarkMode ? 'rgba(139, 168, 122, 0.08)' : 'rgba(139, 168, 122, 0.05)',
                          borderColor: isDarkMode ? 'rgba(139, 168, 122, 0.2)' : 'rgba(139, 168, 122, 0.15)',
                        }}
                      >
                        <div className="flex items-start gap-2">
                          <Zap size={12} style={{ color: colors.accent, marginTop: 2 }} />
                          <div>
                            <div 
                              className="font-['Inter'] text-[10px] font-bold mb-0.5"
                              style={{ color: colors.accent }}
                            >
                              {bonus.type}
                            </div>
                            <div 
                              className="font-['Inter'] text-[11px]"
                              style={{ color: colors.text }}
                            >
                              {bonus.value}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            {itemData.owned && (
              <div className="space-y-2">
                <BeetleButton variant="primary" className="w-full">
                  <div className="flex items-center justify-center gap-2">
                    <span>Equipped</span>
                    <span>✓</span>
                  </div>
                </BeetleButton>
                <BeetleButton variant="secondary" className="w-full">
                  <div className="flex items-center justify-center gap-2">
                    <span>Unequip</span>
                  </div>
                </BeetleButton>
              </div>
            )}
          </div>

          {/* Right Column - Usage Stats & Sessions */}
          <div className="space-y-6">
            {/* Usage Stats */}
            <div 
              className="rounded-[6px] border-[1px] overflow-hidden"
              style={{ 
                backgroundColor: cardBg,
                borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
              }}
            >
              <div className="px-5 py-4">
                <div className="flex items-center gap-2 mb-4">
                  <Activity size={14} style={{ color: colors.textMuted }} />
                  <h3 
                    className="font-['Inter'] text-[12px] font-bold uppercase tracking-wide"
                    style={{ color: colors.textMuted }}
                  >
                    Usage Stats
                  </h3>
                </div>

                <div className="grid grid-cols-3 gap-6">
                  {/* Rides Used */}
                  <div>
                    <div 
                      className="font-['Cousine'] text-[36px] font-bold leading-none mb-0.5"
                      style={{ color: colors.text }}
                    >
                      {itemData.ridesUsed}
                    </div>
                    <div 
                      className="font-['Inter'] text-[10px]"
                      style={{ color: colors.textMuted }}
                    >
                      Rides
                    </div>
                  </div>

                  {/* KM Ridden */}
                  <div>
                    <div 
                      className="font-['Cousine'] text-[36px] font-bold leading-none mb-0.5"
                      style={{ color: colors.text }}
                    >
                      {itemData.kmRidden}
                      <span className="text-[14px] ml-1" style={{ color: colors.textMuted }}>km</span>
                    </div>
                    <div 
                      className="font-['Inter'] text-[10px]"
                      style={{ color: colors.textMuted }}
                    >
                      Distance
                    </div>
                  </div>

                  {/* Dung Earned */}
                  <div>
                    <div 
                      className="font-['Cousine'] text-[36px] font-bold leading-none mb-0.5"
                      style={{ 
                        color: '#c89b5c',
                        textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
                      }}
                    >
                      <DungGlow>
                        {itemData.dungEarned}
                      </DungGlow>
                    </div>
                    <div 
                      className="font-['Inter'] text-[10px]"
                      style={{ color: colors.textMuted }}
                    >
                      Dung Earned
                    </div>
                  </div>
                </div>

                {/* Equipped Date */}
                {itemData.equippedDate && (
                  <div 
                    className="mt-4 pt-4 flex items-center gap-2"
                    style={{ 
                      borderTop: `1px solid ${isDarkMode ? 'rgba(208, 216, 191, 0.1)' : 'rgba(42, 45, 30, 0.08)'}` 
                    }}
                  >
                    <Calendar size={12} style={{ color: colors.textMuted }} />
                    <span 
                      className="font-['Cousine'] text-[10px]"
                      style={{ color: colors.textMuted }}
                    >
                      Equipped since {itemData.equippedDate}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Recent Sessions */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp size={14} style={{ color: colors.textMuted }} />
                <h3 
                  className="font-['Inter'] text-[12px] font-bold uppercase tracking-wide"
                  style={{ color: colors.textMuted }}
                >
                  Recent Sessions with This Item
                </h3>
              </div>

              <div className="space-y-2">
                {recentSessions.map((session) => (
                  <div 
                    key={session.id}
                    className="rounded-[6px] border-[1px] p-3 cursor-pointer transition-all hover:border-[#8ba87a]"
                    style={{ 
                      backgroundColor: cardBg,
                      borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 
                            className="font-['Inter'] text-[12px] font-bold"
                            style={{ color: colors.text }}
                          >
                            {session.name}
                          </h4>
                          <span 
                            className="font-['Inter'] text-[10px]"
                            style={{ color: colors.textMuted }}
                          >
                            • {session.date}
                          </span>
                        </div>
                        <div 
                          className="font-['Cousine'] text-[11px]"
                          style={{ color: colors.textMuted }}
                        >
                          {session.distance}
                        </div>
                      </div>

                      {/* Dung Earned */}
                      <div 
                        className="px-2 py-0.5 rounded-[4px] border-[2px]"
                        style={{ 
                          backgroundColor: '#c89b5c',
                          borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
                          boxShadow: '1px 1px 0px 0px rgba(42, 45, 30, 0.3)',
                        }}
                      >
                        <span 
                          className="font-['Cousine'] text-[11px] font-bold"
                          style={{ color: 'white' }}
                        >
                          +{session.dungEarned}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
