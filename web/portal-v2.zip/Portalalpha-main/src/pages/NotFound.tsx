import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import { BeetleButton } from '../components/ui/beetle-button';
import { Home, ArrowLeft } from 'lucide-react';

/**
 * NotFound - 404 Page for invalid routes
 * Matches BoulderRoller's brutalist beetle aesthetic
 */
export default function NotFound() {
  const { colors } = useTheme();
  const navigate = useNavigate();

  return (
    <div 
      className="min-h-screen flex items-center justify-center p-6"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div 
        className="max-w-lg w-full rounded border p-12 text-center"
        style={{ 
          backgroundColor: colors.bg,
          borderColor: colors.border,
        }}
      >
        {/* 404 Beetle */}
        <div className="mb-6">
          <div className="text-[80px] mb-4">🪲</div>
          <div 
            className="font-['Cousine'] text-[72px] font-bold mb-2"
            style={{ 
              color: colors.text,
              lineHeight: 0.9,
            }}
          >
            404
          </div>
        </div>

        {/* Message */}
        <h1 
          className="font-['Inter'] font-bold text-[24px] mb-3"
          style={{ color: colors.text }}
        >
          Lost Beetle
        </h1>
        
        <p 
          className="font-['Inter'] text-[14px] mb-8 max-w-sm mx-auto"
          style={{ color: colors.textMuted }}
        >
          This beetle rolled off the map. The page you're looking for doesn't exist or has been moved.
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <BeetleButton 
            variant="secondary" 
            size="md"
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Go Back</span>
          </BeetleButton>

          <BeetleButton 
            variant="primary" 
            size="md"
            onClick={() => navigate('/')}
          >
            <Home className="w-4 h-4" />
            <span>Go Home</span>
          </BeetleButton>
        </div>

        {/* Helpful Links */}
        <div className="mt-8 pt-8 border-t" style={{ borderColor: colors.border }}>
          <div 
            className="font-['Inter'] text-[11px] uppercase tracking-wide mb-3"
            style={{ color: colors.textMuted }}
          >
            Quick Links
          </div>
          <div className="flex flex-wrap gap-3 justify-center">
            <button
              onClick={() => navigate('/my-activities')}
              className="font-['Inter'] text-[13px] hover:underline transition-opacity hover:opacity-70"
              style={{ color: colors.accent }}
            >
              My Activities
            </button>
            <span style={{ color: colors.textMuted }}>•</span>
            <button
              onClick={() => navigate('/leaderboard')}
              className="font-['Inter'] text-[13px] hover:underline transition-opacity hover:opacity-70"
              style={{ color: colors.accent }}
            >
              Leaderboard
            </button>
            <span style={{ color: colors.textMuted }}>•</span>
            <button
              onClick={() => navigate('/store')}
              className="font-['Inter'] text-[13px] hover:underline transition-opacity hover:opacity-70"
              style={{ color: colors.accent }}
            >
              Beetle Store
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
