import { useTheme } from '../contexts/ThemeContext';
import { useState } from 'react';
import { DungGlow } from '../components/ui/animations';
import { BeetleButton } from '../components/ui/beetle-button';
import { Trophy, Lock } from 'lucide-react';

interface Achievement {
  id: string;
  emoji: string;
  name: string;
  description: string;
  dungReward: number;
  unlocked: boolean;
  unlockedDate?: string;
  progress?: number; // 0-100
  requirement?: string;
}

// Mock achievements
const mockAchievements: Achievement[] = [
  {
    id: '1',
    emoji: '🏔️',
    name: 'Mountain Goat',
    description: 'Climb 10,000m in a single month',
    dungReward: 250,
    unlocked: true,
    unlockedDate: 'Dec 6, 2025'
  },
  {
    id: '2',
    emoji: '⚡',
    name: 'Speed Demon',
    description: 'Average 35+ km/h for 50km',
    dungReward: 200,
    unlocked: true,
    unlockedDate: 'Dec 4, 2025'
  },
  {
    id: '3',
    emoji: '💪',
    name: 'Century Crusher',
    description: 'Complete a 100+ km ride',
    dungReward: 300,
    unlocked: true,
    unlockedDate: 'Dec 1, 2025'
  },
  {
    id: '4',
    emoji: '🔥',
    name: 'Consistency King',
    description: 'Ride 7 days in a row',
    dungReward: 400,
    unlocked: false,
    progress: 68,
    requirement: '5/7 days complete'
  },
  {
    id: '5',
    emoji: '🎯',
    name: 'FTP Milestone',
    description: 'Reach 300W FTP',
    dungReward: 500,
    unlocked: false,
    progress: 95,
    requirement: 'Current: 285W'
  },
  {
    id: '6',
    emoji: '⏱️',
    name: 'Early Bird',
    description: 'Complete 10 rides before 6am',
    dungReward: 150,
    unlocked: false,
    progress: 40,
    requirement: '4/10 rides'
  },
  {
    id: '7',
    emoji: '🌧️',
    name: 'Rain Warrior',
    description: 'Ride 5 times in the rain',
    dungReward: 350,
    unlocked: false,
    progress: 20,
    requirement: '1/5 rides'
  },
  {
    id: '8',
    emoji: '👑',
    name: 'Segment Hunter',
    description: 'Get 10 segment crowns',
    dungReward: 600,
    unlocked: false,
    progress: 0,
    requirement: '0/10 crowns'
  },
];

export default function Achievements() {
  const { colors, isDarkMode } = useTheme();
  const [filter, setFilter] = useState<'all' | 'unlocked' | 'locked'>('all');

  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  const unlockedCount = mockAchievements.filter(a => a.unlocked).length;
  const totalDungEarned = mockAchievements
    .filter(a => a.unlocked)
    .reduce((sum, a) => sum + a.dungReward, 0);

  const filteredAchievements = mockAchievements.filter(a => {
    if (filter === 'unlocked') return a.unlocked;
    if (filter === 'locked') return !a.unlocked;
    return true;
  });

  return (
    <div 
      className="min-h-full p-8"
      style={{ backgroundColor: colors.bgSecondary }}
    >
      <div className="max-w-[1000px] mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 
            className="font-['Inter'] font-black text-[28px] mb-1"
            style={{ color: colors.text }}
          >
            🎖️ Achievements
          </h1>
          <p 
            className="font-['Inter'] text-[12px]"
            style={{ color: colors.textMuted }}
          >
            Earn dung through riding achievements and milestones
          </p>
        </div>

        {/* Stats Panel */}
        <div 
          className="rounded-[6px] border-[1px] overflow-hidden mb-6"
          style={{ 
            backgroundColor: cardBg,
            borderColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)',
          }}
        >
          <div className="px-6 py-5">
            <div className="grid grid-cols-3 gap-8">
              {/* Unlocked Count */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {unlockedCount}
                  <span className="text-[16px] ml-1" style={{ color: colors.textMuted }}>
                    /{mockAchievements.length}
                  </span>
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Achievements Unlocked
                </div>
              </div>

              {/* Total Dung from Achievements */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ 
                    color: '#c89b5c',
                    textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
                  }}
                >
                  {totalDungEarned}
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Dung Earned 🪲
                </div>
              </div>

              {/* Completion Percentage */}
              <div>
                <div 
                  className="font-['Cousine'] text-[42px] font-bold leading-none mb-0.5"
                  style={{ color: colors.text }}
                >
                  {Math.round((unlockedCount / mockAchievements.length) * 100)}
                  <span className="text-[16px] ml-1" style={{ color: colors.textMuted }}>
                    %
                  </span>
                </div>
                <div 
                  className="font-['Inter'] text-[10px]"
                  style={{ color: colors.textMuted }}
                >
                  Completion
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-4">
          {(['all', 'unlocked', 'locked'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="px-4 py-2 rounded-[4px] border-[1px] transition-colors"
              style={{
                backgroundColor: filter === f ? (isDarkMode ? 'rgba(139, 168, 122, 0.15)' : 'rgba(139, 168, 122, 0.1)') : 'transparent',
                borderColor: filter === f ? colors.accent : (isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'),
                color: filter === f ? colors.accent : colors.textMuted,
              }}
            >
              <span className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide">
                {f}
              </span>
            </button>
          ))}
        </div>

        {/* Achievements Grid */}
        <div className="space-y-3">
          {filteredAchievements.map((achievement) => (
            <div 
              key={achievement.id}
              className="rounded-[6px] border-[2px] p-5"
              style={{ 
                backgroundColor: cardBg,
                borderColor: achievement.unlocked ? '#c89b5c' : (isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'),
                boxShadow: achievement.unlocked ? '3px 3px 0px 0px #c89b5c' : 'none',
                opacity: achievement.unlocked ? 1 : 0.75,
              }}
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div 
                  className="w-16 h-16 rounded-[6px] border-[2px] flex items-center justify-center flex-shrink-0"
                  style={{ 
                    backgroundColor: achievement.unlocked ? (isDarkMode ? '#2a2d1e' : colors.bg) : (isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)'),
                    borderColor: achievement.unlocked ? '#c89b5c' : (isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)'),
                  }}
                >
                  <span className="text-[32px]">{achievement.emoji}</span>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-1">
                    <div>
                      <h3 
                        className="font-['Inter'] text-[16px] font-bold mb-0.5"
                        style={{ color: colors.text }}
                      >
                        {achievement.name}
                        {achievement.unlocked && (
                          <span className="ml-2 text-[14px]">✓</span>
                        )}
                      </h3>
                      <p 
                        className="font-['Inter'] text-[12px]"
                        style={{ color: colors.textMuted }}
                      >
                        {achievement.description}
                      </p>
                    </div>

                    {/* Dung Reward - LOOT emphasis */}
                    <div 
                      className="px-3 py-1.5 rounded-[4px] border-[2px] flex-shrink-0"
                      style={{ 
                        backgroundColor: achievement.unlocked ? '#c89b5c' : (isDarkMode ? 'rgba(208, 216, 191, 0.05)' : 'rgba(42, 45, 30, 0.03)'),
                        borderColor: '#c89b5c',
                        boxShadow: achievement.unlocked ? '2px 2px 0px 0px #2a2d1e' : 'none',
                      }}
                    >
                      <span 
                        className="font-['Cousine'] text-[14px] font-bold"
                        style={{ color: achievement.unlocked ? 'white' : '#c89b5c' }}
                      >
                        +{achievement.dungReward}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar (for locked achievements) */}
                  {!achievement.unlocked && achievement.progress !== undefined && (
                    <div className="mt-3">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-['Inter'] text-[10px]" style={{ color: colors.textMuted }}>
                          {achievement.requirement}
                        </span>
                        <span className="font-['Cousine'] text-[11px] font-bold" style={{ color: colors.text }}>
                          {achievement.progress}%
                        </span>
                      </div>
                      <div 
                        className="h-2 rounded-full overflow-hidden"
                        style={{ 
                          backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.1)' : 'rgba(42, 45, 30, 0.08)' 
                        }}
                      >
                        <div 
                          className="h-full transition-all duration-300"
                          style={{ 
                            width: `${achievement.progress}%`,
                            backgroundColor: colors.accent,
                          }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Unlocked Date */}
                  {achievement.unlocked && achievement.unlockedDate && (
                    <div className="mt-2">
                      <span className="font-['Cousine'] text-[10px]" style={{ color: colors.textMuted }}>
                        Unlocked {achievement.unlockedDate}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}