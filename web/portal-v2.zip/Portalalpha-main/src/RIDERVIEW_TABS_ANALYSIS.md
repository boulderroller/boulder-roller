# 🪲 RIDERVIEW TABS ANALYSIS
**Date:** December 9, 2024

---

## 🔍 INVESTIGATION: "Activities Tab on RiderView is Wonky"

### **Current State:**

Looking at `/pages/RiderView.tsx` - **THERE ARE NO TABS AT ALL** currently!

**What exists:**
```
┌──────────────────┬────────────────────────────────┐
│                  │                                │
│  GIANT BEETLE    │  Social Stats (3 cols)         │
│  🪲              │  - Followers/Following/Kudos   │
│                  │                                │
│  @username       │  Stats Grid (2x2)              │
│  Location        │  - Dung/Rides/Achievements/FTP │
│  Bio             │                                │
│  [Follow]        │  Recent Activities (List)      │
│  Member Since    │  - 3 most recent rides         │
│                  │                                │
└──────────────────┴────────────────────────────────┘
```

**What's missing:** 
- ❌ No tabs at all
- ❌ No tab navigation
- ❌ No way to switch between different views

---

## 💡 WHAT STRAVA DOES (Reference)

Strava's athlete profile has **tabs below the header**:

```
┌─────────────────────────────────────────────────┐
│  [Profile Photo]  @username                     │
│  Location • Joined 2024                         │
├─────────────────────────────────────────────────┤
│  [Overview] [Training] [Activity Feed]          │  ← TABS HERE
├─────────────────────────────────────────────────┤
│                                                 │
│  Content changes based on active tab            │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Tab Content:**

### **Overview Tab:**
- Recent activities (last 4-5)
- Stats summary
- Recent achievements
- Kudos received

### **Training Tab:**
- Training log calendar
- Weekly TSS chart
- Power curve
- Personal records

### **Activity Feed Tab:**
- Full chronological list of all activities
- Infinite scroll
- Filters by type (rides/runs)

---

## 🎯 PROPOSED IMPLEMENTATION FOR BOULDERROLLER

### **Layout Design:**

```
┌──────────────────┬─────────────────────────────────────┐
│                  │                                     │
│  GIANT BEETLE    │  [Overview] [Activities] [Training] │ ← ADD TABS
│  🪲              ├─────────────────────────────────────┤
│                  │                                     │
│  @username       │  TAB CONTENT AREA                   │
│  Location        │  (Changes based on active tab)      │
│  Bio             │                                     │
│  [Follow]        │                                     │
│                  │                                     │
│  Member Since    │                                     │
│                  │                                     │
└──────────────────┴─────────────────────────────────────┘
```

---

## 📱 TAB CONTENT BREAKDOWN

### **Tab 1: Overview** (Default)
**Shows:**
- Social stats (Followers/Following/Kudos) ← Already exists
- Stats grid (Dung/Rides/Achievements/FTP) ← Already exists
- Recent activities (3-5 activities) ← Already exists
- Recent achievements showcase

**This is basically what we have now!** Just need to wrap it in a tab.

---

### **Tab 2: Activities** (Full Activity Feed)
**Shows:**
- Complete chronological list of all rider's activities
- Filterable by type (All/Rides/Runs)
- Sortable (Recent/Distance/Dung)
- Paginated or infinite scroll
- Each activity card shows:
  - Name, date, type
  - Distance, elevation, duration
  - Dung earned
  - TSS
  - Click to view full activity detail

**Component Pattern:**
```tsx
// Similar to ActivityFeed but filtered to this rider
<div className="space-y-2">
  {activities.map(activity => (
    <ActivityCard 
      activity={activity}
      compact={true}
      onClick={() => navigate(`/activities/${activity.id}`)}
    />
  ))}
</div>
```

---

### **Tab 3: Training** (Data/Analytics)
**Shows:**
- Training calendar (last 12 weeks)
- Weekly TSS/Dung trends (chart)
- Power curve (best efforts 5s, 1m, 5m, 20m, 60m)
- Personal records table
- FTP history chart
- Training stress balance graph

**Mockup:**
```
┌─────────────────────────────────────────────┐
│  Last 12 Weeks                              │
│  ┌───────────────────────────────────────┐  │
│  │   TSS/DUNG CHART                      │  │
│  │   [Bar chart of weekly totals]        │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  Power Curve                                │
│  ┌───────────────────────────────────────┐  │
│  │   [Line graph showing peak power]     │  │
│  └───────────────────────────────────────┘  │
│                                             │
│  Personal Records                           │
│  • Longest Ride: 187 km                    │
│  • Most Elevation: 3,240 m                 │
│  • Highest TSS: 342                        │
│  • Most Dung/Ride: 428                     │
└─────────────────────────────────────────────┘
```

---

## 🛠️ IMPLEMENTATION PLAN

### **Step 1: Add Tab Navigation Component** (15 min)

Create `/components/profile/ProfileTabs.tsx`:

```tsx
type ProfileTab = 'overview' | 'activities' | 'training';

interface ProfileTabsProps {
  activeTab: ProfileTab;
  onTabChange: (tab: ProfileTab) => void;
}

export function ProfileTabs({ activeTab, onTabChange }: ProfileTabsProps) {
  return (
    <div className="flex gap-4 border-b">
      <TabButton 
        active={activeTab === 'overview'}
        onClick={() => onTabChange('overview')}
      >
        Overview
      </TabButton>
      <TabButton 
        active={activeTab === 'activities'}
        onClick={() => onTabChange('activities')}
      >
        Activities
      </TabButton>
      <TabButton 
        active={activeTab === 'training'}
        onClick={() => onTabChange('training')}
      >
        Training
      </TabButton>
    </div>
  );
}
```

**Tab Button Styling (Beetle-style):**
- Inactive: Just text, muted color
- Active: Bold text, underline (2px solid accent), brighter color
- Hover: Slight color change
- Click: Depress effect (like BeetleButton)

---

### **Step 2: Create Tab Content Components** (30 min)

**OverviewTab.tsx** (Easy - just move existing code):
```tsx
export function OverviewTab({ riderData }) {
  return (
    <div className="space-y-6">
      <SocialStats {...riderData} />
      <StatsGrid {...riderData} />
      <RecentActivities activities={riderData.recentActivities} />
    </div>
  );
}
```

**ActivitiesTab.tsx** (Medium - new component):
```tsx
export function ActivitiesTab({ riderId }) {
  const [filter, setFilter] = useState('all'); // all/rides/runs
  const [activities, setActivities] = useState(mockActivities);

  return (
    <div>
      {/* Filter Pills */}
      <div className="flex gap-2 mb-4">
        <FilterPill active={filter === 'all'} onClick={() => setFilter('all')}>All</FilterPill>
        <FilterPill active={filter === 'rides'} onClick={() => setFilter('rides')}>Rides</FilterPill>
        <FilterPill active={filter === 'runs'} onClick={() => setFilter('runs')}>Runs</FilterPill>
      </div>

      {/* Activity List */}
      <div className="space-y-2">
        {activities.map(activity => (
          <CompactActivityCard key={activity.id} activity={activity} />
        ))}
      </div>
    </div>
  );
}
```

**TrainingTab.tsx** (Complex - placeholder for now):
```tsx
export function TrainingTab({ riderId }) {
  return (
    <div className="space-y-6">
      {/* Coming soon placeholder */}
      <div className="rounded border border-dashed p-12 text-center">
        <div className="text-[48px] mb-2">📊</div>
        <p className="text-muted">Training analytics coming soon</p>
      </div>
    </div>
  );
}
```

---

### **Step 3: Update RiderView.tsx** (15 min)

```tsx
export default function RiderView() {
  const [activeTab, setActiveTab] = useState<ProfileTab>('overview');

  return (
    <div className="grid grid-cols-[280px,1fr] gap-6">
      {/* Left: Giant Beetle Card (unchanged) */}
      <BeetleProfileCard riderData={riderData} />

      {/* Right: Tabs + Content */}
      <div>
        {/* Tab Navigation */}
        <ProfileTabs 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
        />

        {/* Tab Content */}
        <div className="mt-6">
          {activeTab === 'overview' && <OverviewTab riderData={riderData} />}
          {activeTab === 'activities' && <ActivitiesTab riderId={riderData.id} />}
          {activeTab === 'training' && <TrainingTab riderId={riderData.id} />}
        </div>
      </div>
    </div>
  );
}
```

---

## 🎨 TAB DESIGN SPEC (Beetle-Style)

### **Visual Design:**

```
┌──────────────────────────────────────────────┐
│  Overview    Activities    Training          │ ← Tabs
│  ═════════   ─────────    ─────────          │ ← Active underline
└──────────────────────────────────────────────┘
```

**Inactive Tab:**
- Font: Inter 12px bold uppercase tracking-wide
- Color: textMuted
- Padding: py-3 px-4
- Border-bottom: 2px transparent
- Hover: Color brightens slightly

**Active Tab:**
- Font: Same
- Color: text (full brightness)
- Border-bottom: 2px solid accent (#8ba87a)
- Background: None (stays quiet)

**Click Animation:**
- Transform: translateY(1px) (subtle depress)
- Duration: 100ms

---

## 📊 MOCK DATA FOR ACTIVITIES TAB

```tsx
const mockAllActivities = [
  {
    id: '1',
    name: 'Morning Alpine Grind',
    type: 'Ride',
    date: 'Dec 7, 2024',
    distance: '87 km',
    elevation: '2,140 m',
    duration: '3:24:15',
    tss: 342,
    dungEarned: 342,
  },
  {
    id: '2',
    name: 'Flagstaff Repeats',
    type: 'Ride',
    date: 'Dec 6, 2024',
    distance: '42 km',
    elevation: '1,280 m',
    duration: '1:52:30',
    tss: 198,
    dungEarned: 198,
  },
  // ... more activities (20-30 for scrolling)
];
```

---

## ✅ CHECKLIST FOR IMPLEMENTATION

### **Phase 1: Basic Tabs (1 hour)**
- [ ] Create ProfileTabs component with tab navigation
- [ ] Create OverviewTab component (move existing code)
- [ ] Create ActivitiesTab component (basic list)
- [ ] Create TrainingTab placeholder
- [ ] Update RiderView to use tab system
- [ ] Add tab state management
- [ ] Style tabs with Beetle aesthetic

### **Phase 2: Activities Tab Polish (30 min)**
- [ ] Add filter pills (All/Rides/Runs)
- [ ] Create CompactActivityCard component
- [ ] Add hover states
- [ ] Add click navigation to activity detail
- [ ] Generate more mock data (20+ activities)

### **Phase 3: Training Tab (Future)**
- [ ] Design analytics layout
- [ ] Add TSS/Dung chart component
- [ ] Add power curve component
- [ ] Add personal records table
- [ ] Wire up to backend when ready

---

## 🎯 RECOMMENDATION

**Option A: Full Implementation (1.5 hours)**
- Build all 3 tabs with proper content
- Activities tab has filter + full list
- Training tab is polished placeholder
- Ready for backend integration

**Option B: Quick Fix (30 min)**
- Just add tab navigation structure
- Overview tab = current content
- Activities + Training tabs = "Coming soon" placeholders
- Proves the pattern works, fill in later

**Option C: Tabs + Activities Only (1 hour)**
- Build tab navigation
- Overview tab = current content
- Activities tab = full implementation
- Training tab = placeholder
- **This is my recommendation** - gives you the most value

---

## 🤔 QUESTIONS FOR YOU

1. **Is this what you meant?** - Adding tabs to the RiderView profile page?
2. **Which tab content is priority?** - Overview exists, Activities is useful, Training can wait?
3. **How many activities to show?** - 10? 20? 50? Infinite scroll?
4. **Filter options?** - By type (Rides/Runs)? By date range? By dung earned?

---

## 🚀 READY TO IMPLEMENT

Once you confirm this is what you want, I can build:

**30 min version:**
- Tab navigation component
- Move existing content to Overview tab
- Placeholder tabs for Activities/Training

**1 hour version:**
- Tab navigation component
- Overview tab (current content)
- Activities tab with full activity list + filters
- Training tab placeholder

**Your call!** 🪲
