# BoulderRoller - Next 4 Steps Strategic Brainstorm 🪲

**Current State:** Core interaction system is rock-solid. Time to expand intelligently.

---

## 1️⃣ ActivityFeed Cards - The Big UX Decision

### **The Question:**
What happens when you click an activity card?

### **Current State:**
```tsx
<div className="p-4 hover:bg-[#f3f5ed]/30 transition-colors">
  {/* Activity content */}
</div>
```
- ❌ Has hover state but isn't clickable (mystery meat!)
- ❌ Dung badges are static
- ❌ No indication of what's interactive

---

### **Option A: Full Card Clickable → Activity Detail Modal**

**What it looks like:**
```tsx
<BeetleCard 
  interactive 
  onClick={() => openActivityDetail(activity.id)}
  className="p-4"
>
  <ActivityContent {...activity} />
</BeetleCard>
```

**Opens a modal showing:**
- Full ride details (distance, elevation, power curve)
- Map of route
- Dung breakdown (how it was earned)
- Comments from other riders
- Kudos/reactions

**Pros:**
- ✅ Clear affordance (whole card responds)
- ✅ Matches Strava's interaction model
- ✅ Gives activities depth (not just feed items)
- ✅ Natural place for social features

**Cons:**
- ❌ Requires building activity detail modal
- ❌ More complex (needs routing or state management)
- ❌ Could be overkill if activities are simple

**Strava analogy:**
```
Activity feed card → click → Full activity page
(This is expected behavior for cycling apps)
```

---

### **Option B: Dung Badges Clickable → Dung Explainer Popover**

**What it looks like:**
```tsx
<div className="p-4">
  <ActivityContent />
  <button
    onClick={() => showDungBreakdown(activity)}
    className="beetle-button-sm"
    style={{ ... }}
  >
    <span>+45</span>
  </button>
</div>
```

**Shows popover:**
```
🪲 Dung Earned: +45

Breakdown:
• Distance: +20 (45km)
• TSS: +15 (120 TSS)
• Consistency: +10 (daily streak)

[View Full Details →]
```

**Pros:**
- ✅ Dung is central to your app (makes sense to explain it)
- ✅ Educational (teaches the reward system)
- ✅ Lighter weight than full modal
- ✅ Keep cards static (cleaner feed)

**Cons:**
- ❌ Dung badges are small (harder to click)
- ❌ Less obvious affordance
- ❌ Doesn't open up social features

**Torrent tracker analogy:**
```
Upload badge → click → Points breakdown
(Shows how you earned reputation)
```

---

### **Option C: Action Menu on Hover → Contextual Actions**

**What it looks like:**
```tsx
<div 
  className="p-4 group relative"
  onMouseEnter={() => setShowActions(true)}
>
  <ActivityContent />
  
  {/* Actions appear on hover (top-right) */}
  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100">
    <button>💬</button>  {/* Comment */}
    <button>🔥</button>  {/* Kudos */}
    <button>📊</button>  {/* Stats */}
  </div>
</div>
```

**Pros:**
- ✅ Strava-like (they do this with actions)
- ✅ Keeps card simple until hover
- ✅ Multiple action paths
- ✅ Pro-user friendly

**Cons:**
- ❌ Not touch-friendly (no hover on mobile)
- ❌ Hidden affordance (users might miss it)
- ❌ More UI complexity

---

### **Option D: Static Cards + Dedicated "View Details" Link**

**What it looks like:**
```tsx
<div className="p-4">
  <ActivityContent />
  <button className="text-sm underline hover:no-underline">
    View ride details →
  </button>
</div>
```

**Pros:**
- ✅ Explicit affordance (no mystery)
- ✅ Keeps feed scannable
- ✅ Simple to implement

**Cons:**
- ❌ Less immersive
- ❌ Extra click (friction)
- ❌ Feels old-school (less modern)

---

### **🎯 MY RECOMMENDATION: Option A (Full Card Clickable)**

**Why:**
1. **Matches user expectations** - In cycling apps, you click activities to see details
2. **Natural depth** - Feed → Detail is a proven pattern
3. **Enables social** - Detail modal becomes hub for comments/kudos
4. **Our physics shine** - BeetleCard lift on hover is perfect for this

**Implementation Path:**
```tsx
// Phase 1: Make cards clickable (opens stub modal)
<BeetleCard interactive onClick={() => setSelectedActivity(activity)}>

// Phase 2: Build detail modal (simple version)
<ActivityDetailModal activity={selectedActivity} onClose={...} />

// Phase 3: Add features (map, comments, etc.)
```

**Quick Win:** Even a simple modal with "Activity Details - Coming Soon" would make the interaction feel complete.

---

## 2️⃣ Auth Components - First-Run Experience

### **Components to Audit:**

#### **SetupModal.tsx**
```tsx
// Current state (from our earlier read):
- Username input (needs BeetleInput)
- FTP input (needs BeetleInput)
- Weight input (needs BeetleInput)
- Rider type selector (grid of cards - already interactive)
- Submit button (needs BeetleButton)
```

#### **InviteModal.tsx** (need to read, but likely):
```tsx
- Invite code input (needs BeetleInput)
- Submit button (needs BeetleButton)
- "Don't have a code?" link
```

---

### **Why This Matters:**

**First impressions are EVERYTHING.** The auth flow is:
```
InviteGate → InviteModal → WalletConnect → SetupModal → App
     ✅           ?              ✅             ?          ✅
  (beetle!)   (needs fix)   (polished!)   (needs fix)  (done!)
```

**We have 2 gaps in an otherwise perfect onboarding flow.**

---

### **🎯 MY RECOMMENDATION: Do This NEXT**

**Why:**
1. **Highest impact** - Everyone sees this once
2. **Fast fix** - Just swap components (30 min)
3. **Completeness** - Makes entire auth flow consistent
4. **Sets the bar** - If onboarding is polished, users expect polish everywhere

**Exact Changes:**
```tsx
// SetupModal.tsx
import { BeetleInput } from '@/components/ui/beetle-input';
import { BeetleButton } from '@/components/ui/beetle-button';

<BeetleInput value={username} onChange={...} />
<BeetleInput type="number" value={ftp} onChange={...} />
<BeetleInput type="number" value={weight} onChange={...} />
<BeetleButton variant="primary" onClick={handleSubmit}>
  Complete Setup
</BeetleButton>
```

---

## 3️⃣ Loading States - Async Action Feedback

### **Current Gap:**

Most actions are instant (local state changes), but these WILL be async:
- Wallet connection (already has countdown timer ✅)
- Form submissions (SetupModal, ProfileEditPanel)
- Data exports
- Account deletion
- Future: Activity uploads, comments, etc.

---

### **The Problem:**

**Without loading states:**
```
User clicks "Save Changes"
  ↓
??? (nothing happens for 2 seconds) ???
  ↓
Form closes (did it work? 🤷)
```

**With loading states:**
```
User clicks "Save Changes"
  ↓
Button shows spinner: "Saving..."
  ↓
Success toast: "Profile updated ✓"
  ↓
Form closes
```

---

### **Patterns We Need:**

#### **Pattern 1: Button Loading State** ✅ (Already built!)
```tsx
<BeetleButton isLoading>
  Save Changes
</BeetleButton>
```
Shows spinner + "Loading..." text, disabled.

---

#### **Pattern 2: Toast Notifications** (Need to add)
```tsx
import { toast } from 'sonner@2.0.3';

// Success
toast.success('Profile updated successfully');

// Error
toast.error('Failed to save changes');

// Info
toast.info('Exporting data...');
```

**Where to use:**
- ✅ Form submissions
- ✅ Delete actions
- ✅ Export operations
- ✅ Network errors

---

#### **Pattern 3: Skeleton Screens** (Future)
For loading entire sections:
```tsx
<div className="animate-pulse">
  <div className="h-20 bg-gray-200 rounded mb-4" />
  <div className="h-20 bg-gray-200 rounded mb-4" />
</div>
```

**Where to use:**
- Loading activity feed on first load
- Loading profile data
- Loading leaderboards

---

### **🎯 MY RECOMMENDATION: Add Toast System**

**Why:**
1. **Quick win** - Sonner is already in your imports
2. **High impact** - Makes every action feel complete
3. **Complements buttons** - Button shows "doing", toast shows "done"
4. **Professional** - Every modern app has toasts

**Implementation:**
```tsx
// 1. Add Toaster to App.tsx
import { Toaster } from 'sonner@2.0.3';

<ThemeProvider>
  <Toaster position="top-right" />
  <YourApp />
</ThemeProvider>

// 2. Use in handlers
const handleSave = async () => {
  try {
    setIsLoading(true);
    await saveProfile(data);
    toast.success('Profile updated! 🪲');
    onClose();
  } catch (err) {
    toast.error('Failed to save changes');
  } finally {
    setIsLoading(false);
  }
};
```

**Style to match beetle aesthetic:**
```tsx
<Toaster 
  position="top-right"
  toastOptions={{
    style: {
      border: '3px solid #2a2d1e',
      borderRadius: '10px',
      boxShadow: '4px 4px 0px 0px #2a2d1e',
      fontFamily: 'Inter',
    },
  }}
/>
```

---

## 4️⃣ More Variants - Design System Expansion

### **What We Have:**
- ✅ BeetleButton (primary, secondary, danger, ghost)
- ✅ BeetleInput (text, number, error variant)
- ✅ BeetleCard (interactive, static, flat)

### **What We Could Add:**

---

#### **A. Icon Buttons**
For compact actions:
```tsx
<BeetleIconButton 
  icon={<TrashIcon />} 
  onClick={handleDelete}
  variant="danger"
  size="sm"
/>
```

**Use cases:**
- Delete buttons in lists
- Close buttons (X)
- Action menus
- Toolbar buttons

**Should we build this?**
- ⚠️ **Medium priority** - Can use BeetleButton with just icon
- ✅ **Nice to have** - Cleaner API for common pattern
- 🤔 **Question:** Do we have enough use cases yet?

---

#### **B. Button Groups**
For toggle states (like Units selector):
```tsx
<BeetleButtonGroup value={units} onChange={setUnits}>
  <BeetleButton value="metric">Metric</BeetleButton>
  <BeetleButton value="imperial">Imperial</BeetleButton>
</BeetleButtonGroup>
```

**Use cases:**
- Units toggle (already exists, could refactor)
- View switchers (list/grid)
- Filter options

**Should we build this?**
- ✅ **High value** - Used in ProfileEditPanel already
- ✅ **Reusable** - Will use again for filters
- ✅ **Clean abstraction** - DRYs up toggle logic

---

#### **C. Outline Buttons**
Variant with no fill, just border:
```tsx
<BeetleButton variant="outline">
  Secondary Action
</BeetleButton>
```

**Visual:**
```
┌─────────────┐
│   OUTLINE   │  ← transparent bg
└─────────────┘
   ▓▓▓▓▓▓        ← same shadow physics
```

**Should we build this?**
- ⚠️ **Low priority** - Secondary variant covers most cases
- 🤔 **Aesthetic question:** Does outline fit beetle brutalist theme?
- ❓ **User need:** Do we have a use case for this?

---

#### **D. Small Inline Actions**
Tiny buttons for inline actions:
```tsx
<BeetleLinkButton onClick={handleEdit}>
  Edit
</BeetleLinkButton>
```

Looks like a link but behaves like a button (for a11y):
```tsx
<button className="text-sm underline hover:no-underline hover:text-accent">
  Edit
</button>
```

**Should we build this?**
- ✅ **High value** - Common pattern in dense UIs
- ✅ **Accessibility win** - Proper button semantics
- ✅ **Matches vibe** - Torrent tracker style (lots of inline actions)

---

#### **E. Select Dropdown Component**
Right now selects use native `<select>`:
```tsx
<select className="...">
  <option>Sprinter</option>
  <option>Climber</option>
</select>
```

Could build custom BeetleSelect:
```tsx
<BeetleSelect 
  value={riderType} 
  onChange={setRiderType}
  options={RIDER_TYPES}
/>
```

**Should we build this?**
- ⚠️ **Low priority** - Native select works fine
- ❌ **Complex** - Custom dropdowns are hard (positioning, keyboard nav)
- 🤔 **Return on investment:** Not worth it unless we need custom styling

---

### **🎯 MY RECOMMENDATION: Button Groups + Link Buttons**

**Why:**
1. **Button Groups** - Already used in ProfileEditPanel, DRY it up
2. **Link Buttons** - High value for dense UIs, easy to build
3. **Skip the rest** - Current variants cover 90% of use cases

**Implementation Order:**
```
1. BeetleButtonGroup (2 hours)
   → Refactor Units toggle in ProfileEditPanel
   → Add to component library

2. BeetleLinkButton (1 hour)
   → Use in ActivityFeed ("View details →")
   → Use in ProfileDropdown menus

3. STOP - Evaluate if we need more
```

---

## 🎯 OVERALL STRATEGIC RECOMMENDATION

### **Phase 1: Polish Onboarding (This Week)**
```
✅ Day 1: Fix SetupModal + InviteModal (use Beetle components)
✅ Day 2: Add toast system (feedback for all async actions)
✅ Day 3: Build button groups + link buttons
```

**Result:** Entire user journey from invite → app is polished.

---

### **Phase 2: Deepen Main App (Next Week)**
```
🎯 Day 1: Make ActivityFeed cards clickable (Option A)
🎯 Day 2: Build simple ActivityDetailModal stub
🎯 Day 3: Add real data to detail modal
```

**Result:** Main app has depth, not just a feed.

---

### **Phase 3: Future Enhancements (Later)**
```
🔮 Skeleton loading states
🔮 Icon button variants
🔮 Advanced toast customization
🔮 Custom select dropdowns (if needed)
```

---

## 🤔 QUESTIONS FOR YOU:

### **1. ActivityFeed Strategy:**
Which interaction model speaks to you?
- **A:** Full card clickable → detail modal (my rec)
- **B:** Dung badges clickable → popover
- **C:** Action menu on hover
- **D:** Static cards + explicit link

### **2. Priority Order:**
What feels most urgent?
- **Option 1:** Fix auth flow first (SetupModal, InviteModal)
- **Option 2:** Make ActivityFeed interactive first
- **Option 3:** Add toast system first (feedback for everything)

### **3. Component Expansion:**
Which new components do we actually need?
- Button groups? (I vote yes)
- Link buttons? (I vote yes)
- Icon buttons? (maybe later)
- Outline variant? (not sure we need it)

### **4. Scope:**
How deep do we go?
- **Sprint mode:** Fix auth + add toasts (2 days of work)
- **Medium mode:** Above + ActivityFeed clickable (4 days)
- **Deep mode:** Full activity detail modal with real features (2 weeks)

---

## 💭 MY GUT TAKE:

If I were building this, I'd do:

**This session:**
1. ✅ Fix SetupModal + InviteModal (30 min)
2. ✅ Add toast system (30 min)

**Next session:**
3. Make ActivityFeed cards clickable with stub modal (1 hour)
4. Build BeetleButtonGroup component (1 hour)

**Outcome:** Entire app feels alive, onboarding is perfect, and we have a clear path to depth (activity details).

---

**What's your gut saying? Which path excites you most?** 🪲
