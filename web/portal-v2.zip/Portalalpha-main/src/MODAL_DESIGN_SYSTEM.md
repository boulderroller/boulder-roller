# Modal Design System - Data Hierarchy Applied
**Systematic application of our 13-page northstar doc to all 10 remaining modals**

---

## 📐 STANDARDIZED MODAL STRUCTURE

### Base Modal Anatomy
```
┌─────────────────────────────────────┐ 2px border (beetle aesthetic)
│ [HEADER: Title + Close]             │ 
├─────────────────────────────────────┤ 1px divider (optional)
│                                     │
│ [CONTENT AREA]                      │ 
│   - Data panels (quiet 1px borders) │
│   - Hero stats (42px monospace)     │
│   - Form inputs (BeetleInput)       │
│                                     │
├─────────────────────────────────────┤ 1px divider
│ [ACTIONS: Buttons]                  │ 6px padding
└─────────────────────────────────────┘
```

### Standardized Container Specs
```tsx
// Backdrop
className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
onClick={onClose}

// Modal Container
className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50"

// Modal Card (BEETLE AESTHETIC - Heavy borders for modals)
className="rounded-[8px] border-[2px] p-8"
style={{
  backgroundColor: colors.bg,
  borderColor: colors.border,
  boxShadow: `4px 4px 0px 0px ${colors.border}` // Beetle shadow
}}
```

### Size Standards
- **Small:** `w-[400px]` - Confirmations, simple actions
- **Medium:** `w-[520px]` - Standard forms, settings
- **Large:** `w-[680px]` - Complex forms, uploads
- **XLarge:** `w-[840px]` - Search results, wide layouts

### Typography Hierarchy in Modals
```
Modal Title:        20px Inter Black
Section Headers:    12px Inter Bold Uppercase (tracking-wide)
Hero Numbers:       42px Cousine Bold (for emphasis)
Secondary Numbers:  28px Cousine Bold
Form Labels:        11px Inter (muted)
Body Text:          13px Inter
Helper Text:        11px Inter (muted)
```

---

## 🎯 MODAL-BY-MODAL DESIGN PRESCRIPTION

---

### 1. UploadActivityModal 🔴
**Size:** Large (`w-[680px]`)  
**Complexity:** High

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Outer modal: 2px border + shadow (standard modal container)
- Drag-drop zone: 1px dashed border `rgba(42, 45, 30, 0.1)` - QUIET
- Form fields: BeetleInput with minimal borders
- Helper text: 11px muted

**DATA SHOUTS:**
- Calculated dung preview: **42px Cousine** with GLOW
  ```tsx
  <div className="font-['Cousine'] text-[42px] font-bold leading-none">
    +247
  </div>
  <div className="font-['Inter'] text-[11px] uppercase tracking-wide" 
       style={{ color: colors.textMuted }}>
    Dung Earned
  </div>
  ```
- TSS calculation: 28px Cousine (secondary emphasis)
- Distance/Duration: 22px Cousine

**Layout Structure:**
```
[Upload Zone - Dashed border, quiet]
  Drop .fit/.tcx file or click to browse
  
[Divider - 1px subtle]

[Manual Entry Form - If no file]
  Distance  [input] km
  Duration  [input] 
  TSS       [input]
  
[Divider - 1px subtle]

[PREVIEW PANEL - 1px border terminal aesthetic]
  ┌──────────────────────┐
  │ Dung Earned: +247    │ ← 42px GLOW
  │ TSS: 145             │ ← 28px
  │ Distance: 85.3 km    │ ← 22px
  └──────────────────────┘
  
[Actions]
  [Upload & Save] [Cancel]
```

**Key Principles:**
- ✅ Dung preview is LOOT - gets visual weight
- ✅ Form container is quiet (1px border)
- ✅ Numbers 3x larger than labels
- ✅ Tight coupling: labels kiss data (mb-0.5)

---

### 2. SearchModal (Cmd+K) 🔴
**Size:** XLarge (`w-[840px]`)  
**Complexity:** Medium

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Search input: BeetleInput with subtle border
- Result rows: NO borders, hover background tint only
- Category pills: 1px border when inactive

**DATA SHOUTS:**
- Result titles: 14px Inter Bold
- Dung earned: 16px Cousine with amber color
- Segment distances: 14px Cousine

**Layout Structure:**
```
[Search Input - Large]
  🔍 Search activities, segments, riders...
  
[Category Pills - Filter]
  [All] [Activities] [Segments] [Riders]
  
[Results List - NO CONTAINER BORDERS]
  
  🚴 Morning Climb • Dec 5
     85.3 km • 247 dung        ← Dung in amber
     
  ⛰️ Hawk Hill Segment
     2.3 km • 450m gain
     
  🪲 climber_420 • Beetle #4207
     Tier S • 38,456 total dung
```

**Hover Behavior:**
```tsx
const hoverBg = isDarkMode 
  ? 'rgba(139, 168, 122, 0.08)' 
  : 'rgba(139, 168, 122, 0.04)';
```

**Key Principles:**
- ✅ Results are quiet (no borders, just hover tint)
- ✅ Dung gets amber emphasis
- ✅ Keyboard navigation (arrow keys)
- ✅ Tight spacing: 3px between results

---

### 3. EditProfileModal 🔴
**Size:** Medium (`w-[520px]`)  
**Complexity:** Medium

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Form container: Clean white/dark bg, no inner borders
- Input fields: BeetleInput (standard)
- Avatar preview: 1px border, subtle

**DATA SHOUTS:**
- Current FTP: 28px Cousine (show before edit)
- Beetle number: 22px Cousine (immutable, emphasized)

**Layout Structure:**
```
[Profile Header]
  🪲 Beetle #4207 [S]          ← 22px Cousine

[Form Fields]
  Username     [climber_420]
  FTP          [285] W         ← Show old: 28px, new input
  Weight       [72] kg
  Bio          [textarea]
  
[Current Stats Panel - 1px border terminal]
  ┌──────────────────────┐
  │ Current FTP: 285 W   │ ← 28px Cousine
  │ Updated: Dec 1       │ ← 11px muted
  └──────────────────────┘
  
[Actions]
  [Save Changes] [Cancel]
```

**Key Principles:**
- ✅ Current values shown in Cousine (data emphasis)
- ✅ Labels are small (11px), inputs are larger (14px)
- ✅ Stats panel uses terminal aesthetic

---

### 4. AchievementUnlockModal 🟡
**Size:** Medium (`w-[520px]`)  
**Complexity:** Low (Presentation)

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Modal container: Standard 2px border + shadow
- Progress bar container: 1px border

**DATA SHOUTS - LOOT EMPHASIS:**
- Achievement emoji: **96px** (MASSIVE)
- Dung reward: **42px Cousine** with GLOW + text-shadow
- Achievement name: 24px Inter Black

**Layout Structure:**
```
[Achievement Hero]
  
        🏆                    ← 96px emoji
        
  Century Rider              ← 24px Inter Black
  Complete 100km in one ride ← 13px Inter muted
  
[Dung Panel - LOOT EMPHASIS]
  ┌──────────────────────┐
  │      +500            │ ← 42px Cousine GLOW
  │   DUNG EARNED        │ ← 11px uppercase
  └──────────────────────┘
  
[Progress to Next]
  Next: Double Century (200km)
  [████████░░] 124/200 km    ← Subtle progress
  
[Actions]
  [Share Achievement] [Close]
```

**Glow Effects:**
```tsx
// Dung number
style={{
  color: '#c89b5c',
  textShadow: '0 0 20px rgba(200, 155, 92, 0.4)',
  filter: 'drop-shadow(0 0 8px rgba(200, 155, 92, 0.3))'
}}

// Container glow
boxShadow: `4px 4px 0px 0px ${colors.border}, 0 0 24px rgba(200, 155, 92, 0.2)`
```

**Key Principles:**
- ✅ This is LOOT - maximum visual emphasis
- ✅ Dung number dominates the modal
- ✅ Achievement emoji is hero element
- ✅ Container gets subtle glow (rare exception)

---

### 5. StoreConfirmModal 🟡
**Size:** Small (`w-[400px]`)  
**Complexity:** Low

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Modal container: Standard
- Balance display: 1px border terminal

**DATA SHOUTS:**
- Price: 28px Cousine in amber
- Balance remaining: 22px Cousine
- Item emoji: 64px

**Layout Structure:**
```
[Item Preview]
  
      💎                     ← 64px emoji
      
  Diamond Saddle             ← 18px Inter Bold
  +5% comfort on climbs      ← 12px muted
  
[Price Panel]
  ┌──────────────────────┐
  │ Price: 3,200         │ ← 28px Cousine amber
  │                      │
  │ Your Balance: 2,847  │ ← 22px Cousine
  │ After: -353 ⚠️       │ ← 22px red (insufficient)
  └──────────────────────┘
  
[Actions]
  [Confirm Purchase] [Cancel]
```

**State Handling:**
- Insufficient funds: Red text + disabled button
- Sufficient funds: Amber glow on price

**Key Principles:**
- ✅ Price is hero number (28px)
- ✅ Balance math shown clearly
- ✅ Warning state uses color + icon

---

### 6. InviteFriendModal 🟡
**Size:** Medium (`w-[520px]`)  
**Complexity:** Medium

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Invite code box: 1px border, quiet container
- Copy button: BeetleButton (standard)

**DATA SHOUTS:**
- Invite code: 32px Cousine monospace (copiable)
- Invites remaining: 22px Cousine

**Layout Structure:**
```
[Invite Stats]
  ┌──────────────────────┐
  │ Invites Remaining: 3 │ ← 22px Cousine
  │ Friends Invited: 12  │ ← 16px Cousine
  └──────────────────────┘

[Your Invite Code - Emphasis]
  ┌──────────────────────┐
  │  BEETLE-4207-XK9P   │ ← 32px Cousine monospace
  └──────────────────────┘
  [Copy to Clipboard] 📋
  
[Or Share Link]
  https://boulderroller.xyz/invite/...
  [Copy Link]
  
[Invited Friends List]
  climber_420 • Joined Dec 1
  rider_999 • Pending
```

**Key Principles:**
- ✅ Invite code is hero element (32px monospace)
- ✅ Copy interaction emphasized
- ✅ Stats use terminal aesthetic

---

### 7. SegmentDetailModal 🟡
**Size:** Large (`w-[680px]`)  
**Complexity:** Medium

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Modal container: Standard
- Leaderboard rows: NO borders, hover tint only
- Map preview: 1px border, quiet

**DATA SHOUTS:**
- Your PR: 28px Cousine (if exists)
- Crown holder time: 24px Cousine with gold glow
- Dung reward: 22px Cousine amber

**Layout Structure:**
```
[Segment Header]
  ⛰️ Hawk Hill Climb
  2.3 km • 450m gain • 12% avg
  
[Your Performance - If exists]
  ┌──────────────────────┐
  │ Your PR: 8:42        │ ← 28px Cousine
  │ Rank: #12 / 847      │ ← 16px
  │ Earned: 145 dung     │ ← 16px amber
  └──────────────────────┘
  
[Crown Holder - GOLD EMPHASIS]
  👑 Current KOM
  climber_420 • 7:15      ← 24px Cousine GOLD GLOW
  Crown Reward: 450 dung  ← 18px amber
  
[Leaderboard - Top 5]
  1. climber_420  7:15    ← 16px Cousine
  2. rider_999    7:28
  3. beetle_king  7:31
  ...
  
[Actions]
  [⭐ Star Segment] [View Full Leaderboard]
```

**Crown Glow:**
```tsx
style={{
  color: '#d4af37', // Gold
  textShadow: '0 0 16px rgba(212, 175, 55, 0.4)'
}}
```

**Key Principles:**
- ✅ Crown holder gets GOLD emphasis (loot)
- ✅ Your PR is hero stat (28px)
- ✅ Leaderboard is quiet (no borders)
- ✅ Dung rewards in amber

---

### 8. DeleteConfirmModal 🟢
**Size:** Small (`w-[400px]`)  
**Complexity:** Low

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Modal container: Standard (but red accent)
- Activity preview: 1px border, muted

**DATA SHOUTS:**
- Warning text: 14px Inter Bold red
- Activity title: 16px Inter Bold

**Layout Structure:**
```
[Warning Icon]
  ⚠️  Delete Activity?    ← 20px Inter Black
  
[Activity Preview - Muted]
  ┌──────────────────────┐
  │ Morning Climb        │ ← 16px Inter Bold
  │ Dec 5 • 85.3 km      │ ← 13px muted
  │ 247 dung earned      │ ← 13px muted
  └──────────────────────┘
  
[Warning Text]
  This action cannot be undone.
  You will lose 247 dung.     ← 14px red
  
[Actions]
  [Delete] [Cancel]
```

**Delete Button:**
```tsx
<BeetleButton 
  variant="danger"  // Red border/shadow
  onClick={handleDelete}
>
  Delete Activity
</BeetleButton>
```

**Key Principles:**
- ✅ Warning is emphasized (red)
- ✅ Activity preview is muted (de-emphasized)
- ✅ Destructive action clearly labeled

---

### 9. ShareModal 🟢
**Size:** Medium (`w-[520px]`)  
**Complexity:** Medium

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Social buttons: 1px border, quiet
- Preview card: 1px border terminal

**DATA SHOUTS:**
- Activity stats in preview: 22px Cousine
- Dung earned: Amber emphasis

**Layout Structure:**
```
[Activity Preview Card - Terminal]
  ┌──────────────────────────────┐
  │ 🚴 Morning Climb             │
  │ Dec 5, 2025                  │
  │                              │
  │ 85.3 km • 2:15:00 • 450m    │ ← 18px Cousine
  │ Earned 247 dung 🪲          │ ← 18px amber
  └──────────────────────────────┘
  
[Share Options]
  [Share to Twitter/X] 𝕏
  [Copy Link to Clipboard] 🔗
  [Download Image] 📸
  
[Link Preview]
  https://boulderroller.xyz/activities/abc123
  [Copy]
```

**Key Principles:**
- ✅ Preview card uses terminal aesthetic
- ✅ Stats emphasized with Cousine
- ✅ Share buttons are quiet (1px border)

---

### 10. SettingsModal 🟢
**Size:** Large (`w-[680px]`)  
**Complexity:** High

#### Data Hierarchy Application:

**CHROME WHISPERS:**
- Tab navigation: 1px border bottom
- Setting rows: NO borders, dividers only
- Input fields: BeetleInput

**DATA SHOUTS:**
- Current FTP: 28px Cousine (in stats section)
- Data totals: 22px Cousine (rides count, total dung)

**Layout Structure:**
```
[Tab Navigation]
  [Profile] [Units] [Privacy] [Data] [Account]
  
[Settings Content - No inner containers]
  
  Display Name
  [climber_420]
  
  ─────────────────────  ← 1px divider
  
  Units
  ○ Metric (km, kg)
  ○ Imperial (mi, lb)
  
  ─────────────────────
  
  Theme
  ○ Light
  ○ Dark
  ○ Auto
  
[DATA TAB - Terminal Aesthetic]
  ┌──────────────────────┐
  │ Total Activities: 287│ ← 22px Cousine
  │ Total Distance: 8,456│ ← 22px Cousine
  │ Total Dung: 38,456  │ ← 22px Cousine amber
  └──────────────────────┘
  
  [Export All Data (.json)]
  
[DANGER ZONE]
  ⚠️ Delete Account
  This action cannot be undone.
  [Delete My Account]     ← Red beetle button
```

**Key Principles:**
- ✅ Settings are minimalist (no heavy containers)
- ✅ Dividers separate concepts
- ✅ Data tab shows stats in Cousine
- ✅ Danger zone uses red accent

---

## 🎨 MODAL DESIGN TOKENS

### Shared Styles (all modals)

```tsx
// Backdrop (standardized)
const backdropStyles = {
  className: "fixed inset-0 bg-black/40 backdrop-blur-sm z-40",
  onClick: onClose
};

// Modal container (standardized)
const modalContainerStyles = {
  className: "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50"
};

// Modal card (beetle aesthetic)
const modalCardStyles = {
  className: "rounded-[8px] border-[2px] p-8",
  style: {
    backgroundColor: colors.bg,
    borderColor: colors.border,
    boxShadow: `4px 4px 0px 0px ${colors.border}`
  }
};

// Header (standardized)
const headerStyles = {
  title: "font-['Inter'] font-black text-[20px]",
  close: "text-[20px] cursor-pointer transition-colors"
};

// Divider (standardized)
const dividerStyles = {
  className: "h-[1px]",
  style: {
    backgroundColor: isDarkMode 
      ? 'rgba(208, 216, 191, 0.15)' 
      : 'rgba(42, 45, 30, 0.1)'
  }
};

// Terminal panel (quiet data container)
const terminalPanelStyles = {
  className: "rounded-[6px] border-[1px] p-5",
  style: {
    backgroundColor: isDarkMode ? '#2a2d1e' : colors.bg,
    borderColor: isDarkMode 
      ? 'rgba(208, 216, 191, 0.15)' 
      : 'rgba(42, 45, 30, 0.1)'
  }
};

// Loot emphasis (dung, achievements)
const lootEmphasisStyles = {
  className: "font-['Cousine'] text-[42px] font-bold leading-none",
  style: {
    color: '#c89b5c',
    textShadow: '0 0 20px rgba(200, 155, 92, 0.4)'
  }
};
```

---

## ✅ MODAL DESIGN CHECKLIST

For every modal we build:

**Data Hierarchy:**
- [ ] Numbers are 3x larger than labels (minimum)
- [ ] Labels kiss data (mb-0.5, max 4px gap)
- [ ] Monospace (Cousine) for all numbers
- [ ] Sans-serif (Inter) for labels/text
- [ ] Related items grouped (3-4px gap)
- [ ] Concepts separated by dividers

**Container Quietness:**
- [ ] Modal uses 2px border + shadow (standard)
- [ ] Inner panels use 1px border (quiet)
- [ ] NO shadows on data containers
- [ ] 6-8px border radius (subtle, not playful)

**Loot Emphasis:**
- [ ] Dung gets amber color + glow
- [ ] Achievements get visual weight
- [ ] Interactive elements preserve beetle physics

**Accessibility:**
- [ ] Escape key closes modal
- [ ] Click backdrop to close
- [ ] Focus trap (keyboard nav only within modal)
- [ ] First input auto-focused

**Consistency:**
- [ ] Uses BeetleButton for actions
- [ ] Uses BeetleInput for forms
- [ ] Uses theme colors via useTheme()
- [ ] Follows size standards (400/520/680/840)

---

## 🚀 IMPLEMENTATION PRIORITY

**Week 1: Core UX**
1. UploadActivityModal (most complex, most needed)
2. DeleteConfirmModal (simple, prevents mistakes)
3. SearchModal (modern UX expectation)

**Week 2: Engagement**
4. AchievementUnlockModal (dopamine factory)
5. StoreConfirmModal (enable store)
6. SegmentDetailModal (complete map)

**Week 3: Social & Polish**
7. InviteFriendModal (growth mechanism)
8. ShareModal (social proof)
9. EditProfileModal (user control)
10. SettingsModal (comprehensive prefs)

---

**Remember: Modals are INTERRUPTIONS. Make them worth it.**
- Get in fast (animation <200ms)
- Show data clearly (hierarchy applied)
- Get out fast (Escape, backdrop click, clear actions)
- Don't waste the user's attention

**Every modal should feel like:**
- A terminal command executed successfully
- A loot drop animation
- A precise tool, not decoration

---

**This is our modal bible. Every modal follows these rules. No exceptions.** 🪲
