# 🏗️ BoulderRoller - Production Architecture Deep Dive

**Stack:** Supabase + DigitalOcean Droplet (FastAPI + Celery + Redis)

**Mission:** Build Strava-level data pipeline with beetle-quality interactions

---

## 🗺️ THE FULL DATA PIPELINE

### **1. File Upload Flow**

```
User Clicks "Upload Activity"
         ↓
[Frontend: React]
         ↓
Select .fit/.gpx file (input type="file")
         ↓
Read file as base64 (FileReader API)
         ↓
POST /api/activities/upload
{
  file: "base64EncodedData...",
  fileName: "morning-ride.fit",
  fileType: "fit"
}
         ↓
[Backend: FastAPI]
         ↓
Validate file (size, format, auth)
         ↓
Store raw file in Supabase Storage
         ↓
Create activity record (status: "processing")
         ↓
Queue Celery task: process_activity(activity_id)
         ↓
Return to frontend:
{
  activityId: "uuid-123",
  status: "processing",
  estimatedTime: 30 // seconds
}
         ↓
[Frontend: React]
         ↓
Redirect to /activities/uuid-123
         ↓
Show processing UI (progress bar)
         ↓
Poll /api/activities/uuid-123/status every 2s
         ↓
[Backend: Celery Worker]
         ↓
Parse .fit file (extract GPS, power, HR, cadence)
         ↓
Calculate analytics:
  - TSS (Training Stress Score)
  - NP (Normalized Power)
  - IF (Intensity Factor)
  - VI (Variability Index)
  - Power zones distribution
  - Best efforts (20s, 1min, 5min, 20min, 60min)
  - Elevation gain/loss
  - Route polyline (for map)
         ↓
Match segments (geospatial query)
         ↓
Calculate dung earned
         ↓
Update activity record (status: "complete")
         ↓
Publish to Supabase Realtime channel
         ↓
[Frontend: React]
         ↓
Receive realtime event
         ↓
Hydrate RideView with full data
         ↓
Show toast: "Activity processed! 🪲 +45 dung"
```

---

## 🏛️ BACKEND ARCHITECTURE

### **FastAPI Structure**

```
/droplet
├── /app
│   ├── main.py                 # FastAPI app entry
│   ├── /api
│   │   ├── /routes
│   │   │   ├── activities.py   # Activity CRUD
│   │   │   ├── segments.py     # Segment queries
│   │   │   ├── users.py        # Profile management
│   │   │   ├── social.py       # Kudos, comments
│   │   │   └── leaderboard.py  # Rankings
│   │   ├── /models
│   │   │   ├── activity.py     # Pydantic models
│   │   │   ├── user.py
│   │   │   └── segment.py
│   │   └── /services
│   │       ├── fit_parser.py   # Parse .fit files
│   │       ├── analytics.py    # Calculate metrics
│   │       ├── segments.py     # Match segments
│   │       └── dung.py         # Gamification logic
│   ├── /tasks
│   │   ├── celery_app.py       # Celery config
│   │   └── process_activity.py # Async task
│   ├── /db
│   │   ├── supabase.py         # Supabase client
│   │   └── queries.py          # SQL queries
│   └── /cache
│       └── redis.py            # Redis client
├── requirements.txt
└── docker-compose.yml          # Local dev setup
```

---

### **Supabase Schema**

```sql
-- Users table (handled by Supabase Auth)
-- Extended with profile data
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  username TEXT UNIQUE NOT NULL,
  wallet_address TEXT UNIQUE,
  ftp INTEGER,
  weight_kg DECIMAL,
  rider_type TEXT,
  dung_total INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Activities table
CREATE TABLE activities (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id),
  title TEXT NOT NULL,
  description TEXT,
  activity_type TEXT DEFAULT 'ride', -- ride, run, swim
  started_at TIMESTAMP NOT NULL,
  
  -- Raw data storage
  file_url TEXT, -- Supabase Storage URL
  file_type TEXT, -- fit, gpx, tcx
  
  -- Processing status
  status TEXT DEFAULT 'processing', -- processing, complete, failed
  processing_progress INTEGER DEFAULT 0, -- 0-100
  
  -- Basic stats
  distance_km DECIMAL,
  duration_seconds INTEGER,
  elevation_gain_m INTEGER,
  avg_speed_kmh DECIMAL,
  avg_power_w INTEGER,
  normalized_power_w INTEGER,
  avg_hr_bpm INTEGER,
  avg_cadence_rpm INTEGER,
  
  -- Advanced metrics
  tss INTEGER, -- Training Stress Score
  intensity_factor DECIMAL,
  variability_index DECIMAL,
  work_kj INTEGER,
  
  -- Gamification
  dung_earned INTEGER DEFAULT 0,
  
  -- Social
  kudos_count INTEGER DEFAULT 0,
  comment_count INTEGER DEFAULT 0,
  
  -- Privacy
  privacy TEXT DEFAULT 'public', -- public, followers, private
  is_commute BOOLEAN DEFAULT FALSE,
  is_trainer BOOLEAN DEFAULT FALSE,
  
  -- Route data
  polyline TEXT, -- Encoded polyline for map
  start_latlng POINT,
  end_latlng POINT,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Time series data (separate table for performance)
CREATE TABLE activity_streams (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_id UUID REFERENCES activities(id) ON DELETE CASCADE,
  
  -- Arrays of data points (PostreSQL array type)
  time_seconds INTEGER[],      -- [0, 1, 2, 3, ...]
  distance_meters DECIMAL[],   -- [0, 5.2, 10.8, ...]
  altitude_meters DECIMAL[],   -- [100, 102, 105, ...]
  power_watts INTEGER[],       -- [245, 250, 248, ...]
  heart_rate_bpm INTEGER[],    -- [142, 145, 148, ...]
  cadence_rpm INTEGER[],       -- [85, 87, 86, ...]
  speed_kmh DECIMAL[],         -- [25.3, 26.1, 25.8, ...]
  latlng POINT[],              -- [(lat,lng), (lat,lng), ...]
  
  created_at TIMESTAMP DEFAULT NOW()
);

-- Power zones distribution
CREATE TABLE activity_zones (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_id UUID REFERENCES activities(id) ON DELETE CASCADE,
  
  zone_type TEXT NOT NULL, -- power, heart_rate
  z1_seconds INTEGER DEFAULT 0,
  z2_seconds INTEGER DEFAULT 0,
  z3_seconds INTEGER DEFAULT 0,
  z4_seconds INTEGER DEFAULT 0,
  z5_seconds INTEGER DEFAULT 0,
  z6_seconds INTEGER DEFAULT 0,
  
  created_at TIMESTAMP DEFAULT NOW()
);

-- Best efforts
CREATE TABLE activity_efforts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_id UUID REFERENCES activities(id) ON DELETE CASCADE,
  
  duration_seconds INTEGER NOT NULL, -- 20, 60, 300, 1200, 3600
  avg_power_w INTEGER,
  max_power_w INTEGER,
  normalized_power_w INTEGER,
  avg_hr_bpm INTEGER,
  start_time_offset INTEGER, -- Seconds into the activity
  is_pr BOOLEAN DEFAULT FALSE, -- Personal record?
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  UNIQUE(activity_id, duration_seconds)
);

-- Segments (like Strava segments)
CREATE TABLE segments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL, -- hawk-hill
  
  -- Geometry
  polyline TEXT NOT NULL, -- Encoded route
  start_latlng POINT NOT NULL,
  end_latlng POINT NOT NULL,
  distance_km DECIMAL NOT NULL,
  elevation_gain_m INTEGER,
  avg_grade_pct DECIMAL,
  
  -- Metadata
  activity_type TEXT DEFAULT 'ride',
  surface_type TEXT, -- road, gravel, trail
  hazards TEXT[], -- ['steep', 'traffic', 'gravel']
  
  -- Stats
  total_efforts INTEGER DEFAULT 0,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Segment efforts (user attempts on segments)
CREATE TABLE segment_efforts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  segment_id UUID REFERENCES segments(id),
  activity_id UUID REFERENCES activities(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  
  -- Performance
  elapsed_time_seconds INTEGER NOT NULL,
  avg_power_w INTEGER,
  avg_hr_bpm INTEGER,
  
  -- Ranking (calculated)
  rank INTEGER, -- Overall rank
  rank_total INTEGER, -- Total attempts
  is_kom BOOLEAN DEFAULT FALSE, -- King/Queen of Mountain
  is_pr BOOLEAN DEFAULT FALSE, -- Personal record
  
  started_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Kudos
CREATE TABLE kudos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_id UUID REFERENCES activities(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  
  created_at TIMESTAMP DEFAULT NOW(),
  
  UNIQUE(activity_id, user_id) -- One kudos per user per activity
);

-- Comments
CREATE TABLE comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  activity_id UUID REFERENCES activities(id) ON DELETE CASCADE,
  user_id UUID REFERENCES profiles(id),
  parent_comment_id UUID REFERENCES comments(id), -- For replies
  
  text TEXT NOT NULL,
  
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Dung transactions (on-chain later)
CREATE TABLE dung_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES profiles(id),
  
  amount INTEGER NOT NULL, -- Can be negative (spent dung)
  reason TEXT NOT NULL, -- 'activity_completed', 'achievement_unlocked', etc.
  related_activity_id UUID REFERENCES activities(id),
  
  -- Solana blockchain data (future)
  transaction_signature TEXT, -- Solana tx signature
  block_height INTEGER,
  
  created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_activities_user_id ON activities(user_id);
CREATE INDEX idx_activities_started_at ON activities(started_at DESC);
CREATE INDEX idx_segment_efforts_segment_id ON segment_efforts(segment_id);
CREATE INDEX idx_segment_efforts_elapsed_time ON segment_efforts(segment_id, elapsed_time_seconds ASC);
CREATE INDEX idx_kudos_activity_id ON kudos(activity_id);
CREATE INDEX idx_comments_activity_id ON comments(activity_id);

-- Full-text search on activities
CREATE INDEX idx_activities_search ON activities USING GIN(to_tsvector('english', title || ' ' || COALESCE(description, '')));
```

---

## 🔄 CELERY TASK PIPELINE

### **Task: `process_activity(activity_id)`**

```python
# /app/tasks/process_activity.py

from celery import Task
from app.services.fit_parser import parse_fit_file
from app.services.analytics import calculate_metrics
from app.services.segments import match_segments
from app.services.dung import calculate_dung
from app.db.supabase import supabase
from app.cache.redis import redis_client

class ProcessActivityTask(Task):
    def on_failure(self, exc, task_id, args, kwargs, einfo):
        """Handle task failure"""
        activity_id = args[0]
        supabase.table('activities').update({
            'status': 'failed',
            'error_message': str(exc)
        }).eq('id', activity_id).execute()

@celery_app.task(bind=True, base=ProcessActivityTask)
def process_activity(self, activity_id: str):
    """
    Process uploaded activity file
    
    Steps:
    1. Download file from Supabase Storage
    2. Parse file (extract streams)
    3. Calculate metrics (TSS, NP, IF, etc.)
    4. Match segments (geospatial query)
    5. Calculate dung earned
    6. Update database
    7. Publish realtime event
    """
    
    # Update progress: 0%
    self.update_state(state='PROGRESS', meta={'progress': 0})
    supabase.table('activities').update({
        'processing_progress': 0
    }).eq('id', activity_id).execute()
    
    # 1. Download file
    activity = supabase.table('activities').select('*').eq('id', activity_id).single().execute()
    file_url = activity.data['file_url']
    file_type = activity.data['file_type']
    
    file_data = download_file(file_url)
    
    # Update progress: 10%
    self.update_state(state='PROGRESS', meta={'progress': 10})
    
    # 2. Parse file
    if file_type == 'fit':
        streams = parse_fit_file(file_data)
    elif file_type == 'gpx':
        streams = parse_gpx_file(file_data)
    else:
        raise ValueError(f"Unsupported file type: {file_type}")
    
    # Update progress: 30%
    self.update_state(state='PROGRESS', meta={'progress': 30})
    
    # 3. Calculate metrics
    metrics = calculate_metrics(
        streams=streams,
        user_ftp=activity.data['user_ftp'],  # From user profile
        user_weight=activity.data['user_weight']
    )
    
    # Update progress: 50%
    self.update_state(state='PROGRESS', meta={'progress': 50})
    
    # 4. Match segments
    matched_segments = match_segments(
        route_points=streams['latlng'],
        activity_id=activity_id
    )
    
    # Update progress: 70%
    self.update_state(state='PROGRESS', meta={'progress': 70})
    
    # 5. Calculate dung
    dung_earned = calculate_dung(
        distance_km=metrics['distance_km'],
        tss=metrics['tss'],
        elevation_gain=metrics['elevation_gain_m'],
        segments=matched_segments
    )
    
    # Update progress: 80%
    self.update_state(state='PROGRESS', meta={'progress': 80})
    
    # 6. Update database
    # Main activity record
    supabase.table('activities').update({
        'status': 'complete',
        'processing_progress': 100,
        'distance_km': metrics['distance_km'],
        'duration_seconds': metrics['duration_seconds'],
        'elevation_gain_m': metrics['elevation_gain_m'],
        'avg_power_w': metrics['avg_power_w'],
        'normalized_power_w': metrics['normalized_power_w'],
        'tss': metrics['tss'],
        'intensity_factor': metrics['intensity_factor'],
        'variability_index': metrics['variability_index'],
        'dung_earned': dung_earned,
        'polyline': metrics['polyline'],
        'updated_at': 'NOW()'
    }).eq('id', activity_id).execute()
    
    # Streams (time series data)
    supabase.table('activity_streams').insert({
        'activity_id': activity_id,
        'time_seconds': streams['time'],
        'distance_meters': streams['distance'],
        'altitude_meters': streams['altitude'],
        'power_watts': streams['power'],
        'heart_rate_bpm': streams['heart_rate'],
        'cadence_rpm': streams['cadence'],
        'speed_kmh': streams['speed'],
        'latlng': streams['latlng']
    }).execute()
    
    # Zones
    supabase.table('activity_zones').insert({
        'activity_id': activity_id,
        'zone_type': 'power',
        'z1_seconds': metrics['power_zones']['z1'],
        'z2_seconds': metrics['power_zones']['z2'],
        'z3_seconds': metrics['power_zones']['z3'],
        'z4_seconds': metrics['power_zones']['z4'],
        'z5_seconds': metrics['power_zones']['z5']
    }).execute()
    
    # Best efforts
    for duration, effort in metrics['best_efforts'].items():
        supabase.table('activity_efforts').insert({
            'activity_id': activity_id,
            'duration_seconds': duration,
            'avg_power_w': effort['avg_power'],
            'max_power_w': effort['max_power'],
            'start_time_offset': effort['start_offset'],
            'is_pr': effort['is_pr']
        }).execute()
    
    # Segment efforts
    for segment in matched_segments:
        supabase.table('segment_efforts').insert({
            'segment_id': segment['id'],
            'activity_id': activity_id,
            'user_id': activity.data['user_id'],
            'elapsed_time_seconds': segment['elapsed_time'],
            'avg_power_w': segment['avg_power'],
            'rank': segment['rank'],
            'rank_total': segment['rank_total'],
            'is_kom': segment['is_kom'],
            'is_pr': segment['is_pr']
        }).execute()
    
    # Dung transaction
    supabase.table('dung_transactions').insert({
        'user_id': activity.data['user_id'],
        'amount': dung_earned,
        'reason': 'activity_completed',
        'related_activity_id': activity_id
    }).execute()
    
    # Update user's total dung
    supabase.rpc('increment_user_dung', {
        'user_id': activity.data['user_id'],
        'amount': dung_earned
    }).execute()
    
    # Update progress: 90%
    self.update_state(state='PROGRESS', meta={'progress': 90})
    
    # 7. Cache hot data in Redis
    redis_client.setex(
        f"activity:{activity_id}",
        3600,  # 1 hour TTL
        json.dumps(metrics)
    )
    
    # 8. Publish realtime event (Supabase Realtime)
    supabase.rpc('publish_activity_complete', {
        'activity_id': activity_id,
        'user_id': activity.data['user_id'],
        'dung_earned': dung_earned
    }).execute()
    
    # Update progress: 100%
    self.update_state(state='PROGRESS', meta={'progress': 100})
    
    return {
        'activity_id': activity_id,
        'status': 'complete',
        'dung_earned': dung_earned,
        'segments_matched': len(matched_segments)
    }
```

---

## 📦 REDIS CACHING STRATEGY

### **What Goes in Redis:**

```python
# Cache keys pattern: resource:id:subresource

# 1. Hot activity data (1 hour TTL)
redis_client.setex(
    f"activity:{activity_id}",
    3600,
    json.dumps(full_activity_data)
)

# 2. User profiles (10 minutes TTL)
redis_client.setex(
    f"user:{user_id}:profile",
    600,
    json.dumps(profile_data)
)

# 3. Segment leaderboards (5 minutes TTL)
redis_client.setex(
    f"segment:{segment_id}:leaderboard",
    300,
    json.dumps(leaderboard_data)
)

# 4. Activity feed (30 seconds TTL - very hot!)
redis_client.setex(
    f"feed:global",
    30,
    json.dumps(feed_activities)
)

# 5. Processing tasks (track progress)
redis_client.setex(
    f"task:{task_id}:progress",
    300,
    json.dumps({'progress': 50, 'status': 'processing'})
)

# 6. Rate limiting (kudos, comments)
redis_client.setex(
    f"ratelimit:{user_id}:kudos",
    60,  # 1 minute window
    "10"  # Max 10 kudos per minute
)
```

### **Cache Invalidation:**

```python
# When activity is updated/deleted
def invalidate_activity_cache(activity_id: str):
    redis_client.delete(f"activity:{activity_id}")
    redis_client.delete(f"feed:global")
    redis_client.delete(f"feed:user:{user_id}")

# When user gives kudos
def invalidate_kudos_cache(activity_id: str):
    redis_client.delete(f"activity:{activity_id}:kudos")
    redis_client.hincrby(f"activity:{activity_id}", "kudos_count", 1)

# Pub/Sub pattern for realtime invalidation
redis_client.publish("cache:invalidate", json.dumps({
    'type': 'activity',
    'id': activity_id
}))
```

---

## 🔌 FASTAPI ENDPOINTS

### **Activity Routes**

```python
# /app/api/routes/activities.py

from fastapi import APIRouter, UploadFile, File, Depends
from app.tasks.process_activity import process_activity

router = APIRouter(prefix="/api/activities", tags=["activities"])

@router.post("/upload")
async def upload_activity(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """
    Upload activity file (.fit, .gpx, .tcx)
    
    Returns:
        - activity_id: UUID
        - status: "processing"
        - task_id: Celery task ID (for progress tracking)
    """
    # Validate file
    if file.content_type not in ['application/octet-stream', 'application/gpx+xml']:
        raise HTTPException(400, "Invalid file type")
    
    # Read file
    file_data = await file.read()
    file_b64 = base64.b64encode(file_data).decode()
    
    # Store in Supabase Storage
    file_path = f"{current_user.id}/{uuid.uuid4()}.{file.filename.split('.')[-1]}"
    storage_response = supabase.storage.from_('activities').upload(
        path=file_path,
        file=file_data
    )
    file_url = supabase.storage.from_('activities').get_public_url(file_path)
    
    # Create activity record
    activity = supabase.table('activities').insert({
        'user_id': current_user.id,
        'title': f"{file.filename}",  # Will be updated after processing
        'file_url': file_url,
        'file_type': file.filename.split('.')[-1],
        'status': 'processing'
    }).execute()
    
    activity_id = activity.data[0]['id']
    
    # Queue Celery task
    task = process_activity.delay(activity_id)
    
    return {
        'activity_id': activity_id,
        'status': 'processing',
        'task_id': task.id,
        'estimated_time': 30  # seconds
    }

@router.get("/{activity_id}")
async def get_activity(
    activity_id: str,
    current_user: User = Depends(get_current_user)
):
    """
    Get full activity data
    
    Caching strategy:
    1. Check Redis (hot cache)
    2. Query Supabase (cold data)
    3. Store in Redis for next request
    """
    # Check cache first
    cached = redis_client.get(f"activity:{activity_id}")
    if cached:
        return json.loads(cached)
    
    # Query database
    activity = supabase.table('activities').select('*').eq('id', activity_id).single().execute()
    
    # Check privacy
    if activity.data['privacy'] == 'private' and activity.data['user_id'] != current_user.id:
        raise HTTPException(403, "Access denied")
    
    # Get related data
    streams = supabase.table('activity_streams').select('*').eq('activity_id', activity_id).single().execute()
    zones = supabase.table('activity_zones').select('*').eq('activity_id', activity_id).execute()
    efforts = supabase.table('activity_efforts').select('*').eq('activity_id', activity_id).execute()
    segments = supabase.table('segment_efforts').select('*, segments(*)').eq('activity_id', activity_id).execute()
    
    # Combine data
    full_data = {
        **activity.data,
        'streams': streams.data,
        'zones': zones.data,
        'efforts': efforts.data,
        'segments': segments.data
    }
    
    # Cache for 1 hour
    redis_client.setex(
        f"activity:{activity_id}",
        3600,
        json.dumps(full_data)
    )
    
    return full_data

@router.get("/{activity_id}/status")
async def get_activity_status(activity_id: str):
    """
    Poll this endpoint during processing
    Returns progress: 0-100
    """
    activity = supabase.table('activities').select('status, processing_progress').eq('id', activity_id).single().execute()
    
    return {
        'status': activity.data['status'],
        'progress': activity.data['processing_progress']
    }

@router.patch("/{activity_id}")
async def update_activity(
    activity_id: str,
    updates: ActivityUpdate,
    current_user: User = Depends(get_current_user)
):
    """
    Edit activity (title, description, privacy, etc.)
    """
    # Verify ownership
    activity = supabase.table('activities').select('user_id').eq('id', activity_id).single().execute()
    if activity.data['user_id'] != current_user.id:
        raise HTTPException(403, "Not your activity")
    
    # Update
    updated = supabase.table('activities').update(updates.dict(exclude_unset=True)).eq('id', activity_id).execute()
    
    # Invalidate cache
    invalidate_activity_cache(activity_id)
    
    return updated.data[0]

@router.delete("/{activity_id}")
async def delete_activity(
    activity_id: str,
    current_user: User = Depends(get_current_user)
):
    """
    Delete activity (soft delete or hard delete?)
    """
    # Verify ownership
    activity = supabase.table('activities').select('user_id, dung_earned').eq('id', activity_id).single().execute()
    if activity.data['user_id'] != current_user.id:
        raise HTTPException(403, "Not your activity")
    
    # Deduct dung
    supabase.rpc('increment_user_dung', {
        'user_id': current_user.id,
        'amount': -activity.data['dung_earned']
    }).execute()
    
    # Delete (cascades to related tables)
    supabase.table('activities').delete().eq('id', activity_id).execute()
    
    # Invalidate cache
    invalidate_activity_cache(activity_id)
    
    return {'deleted': True}
```

### **Social Routes**

```python
# /app/api/routes/social.py

@router.post("/activities/{activity_id}/kudos")
async def give_kudos(
    activity_id: str,
    current_user: User = Depends(get_current_user)
):
    """
    Give kudos to activity
    
    - Idempotent (can't double-kudos)
    - Rate limited (10 per minute)
    - Realtime update via Supabase
    """
    # Rate limit check
    key = f"ratelimit:{current_user.id}:kudos"
    current = redis_client.get(key)
    if current and int(current) >= 10:
        raise HTTPException(429, "Too many kudos, slow down!")
    
    # Increment rate limit counter
    if current:
        redis_client.incr(key)
    else:
        redis_client.setex(key, 60, 1)
    
    # Insert kudos (UNIQUE constraint prevents duplicates)
    try:
        kudos = supabase.table('kudos').insert({
            'activity_id': activity_id,
            'user_id': current_user.id
        }).execute()
    except Exception as e:
        if 'duplicate key' in str(e):
            raise HTTPException(400, "Already gave kudos")
        raise
    
    # Increment activity kudos_count
    supabase.rpc('increment_activity_kudos', {
        'activity_id': activity_id
    }).execute()
    
    # Publish realtime event
    supabase.rpc('publish_kudos', {
        'activity_id': activity_id,
        'user_id': current_user.id
    }).execute()
    
    return {'success': True, 'kudos_id': kudos.data[0]['id']}

@router.delete("/activities/{activity_id}/kudos")
async def remove_kudos(
    activity_id: str,
    current_user: User = Depends(get_current_user)
):
    """Undo kudos"""
    supabase.table('kudos').delete().match({
        'activity_id': activity_id,
        'user_id': current_user.id
    }).execute()
    
    supabase.rpc('decrement_activity_kudos', {
        'activity_id': activity_id
    }).execute()
    
    return {'success': True}

@router.post("/activities/{activity_id}/comments")
async def add_comment(
    activity_id: str,
    comment: CommentCreate,
    current_user: User = Depends(get_current_user)
):
    """
    Add comment to activity
    Supports @mentions
    """
    # Insert comment
    new_comment = supabase.table('comments').insert({
        'activity_id': activity_id,
        'user_id': current_user.id,
        'text': comment.text,
        'parent_comment_id': comment.parent_id  # For replies
    }).execute()
    
    # Increment comment count
    supabase.rpc('increment_activity_comments', {
        'activity_id': activity_id
    }).execute()
    
    # Parse @mentions
    mentions = extract_mentions(comment.text)
    for username in mentions:
        # Send notification (future feature)
        pass
    
    # Publish realtime event
    supabase.rpc('publish_comment', {
        'activity_id': activity_id,
        'comment_id': new_comment.data[0]['id']
    }).execute()
    
    return new_comment.data[0]
```

---

## 🔄 SUPABASE REALTIME INTEGRATION

### **Frontend: Subscribe to Activity Updates**

```tsx
// /hooks/useActivityRealtime.ts

import { useEffect } from 'react';
import { supabase } from '../lib/supabase';

export function useActivityRealtime(activityId: string, onUpdate: (payload: any) => void) {
  useEffect(() => {
    // Subscribe to activity processing updates
    const channel = supabase
      .channel(`activity:${activityId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'activities',
          filter: `id=eq.${activityId}`
        },
        (payload) => {
          console.log('Activity updated:', payload);
          onUpdate(payload.new);
        }
      )
      .subscribe();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [activityId, onUpdate]);
}

// Usage in RideView component
function RideView() {
  const { activityId } = useParams();
  const [activity, setActivity] = useState(null);
  
  useActivityRealtime(activityId, (updated) => {
    setActivity(updated);
    
    if (updated.status === 'complete') {
      toast.success(`Activity processed! 🪲 +${updated.dung_earned} dung`);
    }
  });
  
  return <div>...</div>;
}
```

### **Backend: Publish Custom Events**

```sql
-- Supabase function to publish custom events
CREATE OR REPLACE FUNCTION publish_activity_complete(
  activity_id UUID,
  user_id UUID,
  dung_earned INTEGER
)
RETURNS void AS $$
BEGIN
  PERFORM pg_notify(
    'activity_complete',
    json_build_object(
      'activity_id', activity_id,
      'user_id', user_id,
      'dung_earned', dung_earned
    )::text
  );
END;
$$ LANGUAGE plpgsql;
```

---

## 🎨 FRONTEND DATA HYDRATION PATTERNS

### **Pattern 1: Progressive Loading (RideView)**

```tsx
// /pages/RideView.tsx

function RideView() {
  const { activityId } = useParams();
  const [loadingState, setLoadingState] = useState('initial');
  
  // Stage 1: Load basic data (fast)
  const { data: basicData, isLoading: basicLoading } = useQuery(
    ['activity', activityId, 'basic'],
    () => api.get(`/activities/${activityId}`),
    {
      staleTime: 60000, // Cache for 1 minute
      onSuccess: () => setLoadingState('basic-loaded')
    }
  );
  
  // Stage 2: Load streams (slower, only if processing complete)
  const { data: streamsData, isLoading: streamsLoading } = useQuery(
    ['activity', activityId, 'streams'],
    () => api.get(`/activities/${activityId}/streams`),
    {
      enabled: basicData?.status === 'complete' && loadingState === 'basic-loaded',
      onSuccess: () => setLoadingState('streams-loaded')
    }
  );
  
  // Stage 3: Load social data (lazy)
  const { data: socialData } = useQuery(
    ['activity', activityId, 'social'],
    () => api.get(`/activities/${activityId}/social`),
    {
      enabled: loadingState === 'streams-loaded'
    }
  );
  
  return (
    <div>
      {/* Show immediately (basic data) */}
      <ActivityHeader activity={basicData} />
      <StatsRow activity={basicData} />
      
      {/* Show with skeleton while loading streams */}
      {streamsLoading ? (
        <SkeletonChart />
      ) : (
        <PowerCurveChart data={streamsData} />
      )}
      
      {/* Lazy load social */}
      {socialData && (
        <CommentsSection comments={socialData.comments} />
      )}
    </div>
  );
}
```

### **Pattern 2: Optimistic Updates (Kudos)**

```tsx
// /components/KudosButton.tsx

function KudosButton({ activityId, initialKudosCount, hasGivenKudos }) {
  const queryClient = useQueryClient();
  
  const kudosMutation = useMutation(
    () => api.post(`/activities/${activityId}/kudos`),
    {
      // Optimistic update (instant UI)
      onMutate: async () => {
        // Cancel outgoing refetches
        await queryClient.cancelQueries(['activity', activityId]);
        
        // Snapshot previous value
        const previous = queryClient.getQueryData(['activity', activityId]);
        
        // Optimistically update
        queryClient.setQueryData(['activity', activityId], (old) => ({
          ...old,
          kudos_count: old.kudos_count + 1,
          has_given_kudos: true
        }));
        
        return { previous };
      },
      
      // On error, rollback
      onError: (err, variables, context) => {
        queryClient.setQueryData(['activity', activityId], context.previous);
        toast.error('Failed to give kudos');
      },
      
      // Always refetch after success/error
      onSettled: () => {
        queryClient.invalidateQueries(['activity', activityId]);
      }
    }
  );
  
  return (
    <BeetleButton
      onClick={() => kudosMutation.mutate()}
      variant={hasGivenKudos ? 'primary' : 'secondary'}
      disabled={kudosMutation.isLoading}
    >
      ❤️ {initialKudosCount} Kudos
    </BeetleButton>
  );
}
```

### **Pattern 3: Polling During Processing**

```tsx
// /pages/ActivityProcessing.tsx

function ActivityProcessing({ activityId }) {
  const [progress, setProgress] = useState(0);
  
  // Poll every 2 seconds
  const { data: status } = useQuery(
    ['activity', activityId, 'status'],
    () => api.get(`/activities/${activityId}/status`),
    {
      refetchInterval: (data) => {
        // Stop polling when complete
        if (data?.status === 'complete') return false;
        return 2000; // 2 seconds
      },
      onSuccess: (data) => {
        setProgress(data.progress);
        
        if (data.status === 'complete') {
          // Navigate to full view
          navigate(`/activities/${activityId}`);
        }
      }
    }
  );
  
  return (
    <div className="p-8">
      <h2>Processing Activity...</h2>
      <ProgressBar progress={progress} />
      <p>{Math.round(progress)}% complete</p>
    </div>
  );
}
```

---

## 🚀 SOLANA INTEGRATION POINTS

### **Where Blockchain Fits:**

1. **Dung Tokens (SPL Token)**
   - Each dung point = 1 token on Solana
   - Mint tokens when activity completes
   - Transfer tokens for rewards/challenges

2. **Activity NFTs (Optional)**
   - Major achievements → NFT
   - "First 100km ride" = special NFT
   - Tradeable on secondary markets

3. **Segment Leaderboard Stakes**
   - Bet dung tokens on segment attempts
   - Winner takes pool
   - Smart contract handles escrow

### **Implementation Pattern:**

```tsx
// When activity processing completes
async function mintDungTokens(userId: string, amount: number) {
  // 1. Get user's wallet address from Supabase
  const wallet = await getUserWallet(userId);
  
  // 2. Sign transaction on backend (using program authority)
  const tx = await solanaProgram.methods
    .mintDung(new BN(amount))
    .accounts({
      user: wallet,
      mint: dungMintAddress,
      authority: programAuthority
    })
    .rpc();
  
  // 3. Store transaction signature
  await supabase.table('dung_transactions').update({
    transaction_signature: tx,
    block_height: await getBlockHeight(tx)
  });
  
  return tx;
}
```

---

## 🎯 KEY TAKEAWAYS

### **Big Boy Patterns:**

1. **Async Processing**
   - Never block user on file upload
   - Celery handles heavy lifting
   - Frontend polls or uses WebSockets

2. **Caching Layers**
   - Redis for hot data (< 1 hour)
   - Supabase for cold data (persistent)
   - Browser cache for static assets

3. **Optimistic UI**
   - Kudos/comments appear instantly
   - Rollback on error
   - Toast shows confirmation

4. **Progressive Loading**
   - Load critical data first
   - Lazy load secondary data
   - Skeleton screens for perceived performance

5. **Realtime Updates**
   - Supabase Realtime for live updates
   - Redis Pub/Sub for backend events
   - WebSockets for critical path

### **Next Brainstorm Topics:**

- Segment matching algorithm (geospatial query optimization)
- .fit file parsing (libraries? custom parser?)
- Analytics calculations (TSS, NP, IF formulas)
- Rate limiting strategy (Redis vs Supabase)
- Error handling patterns (retry logic, circuit breakers)
- Monitoring & observability (Sentry, Datadog?)

---

**This is the production architecture.** Now let's keep brainstorming the next piece! 🔥
