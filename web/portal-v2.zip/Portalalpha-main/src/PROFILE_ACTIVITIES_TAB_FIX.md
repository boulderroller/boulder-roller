# 🪲 PROFILE ACTIVITIES TAB FIX
**Date:** December 9, 2024  
**Issue:** Activities tab on Profile page is "wonky and needs polish"

---

## 🔍 THE PROBLEM

**Current Code (Line 382-386 in Profile.tsx):**
```tsx
{activeTab === 'activities' && (
  <div>
    <ActivityFeed />
  </div>
)}
```

**What's Wrong:**

1. **ActivityFeed is a FULL-PAGE component** designed for the Dashboard
   - It has its own 3-column layout (left sidebar, center feed, right sidebar)
   - When nested inside Profile's tab content, it creates **layout conflicts**
   - The sidebars (Dung Bank, Leaderboard) don't belong on a profile page

2. **No context filtering**
   - ActivityFeed shows ALL activities from everyone
   - On a profile page, it should show ONLY that user's activities

3. **Wrong visual hierarchy**
   - Profile page already has header stats
   - ActivityFeed adds MORE sidebars, making it cluttered
   - Strava's profile activities tab is just a clean list

---

## 📊 WHAT STRAVA DOES (Reference)

**Strava's Profile → Activities Tab:**

```
┌──────────────────────────────────────────────┐
│  FILTERS: [All] [Rides] [Runs]               │ ← Simple filter pills
├──────────────────────────────────────────────┤
│  🚴 Morning Climb                 Dec 8      │
│  42.3 km • 1,247 m • 2:15:42                │
│  ──────────────────────────────────────────  │
│                                              │
│  🚴 Recovery Spin                 Dec 6      │
│  28.1 km • 342 m • 1:04:20                  │
│  ──────────────────────────────────────────  │
│                                              │
│  🚴 Hawk Hill Repeats             Dec 4      │
│  35.7 km • 982 m • 1:48:15                  │
│  ──────────────────────────────────────────  │
│                                              │
│  [Load More]                                 │
└──────────────────────────────────────────────┘
```

**Key Points:**
- ✅ Single column, clean list
- ✅ Simple activity cards
- ✅ Filter by type (optional)
- ✅ Sorted by date (newest first)
- ✅ Infinite scroll or "Load More"
- ❌ NO sidebars (Dung Bank, Leaderboard)
- ❌ NO community feed

---

## 🎯 PROPOSED SOLUTION

### **Option A: Quick Fix - Just Show Center Feed** (15 min)

Extract just the center column from ActivityFeed, hide sidebars.

**Pros:**
- Fast to implement
- Reuses existing components
- Works immediately

**Cons:**
- Still shows community activities (not filtered to user)
- Not ideal UX
- Hacky solution

---

### **Option B: Create Dedicated UserActivitiesList Component** (45 min) ⭐ RECOMMENDED

Build a proper user activities list component.

**New Component:** `/components/profile/UserActivitiesList.tsx`

```tsx
interface UserActivitiesListProps {
  userId: string; // Beetle number or ID
  limit?: number; // Optional limit for overview
}

export function UserActivitiesList({ userId, limit }: UserActivitiesListProps) {
  const [filter, setFilter] = useState<'all' | 'rides' | 'runs'>('all');
  const [activities, setActivities] = useState(mockUserActivities);

  const filteredActivities = activities
    .filter(a => filter === 'all' || a.type.toLowerCase() === filter)
    .slice(0, limit);

  return (
    <div className="space-y-4">
      {/* Filter Pills */}
      <div className="flex gap-2">
        <FilterPill 
          active={filter === 'all'} 
          onClick={() => setFilter('all')}
        >
          All
        </FilterPill>
        <FilterPill 
          active={filter === 'rides'} 
          onClick={() => setFilter('rides')}
        >
          🚴 Rides
        </FilterPill>
        <FilterPill 
          active={filter === 'runs'} 
          onClick={() => setFilter('runs')}
        >
          🏃 Runs
        </FilterPill>
      </div>

      {/* Activity List */}
      <div className="space-y-3">
        {filteredActivities.map(activity => (
          <UserActivityCard 
            key={activity.id} 
            activity={activity}
            onClick={() => navigate(`/activities/${activity.id}`)}
          />
        ))}
      </div>

      {/* Load More (if not limited) */}
      {!limit && (
        <div className="text-center pt-4">
          <BeetleButton variant="secondary">
            Load More Activities
          </BeetleButton>
        </div>
      )}
    </div>
  );
}
```

---

### **UserActivityCard Design:**

```tsx
function UserActivityCard({ activity, onClick }) {
  return (
    <div 
      className="p-4 rounded border cursor-pointer transition-all hover:shadow-sm"
      onClick={onClick}
    >
      {/* Header Row */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-[20px]">{activity.type === 'ride' ? '🚴' : '🏃'}</span>
          <h4 className="font-['Inter'] text-[14px] font-bold">
            {activity.name}
          </h4>
        </div>
        <div className="text-right">
          <div className="font-['Inter'] text-[11px] text-muted">
            {activity.date}
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="flex items-center gap-6 font-['Cousine'] text-[13px]">
        <div>
          <span className="font-bold">{activity.distance}</span>
          <span className="text-muted ml-1">km</span>
        </div>
        <div>
          <span className="font-bold">↗ {activity.elevation}</span>
          <span className="text-muted ml-1">m</span>
        </div>
        <div>
          <span className="font-bold">{activity.duration}</span>
        </div>
        <div>
          <span className="text-muted">TSS</span>
          <span className="font-bold ml-1">{activity.tss}</span>
        </div>
      </div>

      {/* Dung Badge (Right Side) */}
      <div className="absolute top-4 right-4">
        <div className="px-2.5 py-1 rounded border-2 bg-accent">
          <span className="font-['Cousine'] text-[11px] font-bold text-white">
            +{activity.dungEarned} CAL
          </span>
        </div>
      </div>
    </div>
  );
}
```

---

### **Visual Mockup:**

```
┌────────────────────────────────────────────────────┐
│  [All]  [🚴 Rides]  [🏃 Runs]                      │
├────────────────────────────────────────────────────┤
│  🚴 Morning Alpine Grind              Dec 7, 2024  │
│  87 km  •  ↗ 2,140 m  •  3:24:15  •  TSS 342   +342│
├────────────────────────────────────────────────────┤
│  🚴 Flagstaff Repeats                 Dec 6, 2024  │
│  42 km  •  ↗ 1,280 m  •  1:52:30  •  TSS 198   +198│
├────────────────────────────────────────────────────┤
│  🚴 Recovery Spin                     Dec 5, 2024  │
│  28 km  •  ↗ 420 m   •  0:58:20   •  TSS 76     +76│
├────────────────────────────────────────────────────┤
│                 [Load More Activities]             │
└────────────────────────────────────────────────────┘
```

---

## 🛠️ IMPLEMENTATION STEPS

### **Step 1: Create FilterPill Component** (10 min)

**File:** `/components/ui/filter-pill.tsx`

```tsx
interface FilterPillProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

export function FilterPill({ active, onClick, children }: FilterPillProps) {
  const { colors, isDarkMode } = useTheme();
  
  return (
    <button
      onClick={onClick}
      className="px-3 py-1.5 rounded-full border font-['Inter'] text-[11px] font-bold uppercase tracking-wide transition-all"
      style={{
        backgroundColor: active ? colors.accent : 'transparent',
        borderColor: active ? colors.accent : borderColor,
        color: active ? '#2a2d1e' : colors.textMuted,
      }}
    >
      {children}
    </button>
  );
}
```

---

### **Step 2: Create UserActivityCard Component** (15 min)

**File:** `/components/profile/UserActivityCard.tsx`

```tsx
interface UserActivityCardProps {
  activity: {
    id: string;
    type: 'ride' | 'run';
    name: string;
    date: string;
    distance: string;
    elevation: string;
    duration: string;
    tss: number;
    dungEarned: number;
  };
  onClick: () => void;
}

export function UserActivityCard({ activity, onClick }: UserActivityCardProps) {
  const { colors, isDarkMode } = useTheme();
  const borderColor = isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)';
  const cardBg = isDarkMode ? '#2a2d1e' : colors.bg;

  return (
    <div 
      className="p-4 rounded border cursor-pointer transition-all relative"
      style={{ 
        backgroundColor: cardBg, 
        borderColor,
      }}
      onClick={onClick}
      onMouseEnter={(e) => {
        e.currentTarget.style.borderColor = colors.accent;
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.borderColor = borderColor;
      }}
    >
      {/* Header Row */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <span className="text-[20px]">
            {activity.type === 'ride' ? '🚴' : '🏃'}
          </span>
          <h4 
            className="font-['Inter'] text-[14px] font-bold"
            style={{ color: colors.text }}
          >
            {activity.name}
          </h4>
        </div>
        <div className="text-right">
          <div 
            className="font-['Inter'] text-[11px]"
            style={{ color: colors.textMuted }}
          >
            {activity.date}
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div 
        className="flex items-center gap-6 font-['Cousine'] text-[13px]"
        style={{ color: colors.text }}
      >
        <div>
          <span className="font-bold">{activity.distance}</span>
          <span className="ml-1" style={{ color: colors.textMuted }}>km</span>
        </div>
        <div>
          <span className="font-bold">↗ {activity.elevation}</span>
          <span className="ml-1" style={{ color: colors.textMuted }}>m</span>
        </div>
        <div>
          <span className="font-bold">{activity.duration}</span>
        </div>
        <div>
          <span style={{ color: colors.textMuted }}>TSS</span>
          <span className="font-bold ml-1">{activity.tss}</span>
        </div>
      </div>

      {/* Dung Badge (Absolute Right) */}
      <div className="absolute top-4 right-4">
        <div 
          className="px-2.5 py-1 rounded border-2"
          style={{ 
            backgroundColor: colors.accent,
            borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
          }}
        >
          <span 
            className="font-['Cousine'] text-[11px] font-bold"
            style={{ color: 'white' }}
          >
            +{activity.dungEarned}
          </span>
        </div>
      </div>
    </div>
  );
}
```

---

### **Step 3: Create UserActivitiesList Component** (15 min)

**File:** `/components/profile/UserActivitiesList.tsx`

```tsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserActivityCard } from './UserActivityCard';
import { FilterPill } from '../ui/filter-pill';
import { BeetleButton } from '../ui/beetle-button';

// Mock data - will come from API
const mockUserActivities = [
  {
    id: '1',
    type: 'ride' as const,
    name: 'Morning Alpine Grind',
    date: 'Dec 7, 2024',
    distance: '87',
    elevation: '2,140',
    duration: '3:24:15',
    tss: 342,
    dungEarned: 342,
  },
  {
    id: '2',
    type: 'ride' as const,
    name: 'Flagstaff Repeats',
    date: 'Dec 6, 2024',
    distance: '42',
    elevation: '1,280',
    duration: '1:52:30',
    tss: 198,
    dungEarned: 198,
  },
  {
    id: '3',
    type: 'ride' as const,
    name: 'Recovery Spin',
    date: 'Dec 5, 2024',
    distance: '28',
    elevation: '420',
    duration: '0:58:20',
    tss: 76,
    dungEarned: 76,
  },
  // Add more mock activities...
];

interface UserActivitiesListProps {
  userId: string;
  limit?: number;
}

export function UserActivitiesList({ userId, limit }: UserActivitiesListProps) {
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'all' | 'rides' | 'runs'>('all');

  const filteredActivities = mockUserActivities
    .filter(a => filter === 'all' || a.type === filter.slice(0, -1))
    .slice(0, limit);

  return (
    <div className="space-y-4">
      {/* Filter Pills */}
      <div className="flex gap-2">
        <FilterPill active={filter === 'all'} onClick={() => setFilter('all')}>
          All
        </FilterPill>
        <FilterPill active={filter === 'rides'} onClick={() => setFilter('rides')}>
          🚴 Rides
        </FilterPill>
        <FilterPill active={filter === 'runs'} onClick={() => setFilter('runs')}>
          🏃 Runs
        </FilterPill>
      </div>

      {/* Activity List */}
      <div className="space-y-3">
        {filteredActivities.map(activity => (
          <UserActivityCard
            key={activity.id}
            activity={activity}
            onClick={() => navigate(`/activities/${activity.id}`)}
          />
        ))}
      </div>

      {/* Load More */}
      {!limit && mockUserActivities.length > filteredActivities.length && (
        <div className="text-center pt-4">
          <BeetleButton variant="secondary">
            Load More Activities
          </BeetleButton>
        </div>
      )}
    </div>
  );
}
```

---

### **Step 4: Update Profile.tsx** (5 min)

**Replace lines 382-386:**

```tsx
// OLD:
{activeTab === 'activities' && (
  <div>
    <ActivityFeed />
  </div>
)}

// NEW:
{activeTab === 'activities' && (
  <UserActivitiesList userId={profile.beetleNumber} />
)}
```

**Add import:**
```tsx
import { UserActivitiesList } from '../components/profile/UserActivitiesList';
```

---

## ✅ IMPLEMENTATION CHECKLIST

- [ ] Create FilterPill component
- [ ] Create UserActivityCard component
- [ ] Create UserActivitiesList component
- [ ] Generate more mock activity data (15-20 activities)
- [ ] Update Profile.tsx to use UserActivitiesList
- [ ] Test filter pills (All/Rides/Runs)
- [ ] Test click navigation to activity detail
- [ ] Test responsive behavior
- [ ] Add loading state (optional)
- [ ] Add empty state (optional)

---

## 🎨 DESIGN NOTES

**Beetle Aesthetic:**
- ✅ Clean, dense list (like Strava)
- ✅ 1px borders (quiet containers)
- ✅ Dung badges prominent (loud content)
- ✅ Hover state brightens border
- ✅ Click navigates to full activity

**Spacing:**
- Cards: 12px padding
- Gap between cards: 12px
- Filter pills: 8px gap

**Colors:**
- Active filter: Accent background, dark text
- Inactive filter: Transparent, muted text
- Hover: Border → accent color

---

## 🚀 ESTIMATED TIME

**Total: 45 minutes**
- FilterPill component: 10 min
- UserActivityCard: 15 min
- UserActivitiesList: 15 min
- Update Profile.tsx: 5 min

---

## 🎯 RESULT

**Before:** 
- Confusing nested full-page ActivityFeed
- Shows community activities (wrong context)
- Sidebars clutter the profile page

**After:**
- Clean, focused list of user's activities
- Filter by type
- Proper visual hierarchy
- Click to view full activity
- Exactly like Strava's profile activities tab

Ready to implement! 🪲
