# BoulderRoller Interaction Quick Reference 🪲

**One-page cheat sheet for building interactive components**

---

## 🎯 The Golden Rules

1. **Nothing feels dead** - Every interactive element responds
2. **<100ms feedback** - User sees reaction instantly
3. **Shadows depress** - Physical metaphor always active
4. **Focus is visible** - WCAG 2.1 compliant, no exceptions
5. **Semantic HTML** - `<button>` for actions, `<a>` for navigation

---

## 🔨 Component Library

### Buttons
```tsx
import { BeetleButton } from '@/components/ui/beetle-button';

// Primary action (theme accent color)
<BeetleButton variant="primary" onClick={handleClick}>
  Save Changes
</BeetleButton>

// Secondary action (neutral)
<BeetleButton variant="secondary" size="sm">
  Cancel
</BeetleButton>

// Danger action (red)
<BeetleButton variant="danger" onClick={handleDelete}>
  Delete Account
</BeetleButton>

// Loading state
<BeetleButton isLoading>
  Processing...
</BeetleButton>

// Disabled
<BeetleButton disabled>
  Unavailable
</BeetleButton>
```

**Variants:** `primary` | `secondary` | `danger` | `ghost`  
**Sizes:** `sm` | `md` | `lg`

---

### Inputs
```tsx
import { BeetleInput } from '@/components/ui/beetle-input';

// Text input
<BeetleInput
  type="text"
  value={username}
  onChange={(e) => setUsername(e.target.value)}
  placeholder="Enter username"
/>

// Number input
<BeetleInput
  type="number"
  value={ftp}
  onChange={(e) => setFtp(e.target.value)}
/>

// Error state
<BeetleInput
  error
  value={email}
  onChange={(e) => setEmail(e.target.value)}
/>
```

**Auto-includes:**
- ✅ Hover border darkening
- ✅ Focus ring (WCAG 2.1)
- ✅ Keyboard navigation support
- ✅ Error variant (red borders)

---

### Cards
```tsx
import { BeetleCard } from '@/components/ui/beetle-card';

// Clickable card
<BeetleCard interactive onClick={() => handleClick(activity.id)}>
  <ActivityItem {...activity} />
</BeetleCard>

// Static card
<BeetleCard>
  <StatsDisplay />
</BeetleCard>

// Flat variant (no shadow)
<BeetleCard variant="flat">
  <Content />
</BeetleCard>
```

---

## 📐 Shadow Physics Cheat Sheet

```
State      Shadow       Transform        Brightness
─────────────────────────────────────────────────────
RESTING    3px 3px      translateY(0)    1.0
HOVER      4px 4px      translateY(-1px) 1.05
ACTIVE     1px 1px      translateY(2px)  0.95
DISABLED   3px 3px      translateY(0)    1.0 (locked)
```

**Cards lift more:** `translateY(-2px)` on hover

---

## 🎨 Color Tokens for Interactions

```tsx
// Hover border (inputs)
'#8b6f47'

// Focus border (inputs)
'#c89b5c'

// Focus ring (20% opacity)
'rgba(200, 155, 92, 0.2)'

// Danger border
'#8b3a3a'

// Danger background
'#d45d5d'
```

---

## ⏱️ Timing Constants

```tsx
// Use these everywhere
transition: 'all 120ms ease-out'  // Standard
transition: 'all 100ms ease-out'  // Fast (micro-interactions)
transition: 'all 150ms ease-out'  // Slow (larger movements)

// NEVER use:
transition: 'all 300ms' // Too sluggish!
transition: 'all 50ms'  // Too jarring!
```

---

## ✅ Accessibility Checklist

Every interactive element MUST have:

```tsx
// 1. Semantic HTML
<button type="button" onClick={...}>  // ✅ Good
<div onClick={...}>                    // ❌ Bad

// 2. Focus state (automatic with our components)
button:focus-visible {
  outline: 2px solid #c89b5c;
  outline-offset: 2px;
}

// 3. Disabled state
<button disabled>                      // ✅ Good (cursor: not-allowed)
<button className="opacity-50">       // ❌ Bad (still clickable!)

// 4. Loading state
<BeetleButton isLoading>              // ✅ Good (disabled + spinner)
```

---

## 🔧 Custom Button (Manual Implementation)

If you need a one-off button outside the component:

```tsx
<button
  className="beetle-button ..."
  style={{
    boxShadow: `3px 3px 0px 0px ${colors.border}`,
    transform: 'translateY(0)',
    transition: 'all 120ms ease-out',
    // Hover
    '--hover-shadow': `4px 4px 0px 0px ${colors.border}`,
    '--hover-transform': 'translateY(-1px)',
    '--hover-filter': 'brightness(1.05)',
    // Active
    '--active-shadow': `1px 1px 0px 0px ${colors.border}`,
    '--active-transform': 'translateY(2px)',
    '--active-filter': 'brightness(0.95)',
  } as React.CSSProperties}
>
  Click me
</button>
```

**Global CSS picks up the `.beetle-button` class and applies states automatically.**

---

## 🚫 Common Mistakes

### ❌ DON'T DO THIS:
```tsx
// No hover state
<button style={{ boxShadow: '3px 3px 0px' }}>
  Click
</button>

// Removing outline without replacement
<input style={{ outline: 'none' }} />

// Using transition-all without specificity
<button className="transition-all">

// Dead hover (hover with no click handler)
<div className="hover:bg-gray-100">
  Not clickable
</div>
```

### ✅ DO THIS INSTEAD:
```tsx
// Proper button component
<BeetleButton onClick={handleClick}>
  Click
</BeetleButton>

// Proper input with focus
<BeetleInput />

// Specific transitions
<button style={{ transition: 'all 120ms ease-out' }}>

// If not clickable, no hover
<div>
  Static content
</div>
```

---

## 📱 Responsive Considerations

Buttons work on touch **and** mouse:

```tsx
// Touch devices:
- :hover often sticky, but that's fine
- :active fires properly
- Shadow depression still visible

// Mouse devices:
- :hover provides pre-click affordance
- :active confirms click
- Cursor: pointer shows clickability
```

**No special mobile handling needed - physics work everywhere!**

---

## 🎓 Philosophy Reminders

### From the Knowledge Dump:

> **"Tiny Contracts"**  
> Resting = "I'm available"  
> Hover = "I see you"  
> Active = "I'm doing it"

> **"Gulf of Execution/Evaluation"**  
> User should never wonder:
> - "Is this clickable?" (hover tells them)
> - "Did it work?" (active tells them)

> **"Physical Feedback Loop"**  
> Digital should mimic physical:
> - Button depresses when pressed
> - Shadow shrinks when compressed
> - Springs back when released

---

## 🐛 Debugging Interactive States

**Button not responding?**
1. Check if `.beetle-button` class is applied
2. Verify `--hover-shadow` and `--active-shadow` are set
3. Check if `:disabled` is blocking states
4. Look for CSS specificity conflicts

**Input focus not showing?**
1. Verify BeetleInput is used (or global CSS applies)
2. Check if `outline: none` is set elsewhere
3. Test keyboard navigation (Tab key)

**Card not lifting?**
1. Verify `interactive` prop is set
2. Check if `onClick` handler exists
3. Look for `.beetle-card` class

---

## 📚 Full Documentation

- **Component Library:** `/components/ui/beetle-*`
- **Global CSS:** `/styles/globals.css` (search "BEETLE INTERACTION SYSTEM")
- **Audit Report:** `/INTERACTION_AUDIT.md`
- **Implementation Summary:** `/INTERACTION_FIX_SUMMARY.md`
- **Physics Guide:** `/BEETLE_PHYSICS_GUIDE.md`

---

## 🎯 Quick Decision Tree

```
Need an interactive element?
  ↓
Is it an action?
  ↓ YES
  Use <BeetleButton>
  ↓ NO
  ↓
Is it navigation?
  ↓ YES
  Use <a> with hover states
  ↓ NO
  ↓
Is it a form input?
  ↓ YES
  Use <BeetleInput>
  ↓ NO
  ↓
Is it a clickable surface?
  ↓ YES
  Use <BeetleCard interactive>
  ↓ NO
  ↓
It's static content
  → No hover states needed
```

---

**Remember: When in doubt, check the physics guide. Every button should feel like a physical beetle exoskeleton.** 🪲✨
