# BoulderRoller Data Hierarchy Principles
**Inspired by Strava's commitment to data-forward design**

## Core Philosophy
**"Chrome whispers, data shouts"**

Data is the star. Containers, borders, and UI chrome exist only to organize—never to compete with the content.

---

## Principle 1: The Number-First Hierarchy

### The Scale
```
Hero Data:     42px (massive presence)
Secondary:     28px (supporting stats)
Tertiary:      16-18px (detailed tables)
Quaternary:    13-14px (inline metrics)

Labels:        10-11px (whispered)
Units:         Inline at 30-40% of number size, muted color
```

### The Rule
**Numbers are ALWAYS larger than their labels. Minimum 3:1 ratio.**

Bad:
```
[14px] Heart Rate
[16px] 152 bpm
```

Good:
```
[16px] 152 bpm
[10px] Avg
```

### Label Position
- Hero/Secondary stats: Label below number
- Table/List data: Label left or above
- Inline metrics: Number first, label after

---

## Principle 2: Tight Coupling (The Kiss)

### The Rule
**Labels should almost kiss the data they describe.**

Spacing between number and label:
- Hero stats: `mb-0.5` (2px)
- Secondary stats: `mb-0.5` (2px)
- Table data: `mb-0.5` (2px)
- Never more than 4px

### Why?
Creates visual binding. The eye should never question which label belongs to which number.

---

## Principle 3: Smart Spacing (Golden Ratio Over Uniformity)

### The Rule
**Group related data close. Separate concepts with dividers.**

Don't:
```
Heart Rate: 152 bpm
[16px gap]
Cadence: 87 rpm
[16px gap]
Intensity Factor: 0.85
```

Do:
```
Heart Rate: 152 bpm
[12px gap]
Cadence: 87 rpm
[divider + 16px]
Intensity Factor: 0.85
```

### Relationships
- **Related metrics** (HR + Cadence): 3-4px gap (`space-y-3`)
- **Different concepts** (Performance vs Weather): Divider + larger gap
- **Sections** (Hero → Secondary → Detailed): 1px divider, no extra padding

### Strava's Courage
Strava isn't afraid of tight spacing. Dense layouts with breathing room only where meaning requires it.

---

## Principle 4: Container Quietness

### The Rule
**Containers use the minimal border/shadow necessary to define space.**

Container Hierarchy (least → most emphasis):
1. **No container** - Data floats on background (use sparingly for hero content)
2. **1px border, 6-8% opacity** - Standard panels (`rgba(42, 45, 30, 0.08)`)
3. **1px border, 15% opacity** - Primary content areas
4. **2px border + shadow** - Interactive elements only (buttons, badges)

### Border Colors
```css
Light mode: rgba(42, 45, 30, 0.1)  /* 10% black-ish */
Dark mode:  rgba(208, 216, 191, 0.15) /* 15% cream */

Dividers (lighter):
Light mode: rgba(42, 45, 30, 0.06)
Dark mode:  rgba(208, 216, 191, 0.08)
```

### Corner Radius
- Outer containers: 6px
- Inner elements: 4px
- Never larger unless it's a badge/pill

---

## Principle 5: Divider Intentionality

### The Rule
**Dividers separate meaning, not space.**

Use dividers when:
- ✅ Changing data type (stats → weather)
- ✅ Shifting visual hierarchy (hero → detailed)
- ✅ Creating sections for scannability
- ✅ Separating interactive from static content

Don't use dividers when:
- ❌ Just adding visual "design"
- ❌ Between related metrics
- ❌ To fill empty space

### Divider Styling
```tsx
// Section divider (full-width, between concepts)
<div className="h-[1px]" style={{ 
  backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.15)' : 'rgba(42, 45, 30, 0.1)' 
}} />

// Subtle row divider (between related items)
<div className="h-[1px]" style={{ 
  backgroundColor: isDarkMode ? 'rgba(208, 216, 191, 0.08)' : 'rgba(42, 45, 30, 0.06)' 
}} />
```

---

## Principle 6: Visual Weight Distribution

### The Rule
**Loot, achievements, and insights get visual emphasis. Everything else fades.**

High Visual Weight (shadows, glows, bold borders):
- 🔥 Dung earned
- 🔥 Achievement badges
- 🔥 PR indicators
- 🔥 Segment crowns
- 🔥 Level-ups

Medium Weight (larger text, monospace):
- ⚡ Performance stats (power, speed, HR)
- ⚡ Activity titles
- ⚡ User actions

Low Weight (small, muted, thin):
- 🔇 Timestamps
- 🔇 Metadata labels
- 🔇 Container borders
- 🔇 Dividers

### Loot Emphasis Techniques
```tsx
// Dung badges get glow
style={{ 
  boxShadow: `2px 2px 0px 0px #2a2d1e, 0 0 12px rgba(200, 155, 92, 0.3)`
}}

// Achievement numbers get text-shadow
style={{ 
  color: '#c89b5c',
  textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'
}}
```

---

## Principle 7: Typography for Data

### The Rule
**Monospace for numbers. Sans-serif for labels.**

```tsx
// Numbers (precise, aligned)
className="font-['Cousine']"

// Labels (readable, subtle)
className="font-['Inter']"
```

### Why?
- Monospace creates vertical alignment in tables
- Communicates precision and data integrity
- Numbers feel "terminal-like" and technical

### Font Sizes by Context
```
Hero number:          42px Cousine, bold, leading-none
Hero label:           11px Inter, muted
Secondary number:     28px Cousine, bold, leading-none
Secondary label:      11px Inter, muted
Table number:         16px Cousine, bold, leading-none
Table label:          10px Inter, muted
Inline stat:          13-14px Cousine, bold
```

---

## Principle 8: Units and Metadata

### The Rule
**Units are whispered inline. Metadata lives below or to the side.**

Units:
```tsx
// Inline, 30-40% size of number, muted
<div className="font-['Cousine'] text-[42px]">
  45.2
  <span className="text-[16px] ml-1" style={{ color: colors.textMuted }}>
    km
  </span>
</div>
```

Metadata (dates, usernames):
```tsx
// Below primary content, 11-12px, tight spacing
<div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
  @climber_420 • 2 hours ago
</div>
```

---

## Principle 9: Hover States for Data (Subtle)

### The Rule
**Interactive data areas use background tint on hover, not borders.**

```tsx
// Feed card hover
onMouseEnter={(e) => e.currentTarget.style.backgroundColor = hoverBg}
onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}

// Hover background
const hoverBg = isDarkMode ? 'rgba(139, 168, 122, 0.08)' : 'rgba(139, 168, 122, 0.04)';
```

Never:
- ❌ Border color changes on hover
- ❌ Shadow changes on data containers
- ❌ Underlines on non-link text

---

## Principle 10: The Terminal Aesthetic

### The Rule
**Data panels should feel like terminal windows—modular, bordered, functional.**

Characteristics:
- Single 1px border wrapping all content
- Horizontal dividers separate sections
- Clean typography hierarchy within
- No background gradients or textures
- 6px corner radius (subtle, not playful)

Example structure:
```
┌─────────────────────────┐ 1px border
│ [Hero Stats Section]    │
├─────────────────────────┤ 1px divider
│ [Secondary Stats]       │
├─────────────────────────┤ 1px divider
│ [Detailed Table]        │
└─────────────────────────┘
```

---

## Application Examples

### Activity Feed Card
```
✓ 1px border, subtle
✓ No shadow at rest
✓ Hover: background tint only
✓ Dung badge: 2px shadow + glow
✓ Icon: preserved visual weight
✓ Timestamp: 11px, muted, tight to action
```

### RideView Stats Panel
```
✓ Single bordered container
✓ 42px hero numbers, 11px labels
✓ Labels kiss numbers (mb-0.5)
✓ Related stats grouped (3px gap)
✓ Concepts divided (1px divider)
✓ Monospace numbers, sans labels
```

### Dung Breakdown (Sidebar)
```
✓ Total dung: 26px with glow effect
✓ Breakdown items: 13px monospace
✓ Labels: 12px, muted
✓ Tight spacing: 2.5px between items
✓ Container: quiet 1px border
```

### Achievement Badge
```
✓ Heavy visual weight (2px border + shadow)
✓ Amber glow on hover
✓ Number: 14-16px monospace
✓ Icon: preserved size/shadow
✓ This is LOOT—it screams
```

---

## Anti-Patterns to Avoid

❌ **Equal spacing everywhere** (uniformity kills meaning)  
❌ **Labels larger than data** (hierarchy inversion)  
❌ **Heavy containers around simple data** (chrome dominance)  
❌ **Borders + shadows together** (visual noise)  
❌ **3px+ gap between number and label** (visual unbinding)  
❌ **Dividers without purpose** (decoration)  
❌ **Sans-serif for numbers** (lacks precision feel)  
❌ **Multiple box-shadows on data** (confusion)  

---

## Implementation Checklist

When designing any data display:

- [ ] Is the number larger than its label? (3:1 minimum)
- [ ] Is the label tight to the number? (mb-0.5 or less)
- [ ] Are related items grouped closer than unrelated?
- [ ] Do dividers separate concepts, not just space?
- [ ] Is the container as quiet as possible?
- [ ] Are units inline and whispered?
- [ ] Is monospace used for numbers?
- [ ] Does loot have visual emphasis?
- [ ] Would Strava approve? (the acid test)

---

## Future Applications

### Dashboard
- Hero stats: FTP, Weekly TSS, Current Form
- Terminal panels for training zones
- Quiet feed of recent activities

### BeetleView (Profile)
- Giant beetle card (this gets visual weight)
- Stats control panel (terminal aesthetic)
- Equipment slots (loot emphasis)

### Leaderboards
- Rank numbers: massive
- User stats: tight table format
- Segment times: monospace precision

### Achievements Page
- Each achievement: heavy emphasis
- Unlock dates: whispered
- Progress bars: subtle container

---

**Remember: Strava's visual hierarchy works because they're obsessed with the data, not the chrome. Be brave. Make it tight. Let numbers dominate.**
