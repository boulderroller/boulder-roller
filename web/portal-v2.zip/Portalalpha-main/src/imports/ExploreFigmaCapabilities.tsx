import svgPaths from "./svg-o0esxi8uc1";

function Container() {
  return (
    <div className="h-[40px] relative shrink-0 w-[36px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[40px] relative w-[36px]">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[40px] left-0 not-italic text-[#2a2d1e] text-[36px] text-nowrap top-0 tracking-[0.3691px] whitespace-pre">🪲</p>
      </div>
    </div>
  );
}

function Heading() {
  return (
    <div className="basis-0 grow h-[140.781px] min-h-px min-w-px relative shrink-0" data-name="Heading 1">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[140.781px] relative w-full">
        <p className="absolute font-['Inter:Black',sans-serif] font-black leading-[70.4px] left-0 not-italic text-[#2a2d1e] text-[64px] top-px tracking-[-1.7012px] w-[287px]">BOULDER ROLLERS</p>
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="basis-0 grow h-[140.781px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] h-[140.781px] items-center relative w-full">
        <Container />
        <Heading />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="bg-[#2a2d1e] h-[40px] relative shrink-0 w-[0.797px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[40px] w-[0.797px]" />
    </div>
  );
}

function Container3() {
  return (
    <div className="h-[15.609px] opacity-80 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[15.6px] left-0 not-italic text-[10.4px] text-nowrap text-white top-[-1px] tracking-[0.6175px] uppercase whitespace-pre">Beetle</p>
    </div>
  );
}

function Container4() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Bold',sans-serif] leading-[28px] left-0 not-italic text-[18px] text-white top-[-1px] w-[55px]">#4821</p>
    </div>
  );
}

function Container5() {
  return (
    <div className="bg-[#8b9475] h-[65.609px] relative rounded-[10px] shrink-0 w-[92.203px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[65.609px] items-start pb-[3px] pt-[11px] px-[19px] relative w-[92.203px]">
        <Container3 />
        <Container4 />
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="h-[140.781px] relative shrink-0 w-[633.781px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] h-[140.781px] items-center relative w-[633.781px]">
        <Container1 />
        <Container2 />
        <Container5 />
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p1b8b3180} fill="var(--fill-0, #2A2D1E)" id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Container7() {
  return (
    <div className="bg-[#d4c993] relative rounded-[3.35544e+07px] shrink-0 size-[48px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[3px] relative size-[48px]">
        <Icon />
      </div>
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#6b7a5a] text-[12px] text-nowrap top-0 tracking-[0.6px] uppercase whitespace-pre">Energy</p>
    </div>
  );
}

function Container9() {
  return <div className="bg-gradient-to-r from-[#d4c993] h-[10px] shrink-0 to-[#c7a76f] w-full" data-name="Container" />;
}

function Container10() {
  return (
    <div className="basis-0 bg-[#d0d8bf] grow h-[16px] min-h-px min-w-px relative rounded-[3.35544e+07px] shrink-0" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[16px] items-start pl-[3px] pr-[95.406px] py-[3px] relative w-full">
          <Container9 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
    </div>
  );
}

function Text() {
  return (
    <div className="h-[28px] relative shrink-0 w-[97.563px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[28px] relative w-[97.563px]">
        <p className="absolute font-['Cousine:Bold',sans-serif] leading-[28px] left-0 not-italic text-[#2a2d1e] text-[18px] top-[-1px] w-[98px]">1000/2500</p>
      </div>
    </div>
  );
}

function Container11() {
  return (
    <div className="content-stretch flex gap-[12px] h-[28px] items-center relative shrink-0 w-full" data-name="Container">
      <Container10 />
      <Text />
    </div>
  );
}

function Container12() {
  return (
    <div className="basis-0 grow h-[50px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] h-[50px] items-start relative w-full">
        <Container8 />
        <Container11 />
      </div>
    </div>
  );
}

function Container13() {
  return (
    <div className="basis-0 grow h-[50px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] h-[50px] items-center relative w-full">
        <Container7 />
        <Container12 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="bg-[#d0d8bf] h-[40px] relative shrink-0 w-px" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[40px] w-px" />
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[15.609px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[15.6px] left-0 not-italic text-[10.4px] text-nowrap text-white top-[-1px] tracking-[0.6175px] uppercase whitespace-pre">Rank</p>
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Bold',sans-serif] leading-[32px] left-0 not-italic text-[24px] text-nowrap text-white top-0 whitespace-pre">A</p>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[69.609px] relative rounded-[10px] shrink-0 w-[70.688px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[10px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[69.609px] items-start pb-[3px] pt-[11px] px-[19px] relative w-[70.688px]">
        <Container15 />
        <Container16 />
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="h-[69.609px] relative shrink-0 w-[469.25px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[32px] h-[69.609px] items-center relative w-[469.25px]">
        <Container13 />
        <Container14 />
        <Container17 />
      </div>
    </div>
  );
}

function Text1() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Text">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[32px] left-[12px] not-italic text-[#2a2d1e] text-[24px] text-center text-nowrap top-0 tracking-[0.0703px] translate-x-[-50%] whitespace-pre">🏔️</p>
    </div>
  );
}

function Button() {
  return (
    <div className="bg-[#f9faf5] relative rounded-[16.4px] shrink-0 size-[62px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-[3px] pt-[15px] px-[19px] relative size-[62px]">
        <Text1 />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p3e8f800} id="Vector" stroke="var(--stroke-0, #F9FAF5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p11d57a00} id="Vector_2" stroke="var(--stroke-0, #F9FAF5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Text2() {
  return (
    <div className="basis-0 grow h-[24px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-full">
        <p className="absolute font-['Cousine:Bold',sans-serif] leading-[24px] left-[53px] not-italic text-[#f9faf5] text-[16px] text-center text-nowrap top-[-1px] translate-x-[-50%] whitespace-pre">7xK9...mP3q</p>
      </div>
    </div>
  );
}

function Container19() {
  return (
    <div className="content-stretch flex gap-[8px] h-[24px] items-center relative shrink-0 w-full" data-name="Container">
      <Icon1 />
      <Text2 />
    </div>
  );
}

function Button1() {
  return (
    <div className="basis-0 bg-[#8b9475] grow h-[54px] min-h-px min-w-px relative rounded-[16.4px] shrink-0" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="size-full">
        <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[54px] items-start pb-[3px] pt-[15px] px-[27px] relative w-full">
          <Container19 />
        </div>
      </div>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[62px] relative shrink-0 w-[261.969px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] h-[62px] items-center relative w-[261.969px]">
        <Button />
        <Button1 />
      </div>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[188.781px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex h-[188.781px] items-center justify-between px-[32px] py-0 relative w-full">
          <Container6 />
          <Container18 />
          <Container20 />
        </div>
      </div>
    </div>
  );
}

function Header() {
  return (
    <div className="bg-[#f9faf5] h-[191.781px] relative shrink-0 w-[1429px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[0px_0px_3px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[191.781px] items-start pb-[3px] pt-0 px-0 relative w-[1429px]">
        <Container21 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p2bbf6680} id="Vector" stroke="var(--stroke-0, #F9FAF5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p28601a80} id="Vector_2" stroke="var(--stroke-0, #F9FAF5)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
        </g>
      </svg>
    </div>
  );
}

function Text3() {
  return (
    <div className="h-[24px] relative shrink-0 w-[45.734px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-[45.734px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#f9faf5] text-[16px] text-nowrap top-0 tracking-[-0.3125px] whitespace-pre">Home</p>
      </div>
    </div>
  );
}

function Button2() {
  return (
    <div className="absolute content-stretch flex gap-[16px] h-[62px] items-center left-[22px] pl-[23px] pr-[3px] py-[3px] rounded-[16.4px] top-[22px] w-[237px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <Icon2 />
      <Text3 />
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g clipPath="url(#clip0_1_231)" id="Icon">
          <path d={svgPaths.p28b1aae0} id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
        </g>
        <defs>
          <clipPath id="clip0_1_231">
            <rect fill="white" height="24" width="24" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Text4() {
  return (
    <div className="h-[24px] relative shrink-0 w-[43.25px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-[43.25px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#2a2d1e] text-[16px] text-nowrap top-0 tracking-[-0.3125px] whitespace-pre">Rides</p>
      </div>
    </div>
  );
}

function Button3() {
  return (
    <div className="absolute bg-[#f9faf5] content-stretch flex gap-[16px] h-[62px] items-center left-[24px] pl-[23px] pr-[3px] py-[3px] rounded-[16.4px] top-[98px] w-[237px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <Icon3 />
      <Text4 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p27c543b0} id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p2d59bff0} id="Vector_2" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
        </g>
      </svg>
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[24px] relative shrink-0 w-[37.219px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-[37.219px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#2a2d1e] text-[16px] text-nowrap top-0 tracking-[-0.3125px] whitespace-pre">Piles</p>
      </div>
    </div>
  );
}

function Button4() {
  return (
    <div className="absolute bg-[#f9faf5] content-stretch flex gap-[16px] h-[62px] items-center left-[24px] pl-[23px] pr-[3px] py-[3px] rounded-[16.4px] top-[172px] w-[237px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <Icon4 />
      <Text5 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d="M16 7H22V13" id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p13253c0} id="Vector_2" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
        </g>
      </svg>
    </div>
  );
}

function Text6() {
  return (
    <div className="h-[24px] relative shrink-0 w-[66.875px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-[66.875px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#2a2d1e] text-[16px] text-nowrap top-0 tracking-[-0.3125px] whitespace-pre">Portfolio</p>
      </div>
    </div>
  );
}

function Button5() {
  return (
    <div className="absolute bg-[#f9faf5] content-stretch flex gap-[16px] h-[62px] items-center left-[24px] pl-[23px] pr-[3px] py-[3px] rounded-[16.4px] top-[246px] w-[237px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <Icon5 />
      <Text6 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p1d820380} id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p27451300} id="Vector_2" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p2981fe00} id="Vector_3" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p161d4800} id="Vector_4" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
        </g>
      </svg>
    </div>
  );
}

function Text7() {
  return (
    <div className="h-[24px] relative shrink-0 w-[37.969px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-[37.969px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#2a2d1e] text-[16px] text-nowrap top-0 tracking-[-0.3125px] whitespace-pre">Feed</p>
      </div>
    </div>
  );
}

function Button6() {
  return (
    <div className="absolute bg-[#f9faf5] content-stretch flex gap-[16px] h-[62px] items-center left-[24px] pl-[23px] pr-[3px] py-[3px] rounded-[16.4px] top-[320px] w-[237px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <Icon6 />
      <Text7 />
    </div>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p67f12c8} id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
          <path d={svgPaths.p2c19cb00} id="Vector_2" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" />
        </g>
      </svg>
    </div>
  );
}

function Text8() {
  return (
    <div className="h-[24px] relative shrink-0 w-[50.734px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[24px] relative w-[50.734px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[24px] left-0 not-italic text-[#2a2d1e] text-[16px] text-nowrap top-0 tracking-[-0.3125px] whitespace-pre">Profile</p>
      </div>
    </div>
  );
}

function Button7() {
  return (
    <div className="absolute bg-[#f9faf5] content-stretch flex gap-[16px] h-[62px] items-center left-[22px] pl-[23px] pr-[3px] py-[3px] rounded-[16.4px] top-[392px] w-[237px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <Icon7 />
      <Text8 />
    </div>
  );
}

function Navigation() {
  return (
    <div className="h-[492px] relative shrink-0 w-full" data-name="Navigation">
      <Button2 />
      <Button3 />
      <Button4 />
      <Button5 />
      <Button6 />
      <Button7 />
    </div>
  );
}

function Sidebar() {
  return (
    <div className="bg-[#f9faf5] h-[1299.22px] relative shrink-0 w-[288px]" data-name="Sidebar">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[0px_3px_0px_0px] border-solid inset-0 pointer-events-none" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[1299.22px] items-start pl-0 pr-[3px] py-0 relative w-[288px]">
        <Navigation />
      </div>
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[52.797px] relative shrink-0 w-full" data-name="Heading 2">
      <p className="absolute font-['Inter:Extra_Bold',sans-serif] font-extrabold leading-[52.8px] left-0 not-italic text-[#2a2d1e] text-[48px] text-nowrap top-0 tracking-[-0.8484px] whitespace-pre">Good morning</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[32px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[32px] left-0 not-italic text-[#6b7a5a] text-[20px] top-0 tracking-[-0.4492px] w-[264px]">Ready to ride • Energy at 40%</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[84.797px] relative shrink-0 w-[307.078px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[84.797px] items-start relative w-[307.078px]">
        <Heading1 />
        <Paragraph />
      </div>
    </div>
  );
}

function Container23() {
  return (
    <div className="h-[18px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-[154.83px] not-italic text-[12px] text-nowrap text-right text-white top-0 tracking-[0.6px] translate-x-[-100%] uppercase whitespace-pre">This week</p>
    </div>
  );
}

function Container24() {
  return (
    <div className="h-[64px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Bold',sans-serif] leading-[64px] left-[155px] not-italic text-[64px] text-right text-white top-0 translate-x-[-100%] w-[155px]">+147</p>
    </div>
  );
}

function Container25() {
  return (
    <div className="h-[28px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-[155.09px] not-italic text-[20px] text-nowrap text-right text-white top-0 tracking-[-0.4492px] translate-x-[-100%] whitespace-pre">DUNG EARNED</p>
    </div>
  );
}

function Container26() {
  return (
    <div className="h-[180px] relative rounded-[16px] shrink-0 w-[224.125px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[8px_8px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[8px] h-[180px] items-start pb-[3px] pt-[27px] px-[35px] relative w-[224.125px]">
        <Container23 />
        <Container24 />
        <Container25 />
      </div>
    </div>
  );
}

function Container27() {
  return (
    <div className="content-stretch flex h-[180px] items-start justify-between relative shrink-0 w-full" data-name="Container">
      <Container22 />
      <Container26 />
    </div>
  );
}

function Icon8() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p231a5100} fill="var(--fill-0, #2A2D1E)" id="Vector" stroke="var(--stroke-0, #2A2D1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container28() {
  return (
    <div className="bg-[#d4c993] relative rounded-[3.35544e+07px] shrink-0 size-[40px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[3px] relative size-[40px]">
        <Icon8 />
      </div>
    </div>
  );
}

function Text9() {
  return (
    <div className="basis-0 grow h-[28px] min-h-px min-w-px relative shrink-0" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[28px] relative w-full">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[#2a2d1e] text-[20px] text-nowrap top-0 tracking-[-0.4492px] whitespace-pre">DAILY ENERGY</p>
      </div>
    </div>
  );
}

function Container29() {
  return (
    <div className="h-[40px] relative shrink-0 w-[191.578px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] h-[40px] items-center relative w-[191.578px]">
        <Container28 />
        <Text9 />
      </div>
    </div>
  );
}

function Text10() {
  return (
    <div className="h-[32px] relative shrink-0 w-[158.953px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[32px] relative w-[158.953px]">
        <p className="absolute font-['Cousine:Bold',sans-serif] leading-[32px] left-0 not-italic text-[#2a2d1e] text-[24px] top-0 w-[159px]">1000 / 2500</p>
      </div>
    </div>
  );
}

function Container30() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container29 />
      <Text10 />
    </div>
  );
}

function Container31() {
  return <div className="bg-gradient-to-r from-[#d4c993] h-[26px] shrink-0 to-[#a87373] via-50% via-[#c7a76f] w-full" data-name="Container" />;
}

function Container32() {
  return (
    <div className="bg-[#d0d8bf] h-[32px] relative rounded-[3.35544e+07px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col h-[32px] items-start pl-[3px] pr-[594px] py-[3px] relative w-full">
          <Container31 />
        </div>
      </div>
      <div className="absolute inset-0 pointer-events-none shadow-[0px_2px_4px_0px_inset_rgba(0,0,0,0.1)]" />
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[3.35544e+07px]" />
    </div>
  );
}

function Container33() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[88px] items-start relative shrink-0 w-full" data-name="Container">
      <Container30 />
      <Container32 />
    </div>
  );
}

function Icon9() {
  return (
    <div className="relative shrink-0 size-[28px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
        <g id="Icon">
          <path d="M14 3.5V17.5" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.91667" />
          <path d={svgPaths.p1264cb00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.91667" />
          <path d={svgPaths.p1e686c20} id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.91667" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <div className="h-[28px] relative shrink-0 w-[130.125px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[28px] relative w-[130.125px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-[65.5px] not-italic text-[20px] text-center text-nowrap text-white top-0 tracking-[-0.4492px] translate-x-[-50%] whitespace-pre">UPLOAD RIDE</p>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <div className="content-stretch flex gap-[12px] h-[82px] items-center justify-center p-[3px] relative rounded-[16px] shrink-0 w-full" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[8px_8px_0px_0px_#2a2d1e]" />
      <Icon9 />
      <Text11 />
    </div>
  );
}

function Container34() {
  return (
    <div className="bg-[#f9faf5] h-[516px] relative rounded-[12px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[40px] h-[516px] items-start pb-[3px] pt-[43px] px-[43px] relative w-full">
          <Container27 />
          <Container33 />
          <Button8 />
        </div>
      </div>
    </div>
  );
}

function Container35() {
  return (
    <div className="h-[18px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[12px] text-nowrap text-white top-0 tracking-[0.6px] uppercase whitespace-pre">Rides</p>
    </div>
  );
}

function Container36() {
  return (
    <div className="h-[64px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Bold',sans-serif] leading-[64px] left-0 not-italic text-[64px] text-nowrap text-white top-0 whitespace-pre">4</p>
    </div>
  );
}

function Container37() {
  return (
    <div className="h-[28px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-0 not-italic text-[20px] text-nowrap text-white top-0 tracking-[-0.4492px] whitespace-pre">this week</p>
    </div>
  );
}

function Container38() {
  return (
    <div className="[grid-area:1_/_1] place-self-stretch relative rounded-[12px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[16px] items-start pb-[3px] pt-[35px] px-[35px] relative size-full">
          <Container35 />
          <Container36 />
          <Container37 />
        </div>
      </div>
    </div>
  );
}

function Container39() {
  return (
    <div className="h-[18px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[12px] text-nowrap text-white top-0 tracking-[0.6px] uppercase whitespace-pre">Training Stress</p>
    </div>
  );
}

function Container40() {
  return (
    <div className="h-[64px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Bold',sans-serif] leading-[64px] left-0 not-italic text-[64px] text-nowrap text-white top-0 whitespace-pre">520</p>
    </div>
  );
}

function Container41() {
  return (
    <div className="h-[28px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-0 not-italic text-[20px] text-nowrap text-white top-0 tracking-[-0.4492px] whitespace-pre">TSS accumulated</p>
    </div>
  );
}

function Container42() {
  return (
    <div className="[grid-area:1_/_2] place-self-stretch relative rounded-[12px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[16px] items-start pb-[3px] pt-[35px] px-[35px] relative size-full">
          <Container39 />
          <Container40 />
          <Container41 />
        </div>
      </div>
    </div>
  );
}

function Container43() {
  return (
    <div className="h-[18px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[12px] text-nowrap text-white top-0 tracking-[0.6px] uppercase whitespace-pre">Rank</p>
    </div>
  );
}

function Container44() {
  return (
    <div className="h-[64px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Cousine:Bold',sans-serif] leading-[64px] left-0 not-italic text-[64px] text-nowrap text-white top-0 whitespace-pre">A</p>
    </div>
  );
}

function Container45() {
  return (
    <div className="h-[28px] opacity-90 relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[28px] left-0 not-italic text-[20px] text-nowrap text-white top-0 tracking-[-0.4492px] whitespace-pre">current grade</p>
    </div>
  );
}

function Container46() {
  return (
    <div className="[grid-area:1_/_3] place-self-stretch relative rounded-[12px] shrink-0" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[16px] items-start pb-[3px] pt-[35px] px-[35px] relative size-full">
          <Container43 />
          <Container44 />
          <Container45 />
        </div>
      </div>
    </div>
  );
}

function Container47() {
  return (
    <div className="gap-[24px] grid grid-cols-[repeat(3,_minmax(0px,_1fr))] grid-rows-[repeat(1,_minmax(0px,_1fr))] h-[208px] relative shrink-0 w-full" data-name="Container">
      <Container38 />
      <Container42 />
      <Container46 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[31.188px] relative shrink-0 w-[201.375px]" data-name="Heading 3">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid h-[31.188px] relative w-[201.375px]">
        <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[31.2px] left-0 not-italic text-[#2a2d1e] text-[24px] text-nowrap top-0 tracking-[-0.2897px] whitespace-pre">RECENT ACTIVITY</p>
      </div>
    </div>
  );
}

function Container48() {
  return (
    <div className="bg-[#8ba87a] opacity-[0.857] relative rounded-[3.35544e+07px] shadow-[0px_0px_12px_0px_#8ba87a] shrink-0 size-[12px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid size-[12px]" />
    </div>
  );
}

function Container49() {
  return (
    <div className="h-[98.188px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[0px_0px_3px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex h-[98.188px] items-center justify-between pb-[3px] pt-0 px-[32px] relative w-full">
          <Heading2 />
          <Container48 />
        </div>
      </div>
    </div>
  );
}

function Icon10() {
  return (
    <div className="relative shrink-0 size-[28px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
        <g id="Icon">
          <path d={svgPaths.p275e0300} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.91667" />
          <path d={svgPaths.p3997a780} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.91667" />
        </g>
      </svg>
    </div>
  );
}

function Container50() {
  return (
    <div className="relative rounded-[16px] shrink-0 size-[56px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[3px] relative size-[56px]">
        <Icon10 />
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[#2a2d1e] text-[20px] text-nowrap top-0 tracking-[-0.4492px] whitespace-pre">Improved ranking on HAWK HILL</p>
    </div>
  );
}

function Container52() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#6b7a5a] text-[12px] text-nowrap top-0 tracking-[0.6px] uppercase whitespace-pre">2 hours ago</p>
    </div>
  );
}

function Container53() {
  return (
    <div className="basis-0 grow h-[50px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] h-[50px] items-start relative w-full">
        <Container51 />
        <Container52 />
      </div>
    </div>
  );
}

function Container54() {
  return (
    <div className="h-[56px] relative shrink-0 w-[385.094px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] h-[56px] items-center relative w-[385.094px]">
        <Container50 />
        <Container53 />
      </div>
    </div>
  );
}

function Container55() {
  return (
    <div className="bg-[#8ba87a] h-[66px] relative rounded-[16.4px] shrink-0 w-[108.188px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[66px] items-start px-[27px] py-[15px] relative w-[108.188px]">
        <p className="font-['Cousine:Bold',sans-serif] leading-[36px] not-italic relative shrink-0 text-[30px] text-nowrap text-white whitespace-pre">+15</p>
      </div>
    </div>
  );
}

function Container56() {
  return (
    <div className="h-[133px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[0px_0px_3px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex h-[133px] items-center justify-between pb-[3px] pt-0 px-[32px] relative w-full">
          <Container54 />
          <Container55 />
        </div>
      </div>
    </div>
  );
}

function Icon11() {
  return (
    <div className="relative shrink-0 size-[28px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 28 28">
        <g id="Icon">
          <path d={svgPaths.p12316000} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.91667" />
        </g>
      </svg>
    </div>
  );
}

function Container57() {
  return (
    <div className="relative rounded-[16px] shrink-0 size-[56px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[3px] relative size-[56px]">
        <Icon11 />
      </div>
    </div>
  );
}

function Container58() {
  return (
    <div className="h-[28px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[28px] left-0 not-italic text-[#2a2d1e] text-[20px] text-nowrap top-0 tracking-[-0.4492px] whitespace-pre">Completed morning ride</p>
    </div>
  );
}

function Container59() {
  return (
    <div className="h-[18px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[18px] left-0 not-italic text-[#6b7a5a] text-[12px] text-nowrap top-0 tracking-[0.6px] uppercase whitespace-pre">5 hours ago</p>
    </div>
  );
}

function Container60() {
  return (
    <div className="basis-0 grow h-[50px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] h-[50px] items-start relative w-full">
        <Container58 />
        <Container59 />
      </div>
    </div>
  );
}

function Container61() {
  return (
    <div className="h-[56px] relative shrink-0 w-[307.781px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[24px] h-[56px] items-center relative w-[307.781px]">
        <Container57 />
        <Container60 />
      </div>
    </div>
  );
}

function Container62() {
  return (
    <div className="h-[66px] relative rounded-[16.4px] shrink-0 w-[108.188px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[16.4px] shadow-[4px_4px_0px_0px_#2a2d1e]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-[66px] items-start px-[27px] py-[15px] relative w-[108.188px]">
        <p className="font-['Cousine:Bold',sans-serif] leading-[36px] not-italic relative shrink-0 text-[30px] text-nowrap text-white whitespace-pre">+45</p>
      </div>
    </div>
  );
}

function Container63() {
  return (
    <div className="h-[130px] relative shrink-0 w-full" data-name="Container">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex h-[130px] items-center justify-between px-[32px] py-0 relative w-full">
          <Container61 />
          <Container62 />
        </div>
      </div>
    </div>
  );
}

function Container64() {
  return (
    <div className="content-stretch flex flex-col h-[263px] items-start relative shrink-0 w-full" data-name="Container">
      <Container56 />
      <Container63 />
    </div>
  );
}

function Container65() {
  return (
    <div className="bg-[#f9faf5] h-[367.188px] relative rounded-[12px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#2a2d1e] border-[3px] border-solid inset-0 pointer-events-none rounded-[12px] shadow-[6px_6px_0px_0px_#2a2d1e]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col h-[367.188px] items-start p-[3px] relative w-full">
          <Container49 />
          <Container64 />
        </div>
      </div>
    </div>
  );
}

function HomeTab() {
  return (
    <div className="h-[1219.19px] relative shrink-0 w-full" data-name="HomeTab">
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[32px] h-[1219.19px] items-start pb-0 pt-[32px] px-[32px] relative w-full">
          <Container34 />
          <Container47 />
          <Container65 />
        </div>
      </div>
    </div>
  );
}

function MainContent() {
  return (
    <div className="basis-0 grow h-[1299.22px] min-h-px min-w-px relative shrink-0" data-name="Main Content">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col h-[1299.22px] items-start overflow-clip relative rounded-[inherit] w-full">
        <HomeTab />
      </div>
    </div>
  );
}

function Container66() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0 w-[1429px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex h-full items-start overflow-clip relative rounded-[inherit] w-[1429px]">
        <Sidebar />
        <MainContent />
      </div>
    </div>
  );
}

export default function ExploreFigmaCapabilities() {
  return (
    <div className="bg-[#f3f5ed] content-stretch flex flex-col items-start relative size-full" data-name="Explore Figma Capabilities">
      <Header />
      <Container66 />
    </div>
  );
}