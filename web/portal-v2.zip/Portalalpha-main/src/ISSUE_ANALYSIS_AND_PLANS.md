# 🪲 ISSUE ANALYSIS & IMPLEMENTATION PLANS
**Date:** December 9, 2024  
**Status:** Analysis Complete - Awaiting Approval

---

## 🔍 INVESTIGATION FINDINGS

### 1. ❌ **ISSUE: RideView Stats Overlap Strangely**

**Location:** `/pages/RideView.tsx` → `/components/ride/StatsPanel.tsx`

**Root Cause:**
- Grid layout uses `grid-cols-4` with `gap-8` for hero stats (line 39)
- Each stat has massive 64px Cousine font
- At smaller viewport widths, the grid doesn't have responsive breakpoints
- Numbers like "1:42:30" are wide, causing overflow

**Evidence:**
```tsx
// Line 39-40 in StatsPanel.tsx
<div className="grid grid-cols-4 gap-8">
  <div>
    <div className="font-['Cousine'] text-[64px] font-bold leading-none mb-1">
```

**The Problem:**
- 64px font + 4 columns + 8-gap = ~900px minimum width
- Container might be narrower, causing overlap
- No `grid-cols-1` or `grid-cols-2` for tablet/mobile

---

### 2. ❌ **ISSUE: Modal Background Scroll Not Locked**

**Location:** `/hooks/useScrollLock.ts`

**Root Cause:**
The hook tries to lock `<main>` element, but BoulderRoller's scroll architecture is on the **window/body level**, not the `main` element.

**Evidence:**
```tsx
// Current approach in useScrollLock.ts (line 10-19)
const mainElement = document.querySelector('main');
mainElement.style.overflow = 'hidden'; // ❌ Wrong target
```

**The Problem:**
- Our app's main scroll is on `window` (whole page scrolls)
- We're locking `main.scrollTop` but user is scrolling `window`
- That's why background still scrolls when modal is open

**Current State:**
- ✅ useScrollLock is CALLED in modals
- ❌ useScrollLock targets wrong element

---

### 3. ❌ **ISSUE: ActivityFeed Sidebars Don't Stick Like Strava**

**Location:** `/components/feed/ActivityFeed.tsx` line 476-477

**Root Cause:**
Missing `sticky` positioning on sidebars.

**Evidence:**
```tsx
// Line 477 - Right Panel has NO sticky class
<div className="space-y-4">
  {/* Weekly Leaderboard */}
```

**Strava's Pattern:**
- Left sidebar: `position: sticky; top: 80px;`
- Right sidebar: `position: sticky; top: 80px;`
- Both stick as you scroll, center panel flows

**Our Pattern:**
- Left sidebar: No sticky ❌
- Right sidebar: No sticky ❌
- All three columns scroll together

---

### 4. ⚠️ **ISSUE: Activities Tab on RideView "Wonky"**

**Location:** `/pages/RideView.tsx`

**Analysis:**
Actually... **there is NO activities tab** on RideView currently. 

Looking at the code:
- Line 163-348: Single page layout
- No tab navigation
- No "Activities" section

**Possible Interpretations:**
1. User meant the **Segments table** (line 236-273) needs polish?
2. User wants us to ADD an activities tab (like Strava's athlete profile)?
3. Referring to a different page?

**Need Clarification:** What is the "activities tab" you're referring to?

---

### 5. ⏳ **TODO: Notification Dropdown**

**Location:** `/components/layout/TopNav.tsx` line 72-75

**Current State:**
```tsx
const handleNotifications = () => {
  toast.info('Notifications coming soon! 🔔');
  // TODO: Open notifications dropdown
};
```

**Status:** Placeholder only - needs full implementation

---

### 6. 💡 **DISCUSSION: Strava's Left-Hand Control Frame Pattern**

**Strava's Design Pattern:**

They use a **sticky left-hand control panel** that acts as a filter/switcher for the main content area:

**Example 1 - Dashboard:**
```
┌─────────────┬──────────────────────┐
│   FILTER    │                      │
│             │   MAIN CONTENT       │
│ • Rides     │   (Activity Feed)    │
│ • Runs      │                      │
│ • Swims     │                      │
│ • All       │                      │
│             │                      │
│   DATE      │                      │
│ • This Week │                      │
│ • This Month│                      │
└─────────────┴──────────────────────┘
```

**Example 2 - Activity Detail:**
```
┌─────────────┬──────────────────────┐
│   VIEW      │                      │
│             │   MAIN FRAME         │
│ • Overview  │   (Map/Stats)        │
│ • Analysis  │                      │
│ • Segments  │                      │
│ • Kudos     │                      │
└─────────────┴──────────────────────┘
```

**Why It Works:**
1. **Spatial Consistency** - Controls always in same spot
2. **Context Switching** - Change view without losing position
3. **Progressive Disclosure** - Hide complexity until needed
4. **Mobile Friendly** - Collapses to top tabs on mobile

---

## 🎯 PROPOSED SOLUTIONS

### **FIX 1: Stats Panel Responsive Grid**

**File:** `/components/ride/StatsPanel.tsx`

**Changes:**
```tsx
// OLD (line 39):
<div className="grid grid-cols-4 gap-8">

// NEW:
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
```

**Also adjust font sizes for mobile:**
```tsx
// OLD:
className="font-['Cousine'] text-[64px] font-bold leading-none mb-1"

// NEW:
className="font-['Cousine'] text-[48px] md:text-[64px] font-bold leading-none mb-1"
```

**Impact:**
- ✅ No more overlap on tablets
- ✅ Stats stack 2x2 on mobile
- ✅ 4 columns on desktop (unchanged)

---

### **FIX 2: Correct Scroll Lock Implementation**

**File:** `/hooks/useScrollLock.ts`

**Root Issue:** We need to lock `document.body`, not `main`

**NEW Implementation:**
```tsx
export function useScrollLock(isLocked: boolean) {
  useEffect(() => {
    if (!isLocked) return;

    // Store original values
    const originalStyle = window.getComputedStyle(document.body).overflow;
    const originalPaddingRight = document.body.style.paddingRight;
    
    // Get scrollbar width to prevent layout shift
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    
    // Lock body scroll
    document.body.style.overflow = 'hidden';
    document.body.style.paddingRight = `${scrollbarWidth}px`; // Prevent layout shift
    
    // Cleanup
    return () => {
      document.body.style.overflow = originalStyle;
      document.body.style.paddingRight = originalPaddingRight;
    };
  }, [isLocked]);
}
```

**Why This Works:**
- ✅ Locks the actual scrolling element (body)
- ✅ Prevents layout shift (adds padding for scrollbar width)
- ✅ Properly restores on cleanup

---

### **FIX 3: Sticky Sidebars Like Strava**

**File:** `/components/feed/ActivityFeed.tsx`

**Changes:**
```tsx
// LEFT SIDEBAR (line ~230)
// OLD:
<div className="space-y-4">

// NEW:
<div className="space-y-4 sticky top-[80px] self-start">
```

```tsx
// RIGHT SIDEBAR (line ~477)
// OLD:
<div className="space-y-4">

// NEW:
<div className="space-y-4 sticky top-[80px] self-start">
```

**Explanation:**
- `sticky top-[80px]` - Sticks 80px from top (below 64px nav + 16px buffer)
- `self-start` - Aligns to start of grid row (prevents stretching)

**Result:**
- ✅ Sidebars stick as you scroll
- ✅ Center feed scrolls independently
- ✅ Exactly like Strava's behavior

---

### **FIX 4: Activities Tab - Need Clarification**

**Questions:**
1. Are you referring to the **Segments table** needing polish?
2. Do you want to ADD a tabbed interface to RideView (Overview/Segments/Analysis)?
3. Is there a specific visual issue you're seeing?

**If you want tabs added:**
We could implement Strava-style tabs:
```
[Overview] [Segments] [Analysis] [Kudos]
```

Each tab would show/hide different content sections.

**Please clarify what you'd like here.**

---

### **FIX 5: Notification Dropdown Implementation**

**File:** Create `/components/layout/NotificationDropdown.tsx`

**Design Concept:**

```
┌─────────────────────────────────┐
│ 🔔 Notifications          [x]   │
├─────────────────────────────────┤
│                                 │
│ 🏆 @climber_420 gave you kudos │
│    Morning Climb • 2h ago       │
│                                 │
│ 📈 New PR on Hawk Hill!         │
│    You ranked #12 • 5h ago      │
│                                 │
│ 🪲 Achievement Unlocked         │
│    Century Beetle • 1d ago      │
│                                 │
├─────────────────────────────────┤
│        View All (24)            │
└─────────────────────────────────┘
```

**Features:**
- Show recent 5 notifications
- Unread badge counter
- Click to mark as read
- "View All" goes to `/notifications` page
- Real-time updates (when backend is ready)

**Notification Types:**
1. **Kudos** - Someone gave you kudos
2. **PR/Achievement** - You set a new record
3. **Segment Challenge** - Someone beat your time
4. **Social** - New follower, comment, mention
5. **System** - Dung payout, rank change

**Implementation Pattern:**
- Same dropdown pattern as Dashboard/Explore
- Position absolute, right-aligned
- Backdrop click to close
- ESC key to close
- Focus trap

---

### **DISCUSSION: Control Panel Pattern for BoulderRoller**

**Where This Pattern Would Work:**

#### **Option A: Activity Feed (Dashboard Page)**
```
┌──────────────┬───────────────────────┬────────────┐
│  PROFILE     │                       │ LEADERBOARD│
│  CARD        │   ACTIVITY FEED       │            │
│              │                       │  TRENDING  │
│  FILTERS:    │   [Activity cards]    │  SEGMENTS  │
│  • All       │                       │            │
│  • Rides     │                       │            │
│  • Runs      │                       │            │
│  • Kudos     │                       │            │
│              │                       │            │
│  DATE:       │                       │            │
│  • Today     │                       │            │
│  • Week      │                       │            │
│  • Month     │                       │            │
└──────────────┴───────────────────────┴────────────┘
```

**Benefit:** Filter feed without losing scroll position

---

#### **Option B: RideView (Activity Detail)**
```
┌──────────────┬────────────────────────────────────┐
│  VIEW        │                                    │
│              │      [MAIN CONTENT AREA]           │
│  • Overview  │                                    │
│  • Segments  │   Shows different content based    │
│  • Analysis  │   on left selection                │
│  • Power     │                                    │
│  • HR Zones  │                                    │
│              │                                    │
│  ACTIONS     │                                    │
│  • Edit      │                                    │
│  • Share     │                                    │
│  • Delete    │                                    │
└──────────────┴────────────────────────────────────┘
```

**Benefit:** Reduce vertical scroll, organize dense data

---

#### **Option C: Data/Training Page**
```
┌──────────────┬────────────────────────────────────┐
│  TIME RANGE  │                                    │
│              │      [CHARTS/STATS]                │
│  • 7 Days    │                                    │
│  • 4 Weeks   │   TSS/Dung/Power curves            │
│  • 12 Weeks  │                                    │
│  • Year      │                                    │
│              │                                    │
│  METRICS     │                                    │
│  • TSS       │                                    │
│  • Power     │                                    │
│  • HR        │                                    │
│  • Dung      │                                    │
└──────────────┴────────────────────────────────────┘
```

**Benefit:** Complex data views, easy to switch

---

**MY RECOMMENDATION:**

**Best Use Case: RideView (Activity Detail)**

**Why:**
1. **Most Beneficial** - RideView has the most complex data (map, stats, segments, power curve, comments)
2. **Reduces Vertical Scroll** - Currently everything stacks vertically
3. **Matches Strava** - They use this pattern on activity detail
4. **Desktop-First** - Fits our "proportional to Strava" desktop layout

**Implementation:**
```tsx
// Left control panel (200px wide, sticky)
<div className="sticky top-[80px] self-start w-[200px]">
  <BeetleCard>
    <TabButton active={view === 'overview'}>Overview</TabButton>
    <TabButton active={view === 'segments'}>Segments</TabButton>
    <TabButton active={view === 'analysis'}>Analysis</TabButton>
    <TabButton active={view === 'power'}>Power Curve</TabButton>
  </BeetleCard>
</div>

// Main content area (fluid, changes based on view)
<div className="flex-1">
  {view === 'overview' && <OverviewPanel />}
  {view === 'segments' && <SegmentsPanel />}
  {view === 'analysis' && <AnalysisPanel />}
  {view === 'power' && <PowerCurvePanel />}
</div>

// Right sidebar (280px, sticky - Dung/Kudos/Weather)
<div className="sticky top-[80px] self-start w-[280px]">
  <DungBreakdown />
  <KudosCard />
  <WeatherCard />
</div>
```

**Mobile Behavior:**
- Left control panel becomes **horizontal tabs** at top
- Right sidebar stacks below main content

---

## 📊 PRIORITY RANKING

### 🔴 **Critical (Fix Now)**
1. **Scroll Lock Fix** - Modals should prevent background scroll (UX bug)
2. **Stats Overlap Fix** - Broken layout on smaller screens

### 🟡 **Important (Fix Soon)**
3. **Sticky Sidebars** - Expected behavior, feels broken without it
4. **Notification Dropdown** - Needed feature, currently just a placeholder

### 🟢 **Enhancement (Discuss First)**
5. **Activities Tab Clarification** - Need to understand the issue
6. **Control Panel Pattern** - Nice-to-have, significant architectural change

---

## 🎬 RECOMMENDED IMPLEMENTATION ORDER

### **Session 1: Quick Fixes (30 min)**
1. Fix scroll lock hook (15 min)
2. Fix stats panel responsive grid (10 min)
3. Add sticky to sidebars (5 min)

### **Session 2: Notification Dropdown (1 hour)**
1. Create NotificationDropdown component (30 min)
2. Wire up to TopNav (15 min)
3. Add mock data (15 min)

### **Session 3: Control Panel Discussion (If Desired)**
1. Decide on which page(s) to implement
2. Design the control panel component
3. Refactor chosen page to use pattern

---

## ❓ QUESTIONS FOR YOU

1. **Stats Overlap** - Ready to implement responsive fix?
2. **Scroll Lock** - Ready to fix the hook to target body?
3. **Sticky Sidebars** - Ready to add sticky positioning?
4. **Activities Tab** - Can you clarify which tab/section needs work?
5. **Notifications** - Want full dropdown now, or mock it for later?
6. **Control Panel Pattern** - Should we implement on RideView, or just discuss for now?

---

## 🚀 MY TAKE

**Scroll Lock:** This is a **real bug** - it's jarring when background scrolls under modal. Should fix ASAP.

**Stats Overlap:** Easy responsive fix, should do it.

**Sticky Sidebars:** Missing this feature makes the feed feel less polished. Quick add.

**Notifications:** Great opportunity to add polish. I'd build a nice dropdown with mock data, ready for backend integration.

**Control Panel:** **Love this pattern** for RideView. It would clean up the vertical scroll problem and make the page feel more interactive. Would require some refactoring but worth it.

**Activities Tab:** Need you to point me to the specific issue so I can diagnose it.

---

**Ready for your direction! Which fixes should I implement first?** 🪲
