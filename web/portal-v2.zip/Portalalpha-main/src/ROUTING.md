# BoulderRoller Routing Guide

## Route Structure

### Core Pages
- `/` - **ActivityFeed** (friends feed - HOME)
- `/profile` - **BeetleView** (your beetle/profile page)

### Dashboard Dropdown Routes
- `/profile` - BeetleView (your beetle profile & gear)
- `/my-activities` - MyActivities (activity history table)
- `/my-segments` - MySegments (starred segments & attempts)
- `/data` - Data (analytics & insights)
- `/portfolio` - Portfolio (tokens & achievements)

### Explore Dropdown Routes
- `/map` - Map (discover segments on map)
- `/leaderboard` - Leaderboard (global rankings)
- `/find-friends` - FindFriends (discover riders)
- `/achievements` - Achievements (earn rewards)
- `/store` - BeetleStore (redeem dung for items)

### Detail Pages (Dynamic Routes)
- `/activities/:activityId` - RideView (single activity detail)
- `/rider/:riderId` - RiderView (other user's profile)
- `/item/:itemId` - ItemDetail (equipment with session tracking)

## Navigation Patterns

### Logo Click → Friends Feed
```tsx
<Link to="/">BOULDER ROLLER</Link>
// Returns to home (friends feed)
```

### From ActivityFeed → Activity Detail
```tsx
navigate(`/activities/${activity.id}`)
```

### From FindFriends → Rider Profile
```tsx
navigate(`/rider/${rider.beetleNumber}`)
```

### From BeetleView → Item Detail
```tsx
navigate(`/item/wheels_001`)
```

### From SearchModal
- Activity: `navigate(\`/activities/\${result.id}\`)`
- Segment: `navigate('/my-segments')` (navigate to list page)
- Rider: `navigate(\`/rider/\${result.id}\`)`

## Important Notes

1. **Home is the friends feed** (`/`) - ActivityFeed component
2. **Your profile is at `/profile`** - BeetleView component
3. **Activity routes use `/activities/` NOT `/ride/`**
4. **Rider routes use `/rider/` NOT `/athlete/`**
5. **Segments don't have detail pages yet** - navigate to `/my-segments` list instead
6. **All navigation uses React Router's `useNavigate()` hook**

## TopNav Active States

The TopNav dropdowns highlight based on current path:
- **Dashboard**: `/profile`, `/my-activities`, `/my-segments`, `/data`, `/portfolio`
- **Explore**: `/map`, `/leaderboard`, `/find-friends`, `/achievements`, `/store`