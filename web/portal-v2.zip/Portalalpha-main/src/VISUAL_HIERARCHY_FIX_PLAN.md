# 🎨 **VISUAL HIERARCHY FIX PLAN**
**Date:** December 9, 2024  
**Philosophy:** "Quiet containers, loud content"

---

## 📊 **AUDIT RESULTS**

### **✅ FOLLOWING PATTERN (No changes needed):**
1. ✅ **ActivityFeed** - 1px borders, subtle hover, bold content
2. ✅ **Profile** - Clean containers, bold avatar + stats
3. ✅ **Settings** - Simple borders, emphasis on form elements
4. ✅ **Leaderboard** - Quiet rows, loud numbers
5. ✅ **StatsPanel component** - Single container, grid inside (already correct!)

---

### **❌ NEEDS FIXING:**

## **1. RideView Header** 
**Priority:** 🔴 **HIGH** (Most visible page)

### **Current Issues:**
```tsx
// ❌ TOO HEAVY
<div className="flex items-center gap-3 mb-2">
  <span className="text-[28px]">🚴</span>           // 28px → 20px
  <h1 className="font-extrabold text-[28px]">      // extrabold → bold, 28px → 20px
    {activity.title}
  </h1>
</div>
```

### **Fix:**
```tsx
// ✅ LIGHTER, CLEANER
<div className="mb-8">
  {/* Title row */}
  <div className="flex items-center gap-2.5 mb-1.5">
    <span className="text-[20px]">🚴</span>
    <h1 className="font-['Inter'] font-bold text-[20px]" style={{ color: colors.text }}>
      {activity.title}
    </h1>
  </div>
  
  {/* Meta row */}
  <div className="flex items-center justify-between">
    <p className="font-['Cousine'] text-[12px]" style={{ color: colors.textMuted }}>
      {activity.date}
    </p>
    <div className="flex gap-2">
      <BeetleButton variant="ghost" size="sm">Edit</BeetleButton>
      <BeetleButton variant="ghost" size="sm" onClick={() => setShowDeleteModal(true)}>
        Delete
      </BeetleButton>
    </div>
  </div>
</div>
```

**Changes:**
- Icon: 28px → 20px
- Title: `font-extrabold text-[28px]` → `font-bold text-[20px]`
- Layout: Buttons move to same row as date
- Buttons: `variant="secondary"` → `variant="ghost"` (less visual weight)
- Spacing: mb-6 → mb-8 (more breathing room before content)

---

## **2. ActivityDetailModal (BeetleView)**
**Priority:** 🟡 **MEDIUM** (Modal, less frequent)

### **Current Issues:**
```tsx
// ❌ TOO HEAVY - Shadows + borders competing
<div className="rounded-[12px] border-[2px] shadow-[6px_6px_0px_0px_#2a2d1e]">
  // ❌ Icon too big
  <span className="text-[24px]">🚴</span>
  // ❌ Title too bold
  <h2 className="font-extrabold text-[22px]">{activity.title}</h2>
</div>
```

### **Fix:**
```tsx
// ✅ LIGHTER
<div className="rounded border p-8" style={{ backgroundColor: colors.bg, borderColor: colors.border }}>
  <div className="flex items-center gap-2.5 mb-1.5">
    <span className="text-[20px]">🚴</span>
    <h2 className="font-['Inter'] font-bold text-[18px]" style={{ color: colors.text }}>
      {activity.title}
    </h2>
  </div>
  <p className="font-['Cousine'] text-[12px]" style={{ color: colors.textMuted }}>
    {activity.date}
  </p>
</div>
```

**Changes:**
- Border: `border-[2px]` → `border` (1px)
- Shadow: `shadow-[6px_6px_0px_0px]` → **REMOVE** (too heavy for modal)
- Rounded: `rounded-[12px]` → `rounded` (standard 6px)
- Icon: 24px → 20px
- Title: `font-extrabold text-[22px]` → `font-bold text-[18px]`

---

## **3. UploadActivityModal**
**Priority:** 🔴 **HIGH** (Primary action)

### **Current Issues:**
```tsx
// ❌ MASSIVE VISUAL WEIGHT
<div className="rounded-[8px] border-[2px] p-8"
  style={{ boxShadow: `4px 4px 0px 0px ${colors.border}` }}
>
  <h2 className="font-black text-[20px]">📤 Upload Ride</h2>
  <div className="text-[64px] mb-4">📁</div>
  <p className="font-bold text-[16px]">Upload your ride file</p>
</div>
```

### **Fix:**
```tsx
// ✅ CLEAN, FOCUSED
<div className="rounded border p-6" style={{ backgroundColor: colors.bg, borderColor: colors.border }}>
  <div className="flex items-center justify-between mb-6">
    <h2 className="font-['Inter'] font-bold text-[16px]" style={{ color: colors.text }}>
      📤 Upload Ride
    </h2>
    <button onClick={onClose} className="text-[20px]" style={{ color: colors.textMuted }}>
      ✕
    </button>
  </div>

  <div className="text-center py-8 mb-6">
    <div className="text-[48px] mb-3">📁</div>
    <p className="font-['Inter'] text-[14px] mb-1" style={{ color: colors.text }}>
      Upload your ride file
    </p>
    <p className="font-['Inter'] text-[11px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
      .fit, .tcx, or .gpx files
    </p>
  </div>

  <div className="flex gap-3">
    <BeetleButton onClick={handleMockUpload} className="flex-1">
      Choose File
    </BeetleButton>
    <BeetleButton variant="secondary" onClick={onClose}>
      Cancel
    </BeetleButton>
  </div>
</div>
```

**Changes:**
- Border: `border-[2px]` → `border` (1px)
- Shadow: `4px 4px` → **REMOVE** (no shadow)
- Padding: p-8 → p-6 (less space)
- Title: `font-black text-[20px]` → `font-bold text-[16px]`
- Icon: 64px → 48px
- Body text: `font-bold text-[16px]` → `text-[14px]` (no bold)
- Subtitle: Added uppercase tracking for file types
- Padding: py-12 → py-8 (tighter)

---

## **4. ProfileDropdown - Reorder Menu**
**Priority:** 🟡 **MEDIUM** (UX improvement)

### **Current Order:**
```
1. Settings ⚙️
2. Edit Profile ✏️
3. Sessions 🔒 (disabled)
4. Export Data 📥
[divider]
5. Disconnect
```

### **New Order:**
```
1. Edit Profile ✏️      (most common action)
2. Settings ⚙️          (secondary)
3. Docs 📚              (new - help/documentation)
4. Export Data 📥       (tertiary)
[divider]
5. Disconnect 🔌        (danger action)
```

### **Fix:**
```tsx
{/* Menu Items */}
<div className="py-2">
  {/* 1. EDIT PROFILE - Most common */}
  <button
    onClick={onOpenEditPanel}
    className={`w-full px-4 py-2.5 ${hoverBg} transition-all flex items-center justify-between group`}
  >
    <div className="flex items-center gap-2">
      <svg>{/* edit icon */}</svg>
      <span className="font-['Inter'] text-[13px]" style={{ color: colors.text }}>
        Edit Profile
      </span>
    </div>
    <svg>{/* arrow icon */}</svg>
  </button>

  {/* 2. SETTINGS */}
  <button onClick={() => navigate('/settings')} className={/* ... */}>
    <div className="flex items-center gap-2">
      <svg>{/* settings icon */}</svg>
      <span className="font-['Inter'] text-[13px]">Settings</span>
    </div>
  </button>

  {/* 3. DOCS - NEW */}
  <button onClick={() => navigate('/docs')} className={/* ... */}>
    <div className="flex items-center gap-2">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14 2 14 8 20 8" />
        <line x1="16" y1="13" x2="8" y2="13" />
        <line x1="16" y1="17" x2="8" y2="17" />
        <polyline points="10 9 9 9 8 9" />
      </svg>
      <span className="font-['Inter'] text-[13px]">Docs</span>
    </div>
  </button>

  {/* 4. EXPORT DATA */}
  <button onClick={onExportData} className={/* ... */}>
    {/* ... */}
  </button>
</div>

{/* Disconnect - Separate section */}
<div className="p-3 border-t" style={{ borderColor: colors.border }}>
  <BeetleButton onClick={onDisconnect} variant="secondary" size="sm" className="w-full">
    Disconnect
  </BeetleButton>
</div>
```

**Changes:**
- Reorder: Edit Profile → Settings → Docs → Export
- Add: New "Docs" menu item (with file icon)
- Remove: "Sessions" (disabled/not implemented)
- Keep: Disconnect at bottom (danger action)

---

## 📝 **IMPLEMENTATION CHECKLIST**

### **Phase 1: High Priority (Do First)**
- [ ] 1. Fix RideView header (icon, title, layout)
- [ ] 2. Fix UploadActivityModal (borders, shadow, sizes)

### **Phase 2: Medium Priority (Do Next)**
- [ ] 3. Fix ActivityDetailModal (shadow, borders, sizes)
- [ ] 4. Reorder ProfileDropdown menu items
- [ ] 5. Add "Docs" link to ProfileDropdown

### **Phase 3: Audit More Components**
- [ ] 6. Check DeleteConfirmModal
- [ ] 7. Check AchievementUnlockModal
- [ ] 8. Check RideUploadSuccessModal
- [ ] 9. Check any other modals

---

## 🎯 **DESIGN RULES (Reference)**

### **Containers (Quiet):**
```css
border: 1px solid rgba(...)      /* Always 1px */
box-shadow: none                 /* No shadows on containers */
border-radius: 6px               /* Standard, or 'rounded' class */
background: cardBg or colors.bg  /* Theme-aware */
```

### **Content (Loud):**
```css
font-weight: bold                /* Never black/extrabold */
font-size: 14-20px               /* Readable, not massive */
icons: 16-20px                   /* Consistent sizing */
color: colors.text               /* Full contrast */
```

### **Modals (Special Case):**
```css
border: 1px solid colors.border  /* Same as cards */
box-shadow: none OR 2px 2px      /* Subtle if any */
padding: p-6 (24px)              /* Not p-8 */
backdrop: bg-black/40            /* Standard overlay */
```

### **Typography Hierarchy:**
```tsx
// Page titles
<h1 className="font-bold text-[20px]">Title</h1>

// Section headers
<h2 className="font-bold text-[16px]">Section</h2>

// Card titles
<h3 className="font-bold text-[14px]">Card Title</h3>

// Labels
<span className="font-bold text-[11px] uppercase tracking-wide">LABEL</span>

// Body text
<p className="text-[13px]">Regular text</p>

// Metadata
<span className="text-[12px] text-muted">Metadata</span>

// Tiny labels
<span className="text-[10px] uppercase tracking-wide text-muted">LABEL</span>
```

### **Icon Sizing:**
```tsx
// Large emphasis (avatars, empty states)
48px - 64px

// Medium emphasis (page headers, modals)
20px - 24px

// Small (inline, buttons, menu items)
14px - 16px

// Tiny (decorative)
12px
```

---

## 🔍 **BEFORE/AFTER COMPARISON**

### **RideView Header:**
```diff
- <span className="text-[28px]">🚴</span>
- <h1 className="font-extrabold text-[28px]">Morning Ride</h1>
+ <span className="text-[20px]">🚴</span>
+ <h1 className="font-bold text-[20px]">Morning Ride</h1>
```

### **Upload Modal:**
```diff
- <div className="border-[2px] shadow-[4px_4px_0px_0px]">
-   <h2 className="font-black text-[20px]">📤 Upload Ride</h2>
-   <div className="text-[64px]">📁</div>
+ <div className="border">
+   <h2 className="font-bold text-[16px]">📤 Upload Ride</h2>
+   <div className="text-[48px]">📁</div>
```

### **ActivityDetailModal:**
```diff
- <div className="rounded-[12px] border-[2px] shadow-[6px_6px_0px_0px]">
-   <h2 className="font-extrabold text-[22px]">Activity</h2>
+ <div className="rounded border">
+   <h2 className="font-bold text-[18px]">Activity</h2>
```

---

## 📏 **VISUAL WEIGHT SCALE**

Use this as reference when designing new components:

```
CONTAINERS (Quietest)
└─ 1px border, no shadow, subtle bg
   └─ Example: Card backgrounds, table rows

SECONDARY EMPHASIS
└─ Bold text (not extrabold), 13-16px
   └─ Example: Card titles, section headers

PRIMARY EMPHASIS  
└─ Bold text, 18-20px, or accent color
   └─ Example: Page titles, hero stats

MAXIMUM EMPHASIS (Loudest)
└─ Large bold numbers (42px+), glows, icons with shadows
   └─ Example: Dung amounts, achievements, big stats
```

**Rule of thumb:** If you're unsure, go quieter. Content should always be louder than its container.

---

## ✅ **READY TO EXECUTE?**

Say **"fix it all!"** and I'll:
1. Update RideView header
2. Fix UploadActivityModal
3. Fix ActivityDetailModal  
4. Reorder ProfileDropdown + add Docs
5. Create a final summary report

Or say **"fix [specific item]"** to do one at a time!
