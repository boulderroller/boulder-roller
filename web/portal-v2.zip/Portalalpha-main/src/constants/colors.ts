/**
 * SEMANTIC COLOR CONSTANTS
 * Single source of truth for all special-purpose colors across BoulderRoller
 * These complement the theme system and should be used for semantic meanings
 */

export const SEMANTIC_COLORS = {
  // Dung & Rewards - The golden treasure
  dungGlow: '#c89b5c',
  dungGlowDark: '#a8845a',
  dungDisplay: '#d4a574',
  crownGold: '#d4af37',
  
  // Activity type colors
  activityRide: '#8ba87a',
  activityAchievement: '#d4c993',
  activityReward: '#c7a76f',
  
  // Status & Feedback
  dangerRed: '#d45d5d',
  dangerDark: '#8b3a3a',
  successGreen: '#8ba87a',
  warningYellow: '#d4c993',
  
  // Rank colors
  rankS: '#d4af37', // Gold
  rankA: '#c7a76f', // Bronze-gold
  rankB: '#8ba87a', // Green
  rankC: '#a0a89a', // Gray-green
  rankD: '#6b7a5a', // Muted green
  
  // Overlays (for borders/backgrounds - theme-aware)
  overlayLight: 'rgba(42, 45, 30, 0.1)',
  overlayLightStrong: 'rgba(42, 45, 30, 0.15)',
  overlayDark: 'rgba(208, 216, 191, 0.15)',
  overlayDarkStrong: 'rgba(208, 216, 191, 0.2)',
  
  // Hover states
  hoverLight: 'rgba(139, 168, 122, 0.04)',
  hoverDark: 'rgba(139, 168, 122, 0.08)',
  
  // Dividers (very subtle)
  dividerLight: 'rgba(42, 45, 30, 0.06)',
  dividerDark: 'rgba(208, 216, 191, 0.08)',
} as const;

/**
 * GLOW EFFECTS
 * Box-shadow presets for making content "pop"
 */
export const GLOW_EFFECTS = {
  dung: '0 0 20px rgba(200, 155, 92, 0.3)',
  dungSubtle: '0 0 12px rgba(200, 155, 92, 0.15)',
  dungStrong: '0 0 24px rgba(212, 165, 116, 0.4)',
  crown: '0 0 16px rgba(212, 175, 55, 0.4)',
  achievement: '0 0 12px rgba(200, 155, 92, 0.3)',
  liveIndicator: '0 0 8px rgba(139, 168, 122, 0.5)',
} as const;

/**
 * BRUTALIST SHADOWS
 * Hard-edge shadows for beetle UI components
 */
export const BEETLE_SHADOWS = {
  sm: '2px 2px 0px 0px',
  md: '3px 3px 0px 0px',
  lg: '4px 4px 0px 0px',
} as const;

/**
 * Helper function to get theme-aware overlay colors
 */
export function getOverlay(isDarkMode: boolean, strength: 'normal' | 'strong' = 'normal'): string {
  if (isDarkMode) {
    return strength === 'strong' ? SEMANTIC_COLORS.overlayDarkStrong : SEMANTIC_COLORS.overlayDark;
  }
  return strength === 'strong' ? SEMANTIC_COLORS.overlayLightStrong : SEMANTIC_COLORS.overlayLight;
}

/**
 * Helper function to get theme-aware hover colors
 */
export function getHoverBg(isDarkMode: boolean): string {
  return isDarkMode ? SEMANTIC_COLORS.hoverDark : SEMANTIC_COLORS.hoverLight;
}

/**
 * Helper function to get theme-aware divider colors
 */
export function getDivider(isDarkMode: boolean): string {
  return isDarkMode ? SEMANTIC_COLORS.dividerDark : SEMANTIC_COLORS.dividerLight;
}

/**
 * Helper function to get accent hover/highlight colors (for dung/selected states)
 */
export function getAccentHighlight(isDarkMode: boolean, intensity: 'subtle' | 'medium' | 'strong' = 'medium'): string {
  if (isDarkMode) {
    if (intensity === 'subtle') return 'rgba(200, 155, 92, 0.05)';
    if (intensity === 'medium') return 'rgba(200, 155, 92, 0.1)';
    return 'rgba(200, 155, 92, 0.15)';
  }
  if (intensity === 'subtle') return 'rgba(200, 155, 92, 0.03)';
  if (intensity === 'medium') return 'rgba(200, 155, 92, 0.08)';
  return 'rgba(200, 155, 92, 0.12)';
}