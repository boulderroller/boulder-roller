# Strava Visual Hierarchy Applied

## Design Philosophy

We've refactored BoulderRoller to match Strava's refined visual hierarchy and proportions, following the principle: **quiet containers, loud content**.

## Key Changes Implemented

### 1. Activity Feed - The Quiet Feed
**Before:**
- Heavy 3px borders on all cards
- 4px shadows on community activity panel
- Visual weight distributed evenly

**After:**
- 1px subtle borders (`rgba` with 10-15% opacity)
- No shadows on feed cards
- Hover uses subtle background tint only (`rgba(139, 168, 122, 0.04)`)
- Visual weight concentrated on:
  - Dung badges (with glow on achievements)
  - Activity icons (2px shadows, preserved)
  - User actions and data

**Proportions:**
- Reduced header from 42px → 32px
- Tighter spacing: 8px gaps → 5px gaps
- Smaller panel radii: 12px → 8px
- More efficient padding: 6px instead of 8px

### 2. RideView - Terminal Window Aesthetic
**Layout:**
- 65/35 split: `grid-cols-[1fr_380px]` matching Strava's proportions
- Left column: Main content viewport
- Right column: Fixed 380px control panel

**Container Treatment:**
- All panels use 1px borders with subtle rgba colors
- 6px border radius (down from 12px)
- Clean, modular tile system
- Dashed borders for placeholders (lighter opacity)

**Data Emphasis:**
- Dung earned gets text-shadow glow effect
- Stats use monospace Cousine font at refined sizes
- Labels at 10px uppercase tracking-wide
- Values at 17-22px depending on hierarchy

### 3. Typography Scale (Refined)
```
Page Title: 28-32px (down from 42px)
Section Headers: 12px uppercase tracking-wide
Body Text: 12-14px
Metadata: 11px
Data Values: 17-26px monospace (Cousine)
```

### 4. Border & Shadow System

**Borders:**
- Primary containers: 1px rgba borders
- Interactive elements (buttons): 2px solid borders (preserved beetle aesthetic)
- Dashed placeholders: 1px dashed, lighter opacity

**Shadows:**
- Removed from: Feed cards, data panels, containers
- Preserved on: Buttons, dung badges, modals, dropdowns
- Achievement badges get subtle glow: `0 0 12px rgba(200, 155, 92, 0.3)`

### 5. Visual Weight Distribution

**High Priority (Heavy Treatment):**
- 🔥 Dung earned numbers (glow effect)
- 🔥 Achievement badges (enhanced shadow + glow)
- 🔥 Activity type icons (2px shadows)
- 🔥 Primary CTAs (beetle button depression)

**Medium Priority:**
- ⚡ Ride stats (larger monospace)
- ⚡ User actions
- ⚡ Ride titles

**Low Priority (Whisper):**
- 🔇 Container borders (1px rgba)
- 🔇 Timestamps
- 🔇 Metadata labels
- 🔇 Dividers

### 6. Spacing System (Strava-matched)
```
Gap between sections: 5px (was 6-8px)
Card padding: 5px (was 6-8px)
Item spacing: 2.5-3px (was 3-4px)
Outer margins: 6px (was 8px)
```

### 7. Color Strategy

**Neutral Tones (Quiet):**
- Light mode borders: `rgba(42, 45, 30, 0.1)`
- Dark mode borders: `rgba(208, 216, 191, 0.15)`
- Hover tints: `rgba(139, 168, 122, 0.04-0.08)`

**Accent Colors (Loud):**
- Dung/amber: `#c89b5c` with glow effects
- Achievement badges: Enhanced with `textShadow`
- Only used for high-value items (loot, achievements)

## Design Principles

1. **Containers Whisper, Content Shouts**
   - Remove visual weight from chrome
   - Add emphasis to data and achievements

2. **Proportional Commitment**
   - Match Strava's efficient space usage
   - Dense, scannable layouts
   - Every pixel earns its place

3. **Brutalist Where It Matters**
   - Keep 2px shadows on interactive elements (buttons, badges)
   - Terminal window feel on data panels
   - But containers remain subtle

4. **Dung as Loot**
   - Treat dung/achievements as game loot
   - Visual emphasis through glows and shadows
   - Reserved amber color palette

## Next Steps

Potential areas to continue refinement:
- Apply this system to all 11 stub pages
- Create BeetleView with "terminal control panel" layout
- Add subtle animations on loot moments
- Implement proper focus states for accessibility
- Consider adding subtle inset shadows on panels for depth
