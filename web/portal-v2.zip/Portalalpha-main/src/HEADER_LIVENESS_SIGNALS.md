# Dashboard Header - Liveness Signals

## Philosophy: "The App is Alive"

The header should answer: **"What's happening RIGHT NOW?"**

Not: "Look at your stats" (hubris)  
But: "Look at what's going on" (FOMO, social proof, urgency)

---

## Liveness Signal Ideas

### 1. **Live Segment Activity**
```
Good morning • Hawk Hill: 12 attempts in last hour 🔥
                          [View Leaderboard]  [Upload Ride]
```

**Signals:**
- Real-time segment attempts
- Creates FOMO ("I should ride that")
- Shows community is active
- Updates every minute

**Variants:**
- "Old La Honda heating up: 8 riders battling for KOM"
- "Golden Gate Sprint: 3 new PRs in last 30min"
- "Mt Tam: Sarah_Watts just took KOM (+8 positions!)"

---

### 2. **Weather + Riding Conditions**
```
Good morning • 62°F, Clear, Light wind SSW → Perfect climbing weather
                                            [Upload Ride]  [Find Routes]
```

**Signals:**
- Current local weather
- Riding recommendation based on conditions
- Changes throughout day
- Feels immediate and contextual

**Variants:**
- "58°F, Overcast → Recovery ride weather"
- "72°F, Sunny, Calm → PR hunting conditions 🎯"
- "Rain expected 3pm → Ride now or trainer later"
- "Golden hour in 45min → Sunset ride-optimal"

---

### 3. **Epoch Countdown + Prize Pool**
```
Good morning • Weekly epoch ends in 2d 8h → 1.2M CAL to distribute
                                            [View Segments]  [Upload Ride]
```

**Signals:**
- Urgency (time running out)
- Scale of rewards (big number)
- Motivates action NOW
- Updates in real-time

**Variants:**
- "Epoch ends tonight! Last chance for top 10 on Hawk Hill"
- "New epoch starts in 4h → Fresh leaderboards, new opportunities"
- "48h left → You're 2 rides from top 50 global"

---

### 4. **Recent Community Moments** (Last 10min)
```
Good morning • diesel_dave just crushed Hawk Hill KOM (-12s) 💥
                                            [Watch Effort]  [Challenge It]
```

**Signals:**
- Something JUST happened
- Creates rivalry/competition
- Social proof of activity
- Personality (rider names, emojis)

**Variants:**
- "climber_420 earned 'Century Beetle' 2 min ago"
- "3 riders are battling for Old La Honda KOM right now"
- "velo_queen just earned 847 dung (biggest ride today)"
- "Segment record broken: Golden Gate Sprint -3s!"

---

### 5. **Trending Segments** (Data-driven)
```
Good morning • 🔥 Hawk Hill: 47 attempts today (2x normal) 
                                            [Join Battle]  [Upload Ride]
```

**Signals:**
- Unusual activity (trending)
- Data comparison (vs normal)
- Hot emoji indicates heat
- Invites participation

**Variants:**
- "Old La Honda pot grew 40% today → Big competition"
- "3 segments have 5+ riders within 10s of KOM"
- "Mt Tam seeing double usual traffic → Join the action"

---

### 6. **Friends Activity** (Social)
```
Good morning • tt_master riding Old La Honda now • climber_420 PR'd 12min ago
                                                    [Kudos]  [Upload Ride]
```

**Signals:**
- Your network is active
- Real-time presence
- Social connection
- Peer motivation

**Variants:**
- "3 friends rode this morning → You're next"
- "diesel_dave is hunting your Hawk Hill time"
- "5 friends online now → Challenge them"

---

### 7. **Global Pulse** (Platform health)
```
Good morning • 127 riders active • 34 segments ridden today • 12k dung flowing
                                                    [Explore]  [Upload Ride]
```

**Signals:**
- Platform scale/activity
- Multiple metrics = vitality
- Numbers updating = alive
- Community size

**Variants:**
- "89 riders online • 18 KOMs changing hands today"
- "BoulderRoller burning: 340 rides uploaded in last 24h"
- "Platform record: 1,847 segments attempted this week"

---

### 8. **Personal Nudge + Community Context**
```
Good morning • You're 1 ride from 10-day streak → 43 riders hit it this week
                                                   [Let's Go]  [View Streaks]
```

**Signals:**
- Personal goal (not hubris, it's motivational)
- Social proof (others doing it)
- Achievable target
- FOMO (others are succeeding)

---

### 9. **Market/Economic Signals** (Web3 angle)
```
Good morning • DUNG price up 12% → Your 2,847 worth $341 (+$37)
                                    [View Portfolio]  [Trade]
```

**Signals:**
- Financial relevance
- Real-time price movement
- Your stake in the game
- Web3 engagement

**Variants:**
- "Hawk Hill pot: 45k CAL → 11 DUNG if you take KOM"
- "Staking yields 8% APY this week → Consider locking"
- "Gas low on Solana → Cheap to mint achievements"

---

### 10. **Hybrid: Rotating Liveness**

Cycle through different signals every 10-30 seconds:

```
Rotation 1: Weather-based
Good morning • 62°F, Perfect climbing conditions → Old La Honda calling

Rotation 2: Recent activity
Good morning • diesel_dave just took Hawk Hill KOM 💥 → 3min ago

Rotation 3: Epoch urgency  
Good morning • 2d 8h left in epoch → 450k CAL in play

Rotation 4: Community pulse
Good morning • 89 riders active • 23 KOMs contested today
```

**Signals:**
- Always fresh
- Multiple types of liveness
- No single point of failure
- Maximum engagement surface

---

## Recommended Implementation

### **Primary: Weather + Live Activity**

```tsx
<div className="mb-6 px-2 sm:px-0">
  <div className="flex items-center justify-between">
    {/* Left: Greeting + Liveness Signal */}
    <div className="flex-1">
      <h1 className="font-['Inter'] font-bold text-[20px] tracking-tight mb-0.5" style={{ color: colors.text }}>
        Good morning
      </h1>
      
      {/* LIVENESS SIGNAL - Changes based on context */}
      <div className="flex items-center gap-3">
        {/* Weather */}
        <span className="font-['Inter'] text-[12px]" style={{ color: colors.textMuted }}>
          62°F, Clear, Light wind → Perfect climbing
        </span>
        
        <span style={{ color: colors.textMuted }}>•</span>
        
        {/* Live Activity */}
        <span className="font-['Inter'] text-[12px]" style={{ color: colors.accent }}>
          Hawk Hill: 12 attempts in last hour 🔥
        </span>
      </div>
    </div>
    
    {/* Right: CTAs */}
    <div className="flex items-center gap-2">
      <BeetleButton variant="secondary" size="sm">
        View Segments
      </BeetleButton>
      <BeetleButton variant="primary" size="sm">
        Upload Ride
      </BeetleButton>
    </div>
  </div>
</div>
```

### Why This Works:
- ✅ **Immediate context** - Weather tells you to ride NOW
- ✅ **Social proof** - Others are riding (FOMO)
- ✅ **Not about you** - It's about the world around you
- ✅ **Actionable** - Weather + hot segment = clear call to action
- ✅ **Updates frequently** - Weather changes, activity changes
- ✅ **Dual liveness** - Two independent signals

---

## Priority Ranking (Most to Least "Alive")

1. **Recent Community Moments** - "diesel_dave just took KOM 3min ago" ⭐⭐⭐⭐⭐
2. **Live Segment Activity** - "12 attempts in last hour" ⭐⭐⭐⭐⭐
3. **Weather + Conditions** - "62°F, Perfect climbing" ⭐⭐⭐⭐
4. **Epoch Countdown** - "2d 8h left → 450k CAL in play" ⭐⭐⭐⭐
5. **Trending Segments** - "2x normal activity" ⭐⭐⭐⭐
6. **Friends Activity** - "tt_master riding now" ⭐⭐⭐⭐
7. **Global Pulse** - "127 riders active" ⭐⭐⭐
8. **Market Signals** - "DUNG +12%" ⭐⭐⭐
9. **Personal Nudge** - "1 ride from 10-day streak" ⭐⭐

---

## Technical Implementation

### Data Sources Needed:
- **Weather**: OpenWeather API (free tier)
- **Live Activity**: WebSocket or polling recent segments
- **Community Events**: Event stream of achievements, KOMs
- **Epoch Timer**: Simple countdown
- **Trending**: Analytics on segment attempts (rolling window)
- **Friends**: User relationship graph + recent activity

### Mock Data for Now:
```tsx
const livenessSignals = {
  weather: {
    temp: 62,
    conditions: 'Clear',
    wind: 'Light SSW',
    recommendation: 'Perfect climbing'
  },
  liveActivity: {
    segment: 'Hawk Hill',
    attempts: 12,
    window: '1 hour'
  },
  recentMoment: {
    rider: 'diesel_dave',
    action: 'took KOM on Hawk Hill',
    delta: '-12s',
    ago: '3min'
  },
  epochCountdown: {
    days: 2,
    hours: 8,
    prizePool: 450000
  }
};
```

### Rotation Logic:
```tsx
const [currentSignal, setCurrentSignal] = useState(0);

useEffect(() => {
  const interval = setInterval(() => {
    setCurrentSignal(prev => (prev + 1) % 3); // Rotate through 3 signals
  }, 20000); // Every 20 seconds
  
  return () => clearInterval(interval);
}, []);
```

---

## Decision Matrix

| Signal | Alive? | FOMO? | Actionable? | Easy to Mock? | Complexity |
|--------|--------|-------|-------------|---------------|------------|
| Live Segment Activity | ✅✅✅ | ✅✅✅ | ✅✅ | ✅ | Medium |
| Recent Moments | ✅✅✅ | ✅✅✅ | ✅✅ | ✅✅ | Low |
| Weather | ✅✅ | ✅ | ✅✅✅ | ✅ | Low |
| Epoch Countdown | ✅✅ | ✅✅✅ | ✅✅ | ✅✅ | Low |
| Trending Segments | ✅✅✅ | ✅✅✅ | ✅✅ | ✅ | Medium |
| Friends Activity | ✅✅✅ | ✅✅ | ✅✅ | ✅ | Medium |
| Global Pulse | ✅✅ | ✅ | ✅ | ✅✅ | Low |

---

## Recommended MVP Approach

**Phase 1 (Now):** Mock rotating signals
```
Rotation 1: Weather hint
Rotation 2: Recent community moment  
Rotation 3: Epoch countdown
```

**Phase 2:** Real weather API integration

**Phase 3:** Real-time segment activity tracking

**Phase 4:** WebSocket for live events

---

## Example Messages (Copy Bank)

### Weather-based:
- "58°F, Light breeze → Recovery ride weather"
- "72°F, Sunny, Calm → PR hunting conditions 🎯"
- "Perfect climbing temp → Old La Honda awaits"
- "Rain coming 3pm → Ride now or trainer later"

### Live Activity:
- "Hawk Hill: 12 attempts in last hour 🔥"
- "Old La Honda heating up: 8 riders online"
- "Golden Gate Sprint: 3 new PRs in 30min"
- "Mt Tam battle: 5 riders within 10s of KOM"

### Recent Moments:
- "diesel_dave crushed Hawk Hill KOM 3min ago 💥"
- "climber_420 earned 'Century Beetle' just now"
- "Sarah_Watts took #1 on Old La Honda (+8 spots!)"
- "Segment record broken: Golden Gate -3s"

### Epoch:
- "Epoch ends in 2d 8h → 1.2M CAL to distribute"
- "Last chance: 12h until weekly reset"
- "New epoch in 4h → Fresh leaderboards"
- "48h left → 450k CAL in play"

---

## UI Mockup (Final Recommendation)

```
┌────────────────────────────────────────────────────────────────┐
│ Good morning                                [View]  [Upload]   │
│ 62°F, Clear → Perfect climbing • Hawk Hill: 12 attempts/hr 🔥 │
└────────────────────────────────────────────────────────────────┘
```

Height: **~60px**  
Signals: **2 liveness indicators** (weather + activity)  
Updates: **Every 20-30 seconds** (rotation)  
Feel: **Alive, breathing, urgent**

Want me to implement this?
