# 🪲 DESIGN DEVOTION REVIEW
**Quality Bar Check: Does This Match Our Existing Polish?**

---

## 📐 OUR DESIGN PRINCIPLES (Established)

### **1. Quiet Containers, Loud Content**
- Containers: 1px borders, no shadows, whisper
- Data: MASSIVE numbers, glowing dung, shouts

### **2. Visual Hierarchy Through Scale**
- Hero stats: **64px** Cousine (Distance, Time, Elevation)
- Secondary stats: **36px** Cousine (Power, HR)
- Tertiary stats: **20px** Cousine (Detailed metrics)
- Labels: **10-11px** Inter uppercase tracking-wide

### **3. Brutalist Precision**
- Grids use explicit column definitions: `grid-cols-[140px_1fr_1fr]`
- Gaps are intentional: 4px, 6px, 8px (never random)
- Dividers separate content types
- Everything has a reason

### **4. Svelte & Dense**
- No wasted space
- Tight line-heights: `leading-none` on numbers
- Compact but readable
- Information density = high value

### **5. Beetle Aesthetic**
- Dung glows: `textShadow: '0 0 20px rgba(200, 155, 92, 0.3)'`
- Cousine for all numbers (monospace brutalism)
- Inter for labels (geometric clarity)
- Earth tones: `#c89b5c`, `#8ba87a`, `#2a2d1e`

---

## 🔍 TASK-BY-TASK DESIGN DEVOTION CHECK

---

## ✅ **TASK 1: Fix Stats Panel Overlap (RideView)**

### **Current Quality: A+**
Already follows our principles perfectly. Just needs responsive grid.

### **Proposed Fix:**
```tsx
// Simple responsive adjustment
<div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8">
```

### **Design Devotion: ✅ APPROVED**
- Maintains 64px hero stats
- Keeps visual hierarchy
- No compromise on aesthetics
- Just adds breakpoints

**Time:** 10 minutes  
**Impact:** Fixes layout without sacrificing design

---

## ✅ **TASK 2: Fix Scroll Lock (Modals)**

### **Current Quality: B (Functional but wrong target)**

### **Proposed Fix:**
```tsx
// Lock body, not main
document.body.style.overflow = 'hidden';
document.body.style.paddingRight = `${scrollbarWidth}px`;
```

### **Design Devotion: ✅ APPROVED**
- Pure UX fix, no visual changes
- Prevents layout shift (adds scrollbar padding)
- Professional polish

**Time:** 15 minutes  
**Impact:** Critical UX improvement

---

## ✅ **TASK 3: Add Sticky Sidebars (ActivityFeed)**

### **Current Quality: A (Design is perfect, just missing sticky)**

### **Proposed Fix:**
```tsx
// Add sticky positioning to both sidebars
<div className="space-y-4 sticky top-[80px] self-start">
```

### **Design Devotion: ✅ APPROVED**
- No design changes
- Pure behavior improvement
- Matches Strava pattern

**Time:** 5 minutes  
**Impact:** Expected behavior, feels polished

---

## ❌ **TASK 4: Profile Activities Tab - NEEDS REDESIGN**

### **Current Quality: D- (Lazy design, no devotion)**

### **What I Proposed (WEAK):**
```tsx
// Just stats in a row? Come on.
<div className="flex items-center gap-6 font-['Cousine'] text-[13px]">
  <div>
    <span className="font-bold">{activity.distance}</span>
    <span className="ml-1">km</span>
  </div>
  // ... more boring inline stats
</div>
```

**Problems:**
- ❌ No visual hierarchy (everything 13px)
- ❌ No massive numbers
- ❌ Dung badge doesn't glow
- ❌ No thoughtful grid layout
- ❌ Looks like a junior dev made it

---

### **REDESIGNED WITH DEVOTION:**

#### **UserActivityCard (PROPER VERSION)**

```tsx
<div className="rounded border overflow-hidden" style={{ borderColor, backgroundColor }}>
  {/* Header Section - Dense */}
  <div className="px-5 py-3 border-b" style={{ borderColor: dividerColor }}>
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <span className="text-[20px]">{activity.type === 'ride' ? '🚴' : '🏃'}</span>
        <h4 className="font-['Inter'] text-[13px] font-bold" style={{ color: colors.text }}>
          {activity.name}
        </h4>
      </div>
      <div className="font-['Cousine'] text-[10px]" style={{ color: colors.textMuted }}>
        {activity.date}
      </div>
    </div>
  </div>

  {/* Stats Grid - MASSIVE NUMBERS */}
  <div className="px-5 py-4">
    <div className="grid grid-cols-[1fr_1fr_1fr_140px] gap-6 items-end">
      
      {/* Distance - HERO */}
      <div>
        <div className="font-['Cousine'] text-[32px] font-bold leading-none mb-1" style={{ color: colors.text }}>
          {activity.distance}
          <span className="text-[14px] ml-1" style={{ color: colors.textMuted }}>km</span>
        </div>
        <div className="font-['Inter'] text-[9px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
          Distance
        </div>
      </div>

      {/* Elevation - HERO */}
      <div>
        <div className="font-['Cousine'] text-[32px] font-bold leading-none mb-1" style={{ color: colors.text }}>
          ↗ {activity.elevation}
          <span className="text-[14px] ml-1" style={{ color: colors.textMuted }}>m</span>
        </div>
        <div className="font-['Inter'] text-[9px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
          Elevation
        </div>
      </div>

      {/* Duration - HERO */}
      <div>
        <div className="font-['Cousine'] text-[32px] font-bold leading-none mb-1" style={{ color: colors.text }}>
          {activity.duration}
        </div>
        <div className="font-['Inter'] text-[9px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
          Moving Time
        </div>
      </div>

      {/* Dung - GLOWING EMPHASIS */}
      <div className="text-right">
        <div 
          className="font-['Cousine'] text-[36px] font-bold leading-none mb-1"
          style={{ 
            color: colors.accent,
            textShadow: isDarkMode ? '0 0 20px rgba(200, 155, 92, 0.4)' : '0 0 12px rgba(200, 155, 92, 0.3)'
          }}
        >
          +{activity.dungEarned}
        </div>
        <div className="font-['Inter'] text-[9px] uppercase tracking-wide" style={{ color: colors.textMuted }}>
          CAL Earned 🪲
        </div>
      </div>

    </div>
  </div>

  {/* Secondary Stats - Smaller but Still Precise */}
  <div 
    className="px-5 py-3 border-t" 
    style={{ 
      borderColor: dividerColor,
      backgroundColor: isDarkMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.02)'
    }}
  >
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-6 font-['Cousine'] text-[12px]" style={{ color: colors.textMuted }}>
        <div>
          <span className="font-['Inter'] text-[9px] uppercase tracking-wide mr-1.5">TSS</span>
          <span className="font-bold" style={{ color: colors.text }}>{activity.tss}</span>
        </div>
        <div>
          <span className="font-['Inter'] text-[9px] uppercase tracking-wide mr-1.5">Avg Power</span>
          <span className="font-bold" style={{ color: colors.text }}>{activity.avgPower}w</span>
        </div>
        <div>
          <span className="font-['Inter'] text-[9px] uppercase tracking-wide mr-1.5">NP</span>
          <span className="font-bold" style={{ color: colors.text }}>{activity.normalizedPower}w</span>
        </div>
      </div>
      
      {/* View Details Arrow */}
      <div 
        className="font-['Inter'] text-[10px] font-bold uppercase tracking-wide flex items-center gap-1.5"
        style={{ color: colors.accent }}
      >
        View Details
        <span>→</span>
      </div>
    </div>
  </div>
</div>
```

---

#### **Visual Comparison:**

**OLD (Lazy) Design:**
```
┌────────────────────────────────────────────┐
│ 🚴 Morning Climb              Dec 7        │
│ 87 km • 2,140 m • 3:24:15 • TSS 342  +342  │
└────────────────────────────────────────────┘
```
Everything same size, no hierarchy, boring.

---

**NEW (Devotion) Design:**
```
┌──────────────────────────────────────────────────────┐
│ 🚴 Morning Alpine Grind                   Dec 7, 2024│
├──────────────────────────────────────────────────────┤
│                                                      │
│   87        ↗ 2,140      3:24:15          +342      │
│   km          m                           ⚡          │
│   DISTANCE    ELEVATION   MOVING TIME     CAL EARNED │
│                                                      │
├──────────────────────────────────────────────────────┤
│ TSS 342 • Avg Power 268w • NP 285w    View Details → │
└──────────────────────────────────────────────────────┘
```

**Key Improvements:**
- ✅ **32-36px hero numbers** (Distance, Elevation, Time, Dung)
- ✅ **Dung glows** with textShadow
- ✅ **Grid layout** with precise columns
- ✅ **Dividers** separate sections (header/stats/secondary)
- ✅ **Secondary stats** in footer (subtle background)
- ✅ **Visual hierarchy** - data SHOUTS
- ✅ **Beetle aesthetic** throughout

---

### **FilterPill - Also Needs Devotion:**

**OLD (Basic):**
```tsx
<button className="px-3 py-1.5 rounded-full">
  All
</button>
```

**NEW (Beetle-Style):**
```tsx
<button
  className="px-3.5 py-2 rounded border-2 font-['Inter'] text-[10px] font-black uppercase tracking-wide transition-all duration-100"
  style={{
    backgroundColor: active ? colors.accent : 'transparent',
    borderColor: active ? colors.accent : borderColor,
    color: active ? '#2a2d1e' : colors.textMuted,
    boxShadow: active ? `2px 2px 0px 0px ${colors.accent}` : 'none',
    transform: active ? 'none' : 'translateY(0)',
  }}
  onMouseDown={(e) => {
    if (active) e.currentTarget.style.transform = 'translateY(1px)';
  }}
  onMouseUp={(e) => {
    e.currentTarget.style.transform = 'translateY(0)';
  }}
>
  {children}
</button>
```

**Improvements:**
- ✅ Border-2 (not 1px - more brutalist)
- ✅ Box shadow on active (beetle depress)
- ✅ Transform on click (tactile feedback)
- ✅ Font-black (heavier weight)
- ✅ Uppercase tracking-wide (architectural)

---

### **Design Devotion: ✅ APPROVED (After Redesign)**

**Time:** 60 minutes (was 45 - worth the extra polish)  
**Impact:** Matches our quality bar, worthy of the app

---

## ⚠️ **TASK 5: Notification Dropdown - NEEDS DEPTH**

### **Current Quality: Not yet designed**

### **What I Proposed (Surface-level):**
Just a basic dropdown with notification items. No real thought about hierarchy, interaction, or polish.

---

### **REDESIGNED WITH DEVOTION:**

#### **NotificationDropdown Component**

```tsx
<div 
  className="absolute top-[64px] right-4 w-[380px] rounded border-2 overflow-hidden shadow-[4px_4px_0px_0px_rgba(42,45,30,0.2)] z-50"
  style={{ 
    backgroundColor: cardBg,
    borderColor: borderColorStrong,
  }}
>
  {/* Header - Dense */}
  <div className="px-5 py-4 border-b-2" style={{ borderColor: borderColorStrong }}>
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2.5">
        <span className="text-[16px]">🔔</span>
        <h3 className="font-['Inter'] text-[13px] font-black uppercase tracking-wide" style={{ color: colors.text }}>
          Notifications
        </h3>
        {/* Unread count badge */}
        <div 
          className="px-2 py-0.5 rounded-full border-2"
          style={{ 
            backgroundColor: colors.accent,
            borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
          }}
        >
          <span className="font-['Cousine'] text-[10px] font-bold" style={{ color: 'white' }}>
            3
          </span>
        </div>
      </div>
      
      {/* Close button */}
      <button
        onClick={onClose}
        className="w-6 h-6 rounded border flex items-center justify-center transition-all"
        style={{ borderColor }}
      >
        <span className="text-[14px]">×</span>
      </button>
    </div>
  </div>

  {/* Notifications List */}
  <div className="max-h-[480px] overflow-y-auto">
    {notifications.map((notif, index) => (
      <div
        key={notif.id}
        className="border-b px-5 py-4 cursor-pointer transition-all"
        style={{ 
          borderColor: dividerColor,
          backgroundColor: notif.read ? 'transparent' : (isDarkMode ? 'rgba(200, 155, 92, 0.05)' : 'rgba(200, 155, 92, 0.03)'),
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = isDarkMode ? 'rgba(200, 155, 92, 0.08)' : 'rgba(200, 155, 92, 0.05)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = notif.read ? 'transparent' : (isDarkMode ? 'rgba(200, 155, 92, 0.05)' : 'rgba(200, 155, 92, 0.03)');
        }}
      >
        {/* Different layouts based on notification type */}
        {notif.type === 'kudos' && (
          <div className="flex items-start gap-3">
            <div className="text-[20px] flex-shrink-0">👍</div>
            <div className="flex-1">
              <p className="font-['Inter'] text-[12px] leading-relaxed mb-1" style={{ color: colors.text }}>
                <span className="font-bold">@{notif.from}</span> gave you kudos
              </p>
              <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                {notif.activityName} • {notif.time}
              </div>
            </div>
          </div>
        )}

        {notif.type === 'pr' && (
          <div className="flex items-start gap-3">
            <div className="text-[20px] flex-shrink-0">🏆</div>
            <div className="flex-1">
              <p className="font-['Inter'] text-[12px] font-bold leading-relaxed mb-1.5" style={{ color: colors.accent }}>
                New Personal Record!
              </p>
              <p className="font-['Inter'] text-[12px] leading-relaxed mb-1" style={{ color: colors.text }}>
                You ranked <span className="font-['Cousine'] font-bold">#{notif.rank}</span> on {notif.segmentName}
              </p>
              <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                {notif.time}
              </div>
            </div>
            {/* Rank badge */}
            <div 
              className="px-2.5 py-1.5 rounded border-2 flex-shrink-0"
              style={{ 
                backgroundColor: colors.accent,
                borderColor: isDarkMode ? '#2a2d1e' : '#1a1d0e',
              }}
            >
              <div className="font-['Cousine'] text-[16px] font-bold leading-none" style={{ color: 'white' }}>
                #{notif.rank}
              </div>
            </div>
          </div>
        )}

        {notif.type === 'achievement' && (
          <div className="flex items-start gap-3">
            <div className="text-[28px] flex-shrink-0">{notif.emoji}</div>
            <div className="flex-1">
              <p className="font-['Inter'] text-[12px] font-bold leading-relaxed mb-1" style={{ color: colors.accent }}>
                Achievement Unlocked!
              </p>
              <p className="font-['Inter'] text-[13px] font-bold leading-relaxed mb-1" style={{ color: colors.text }}>
                {notif.achievementName}
              </p>
              <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                +{notif.dungReward} CAL • {notif.time}
              </div>
            </div>
            {/* Dung reward - GLOWING */}
            <div className="flex-shrink-0">
              <div 
                className="font-['Cousine'] text-[20px] font-bold leading-none"
                style={{ 
                  color: colors.accent,
                  textShadow: isDarkMode ? '0 0 16px rgba(200, 155, 92, 0.5)' : '0 0 10px rgba(200, 155, 92, 0.4)'
                }}
              >
                +{notif.dungReward}
              </div>
            </div>
          </div>
        )}

        {notif.type === 'dung_payout' && (
          <div className="flex items-start gap-3">
            <div className="text-[20px] flex-shrink-0">🪲</div>
            <div className="flex-1">
              <p className="font-['Inter'] text-[12px] font-bold leading-relaxed mb-1" style={{ color: colors.accent }}>
                Period Payout Received
              </p>
              <p className="font-['Inter'] text-[12px] leading-relaxed mb-1" style={{ color: colors.text }}>
                You earned <span className="font-['Cousine'] font-bold">{notif.calAmount} CAL</span> this period
              </p>
              <div className="font-['Inter'] text-[11px]" style={{ color: colors.textMuted }}>
                Converted to {notif.dungAmount} DUNG • {notif.time}
              </div>
            </div>
            {/* MASSIVE glowing dung */}
            <div className="flex-shrink-0">
              <div 
                className="font-['Cousine'] text-[28px] font-bold leading-none"
                style={{ 
                  color: colors.accent,
                  textShadow: isDarkMode ? '0 0 24px rgba(200, 155, 92, 0.6)' : '0 0 16px rgba(200, 155, 92, 0.5)'
                }}
              >
                {notif.dungAmount}
              </div>
              <div className="font-['Inter'] text-[8px] uppercase tracking-wide text-center" style={{ color: colors.textMuted }}>
                DUNG
              </div>
            </div>
          </div>
        )}
      </div>
    ))}
  </div>

  {/* Footer - View All */}
  <div 
    className="px-5 py-3 border-t-2 text-center cursor-pointer transition-all"
    style={{ 
      borderColor: borderColorStrong,
      backgroundColor: isDarkMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.02)',
    }}
    onClick={() => navigate('/notifications')}
    onMouseEnter={(e) => {
      e.currentTarget.style.backgroundColor = isDarkMode ? 'rgba(0, 0, 0, 0.15)' : 'rgba(0, 0, 0, 0.04)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.backgroundColor = isDarkMode ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.02)';
    }}
  >
    <span 
      className="font-['Inter'] text-[11px] font-bold uppercase tracking-wide"
      style={{ color: colors.accent }}
    >
      View All Notifications ({totalCount}) →
    </span>
  </div>
</div>
```

---

#### **Key Design Decisions:**

**1. Different Layouts Per Type**
- Kudos: Simple user mention
- PR: Rank badge prominent (LOUD)
- Achievement: Emoji + glowing dung reward
- Payout: MASSIVE glowing dung number (celebration)

**2. Visual Hierarchy**
- Most important info: 12-13px bold
- Secondary info: 11px regular
- Numbers: Cousine font (brutalist)
- Rewards: GLOW (textShadow)

**3. Interaction**
- Unread: Subtle background tint
- Hover: Stronger background
- Click: Navigate to relevant page
- Tactile feedback on all interactions

**4. Beetle Aesthetic**
- Border-2 (not 1px)
- Box shadow: `4px 4px 0px` brutalist shadow
- Dung glows everywhere
- Dense but scannable

---

### **Mock Data Structure:**
```tsx
const mockNotifications = [
  {
    id: '1',
    type: 'kudos',
    from: 'climber_420',
    activityName: 'Morning Climb',
    time: '2h ago',
    read: false,
  },
  {
    id: '2',
    type: 'pr',
    segmentName: 'Hawk Hill',
    rank: 12,
    time: '5h ago',
    read: false,
  },
  {
    id: '3',
    type: 'achievement',
    achievementName: 'Century Beetle',
    emoji: '🏆',
    dungReward: 500,
    time: '1d ago',
    read: false,
  },
  {
    id: '4',
    type: 'dung_payout',
    calAmount: '1,247',
    dungAmount: '247',
    time: '2d ago',
    read: true,
  },
];
```

---

### **Design Devotion: ✅ APPROVED (After Redesign)**

**Time:** 90 minutes (was 60 - worth it for proper polish)  
**Impact:** Every notification type has thoughtful design, matches our quality bar

---

## 💭 **TASK 6: Control Panel Pattern - NEEDS STRATEGIC DEPTH**

### **Current Quality: Concept only, no implementation**

This isn't just about adding tabs - it's about **reimagining the information architecture** of complex pages.

---

### **DEEPER ANALYSIS:**

#### **Where This Pattern REALLY Shines:**

**1. RideView (Activity Detail) - HIGHEST VALUE**

**Current Problem:**
- Everything stacks vertically
- Scroll to see power curve (way down)
- Segments table interrupts flow
- Map/stats/charts all compete for attention

**Control Panel Solution:**
```
┌────────────┬─────────────────────────────────┬─────────┐
│ VIEW       │                                 │ DUNG    │
│            │                                 │ KUDOS   │
│ • Overview │     [MAIN CONTENT AREA]        │ WEATHER │
│ • Segments │     Changes based on selection  │         │
│ • Power    │                                 │         │
│ • HR Zones │                                 │         │
│ • Map      │                                 │         │
│            │                                 │         │
│ ACTIONS    │                                 │         │
│ • Edit     │                                 │         │
│ • Share    │                                 │         │
│ • Delete   │                                 │         │
└────────────┴─────────────────────────────────┴─────────┘
```

**Benefits:**
- ✅ No vertical scroll hell
- ✅ Quick switching between views
- ✅ Actions grouped logically
- ✅ Main content area stays focused
- ✅ Right sidebar always visible (context)

**Control Panel Design (LEFT):**
```tsx
<div className="w-[200px] sticky top-[80px] self-start space-y-6">
  {/* View Tabs */}
  <div 
    className="rounded border-2 overflow-hidden"
    style={{ backgroundColor: cardBg, borderColor: borderColorStrong }}
  >
    <div className="px-4 py-3 border-b-2" style={{ borderColor: borderColorStrong }}>
      <h4 className="font-['Inter'] text-[10px] font-black uppercase tracking-wide" style={{ color: colors.textMuted }}>
        View
      </h4>
    </div>
    
    {[
      { id: 'overview', label: 'Overview', icon: '📊' },
      { id: 'segments', label: 'Segments', icon: '🏔️' },
      { id: 'power', label: 'Power Curve', icon: '⚡' },
      { id: 'hr-zones', label: 'HR Zones', icon: '❤️' },
      { id: 'map', label: 'Map', icon: '🗺️' },
    ].map((view) => (
      <button
        key={view.id}
        onClick={() => setView(view.id)}
        className="w-full px-4 py-3 border-b text-left transition-all"
        style={{
          borderColor: dividerColor,
          backgroundColor: activeView === view.id 
            ? (isDarkMode ? 'rgba(138, 168, 122, 0.15)' : 'rgba(138, 168, 122, 0.1)')
            : 'transparent',
          color: activeView === view.id ? colors.accent : colors.text,
        }}
      >
        <div className="flex items-center gap-2.5">
          <span className="text-[14px]">{view.icon}</span>
          <span className="font-['Inter'] text-[12px] font-bold">
            {view.label}
          </span>
        </div>
      </button>
    ))}
  </div>

  {/* Actions */}
  <div 
    className="rounded border-2 overflow-hidden"
    style={{ backgroundColor: cardBg, borderColor: borderColorStrong }}
  >
    <div className="px-4 py-3 border-b-2" style={{ borderColor: borderColorStrong }}>
      <h4 className="font-['Inter'] text-[10px] font-black uppercase tracking-wide" style={{ color: colors.textMuted }}>
        Actions
      </h4>
    </div>
    
    <div className="p-3 space-y-2">
      <BeetleButton variant="secondary" size="sm" fullWidth>
        Edit Activity
      </BeetleButton>
      <BeetleButton variant="secondary" size="sm" fullWidth>
        Share
      </BeetleButton>
      <BeetleButton variant="ghost" size="sm" fullWidth onClick={() => setShowDeleteModal(true)}>
        Delete
      </BeetleButton>
    </div>
  </div>
</div>
```

---

**2. Data/Training Page - MEDIUM VALUE**

Good for switching time ranges and metric types, but less critical than RideView.

**3. Profile/ActivityFeed - LOW VALUE**

Tabs work fine here, don't need full control panel pattern.

---

### **Design Devotion: ✅ APPROVED FOR RIDVIEW**

**Recommendation:** Implement control panel for RideView ONLY (not everywhere)

**Time:** 2 hours (significant refactor, but worth it)  
**Impact:** Transforms activity detail page from scroll-heavy to elegant

---

## 📊 FINAL TASK LIST (Prioritized by Impact & Devotion)

### **🔴 PHASE 1: Critical Fixes (1 hour total)**
**Must-haves for production quality**

1. **Fix Scroll Lock** (15 min) ✅ APPROVED
   - Pure UX bug fix
   - Prevents background scroll
   - Professional polish

2. **Fix Stats Panel Responsive Grid** (10 min) ✅ APPROVED
   - Broken layout on smaller screens
   - Simple breakpoint addition
   - No design compromise

3. **Add Sticky Sidebars** (5 min) ✅ APPROVED
   - Expected behavior missing
   - Pure CSS addition
   - Matches Strava

4. **Test All Three Fixes** (30 min)
   - Desktop/tablet/mobile
   - Dark/light mode
   - All modals

---

### **🟡 PHASE 2: Profile Activities Tab (1.5 hours)**
**Polish to match existing quality bar**

5. **Create FilterPill Component** (15 min) ✅ REDESIGNED
   - Beetle-style with border-2
   - Box shadow, depress effect
   - Font-black, uppercase

6. **Create UserActivityCard** (30 min) ✅ REDESIGNED
   - MASSIVE numbers (32-36px)
   - Glowing dung
   - Grid layout with dividers
   - Secondary stats footer

7. **Create UserActivitiesList** (30 min) ✅ APPROVED
   - Filter logic
   - Mock data (15-20 activities)
   - Load more functionality

8. **Update Profile.tsx** (15 min) ✅ APPROVED
   - Replace ActivityFeed
   - Wire up new component

---

### **🟢 PHASE 3: Notification Dropdown (1.5 hours)**
**Signature feature polish**

9. **Create NotificationDropdown** (60 min) ✅ REDESIGNED
   - Different layouts per type (kudos/PR/achievement/payout)
   - Glowing dung on rewards
   - Visual hierarchy
   - Unread states, hover states

10. **Create Mock Notification Data** (15 min) ✅ DESIGNED
    - 10-15 varied notifications
    - Different types
    - Read/unread mix

11. **Wire to TopNav** (15 min) ✅ APPROVED
    - Toggle dropdown
    - Click outside to close
    - ESC key handler
    - Scroll lock

---

### **🔵 PHASE 4: Control Panel (RideView Only) (2 hours)**
**Architectural improvement**

12. **Design View Switching Logic** (30 min)
    - Which views to include
    - Content for each view
    - Transition behavior

13. **Create Control Panel Component** (30 min) ✅ DESIGNED
    - View selector
    - Actions section
    - Beetle-style cards

14. **Refactor RideView Layout** (45 min)
    - Extract content into view components
    - Wire up view switching
    - Maintain right sidebar

15. **Test & Polish** (15 min)
    - Smooth transitions
    - Responsive behavior
    - State persistence

---

## ⏱️ TOTAL TIME ESTIMATE

**Phase 1:** 1 hour (Critical)  
**Phase 2:** 1.5 hours (Important)  
**Phase 3:** 1.5 hours (Polish)  
**Phase 4:** 2 hours (Enhancement)  

**Grand Total:** **6 hours to production-ready** 🪲

---

## ✅ QUALITY CHECKPOINTS

Before moving to next phase, verify:

- [ ] **Visual Hierarchy** - Numbers use 32px+, labels 9-11px
- [ ] **Dung Glows** - All dung uses textShadow
- [ ] **Grids Are Precise** - No flex with random gaps, use grid-cols-[explicit]
- [ ] **Borders Whisper** - 1px for containers (2px for emphasis elements)
- [ ] **Cousine for Numbers** - All metrics use monospace
- [ ] **Inter for Labels** - All text uses geometric sans
- [ ] **Dividers Separate** - Different content types have visual breaks
- [ ] **Hover States** - All interactive elements have feedback
- [ ] **Dark Mode** - Everything tested in both themes

---

## 🎯 GREENLIGHT CHECKLIST

- [ ] Each component matches RideView/ActivityFeed quality
- [ ] No lazy shortcuts (13px inline stats, rounded-full buttons)
- [ ] Beetle aesthetic throughout (borders, shadows, glows)
- [ ] Information hierarchy is intentional
- [ ] Every spacing value has a reason
- [ ] Dark mode is first-class citizen
- [ ] Responsive behavior is thoughtful

---

**This is the level of devotion our app deserves.** 🪲

Ready for greenlight?
