# BoulderRoller Modal Audit
**All the modals we need to build**

---

## ✅ EXISTING MODALS (4)

### 1. InviteModal ✅
**Location:** `/components/auth/InviteModal.tsx`
**Trigger:** Click beetle 3x on InviteGate
**Purpose:** Enter invite code to access app
**Status:** Complete

### 2. WalletConnect ✅
**Location:** `/components/auth/WalletConnect.tsx`
**Trigger:** After valid invite code
**Purpose:** Select Solana wallet (Phantom, Solflare, Backpack)
**Status:** Complete

### 3. SetupModal ✅
**Location:** `/components/auth/SetupModal.tsx`
**Trigger:** After wallet connection
**Purpose:** Set username, FTP, weight
**Status:** Complete

### 4. ActivityDetailModal ✅
**Location:** `/components/feed/ActivityDetailModal.tsx`
**Trigger:** Click activity card in feed
**Purpose:** Quick preview before navigating to full RideView
**Status:** Complete

---

## 🚧 NEEDED MODALS (10)

### PRIORITY 1: Core Functionality

#### 5. UploadActivityModal 🔴
**Trigger:** Click "Upload" button in TopNav
**Purpose:** Upload ride data
**Features:**
- Drag & drop .fit/.tcx/.gpx files
- Manual entry form (distance, duration, TSS)
- Activity type selection (ride, run, virtual)
- Date/time picker
- Title and description fields
- Calculate dung reward preview
**Complexity:** High (file upload, parsing, validation)

#### 6. SearchModal (Cmd+K) 🔴
**Trigger:** Click search icon OR Cmd+K keyboard shortcut
**Purpose:** Global search across app
**Features:**
- Search activities (title, date, type)
- Search segments (name, location)
- Search riders (username, beetle #)
- Recent searches
- Keyboard navigation (arrow keys, enter)
- Category filters
**Complexity:** Medium (search logic, keyboard shortcuts)

#### 7. EditProfileModal 🔴
**Trigger:** Profile dropdown → "Edit Profile"
**Purpose:** Update user settings
**Features:**
- Username change
- FTP update
- Weight update
- Bio/description
- Avatar upload (optional)
- Privacy settings
**Complexity:** Medium (form validation, image upload)

---

### PRIORITY 2: Engagement Features

#### 8. AchievementUnlockModal 🟡
**Trigger:** When user unlocks an achievement (after ride upload, milestone)
**Purpose:** Celebration moment
**Features:**
- Large achievement emoji
- Achievement name + description
- Dung reward (with glow effect)
- Progress to next achievement
- Share button
- Confetti animation (optional)
**Complexity:** Low (presentation only)

#### 9. StoreConfirmModal 🟡
**Trigger:** Click "Buy" on item in BeetleStore
**Purpose:** Confirm purchase
**Features:**
- Item preview (emoji, name, description)
- Price in dung
- Current balance display
- Confirm/Cancel buttons
- Success state animation
**Complexity:** Low (confirmation dialog)

#### 10. InviteFriendModal 🟡
**Trigger:** Profile dropdown → "Invite Friends" OR FindFriends page
**Purpose:** Generate and share invite codes
**Features:**
- Your unique invite link
- Copy to clipboard
- Show remaining invites (if limited)
- Track who you've invited
- Social share buttons
**Complexity:** Medium (code generation, clipboard API)

---

### PRIORITY 3: Map & Segments

#### 11. SegmentDetailModal 🟡
**Trigger:** Click segment marker on Map page
**Purpose:** View segment details
**Features:**
- Segment name + distance
- Your PR (if exists)
- Leaderboard (top 5)
- Dung reward for crown
- View full leaderboard link
- Star segment button
**Complexity:** Medium (leaderboard data, stats)

---

### PRIORITY 4: Utility Modals

#### 12. DeleteConfirmModal 🟢
**Trigger:** Delete button on activity (MyActivities page, RideView)
**Purpose:** Confirm destructive action
**Features:**
- Warning message
- Activity preview (title, date)
- Confirm/Cancel buttons
- "This cannot be undone" warning
**Complexity:** Low (simple confirmation)

#### 13. ShareModal 🟢
**Trigger:** Share button on RideView
**Purpose:** Share activity to social media
**Features:**
- Activity preview card
- Share to Twitter/X
- Copy link to clipboard
- Download image (optional)
**Complexity:** Medium (social APIs, image generation)

#### 14. SettingsModal 🟢
**Trigger:** Profile dropdown → "Settings"
**Purpose:** App preferences
**Features:**
- Theme toggle (light/dark) - already exists in dropdown
- Unit preferences (metric/imperial)
- Notification settings
- Data export
- Connected accounts
- Privacy settings
- Danger zone (delete account)
**Complexity:** High (many settings categories)

---

## 📊 MODAL BREAKDOWN

**Total Needed:** 10 new modals
**Priority 1 (Core):** 3 modals - Upload, Search, EditProfile
**Priority 2 (Engagement):** 3 modals - Achievement, Store, Invite
**Priority 3 (Map):** 1 modal - SegmentDetail
**Priority 4 (Utility):** 3 modals - Delete, Share, Settings

**Complexity:**
- High: 2 modals (Upload, Settings)
- Medium: 4 modals (Search, EditProfile, Invite, SegmentDetail, Share)
- Low: 4 modals (Achievement, StoreConfirm, Delete)

---

## 🎯 SUGGESTED BUILD ORDER

### Phase 1: Core UX (must-haves)
1. **UploadActivityModal** - Can't have cycling app without uploading rides
2. **SearchModal** - Quality of life, feels professional
3. **DeleteConfirmModal** - Prevent accidental deletions

### Phase 2: Engagement (make it fun)
4. **AchievementUnlockModal** - Dopamine hit when earning dung
5. **StoreConfirmModal** - Enable store functionality
6. **SegmentDetailModal** - Complete the map experience

### Phase 3: Social (community features)
7. **InviteFriendModal** - Growth mechanism
8. **ShareModal** - Social proof
9. **EditProfileModal** - User customization

### Phase 4: Polish (nice-to-haves)
10. **SettingsModal** - Comprehensive preferences

---

## 🛠️ MODAL COMPONENT PATTERN

All modals should follow this structure:

```tsx
interface ModalNameProps {
  onClose: () => void;
  onSuccess?: () => void;
  // ... specific props
}

export default function ModalName({ onClose, onSuccess, ... }: ModalNameProps) {
  const { colors, isDarkMode } = useTheme();

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50">
        <div
          className="w-[480px] rounded-[8px] border-[2px] p-8"
          style={{
            backgroundColor: colors.bg,
            borderColor: colors.border,
            boxShadow: `4px 4px 0px 0px ${colors.border}`,
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-['Inter'] font-black text-[20px]">
              Modal Title
            </h2>
            <button onClick={onClose}>✕</button>
          </div>

          {/* Content */}
          <div>
            {/* ... */}
          </div>

          {/* Actions */}
          <div className="flex gap-3 mt-6">
            <BeetleButton onClick={onSuccess}>
              Confirm
            </BeetleButton>
            <BeetleButton variant="secondary" onClick={onClose}>
              Cancel
            </BeetleButton>
          </div>
        </div>
      </div>
    </>
  );
}
```

---

## 📝 NOTES

- All modals should use beetle aesthetics (2px borders, shadows depress)
- Modals should trap focus (keyboard nav)
- Escape key should close modal
- Click backdrop to close
- Use BeetleButton, BeetleInput components
- Mobile responsive (smaller width on mobile)
- Consider animation transitions (fade in/out)

---

## 🎨 MODAL SIZES

```
Small:   w-[360px] - DeleteConfirm, StoreConfirm
Medium:  w-[480px] - Achievement, Invite, Share
Large:   w-[600px] - Upload, EditProfile, Settings
XLarge:  w-[800px] - Search (full width search results)
```
