
  # boulderroller

  This is a code bundle for boulderroller. The original project is available at https://www.figma.com/design/rp2XxJaYfEKJtiPrNlJsN0/boulderroller.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  