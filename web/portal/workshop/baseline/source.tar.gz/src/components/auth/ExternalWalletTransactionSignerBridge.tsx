import { useCallback, useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { Buffer } from 'buffer';
import { useAuth } from '../../contexts/AuthContext';
import type { PreparedVaultTransaction } from '../../lib/api';
import {
  validateAndSignPreparedTransaction,
  type PreparedTransactionIntent,
} from '../../lib/portalTransactionIntent';
import { WalletRuntimeProvider } from './WalletRuntimeProvider';
import type { SignPreparedTransaction } from './WalletTransactionSignerBridge';

interface ExternalWalletTransactionSignerBridgeProps {
  onSignerReady: (signer: SignPreparedTransaction | null) => void;
}

function ExternalWalletTransactionSignerBridgeInner({ onSignerReady }: ExternalWalletTransactionSignerBridgeProps) {
  const { walletAddress } = useAuth();
  const { wallet, connected, connect, publicKey, signTransaction } = useWallet();

  const signPreparedTransaction = useCallback(async (
    prepared: PreparedVaultTransaction,
    intent: PreparedTransactionIntent,
  ): Promise<string> => {
    if (!walletAddress) {
      throw new Error('Authenticated wallet is not ready.');
    }

    return validateAndSignPreparedTransaction(
      prepared,
      intent,
      walletAddress,
      async (transaction) => {
        if (!wallet) {
          throw new Error('Reconnect your Solana wallet to continue.');
        }

        if (!connected) {
          await connect();
        }

        if (!publicKey) {
          throw new Error('Wallet connection is not ready.');
        }

        if (publicKey.toBase58() !== walletAddress) {
          throw new Error('Connected wallet does not match your authenticated wallet.');
        }

        if (!signTransaction) {
          throw new Error('Connected wallet cannot sign transactions.');
        }

        const signedTransaction = await signTransaction(transaction);
        return Buffer.from(signedTransaction.serialize()).toString('base64');
      },
    );
  }, [connect, connected, publicKey, signTransaction, wallet, walletAddress]);

  useEffect(() => {
    onSignerReady(signPreparedTransaction);
    return () => onSignerReady(null);
  }, [onSignerReady, signPreparedTransaction]);

  return null;
}

export default function ExternalWalletTransactionSignerBridge(props: ExternalWalletTransactionSignerBridgeProps) {
  return (
    <WalletRuntimeProvider>
      <ExternalWalletTransactionSignerBridgeInner {...props} />
    </WalletRuntimeProvider>
  );
}
