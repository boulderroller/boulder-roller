import { memo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  ResponsiveContainer,
  ReferenceLine,
  Tooltip,
} from 'recharts';

import type { StreamResponse } from '../../lib/api';
import { useFormatters } from '../../hooks/useFormatters';
import {
  formatCadence,
  formatHeartRate,
  formatInteger,
  formatWatts,
} from '../../lib/formatters';
import { PORTAL_STREAM_COLORS } from '../../lib/portalPalette';

interface ChartPoint {
  index: number;
  distance: number;
  [key: string]: number | null;
}

interface AnalyzeChartsColumnProps {
  chartData: ChartPoint[];
  hasData: {
    power: boolean;
    hr: boolean;
    cadence: boolean;
    speed: boolean;
  };
  telemetry: {
    power: StreamResponse | null;
    heartRate: StreamResponse | null;
    cadence: StreamResponse | null;
    speed: StreamResponse | null;
  } | null;
  hoverIndex: number | null;
  onHover: (index: number | null) => void;
}

type ChartTone = 'elevation' | 'power' | 'hr' | 'cadence' | 'speed';
type ChartSize = 'overview' | 'stream';

const CHART_COLORS: Record<ChartTone, string> = PORTAL_STREAM_COLORS;

interface ChartPanelProps {
  title: string;
  data: ChartPoint[];
  dataKey: ChartTone;
  formatValue: (value: number) => string;
  formatDistance: (meters: number) => string;
  hoverIndex: number | null;
  onHover: (index: number | null) => void;
  size: ChartSize;
  stats?: StreamResponse | null;
}

function ChartPanel({
  title,
  data,
  dataKey,
  formatValue,
  formatDistance,
  hoverIndex,
  onHover,
  size,
  stats,
}: ChartPanelProps) {
  const color = CHART_COLORS[dataKey];
  const values = data
    .map((datum) => datum[dataKey] as number | null)
    .filter((value): value is number => value !== null);
  const minVal = values.length > 0 ? Math.min(...values) : 0;
  const maxVal = values.length > 0 ? Math.max(...values) : 100;
  const padding = (maxVal - minVal) * 0.1 || 10;

  const gridColor = 'var(--portal-border)';
  const textColor = 'var(--color-text-muted, var(--muted-foreground))';

  const CustomTooltip = ({
    active,
    payload,
  }: {
    active?: boolean;
    payload?: Array<{ payload: ChartPoint }>;
  }) => {
    if (!active || !payload || !payload.length) return null;
    const point = payload[0].payload;
    const value = point[dataKey];
    if (value === null) return null;

    return (
      <div className={`analyze-chart-tooltip analyze-chart-tooltip--${dataKey}`}>
        <div>{formatDistance(point.distance)}</div>
        <div className="analyze-chart-tooltip__value">
          {formatValue(value)}
        </div>
      </div>
    );
  };

  return (
    <div className={`analyze-chart-panel analyze-chart-panel--${size} analyze-chart-panel--${dataKey}`}>
      <div className="analyze-chart-panel__header">
        <span className="analyze-chart-panel__title">
          {title}
        </span>
        {stats && (
          <div className="analyze-chart-panel__stats">
            <span>
              Avg: <span className="analyze-chart-panel__stat-value">{formatInteger(stats.avgValue)}</span>
            </span>
            <span>
              Max: <span className="analyze-chart-panel__stat-value">{formatInteger(stats.maxValue)}</span>
            </span>
          </div>
        )}
      </div>

      <div className="analyze-chart-panel__plot">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{ top: 2, right: 4, left: 0, bottom: 0 }}
            onMouseMove={(state: { activeTooltipIndex?: number }) => {
              if (state.activeTooltipIndex !== undefined) {
                onHover(state.activeTooltipIndex);
              }
            }}
            onMouseLeave={() => onHover(null)}
          >
            <defs>
              <linearGradient id={`gradient-${dataKey}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.4} />
                <stop offset="100%" stopColor={color} stopOpacity={0.05} />
              </linearGradient>
            </defs>

            <XAxis
              dataKey="distance"
              type="number"
              domain={['dataMin', 'dataMax']}
              tick={false}
              axisLine={{ stroke: gridColor }}
              tickLine={false}
            />

            <YAxis
              domain={[Math.floor(minVal - padding), Math.ceil(maxVal + padding)]}
              tick={{ fontSize: 12, fontFamily: 'var(--br-font-mono)', fill: textColor }}
              axisLine={{ stroke: gridColor }}
              tickLine={false}
              width={44}
              tickCount={3}
            />

            {hoverIndex !== null && data[hoverIndex] && (
              <ReferenceLine
                x={data[hoverIndex].distance}
                stroke="var(--color-text-muted, var(--muted-foreground))"
                strokeOpacity={0.55}
                strokeDasharray="3 3"
              />
            )}

            <Tooltip content={<CustomTooltip />} />

            <Area
              type="monotone"
              dataKey={dataKey}
              stroke={color}
              strokeWidth={1}
              fill={`url(#gradient-${dataKey})`}
              isAnimationActive={false}
              connectNulls
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

function AnalyzeChartsColumn({
  chartData,
  hasData,
  telemetry,
  hoverIndex,
  onHover,
}: AnalyzeChartsColumnProps) {
  const { distance: formatDistance, elevation: formatElevation } = useFormatters();

  return (
    <div className="analyze-chart-column">
      <ChartPanel
        title="Elevation"
        data={chartData}
        dataKey="elevation"
        formatValue={formatElevation}
        formatDistance={formatDistance}
        hoverIndex={hoverIndex}
        onHover={onHover}
        size="overview"
      />

      {hasData.power && (
        <ChartPanel
          title="Power"
          data={chartData}
          dataKey="power"
          formatValue={formatWatts}
          formatDistance={formatDistance}
          hoverIndex={hoverIndex}
          onHover={onHover}
          size="stream"
          stats={telemetry?.power}
        />
      )}

      {hasData.hr && (
        <ChartPanel
          title="Heart Rate"
          data={chartData}
          dataKey="hr"
          formatValue={formatHeartRate}
          formatDistance={formatDistance}
          hoverIndex={hoverIndex}
          onHover={onHover}
          size="stream"
          stats={telemetry?.heartRate}
        />
      )}

      {hasData.cadence && (
        <ChartPanel
          title="Cadence"
          data={chartData}
          dataKey="cadence"
          formatValue={formatCadence}
          formatDistance={formatDistance}
          hoverIndex={hoverIndex}
          onHover={onHover}
          size="stream"
          stats={telemetry?.cadence}
        />
      )}
    </div>
  );
}

export default memo(AnalyzeChartsColumn);
