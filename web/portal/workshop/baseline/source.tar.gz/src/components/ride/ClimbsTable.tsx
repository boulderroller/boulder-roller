/**
 * ClimbsTable - dense climb rows with an expandable effort sheet.
 *
 * The ride detail table should read as athletic instrumentation first. Vault
 * state is a quiet result layer attached to the climb, not the visual premise.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import type { DependencyList, RefObject } from 'react';
import { Link } from 'react-router-dom';
import { useFormatters } from '../../hooks/useFormatters';
import { ABSENT_VALUE, formatInteger, formatVam, formatWatts } from '../../lib/formatters';
import { useVaultLeaderboard } from '../../hooks/queries';
import type { GpsPoint, VaultLeaderboardEntry } from '../../lib/api';
import { getPublicRiderDisplayName } from '../../lib/riderIdentity';
import {
  Mountain,
  ChevronDown,
  Crown,
  Trophy,
  Star,
} from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

export interface ClimbData {
  id?: string;
  objectClimbId?: string;
  name?: string;
  distanceM: number;
  elevationM: number;
  avgGradient: number;
  timeS: number;
  avgSpeedKmh?: number;
  vam?: number;
  dungEarned?: number;
  vaultMatched?: boolean;
  startIndex?: number;
  endIndex?: number;
  startOffsetS?: number;
  endOffsetS?: number;
  // Extended data for vault creation
  signatureHex?: string;
  roadName?: string;
  tileCount?: number;
  // Real completion-backed facts from the ride patterns endpoint; present
  // only when this ride produced an authoritative vault completion.
  vaultMatch?: {
    vaultId: number;
    vaultClimbId?: string | null;
    name?: string | null;
    yourTime?: number | null;
    yourRank?: number | null;
    yourBestTime?: number | null;
    isPR?: boolean | null;
    komTime?: number | null;
    komHolder?: string | null;
  };
}

interface EntitlementInfo {
  canCreateVault: boolean;
  vaultsRemaining: number;
  vaultsUnlocked: number;
  vaultsUsed: number;
  nextTierVaults?: number;
}

interface ClimbsTableProps {
  climbs: ClimbData[];
  onClimbClick?: (climb: ClimbData) => void;
  onClimbHover?: (climb: ClimbData | null) => void;
  onAnalyzeClimb?: (climb: ClimbData) => void;
  getClimbHref?: (climb: ClimbData) => string | null;
  selectedClimbId?: string;
  hoveredClimbId?: string;
  emptyMessage?: string;
  entitlement?: EntitlementInfo;
  gpsPoints?: GpsPoint[];
  currentUserWallet?: string;
  showHeader?: boolean;
  showFooter?: boolean;
  showColumnHeader?: boolean;
}

// ============================================================================
// UTILITIES
// ============================================================================

function getGradientLabel(gradientPct: number): { label: string; short: string } {
  if (gradientPct >= 12) return { label: 'BRUTAL', short: 'HC' };
  if (gradientPct >= 9) return { label: 'STEEP', short: '1' };
  if (gradientPct >= 6) return { label: 'HARD', short: '2' };
  if (gradientPct >= 4) return { label: 'MODERATE', short: '3' };
  return { label: 'EASY', short: '4' };
}

function getGradientTone(gradientPct: number): string {
  if (gradientPct >= 12) return 'brutal';
  if (gradientPct >= 9) return 'steep';
  if (gradientPct >= 6) return 'hard';
  if (gradientPct >= 4) return 'moderate';
  return 'easy';
}

// Category badge based on elevation × gradient score
function getClimbCategory(vertM: number, avgGradient: number): string | null {
  const score = vertM * avgGradient;
  if (score >= 8000) return 'HC';
  if (score >= 3200) return '1';
  if (score >= 1600) return '2';
  if (score >= 800) return '3';
  if (score >= 400) return '4';
  return null;
}

function getCategoryClass(category: string | null): string {
  if (!category) return 'climbs-table-card__category--empty';
  return `climbs-table-card__category--cat-${category.toLowerCase()}`;
}

function formatRank(rank?: number | null): string {
  if (!rank) return ABSENT_VALUE;
  return `#${formatInteger(rank)}`;
}

function formatLeaderboardRiderName(name?: string | null): string {
  const trimmed = name?.trim();
  if (!trimmed) return 'Leader';
  if (trimmed.length > 22 && /^[a-z0-9]+$/i.test(trimmed)) {
    return `${trimmed.slice(0, 8)}...${trimmed.slice(-4)}`;
  }
  if (trimmed.length > 24) return `${trimmed.slice(0, 22)}...`;
  return trimmed;
}

function getLeaderboardRiderName(entry: VaultLeaderboardEntry): string {
  return formatLeaderboardRiderName(getPublicRiderDisplayName(entry));
}

function formatLeaderboardPower(entry: VaultLeaderboardEntry): string | null {
  return typeof entry.avgPowerW === 'number' && Number.isFinite(entry.avgPowerW)
    ? formatWatts(entry.avgPowerW)
    : null;
}

function resolveClimbGpsSlice(climb: ClimbData, gpsPoints?: GpsPoint[]): GpsPoint[] {
  if (!gpsPoints?.length || climb.startIndex === undefined || climb.endIndex === undefined) return [];

  const start = Math.max(0, Math.min(climb.startIndex, climb.endIndex));
  const end = Math.min(gpsPoints.length - 1, Math.max(climb.startIndex, climb.endIndex));

  return gpsPoints.slice(start, end + 1);
}

function useCanvasRenderer(
  canvasRef: RefObject<HTMLCanvasElement | null>,
  render: (context: CanvasRenderingContext2D, width: number, height: number, canvas: HTMLCanvasElement) => void,
  deps: DependencyList,
) {
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;

    const draw = () => {
      const bounds = canvas.getBoundingClientRect();
      const width = Math.max(1, bounds.width || canvas.parentElement?.clientWidth || 320);
      const height = Math.max(1, bounds.height || canvas.parentElement?.clientHeight || 80);
      const dpr = Math.max(1, window.devicePixelRatio || 1);
      const scaledWidth = Math.round(width * dpr);
      const scaledHeight = Math.round(height * dpr);

      if (canvas.width !== scaledWidth) canvas.width = scaledWidth;
      if (canvas.height !== scaledHeight) canvas.height = scaledHeight;

      const context = canvas.getContext('2d');
      if (!context) return;

      context.setTransform(dpr, 0, 0, dpr, 0, 0);
      context.clearRect(0, 0, width, height);
      render(context, width, height, canvas);
    };

    draw();

    if (typeof ResizeObserver === 'undefined') return undefined;

    const observer = new ResizeObserver(draw);
    observer.observe(canvas);
    if (canvas.parentElement) observer.observe(canvas.parentElement);

    return () => observer.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

function getCanvasColor(canvas: HTMLCanvasElement, variable: string, fallback: string): string {
  const value = getComputedStyle(canvas).getPropertyValue(variable).trim();
  if (!value || value.includes('var(') || value.includes('color-mix(')) return fallback;
  return value || fallback;
}

function withCanvasAlpha(color: string, alpha: number, fallback: string): string {
  const clamped = Math.max(0, Math.min(1, alpha));
  const hex = color.trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (hex) {
    const raw = hex[1].length === 3
      ? hex[1].split('').map((char) => `${char}${char}`).join('')
      : hex[1];
    const red = Number.parseInt(raw.slice(0, 2), 16);
    const green = Number.parseInt(raw.slice(2, 4), 16);
    const blue = Number.parseInt(raw.slice(4, 6), 16);
    return `rgba(${red}, ${green}, ${blue}, ${clamped})`;
  }

  const rgb = color.trim().match(/^rgba?\(([^)]+)\)$/i);
  if (rgb) {
    const [red, green, blue] = rgb[1].split(',').map((part) => part.trim()).slice(0, 3);
    if (red && green && blue) return `rgba(${red}, ${green}, ${blue}, ${clamped})`;
  }

  return fallback;
}

// ============================================================================
// MINI ELEVATION SPARK
// Tiny inline elevation profile for collapsed state
// ============================================================================

function ElevationSparkCanvas({
  climb,
  gpsPoints,
  height = 24,
}: {
  climb: ClimbData;
  gpsPoints?: GpsPoint[];
  height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const elevations = useMemo(() => {
    const samples = resolveClimbGpsSlice(climb, gpsPoints)
      .filter((point) => typeof point.elevationM === 'number');

    if (samples.length < 2) return null;

    return samples.map((point) => point.elevationM as number);
  }, [climb.endIndex, climb.startIndex, gpsPoints]);

  useCanvasRenderer(canvasRef, (context, width, canvasHeight, canvas) => {
    if (!elevations) return;

    const accent = getCanvasColor(canvas, '--climb-inspection-accent', '#d95f2b');
    const muted = getCanvasColor(canvas, '--ride-detail-line', '#d7dce4');
    const minElevation = Math.min(...elevations);
    const maxElevation = Math.max(...elevations);
    const range = Math.max(1, maxElevation - minElevation);
    const lastIndex = Math.max(1, elevations.length - 1);
    const coords = elevations.map((elevation, index) => {
      const x = (index / lastIndex) * width;
      const normalized = (elevation - minElevation) / range;
      const y = canvasHeight - 3 - normalized * (canvasHeight - 7);
      return { x, y };
    });
    const fill = context.createLinearGradient(0, 0, 0, canvasHeight);
    fill.addColorStop(0, withCanvasAlpha(accent, 0.24, 'rgba(217, 95, 43, 0.24)'));
    fill.addColorStop(0.72, withCanvasAlpha(accent, 0.06, 'rgba(217, 95, 43, 0.06)'));
    fill.addColorStop(1, withCanvasAlpha(accent, 0, 'rgba(217, 95, 43, 0)'));

    context.lineWidth = 1;
    context.strokeStyle = withCanvasAlpha(muted, 0.52, 'rgba(216, 222, 232, 0.52)');
    context.beginPath();
    context.moveTo(0, canvasHeight - 2.5);
    context.lineTo(width, canvasHeight - 2.5);
    context.stroke();

    context.beginPath();
    coords.forEach((coord, index) => {
      if (index === 0) context.moveTo(coord.x, coord.y);
      else context.lineTo(coord.x, coord.y);
    });
    context.lineTo(width, canvasHeight);
    context.lineTo(0, canvasHeight);
    context.closePath();
    context.fillStyle = fill;
    context.fill();

    context.beginPath();
    coords.forEach((coord, index) => {
      if (index === 0) context.moveTo(coord.x, coord.y);
      else context.lineTo(coord.x, coord.y);
    });
    context.lineWidth = canvasHeight > 36 ? 2 : 1.5;
    context.lineCap = 'round';
    context.lineJoin = 'round';
    context.strokeStyle = accent;
    context.stroke();
  }, [elevations, height]);

  if (!elevations) {
    return (
      <div className="climbs-table-card__spark-empty" aria-hidden="true">
        <Mountain size={14} />
      </div>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className="climbs-table-card__spark climbs-table-card__spark-canvas"
      style={{ height }}
      aria-hidden="true"
    />
  );
}

// ============================================================================
// CLIMB CARD COMPONENT
// ============================================================================

interface ClimbCardProps {
  climb: ClimbData;
  index: number;
  isExpanded: boolean;
  isSelected: boolean;
  isHovered: boolean;
  onToggle: () => void;
  onHover: (hover: boolean) => void;
  onAnalyze?: () => void;
  objectHref?: string | null;
  showSegmentMetrics?: boolean;
  formatDistance: (m: number | null | undefined) => string;
  formatElevation: (m: number | null | undefined) => string;
  formatSpeedKmh: (kmh: number | null | undefined) => string;
  formatPercent: (value: number | null | undefined, digits?: number) => string;
  formatDuration: (seconds: number | null | undefined) => string;
  gpsPoints?: GpsPoint[];
  currentUserWallet?: string;
}

function ClimbCard({
  climb,
  index,
  isExpanded,
  isSelected,
  isHovered,
  onToggle,
  onHover,
  onAnalyze,
  objectHref,
  showSegmentMetrics = false,
  formatDistance,
  formatElevation,
  formatSpeedKmh,
  formatPercent,
  formatDuration,
  gpsPoints,
  currentUserWallet,
}: ClimbCardProps) {
  const gradientTone = getGradientTone(climb.avgGradient);
  const category = getClimbCategory(climb.elevationM, climb.avgGradient);
  const hasVault = !!climb.vaultMatched || !!climb.vaultMatch;
  const climbName = climb.vaultMatch?.name || climb.name || climb.roadName || `Climb ${formatInteger(index + 1)}`;
  const hasVam = typeof climb.vam === 'number';
  const effortTime = climb.vaultMatch?.yourTime ?? climb.timeS;
  const bestKnownTime = climb.vaultMatch?.yourBestTime ?? climb.vaultMatch?.yourTime;
  const leaderboardTitle = climb.vaultMatch?.name || climbName;
  const resultLabel = climb.vaultMatch?.yourRank ? formatRank(climb.vaultMatch.yourRank) : hasVault ? 'Matched' : ABSENT_VALUE;
  const leaderboardHref = climb.objectClimbId
    ? `/climbs/${encodeURIComponent(climb.objectClimbId)}/leaderboard`
    : climb.vaultMatch?.vaultClimbId
      ? `/climbs/${encodeURIComponent(climb.vaultMatch.vaultClimbId)}/leaderboard`
    : climb.vaultMatch?.vaultId
      ? `/vaults/${climb.vaultMatch.vaultId}`
      : null;
  const vaultLeaderboard = useVaultLeaderboard(climb.vaultMatch?.vaultId, isExpanded && !!climb.vaultMatch?.vaultId);
  const leaderboardEntries = vaultLeaderboard.data?.leaderboard ?? [];
  const previewEntries = leaderboardEntries.slice(0, 3);
  const hasFetchedLeaderboard = leaderboardEntries.length > 0;
  const leaderboardUnavailable = vaultLeaderboard.isError;
  const isCurrentUserInPreview = !!currentUserWallet && previewEntries.some((entry) => entry.wallet === currentUserWallet);
  const shouldShowEffortRow = !!climb.vaultMatch?.yourRank && !isCurrentUserInPreview;
  const leaderboardMeta = climb.vaultMatch?.yourRank
    ? formatRank(climb.vaultMatch.yourRank)
    : vaultLeaderboard.data?.leaderboard.length
      ? `${formatInteger(vaultLeaderboard.data.leaderboard.length)} ranked`
      : hasVault
      ? 'Leaderboard'
      : null;
  const avgSpeedKmh = typeof climb.avgSpeedKmh === 'number'
    ? climb.avgSpeedKmh
    : climb.timeS > 0
      ? (climb.distanceM / climb.timeS) * 3.6
      : null;
  const cardClassName = [
    'climbs-table-card',
    isExpanded ? 'climbs-table-card--expanded' : '',
    isSelected ? 'climbs-table-card--selected' : '',
    isHovered ? 'climbs-table-card--hovered' : '',
  ].filter(Boolean).join(' ');

  return (
    <div
      className={cardClassName}
      data-gradient-tone={gradientTone}
      data-climb-id={climb.id || `climb-${index}`}
      onMouseEnter={() => onHover(true)}
      onMouseLeave={() => onHover(false)}
    >
      <div className="climbs-table-card__accent" />

      <div
        className="climbs-table-card__surface"
        role="button"
        tabIndex={0}
        aria-expanded={isExpanded}
        aria-label={`${isExpanded ? 'Collapse' : 'Inspect'} ${climbName}`}
        onClick={onToggle}
        onKeyDown={(event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            onToggle();
          }
        }}
      >
        <div className="climbs-table-card__body">
          <div className="climbs-table-card-row">
            <div className="climbs-table-card__category-wrap">
              {category ? (
                <div className={`climbs-table-card__category ${getCategoryClass(category)}`}>
                  {category === 'HC' ? 'HC' : `C${category}`}
                </div>
              ) : (
                <div className="climbs-table-card__category climbs-table-card__category--empty">
                  <Mountain size={14} />
                </div>
              )}
            </div>

            <div className="climbs-table-card-name">
              <div className="climbs-table-card__title-row">
                <span className="climbs-table-card__name">{climbName}</span>
                {climb.vaultMatch?.yourRank === 1 ? (
                  <div className="climbs-table-card__rank-badge climbs-table-card__rank-badge--kom">
                    <Crown size={10} />
                    <span>KOM</span>
                  </div>
                ) : climb.vaultMatch?.yourRank && climb.vaultMatch.yourRank <= 3 ? (
                  <div className="climbs-table-card__rank-badge climbs-table-card__rank-badge--podium">
                    <Trophy size={10} />
                    <span>{formatRank(climb.vaultMatch.yourRank)}</span>
                  </div>
                ) : climb.vaultMatch?.yourRank && climb.vaultMatch.yourRank <= 10 ? (
                  <div className="climbs-table-card__rank-badge climbs-table-card__rank-badge--top">
                    <span>{formatRank(climb.vaultMatch.yourRank)}</span>
                  </div>
                ) : hasVault ? (
                  <Trophy size={12} className="climbs-table-card__status-icon" />
                ) : null}
                {climb.vaultMatch?.isPR && (
                  <div className="climbs-table-card__pr-badge">
                    <Star size={9} fill="currentColor" />
                    <span>PR</span>
                  </div>
                )}
              </div>
              <div className="climbs-table-card__subline">
                {climb.roadName && climb.roadName !== climbName && <span>{climb.roadName}</span>}
                <span>{formatDistance(climb.distanceM)}</span>
                <span>{formatElevation(climb.elevationM)} vert</span>
                <span className="climbs-table-card__subline-accent">{formatPercent(climb.avgGradient)}</span>
              </div>
            </div>

            <div className="climbs-table-card__spark-wrap">
              <ElevationSparkCanvas climb={climb} gpsPoints={gpsPoints} height={28} />
            </div>

            <div className="climbs-table-card-metrics climbs-table-card__metrics">
              <div className="climbs-table-card__metric climbs-table-card__metric--primary">
                <div className="climbs-table-card__metric-value">{formatDuration(effortTime)}</div>
                <div className="climbs-table-card__metric-label">Time</div>
              </div>

              {showSegmentMetrics && (
                <>
                  <div className="climbs-table-card__metric">
                    <div className="climbs-table-card__metric-value">
                      {avgSpeedKmh !== null ? formatSpeedKmh(avgSpeedKmh) : ABSENT_VALUE}
                    </div>
                    <div className="climbs-table-card__metric-label">Speed</div>
                  </div>

                  <div className="climbs-table-card__metric">
                    <div
                      className={`climbs-table-card__metric-value ${
                        hasVam && (climb.vam as number) >= 1000
                          ? 'climbs-table-card__metric-value--success'
                          : ''
                      }`}
                    >
                      {hasVam ? formatInteger(climb.vam as number) : ABSENT_VALUE}
                    </div>
                    <div className="climbs-table-card__metric-label">VAM</div>
                  </div>

                  <div className="climbs-table-card__metric">
                    <div
                      className={`climbs-table-card__metric-value ${
                        climb.vaultMatch?.yourRank && climb.vaultMatch.yourRank <= 3
                          ? 'climbs-table-card__metric-value--reward'
                          : ''
                      }`}
                    >
                      {formatRank(climb.vaultMatch?.yourRank)}
                    </div>
                    <div className="climbs-table-card__metric-label">Place</div>
                  </div>
                </>
              )}

              <div className="climbs-table-card__chevron">
                <ChevronDown size={16} />
              </div>
            </div>
          </div>
        </div>

        {isExpanded && (
          <div className="climbs-table-card__details">
            <div className="climbs-table-card__segment-sheet">
              <div className="climbs-table-card__segment-main">
                <div className="climbs-table-card__segment-main-top">
                  <div>
                    <div className="climbs-table-card__panel-label">Climb effort</div>
                    {objectHref ? (
                      <Link
                        className="climbs-table-card__segment-title-link"
                        to={objectHref}
                        onClick={(event) => event.stopPropagation()}
                      >
                        {climbName}
                      </Link>
                    ) : (
                      <strong className="climbs-table-card__segment-title-text">{climbName}</strong>
                    )}
                  </div>
                  <div className="climbs-table-card__segment-actions">
                    {onAnalyze && (
                      <button
                        type="button"
                        className="climbs-table-card__segment-action"
                        onClick={(event) => {
                          event.stopPropagation();
                          onAnalyze();
                        }}
                      >
                        Analyze
                      </button>
                    )}
                    {objectHref && (
                      <Link
                        className="climbs-table-card__segment-action"
                        to={objectHref}
                        onClick={(event) => event.stopPropagation()}
                      >
                        Open climb
                      </Link>
                    )}
                  </div>
                </div>

                <div className="climbs-table-card__segment-main-grid">
                  <div className="climbs-table-card__segment-effort">
                    <div className="climbs-table-card__segment-time">
                      <strong>{formatDuration(effortTime)}</strong>
                      <span>
                        {formatDistance(climb.distanceM)} · {formatElevation(climb.elevationM)} ·{' '}
                        {formatPercent(climb.avgGradient)}
                      </span>
                    </div>
                    <div className="climbs-table-card__effort-table" aria-label="Climb effort metrics">
                      <div className="climbs-table-card__effort-table-row">
                        <span>Distance</span>
                        <strong>{formatDistance(climb.distanceM)}</strong>
                      </div>
                      <div className="climbs-table-card__effort-table-row">
                        <span>Elevation</span>
                        <strong>{formatElevation(climb.elevationM)}</strong>
                      </div>
                      <div className="climbs-table-card__effort-table-row">
                        <span>Avg speed</span>
                        <strong>{avgSpeedKmh !== null ? formatSpeedKmh(avgSpeedKmh) : ABSENT_VALUE}</strong>
                      </div>
                      <div className="climbs-table-card__effort-table-row">
                        <span>Grade</span>
                        <strong>{formatPercent(climb.avgGradient)}</strong>
                      </div>
                      <div className="climbs-table-card__effort-table-row">
                        <span>VAM</span>
                        <strong>{hasVam ? formatVam(climb.vam) : ABSENT_VALUE}</strong>
                      </div>
                    </div>
                  </div>

                  <div className="climbs-table-card__segment-media climbs-table-card__segment-media--profile-only">
                    <div
                      className="climbs-table-card__segment-profile climbs-table-card__segment-profile--expanded"
                      role="img"
                      aria-label={`${climbName} elevation profile`}
                    >
                      <ElevationSparkCanvas climb={climb} gpsPoints={gpsPoints} height={158} />
                    </div>
                  </div>
                </div>
              </div>

              <div className="climbs-table-card__segment-board">
                <div className="climbs-table-card__segment-board-top">
                  <div>
                    <div className="climbs-table-card__panel-label">Leaderboard</div>
                    <div className="climbs-table-card__segment-board-title">{leaderboardTitle}</div>
                    {leaderboardMeta && (
                      <div className="climbs-table-card__segment-board-meta">{leaderboardMeta}</div>
                    )}
                  </div>
                </div>

                {hasVault ? (
                  <div className="climbs-table-card__leaderboard" aria-label="Matched climb leaderboard">
                    {vaultLeaderboard.isLoading && (
                      <div className="climbs-table-card__leaderboard-row climbs-table-card__leaderboard-row--pending">
                        <span>...</span>
                        <strong>Loading board</strong>
                        <em>{ABSENT_VALUE}</em>
                      </div>
                    )}
                    {!vaultLeaderboard.isLoading && previewEntries.map((entry) => {
                      const isCurrentUser = !!currentUserWallet && entry.wallet === currentUserWallet;
                      const power = formatLeaderboardPower(entry);

                      return (
                        <div
                          key={`${entry.wallet}-${entry.rank}-${entry.bestTimeSeconds}`}
                          className={[
                            'climbs-table-card__leaderboard-row',
                            entry.rank === 1 ? 'climbs-table-card__leaderboard-row--leader' : '',
                            isCurrentUser ? 'climbs-table-card__leaderboard-row--you' : '',
                          ].filter(Boolean).join(' ')}
                        >
                          <span>{formatRank(entry.rank)}</span>
                          <strong>{isCurrentUser ? 'You' : getLeaderboardRiderName(entry)}</strong>
                          <em>
                            {formatDuration(entry.bestTimeSeconds)}
                            {power ? <small>{power}</small> : null}
                          </em>
                        </div>
                      );
                    })}
                    {!vaultLeaderboard.isLoading && leaderboardUnavailable && (
                      <div className="climbs-table-card__leaderboard-row climbs-table-card__leaderboard-row--empty">
                        <span>{ABSENT_VALUE}</span>
                        <strong>Leaderboard unavailable</strong>
                        <em>{ABSENT_VALUE}</em>
                      </div>
                    )}
                    {!vaultLeaderboard.isLoading && shouldShowEffortRow && (
                      <div className="climbs-table-card__leaderboard-row climbs-table-card__leaderboard-row--you">
                        <span>{resultLabel}</span>
                        <strong>{currentUserWallet ? 'You' : 'This effort'}</strong>
                        <em>{formatDuration(effortTime)}</em>
                      </div>
                    )}
                    {typeof bestKnownTime === 'number' && bestKnownTime > 0 && bestKnownTime !== effortTime && (
                      <div className="climbs-table-card__leaderboard-row">
                        <span>Best</span>
                        <strong>{currentUserWallet ? 'Your best' : 'Best known'}</strong>
                        <em>{formatDuration(bestKnownTime)}</em>
                      </div>
                    )}
                    {!vaultLeaderboard.isLoading && !leaderboardUnavailable && !hasFetchedLeaderboard && !shouldShowEffortRow && (
                      <div className="climbs-table-card__leaderboard-row climbs-table-card__leaderboard-row--empty">
                        <span>{ABSENT_VALUE}</span>
                        <strong>No leaderboard entries yet</strong>
                        <em>{ABSENT_VALUE}</em>
                      </div>
                    )}
                    {leaderboardHref && (
                      <Link
                        className="climbs-table-card__leaderboard-link"
                        to={leaderboardHref}
                        onClick={(event) => event.stopPropagation()}
                      >
                        View full leaderboard
                      </Link>
                    )}
                  </div>
                ) : (
                  <div
                    className="climbs-table-card__segment-board-empty"
                    role="region"
                    aria-label="Climb leaderboard"
                  >
                    <strong>No leaderboard yet</strong>
                    <span>A leaderboard appears when this climb has a vault.</span>
                    {objectHref && (
                      <Link
                        className="climbs-table-card__segment-board-link"
                        to={objectHref}
                        onClick={(event) => event.stopPropagation()}
                      >
                        Open climb
                      </Link>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function ClimbsTable({
  climbs,
  onClimbClick,
  onClimbHover,
  onAnalyzeClimb,
  getClimbHref,
  selectedClimbId,
  hoveredClimbId,
  emptyMessage = 'No climbs detected',
  gpsPoints,
  currentUserWallet,
  showHeader = true,
  showFooter = true,
  showColumnHeader = false,
}: ClimbsTableProps) {
  const {
    distance: formatDistance,
    elevation: formatElevation,
    speedKmh: formatSpeedKmh,
    percent: formatPercent,
    duration: formatDuration,
  } = useFormatters();
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Summary stats
  const totalVert = climbs.reduce((sum, c) => sum + c.elevationM, 0);
  // Empty state
  if (climbs.length === 0) {
    return (
      <div className="climbs-table-empty">
        <Mountain size={32} />
        <span>
          {emptyMessage}
        </span>
      </div>
    );
  }

  return (
    <div className={`climbs-table ${showColumnHeader ? 'climbs-table--segment-rows' : ''}`}>
      {/* Header */}
      {showHeader && (
        <div className="climbs-table-header">
          <div className="climbs-table-header__title-row">
            <Mountain size={14} />
            <span className="climbs-table-header__title">
              {formatInteger(climbs.length)} Climb{climbs.length !== 1 ? 's' : ''}
            </span>
          </div>
          <div className="climbs-table-header__meta">
            <span className="climbs-table-header__total">
              {formatElevation(totalVert)} total
            </span>
          </div>
        </div>
      )}

      {showColumnHeader && (
        <div className="climbs-table-column-head" aria-hidden="true">
          <span className="climbs-table-column-head__spacer" />
          <span className="climbs-table-column-head__name">Climb</span>
          <span className="climbs-table-column-head__profile">Profile</span>
          <span className="climbs-table-column-head__metric">Time</span>
          <span className="climbs-table-column-head__metric">Speed</span>
          <span className="climbs-table-column-head__metric">VAM</span>
          <span className="climbs-table-column-head__metric">Result</span>
          <span className="climbs-table-column-head__spacer" />
        </div>
      )}

      {/* Climb Cards */}
      <div className="climbs-table-list">
        {climbs.map((climb, index) => {
          const id = climb.id || `climb-${index}`;
          const isExpanded = expandedId === id;
          const isSelected = selectedClimbId === id;
          const isHovered = hoveredClimbId === id;

          return (
            <ClimbCard
              key={id}
              climb={climb}
              index={index}
              isExpanded={isExpanded}
              isSelected={isSelected}
              isHovered={isHovered}
              onToggle={() => {
                setExpandedId(isExpanded ? null : id);
                onClimbClick?.(climb);
              }}
              onHover={(hover) => onClimbHover?.(hover ? climb : null)}
              onAnalyze={onAnalyzeClimb ? () => onAnalyzeClimb(climb) : undefined}
              objectHref={getClimbHref?.(climb) ?? null}
              showSegmentMetrics={showColumnHeader}
              formatDistance={formatDistance}
              formatElevation={formatElevation}
              formatSpeedKmh={formatSpeedKmh}
              formatPercent={formatPercent}
              formatDuration={formatDuration}
              gpsPoints={gpsPoints}
              currentUserWallet={currentUserWallet}
            />
          );
        })}
      </div>

      {/* Footer Summary */}
      {showFooter && (
        <div className="climbs-table-footer">
          <span>
            {formatElevation(totalVert)} total climbing
          </span>
        </div>
      )}
    </div>
  );
}
