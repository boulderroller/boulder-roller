import { StateRow } from '../portal/FailureSpecies';
import { LoadingRows } from '../loading/LoadingSystem';
import { Slot } from '../loading/Slot';
import { useId, useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { ABSENT_VALUE, formatMonthDay, formatInteger, formatRaceTime, formatWatts } from '../../lib/formatters';
import { resolveRankMarkAsset } from '../../assets/rankmarks';

export interface ClimbResultRow {
  key: string;
  seat: number;
  rank: number;
  tied?: boolean;
  name: string;
  path?: string | null;
  identityHidden?: boolean;
  timeS?: number | null;
  powerW?: number | null;
  achievedAt?: string | null;
}

/** Display preferences never reorder or renumber the authoritative seats. */
export default function ClimbLeaderboard({ entries, loading, error, onRetry, hiddenRows = 0, viewer = 'owner' }: {
  entries: ClimbResultRow[];
  loading?: boolean;
  error?: boolean;
  onRetry?: () => void;
  hiddenRows?: number;
  viewer?: 'owner' | 'stranger';
}) {
  // Privacy projection failures can revoke previously visible identities.
  // Fail closed for board data while the independent canon remains readable.
  if (error) entries = [];
  const id = useId();
  const [showAll, setShowAll] = useState(viewer === 'stranger');
  const [metric, setMetric] = useState<'time' | 'power'>('time');
  return <section className="climb-detail-record-board" data-object-layer="climb-record-board" aria-label="Climb leaderboard" aria-busy={loading}>
    <div className="profile-eyebrow"><div className="climb-section-heading">
      <h2>Leaderboard</h2>
      {entries.length > 0 && <fieldset className="climb-metric-picker">
        <legend className="climb-sr-only">Displayed leaderboard value</legend>
        {(['time', 'power'] as const).map((value) => <label key={value}>
          <input type="radio" name={`${id}-metric`} value={value} checked={metric === value}
            onChange={() => setMetric(value)} />
          <span>{value === 'time' ? 'Time' : 'Power'}</span>
        </label>)}
      </fieldset>}
    </div></div>
    <div className="climb-ledger-card climb-detail-leaderboard" data-show-all={showAll}>
      {loading && !entries.length ? <LoadingRows label="Loading leaderboard" rows={10} />
        : error && !entries.length ? <StateRow title="Could not load leaderboard" action={onRetry && <button type="button" onClick={onRetry}>Try again</button>} />
        : !entries.length ? <StateRow title="No times yet" description="Ride it to set the first time." />
        : entries.map((entry) => {
          const available = metric === 'time' ? entry.timeS != null && entry.timeS > 0 : entry.powerW != null && Number.isFinite(entry.powerW);
          const value = viewer === 'stranger' && !available ? null : metric === 'time' ? (entry.timeS != null && entry.timeS > 0 ? formatRaceTime(entry.timeS) : ABSENT_VALUE) : formatWatts(entry.powerW);
          const rank = `${entry.tied ? 'T-' : ''}${formatInteger(entry.rank)}`;
          const mark = entry.rank <= 3 ? resolveRankMarkAsset(entry.rank) : null;
          const contents = <>
            <span className="climb-result-rank" aria-label={`Rank ${rank}`}>
              {mark && !entry.tied ? <img src={mark.src} srcSet={mark.srcSet} alt="" /> : rank}
            </span>
            <span className="climb-result-rider"><strong>{entry.identityHidden ? 'Rider' : entry.name}</strong>
              {entry.identityHidden ? <small>Rider profile private</small> : entry.achievedAt ? <small>{formatMonthDay(entry.achievedAt)}</small> : null}
            </span>
            {value !== null && <span className="climb-result-value">{value}</span>}
            {entry.path && !entry.identityHidden ? <ChevronRight className="climb-chevron" size={15} aria-hidden="true" /> : <span className="climb-chevron" />}
          </>;
          const props = { className: 'climb-result-row', 'data-object-row': 'record-board', 'data-rank': entry.seat };
          return entry.path && !entry.identityHidden
            ? <Link key={entry.key} {...props} to={entry.path} aria-label={`${entry.name}, rank ${rank}, ${value === null ? '' : `${metric} ${value}. `}Rider profile`}>{contents}</Link>
            : <div key={entry.key} {...props}>{contents}</div>;
        })}
      {entries.length > 5 && !showAll && <button className="climb-navigation-row climb-top-ten" onClick={() => setShowAll(true)}><span>Top 10</span><ChevronRight className="climb-chevron" size={15} aria-hidden="true" /></button>}
    </div>
    {hiddenRows > 0 && <p className="climb-ledger-note">{formatInteger(hiddenRows)} more rows require sign in.</p>}
  </section>;
}
