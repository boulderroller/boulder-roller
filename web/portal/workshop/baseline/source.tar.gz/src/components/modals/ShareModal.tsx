import { useEffect, useState } from 'react';
import { BeetleButton } from '../ui/beetle-button';
import { Copy, Check } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '../../lib/api';
import { useFormatters } from '../../hooks/useFormatters';
import {
  ResponsiveModal,
  ResponsiveModalHeader,
  ResponsiveModalTitle,
  ResponsiveModalDescription,
  ResponsiveModalBody,
  ResponsiveModalFooter,
} from '../ui/responsive-modal';
import { formatTokenAmount } from '../../lib/formatters';

interface Activity {
  id: string;
  title: string;
  date: string;
  distance: number;
  duration: string;
  elevation: number;
  dungEarned: number;
}

interface ShareModalProps {
  activity: Activity;
  onClose: () => void;
}

export default function ShareModal({ activity, onClose }: ShareModalProps) {
  const { distance: formatDistance, elevation: formatElevation } = useFormatters();
  const [copiedLink, setCopiedLink] = useState(false);

  const fallbackShareUrl = `${window.location.origin}/rides/${activity.id}`;
  const [shareUrl, setShareUrl] = useState(fallbackShareUrl);

  useEffect(() => {
    let cancelled = false;

    api.resolveLink('ride', activity.id)
      .then((link) => {
        if (!cancelled) {
          setShareUrl(link.share.url || link.canonicalUrl || fallbackShareUrl);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setShareUrl(fallbackShareUrl);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [activity.id, fallbackShareUrl]);

  const handleCopyLink = async () => {
    await navigator.clipboard.writeText(shareUrl);
    setCopiedLink(true);
    toast.success('Link copied');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleShareTwitter = () => {
    const text = `I logged ${formatDistance(activity.distance * 1000)} and ${formatTokenAmount(activity.dungEarned)} CAL on Boulder Roller.`;
    window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
  };

  return (
    <ResponsiveModal open={true} onOpenChange={(open) => { if (!open) onClose(); }}>
      <ResponsiveModalHeader>
        <ResponsiveModalTitle className="share-modal-title">
          Share ride
        </ResponsiveModalTitle>
        <ResponsiveModalDescription className="sr-only">
          Copy or post a share link for this ride.
        </ResponsiveModalDescription>
      </ResponsiveModalHeader>

      <ResponsiveModalBody>
        {/* Activity Preview Card */}
        <div className="share-modal-preview">
          {/* Title & Date */}
          <div className="share-modal-preview__header">
            <div className="share-modal-preview__title">
              {activity.title}
            </div>
            <div className="share-modal-preview__meta">
              {activity.date}
            </div>
          </div>

          {/* Stats - DATA EMPHASIS */}
          <div className="share-modal-preview__stats">
            {formatDistance(activity.distance * 1000)} • {activity.duration} • {formatElevation(activity.elevation)}
          </div>

          {/* Dung Earned - AMBER EMPHASIS */}
          <div className="share-modal-preview__reward">
            Counted {formatTokenAmount(activity.dungEarned)} CAL
          </div>
        </div>

        {/* Share Options */}
        <div className="share-modal-options">
          {/* Twitter/X */}
          <button
            type="button"
            onClick={handleShareTwitter}
            className="share-modal-option"
          >
            <span className="share-modal-option__symbol">𝕏</span>
            <span className="share-modal-option__label">
              Share to X
            </span>
          </button>

        </div>

        <div className="share-modal-divider" />

        {/* Copy Link */}
        <div className="share-modal-copy">
          <label className="share-modal-copy__label">
            Copy link
          </label>
          <div className="share-modal-copy__row">
            <input
              type="text"
              value={shareUrl}
              readOnly
              className="share-modal-copy__input"
            />
            <button
              type="button"
              onClick={handleCopyLink}
              className="share-modal-copy__button"
            >
              {copiedLink ? <Check className="share-modal-copy__icon" /> : <Copy className="share-modal-copy__icon" />}
            </button>
          </div>
        </div>
      </ResponsiveModalBody>

      <ResponsiveModalFooter>
        <BeetleButton
          onClick={onClose}
          variant="secondary"
          className="share-modal-close"
        >
          Close
        </BeetleButton>
      </ResponsiveModalFooter>
    </ResponsiveModal>
  );
}
