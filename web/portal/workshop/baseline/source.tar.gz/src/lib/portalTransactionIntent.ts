import { Buffer } from 'buffer';
import { PublicKey, Transaction, type TransactionInstruction } from '@solana/web3.js';

import type {
  PreparedVaultTransaction,
  VaultCreationPaymentMethod,
} from './api';

export type BalanceFundingAsset = 'CAL' | 'USDC';
export type BalanceWalletAsset = BalanceFundingAsset | 'DUNG';

export type PreparedTransactionIntent =
  | {
      kind: 'create_vault';
      paymentMethod: VaultCreationPaymentMethod;
      climbId: string;
      canonId: string;
      canonVersion: number;
    }
  | {
      kind: 'stake';
      vaultId: number;
      amountBaseUnits: string;
    }
  | {
      kind: 'unstake';
      vaultId: number;
      lpAmountBaseUnits: string;
    }
  | {
      kind: 'balance_add_funds';
      asset: BalanceFundingAsset;
      amountBaseUnits: string;
    }
  | {
      kind: 'balance_withdraw';
      asset: BalanceWalletAsset;
      amountBaseUnits: string;
    };

export function vaultWithdrawalIntent(
  vaultId: number,
  lpAmountBaseUnits: string,
): PreparedTransactionIntent {
  return {
    kind: 'unstake',
    vaultId,
    lpAmountBaseUnits,
  };
}

export class PreparedTransactionIntentError extends Error {
  constructor() {
    super('Prepared Balance transaction does not match the requested action.');
    this.name = 'PreparedTransactionIntentError';
  }
}

// This is intentionally release-pinned. Rotating a key, mint, treasury, or
// program requires a portal release; an unexpected backend response fails
// closed instead of silently broadening wallet authority.
const RELEASE_REGISTRY = {
  program: 'EVjP2Vdz9buHNphywPhoybf213poa8EiSW6FGbXWFqYH',
  feePayer: '9h6UJdZqUPNnShaUHkSoxvEeZ7gBeNxzXGQcShhBnzEP',
  backendAuthority: 'CJz8PUyNVvLuXJvjsYXgSKD9utZVP2XoTEZq6M973Gha',
  calMint: '4bxTCxEQp993cXs5nqhfWthRCPSTDv5K6PMgsfunEaJh',
  dungMint: 'CqDFJWLpr49tB8xjHegy5JR5jwMCfmhicjuWawtKLeCk',
  dungTreasury: '9wkFkPSH9eL1XdifxzM7ASfqyVtSZWAuLGUXTx5ijwPr',
  usdcMint: 'DpLPBaRuLnBsR3P3meU1tmiNUxreXwskXBebTYKvNGne',
  usdcTreasury: 'GEL1JhavEKPuqVBvUiezUgNG2VYK1jtzsUazo2Scm1jA',
  tokenProgram: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
  associatedTokenProgram: 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL',
  systemProgram: '11111111111111111111111111111111',
  rentSysvar: 'SysvarRent111111111111111111111111111111111',
} as const;

const DISCRIMINATORS = {
  createVault: '1dedf7d0c1523687',
  createVaultWithUsdc: '1514224260a15779',
  initializeVaultLpMint: '61c288eef6ff4781',
  initializeVaultCalEscrow: '4db2d097d8221bd0',
  initializeVaultPositionLp: '14c0ccb7e4becef4',
  stakeCalInVault: '93965b0c13fabd6a',
  collectStakeRewardsFor: 'dc76b7f5d1ed423d',
  unstakeCalFromVault: '8f48926ca6362c10',
  withdrawToWallet: '5dbed152738c90e1',
} as const;

const MAX_U64 = (1n << 64n) - 1n;
const textEncoder = new TextEncoder();

type RegistryPublicKeys = ReturnType<typeof publicKeyRegistry>;

function reject(): never {
  throw new PreparedTransactionIntentError();
}

function publicKey(value: string): PublicKey {
  const result = new PublicKey(value);
  if (result.toBase58() !== value) reject();
  return result;
}

function publicKeyRegistry() {
  return {
    program: publicKey(RELEASE_REGISTRY.program),
    feePayer: publicKey(RELEASE_REGISTRY.feePayer),
    backendAuthority: publicKey(RELEASE_REGISTRY.backendAuthority),
    calMint: publicKey(RELEASE_REGISTRY.calMint),
    dungMint: publicKey(RELEASE_REGISTRY.dungMint),
    dungTreasury: publicKey(RELEASE_REGISTRY.dungTreasury),
    usdcMint: publicKey(RELEASE_REGISTRY.usdcMint),
    usdcTreasury: publicKey(RELEASE_REGISTRY.usdcTreasury),
    tokenProgram: publicKey(RELEASE_REGISTRY.tokenProgram),
    associatedTokenProgram: publicKey(RELEASE_REGISTRY.associatedTokenProgram),
    systemProgram: publicKey(RELEASE_REGISTRY.systemProgram),
    rentSysvar: publicKey(RELEASE_REGISTRY.rentSysvar),
  };
}

function exactU64(value: string, positive = true): bigint {
  if (!/^(0|[1-9][0-9]*)$/u.test(value)) reject();
  const parsed = BigInt(value);
  if (parsed > MAX_U64 || (positive && parsed === 0n)) reject();
  return parsed;
}

function exactVaultId(value: number): bigint {
  if (!Number.isSafeInteger(value) || value < 0) reject();
  return BigInt(value);
}

function u64Le(value: bigint): Buffer {
  const result = Buffer.alloc(8);
  result.writeBigUInt64LE(value);
  return result;
}

function discriminator(value: keyof typeof DISCRIMINATORS): Buffer {
  return Buffer.from(DISCRIMINATORS[value], 'hex');
}

function instructionData(prefix: keyof typeof DISCRIMINATORS, amount?: bigint): Buffer {
  return amount === undefined
    ? discriminator(prefix)
    : Buffer.concat([discriminator(prefix), u64Le(amount)]);
}

function pda(program: PublicKey, seed: string, ...remaining: Uint8Array[]): PublicKey {
  return PublicKey.findProgramAddressSync(
    [textEncoder.encode(seed), ...remaining],
    program,
  )[0];
}

function ata(owner: PublicKey, mint: PublicKey, registry: RegistryPublicKeys): PublicKey {
  return PublicKey.findProgramAddressSync(
    [owner.toBytes(), registry.tokenProgram.toBytes(), mint.toBytes()],
    registry.associatedTokenProgram,
  )[0];
}

function sameKey(left: PublicKey, right: PublicKey): boolean {
  return left.equals(right);
}

function keySet(values: PublicKey[]): Set<string> {
  return new Set(values.map((value) => value.toBase58()));
}

function requireSameSet(actual: Set<string>, expected: Set<string>) {
  if (actual.size !== expected.size) reject();
  for (const value of expected) {
    if (!actual.has(value)) reject();
  }
}

function requireInstruction(
  instructions: TransactionInstruction[],
  index: number,
  programId: PublicKey,
  data: Uint8Array,
  accounts: PublicKey[],
): TransactionInstruction {
  const instruction = instructions[index];
  if (
    !instruction
    || !sameKey(instruction.programId, programId)
    || !Buffer.from(instruction.data).equals(Buffer.from(data))
    || instruction.keys.length !== accounts.length
  ) {
    reject();
  }

  const actualAccounts = instruction.keys.map((entry) => entry.pubkey);
  if (keySet(actualAccounts).size !== actualAccounts.length) reject();
  for (let accountIndex = 0; accountIndex < accounts.length; accountIndex += 1) {
    if (!sameKey(actualAccounts[accountIndex], accounts[accountIndex])) reject();
  }
  return instruction;
}

function hasData(
  instructions: TransactionInstruction[],
  index: number,
  data: Uint8Array,
): boolean {
  const instruction = instructions[index];
  return Boolean(instruction && Buffer.from(instruction.data).equals(Buffer.from(data)));
}

function isCreateAta(
  instructions: TransactionInstruction[],
  index: number,
  mint: PublicKey,
  registry: RegistryPublicKeys,
): boolean {
  const instruction = instructions[index];
  return Boolean(
    instruction
    && sameKey(instruction.programId, registry.associatedTokenProgram)
    && instruction.data.length === 0
    && instruction.keys.length === 7
    && sameKey(instruction.keys[3].pubkey, mint)
  );
}

function requireCreateAta(
  instructions: TransactionInstruction[],
  index: number,
  owner: PublicKey,
  mint: PublicKey,
  destination: PublicKey,
  registry: RegistryPublicKeys,
) {
  requireInstruction(
    instructions,
    index,
    registry.associatedTokenProgram,
    Buffer.alloc(0),
    [
      registry.feePayer,
      destination,
      owner,
      mint,
      registry.systemProgram,
      registry.tokenProgram,
      registry.rentSysvar,
    ],
  );
}

function requireGlobalRoles(
  transaction: Transaction,
  expectedSigners: PublicKey[],
  expectedWritable: PublicKey[],
) {
  const message = transaction.compileMessage();
  const { numRequiredSignatures, numReadonlySignedAccounts, numReadonlyUnsignedAccounts } = message.header;
  const writableSignedCount = numRequiredSignatures - numReadonlySignedAccounts;
  const writableUnsignedLimit = message.accountKeys.length - numReadonlyUnsignedAccounts;
  const actualSigners = new Set<string>();
  const actualWritable = new Set<string>();

  message.accountKeys.forEach((key, index) => {
    if (index < numRequiredSignatures) actualSigners.add(key.toBase58());
    if (
      index < writableSignedCount
      || (index >= numRequiredSignatures && index < writableUnsignedLimit)
    ) {
      actualWritable.add(key.toBase58());
    }
  });

  requireSameSet(actualSigners, keySet(expectedSigners));
  requireSameSet(actualWritable, keySet(expectedWritable));
}

function requireEveryStaticKeyIsUsed(transaction: Transaction) {
  const message = transaction.compileMessage();
  const used = new Set<string>([message.accountKeys[0].toBase58()]);
  for (const instruction of transaction.instructions) {
    used.add(instruction.programId.toBase58());
    for (const account of instruction.keys) used.add(account.pubkey.toBase58());
  }
  requireSameSet(used, keySet(message.accountKeys));
}

function strictLegacyTransaction(prepared: PreparedVaultTransaction): Transaction {
  if (
    typeof prepared.transaction !== 'string'
    || prepared.transaction.length === 0
    || prepared.transaction.length % 4 !== 0
    || !/^[A-Za-z0-9+/]+={0,2}$/u.test(prepared.transaction)
    || typeof prepared.blockhash !== 'string'
    || !Number.isSafeInteger(prepared.lastValidBlockHeight)
    || prepared.lastValidBlockHeight <= 0
  ) {
    reject();
  }

  const wire = Buffer.from(prepared.transaction, 'base64');
  if (wire.length === 0 || wire.toString('base64') !== prepared.transaction) reject();

  let transaction: Transaction;
  try {
    transaction = Transaction.from(wire);
  } catch {
    reject();
  }

  const canonicalWire = transaction.serialize({
    requireAllSignatures: false,
    verifySignatures: false,
  });
  if (!Buffer.from(canonicalWire).equals(wire)) reject();

  const message = transaction.compileMessage();
  if (message.recentBlockhash !== prepared.blockhash) reject();
  if (message.accountKeys.length === 0) reject();
  if (keySet(message.accountKeys).size !== message.accountKeys.length) reject();
  if (!sameKey(message.accountKeys[0], publicKey(RELEASE_REGISTRY.feePayer))) reject();
  return transaction;
}

function contextForVault(
  vaultId: number,
  wallet: PublicKey,
  registry: RegistryPublicKeys,
) {
  const vaultIdBytes = u64Le(exactVaultId(vaultId));
  return {
    vaultIdBytes,
    vault: pda(registry.program, 'vault', vaultIdBytes),
    vaultStake: pda(registry.program, 'vault_stake', wallet.toBytes(), vaultIdBytes),
    vaultActivation: pda(registry.program, 'vault_activation', vaultIdBytes),
    programConfig: pda(registry.program, 'program_config'),
    vaultCalEscrow: pda(registry.program, 'vault_cal_escrow', vaultIdBytes),
    vaultLpMint: pda(registry.program, 'vault_lp', vaultIdBytes),
    positionLp: pda(registry.program, 'vault_position_lp', wallet.toBytes(), vaultIdBytes),
    walletCalAta: ata(wallet, registry.calMint, registry),
    walletDungAta: ata(wallet, registry.dungMint, registry),
    dungMintState: pda(registry.program, 'dung_mint_state'),
    dungMintAuthority: pda(registry.program, 'dung_mint_auth'),
  };
}

function validateStake(
  transaction: Transaction,
  wallet: PublicKey,
  vaultId: number,
  amountBaseUnits: string,
  registry: RegistryPublicKeys,
) {
  const amount = exactU64(amountBaseUnits);
  const context = contextForVault(vaultId, wallet, registry);
  const instructions = transaction.instructions;
  let cursor = 0;

  if (hasData(instructions, cursor, discriminator('initializeVaultLpMint'))) {
    requireInstruction(
      instructions,
      cursor,
      registry.program,
      discriminator('initializeVaultLpMint'),
      [
        context.vault,
        context.vaultLpMint,
        registry.feePayer,
        registry.tokenProgram,
        registry.systemProgram,
        registry.rentSysvar,
      ],
    );
    cursor += 1;
  }

  if (hasData(instructions, cursor, discriminator('initializeVaultCalEscrow'))) {
    requireInstruction(
      instructions,
      cursor,
      registry.program,
      discriminator('initializeVaultCalEscrow'),
      [
        context.vault,
        context.programConfig,
        context.vaultCalEscrow,
        registry.calMint,
        registry.feePayer,
        registry.tokenProgram,
        registry.systemProgram,
        registry.rentSysvar,
      ],
    );
    cursor += 1;
  }

  requireInstruction(
    instructions,
    cursor,
    registry.program,
    discriminator('initializeVaultPositionLp'),
    [
      context.vault,
      wallet,
      context.vaultStake,
      context.vaultLpMint,
      context.positionLp,
      registry.backendAuthority,
      registry.tokenProgram,
      registry.systemProgram,
    ],
  );
  cursor += 1;

  requireInstruction(
    instructions,
    cursor,
    registry.program,
    instructionData('stakeCalInVault', amount),
    [
      context.vault,
      context.vaultStake,
      context.vaultActivation,
      context.programConfig,
      registry.backendAuthority,
      wallet,
      context.walletCalAta,
      context.vaultCalEscrow,
      context.vaultLpMint,
      context.positionLp,
      registry.tokenProgram,
      registry.systemProgram,
    ],
  );
  cursor += 1;
  if (cursor !== instructions.length) reject();

  requireGlobalRoles(
    transaction,
    [registry.feePayer, registry.backendAuthority, wallet],
    [
      registry.feePayer,
      registry.backendAuthority,
      wallet,
      context.vault,
      context.vaultStake,
      context.walletCalAta,
      context.vaultCalEscrow,
      context.vaultLpMint,
      context.positionLp,
    ],
  );
}

function validateUnstake(
  transaction: Transaction,
  wallet: PublicKey,
  vaultId: number,
  lpAmountBaseUnits: string,
  registry: RegistryPublicKeys,
) {
  const amount = exactU64(lpAmountBaseUnits);
  const context = contextForVault(vaultId, wallet, registry);
  const instructions = transaction.instructions;
  let cursor = 0;
  let createdDungAta = false;
  let collected = false;

  if (isCreateAta(instructions, cursor, registry.dungMint, registry)) {
    requireCreateAta(
      instructions,
      cursor,
      wallet,
      registry.dungMint,
      context.walletDungAta,
      registry,
    );
    createdDungAta = true;
    cursor += 1;
  }

  if (
    hasData(instructions, cursor, discriminator('collectStakeRewardsFor'))
  ) {
    requireInstruction(
      instructions,
      cursor,
      registry.program,
      discriminator('collectStakeRewardsFor'),
      [
        context.vault,
        context.vaultStake,
        context.vaultActivation,
        wallet,
        registry.feePayer,
        registry.dungMint,
        context.walletDungAta,
        registry.dungTreasury,
        context.dungMintState,
        context.programConfig,
        context.dungMintAuthority,
        registry.tokenProgram,
      ],
    );
    collected = true;
    cursor += 1;
  } else if (createdDungAta) {
    reject();
  }

  if (isCreateAta(instructions, cursor, registry.calMint, registry)) {
    requireCreateAta(
      instructions,
      cursor,
      wallet,
      registry.calMint,
      context.walletCalAta,
      registry,
    );
    cursor += 1;
  }

  requireInstruction(
    instructions,
    cursor,
    registry.program,
    instructionData('unstakeCalFromVault', amount),
    [
      context.vault,
      context.vaultStake,
      context.vaultActivation,
      context.programConfig,
      wallet,
      context.walletCalAta,
      context.vaultCalEscrow,
      registry.calMint,
      context.vaultLpMint,
      context.positionLp,
      registry.tokenProgram,
    ],
  );
  cursor += 1;
  if (cursor !== instructions.length) reject();

  const writable = [
    registry.feePayer,
    wallet,
    context.vault,
    context.vaultStake,
    context.walletCalAta,
    context.vaultCalEscrow,
    registry.calMint,
    context.vaultLpMint,
    context.positionLp,
  ];
  if (collected) {
    writable.push(
      registry.dungMint,
      context.walletDungAta,
      registry.dungTreasury,
      context.dungMintState,
    );
  }
  requireGlobalRoles(transaction, [registry.feePayer, wallet], writable);
}

function balanceContext(
  wallet: PublicKey,
  asset: BalanceWalletAsset,
  registry: RegistryPublicKeys,
) {
  const mint = asset === 'CAL'
    ? registry.calMint
    : asset === 'USDC'
      ? registry.usdcMint
      : asset === 'DUNG'
        ? registry.dungMint
        : reject();
  return {
    mint,
    decimals: asset === 'USDC' ? 6 : 9,
    walletAta: ata(wallet, mint, registry),
    riderBalance: pda(registry.program, 'rider_balance', wallet.toBytes()),
    riderBalanceAuthority: pda(registry.program, 'rider_balance_auth', wallet.toBytes()),
    riderBalanceToken: pda(
      registry.program,
      'rider_balance_token',
      wallet.toBytes(),
      mint.toBytes(),
    ),
    programConfig: pda(registry.program, 'program_config'),
  };
}

function validateBalanceAddFunds(
  transaction: Transaction,
  prepared: PreparedVaultTransaction,
  wallet: PublicKey,
  asset: BalanceFundingAsset,
  amountBaseUnits: string,
  registry: RegistryPublicKeys,
) {
  if (asset !== 'CAL' && asset !== 'USDC') reject();
  const amount = exactU64(amountBaseUnits);
  const context = balanceContext(wallet, asset, registry);
  if (prepared.pda !== context.riderBalanceToken.toBase58()) reject();
  requireInstruction(
    transaction.instructions,
    0,
    registry.tokenProgram,
    Buffer.concat([
      Buffer.from([12]),
      u64Le(amount),
      Buffer.from([context.decimals]),
    ]),
    [context.walletAta, context.mint, context.riderBalanceToken, wallet],
  );
  if (transaction.instructions.length !== 1) reject();
  requireGlobalRoles(
    transaction,
    [registry.feePayer, wallet],
    [registry.feePayer, context.walletAta, context.riderBalanceToken],
  );
}

function validateBalanceWithdraw(
  transaction: Transaction,
  prepared: PreparedVaultTransaction,
  wallet: PublicKey,
  asset: BalanceWalletAsset,
  amountBaseUnits: string,
  registry: RegistryPublicKeys,
) {
  if (asset !== 'CAL' && asset !== 'USDC' && asset !== 'DUNG') reject();
  const amount = exactU64(amountBaseUnits);
  const context = balanceContext(wallet, asset, registry);
  if (prepared.pda !== context.riderBalanceToken.toBase58()) reject();
  let cursor = 0;
  if (isCreateAta(transaction.instructions, cursor, context.mint, registry)) {
    requireCreateAta(
      transaction.instructions,
      cursor,
      wallet,
      context.mint,
      context.walletAta,
      registry,
    );
    cursor += 1;
  }
  requireInstruction(
    transaction.instructions,
    cursor,
    registry.program,
    instructionData('withdrawToWallet', amount),
    [
      context.riderBalance,
      wallet,
      context.riderBalanceAuthority,
      context.programConfig,
      context.riderBalanceToken,
      context.walletAta,
      context.mint,
      registry.tokenProgram,
    ],
  );
  cursor += 1;
  if (cursor !== transaction.instructions.length) reject();
  requireGlobalRoles(
    transaction,
    [registry.feePayer, wallet],
    [registry.feePayer, context.riderBalanceToken, context.walletAta],
  );
}

function parseCanonCommitment(
  value: unknown,
  intent: Extract<PreparedTransactionIntent, { kind: 'create_vault' }>,
): Buffer {
  if (typeof value !== 'string' || !/^[0-9a-f]{128}$/u.test(value)) reject();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u.test(intent.canonId)) {
    reject();
  }
  if (!Number.isInteger(intent.canonVersion) || intent.canonVersion <= 0 || intent.canonVersion > 0xffff) {
    reject();
  }
  const commitment = Buffer.from(value, 'hex');
  const canonIdBytes = Buffer.from(intent.canonId.replaceAll('-', ''), 'hex');
  if (
    commitment[0] !== 1
    || !commitment.subarray(1, 17).equals(canonIdBytes)
    || commitment.readUInt16BE(17) !== intent.canonVersion
    || commitment.subarray(19, 32).some((byte) => byte !== 0)
    || commitment.subarray(32, 64).every((byte) => byte === 0)
  ) {
    reject();
  }
  return commitment;
}

async function sha256(value: Uint8Array): Promise<Uint8Array> {
  if (!globalThis.crypto?.subtle) reject();
  return new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', value));
}

async function validateCreateVault(
  transaction: Transaction,
  prepared: PreparedVaultTransaction,
  wallet: PublicKey,
  intent: Extract<PreparedTransactionIntent, { kind: 'create_vault' }>,
  registry: RegistryPublicKeys,
) {
  const createPrepared = prepared as PreparedVaultTransaction & {
    climbId?: unknown;
    canonCommitmentHex?: unknown;
  };
  if (createPrepared.climbId !== intent.climbId) reject();
  if (!Number.isSafeInteger(prepared.vaultId) || prepared.vaultId === null || prepared.vaultId! < 0) {
    reject();
  }
  const vaultIdBytes = u64Le(exactVaultId(prepared.vaultId!));
  const vault = pda(registry.program, 'vault', vaultIdBytes);
  if (prepared.pda !== vault.toBase58()) reject();

  const commitment = parseCanonCommitment(createPrepared.canonCommitmentHex, intent);
  const climb = pda(registry.program, 'climb', await sha256(commitment));
  const counter = pda(registry.program, 'vault_counter');
  const leaderboard = pda(registry.program, 'vault_leaderboard', vaultIdBytes);
  const localLegend = pda(registry.program, 'local_legend', vaultIdBytes);
  const activation = pda(registry.program, 'vault_activation', vaultIdBytes);
  const programConfig = pda(registry.program, 'program_config');
  const baseAccounts = [
    counter,
    vault,
    climb,
    leaderboard,
    localLegend,
    activation,
    registry.backendAuthority,
    wallet,
  ];
  const baseWritable = [
    registry.feePayer,
    counter,
    vault,
    climb,
    leaderboard,
    localLegend,
    activation,
    registry.backendAuthority,
    wallet,
  ];

  if (intent.paymentMethod === 'dung') {
    const dungState = pda(registry.program, 'dung_mint_state');
    const walletDungAta = ata(wallet, registry.dungMint, registry);
    requireInstruction(
      transaction.instructions,
      0,
      registry.program,
      discriminator('createVault'),
      [
        ...baseAccounts,
        dungState,
        registry.tokenProgram,
        registry.systemProgram,
        programConfig,
        registry.dungMint,
        walletDungAta,
      ],
    );
    requireGlobalRoles(
      transaction,
      [registry.feePayer, registry.backendAuthority, wallet],
      [...baseWritable, dungState, registry.dungMint, walletDungAta],
    );
  } else if (intent.paymentMethod === 'cal_usdc') {
    const walletCalAta = ata(wallet, registry.calMint, registry);
    const walletUsdcAta = ata(wallet, registry.usdcMint, registry);
    requireInstruction(
      transaction.instructions,
      0,
      registry.program,
      discriminator('createVaultWithUsdc'),
      [
        ...baseAccounts,
        walletCalAta,
        registry.usdcTreasury,
        registry.tokenProgram,
        registry.systemProgram,
        registry.calMint,
        programConfig,
        walletUsdcAta,
      ],
    );
    requireGlobalRoles(
      transaction,
      [registry.feePayer, registry.backendAuthority, wallet],
      [
        ...baseWritable,
        walletCalAta,
        registry.usdcTreasury,
        registry.calMint,
        walletUsdcAta,
      ],
    );
  } else {
    reject();
  }
  if (transaction.instructions.length !== 1) reject();
}

async function validatePreparedTransactionIntentInner(
  prepared: PreparedVaultTransaction,
  intent: PreparedTransactionIntent,
  authenticatedWallet: string,
): Promise<Transaction> {
  const registry = publicKeyRegistry();
  const wallet = publicKey(authenticatedWallet);
  const forbiddenWallets = keySet(Object.values(registry));
  if (forbiddenWallets.has(wallet.toBase58())) reject();
  const transaction = strictLegacyTransaction(prepared);

  if (prepared.vaultId !== null && prepared.vaultId !== undefined) {
    if (!Number.isSafeInteger(prepared.vaultId) || prepared.vaultId < 0) reject();
    if (
      (intent.kind === 'stake' || intent.kind === 'unstake')
      && prepared.vaultId !== intent.vaultId
    ) {
      reject();
    }
  }

  switch (intent.kind) {
    case 'create_vault':
      await validateCreateVault(transaction, prepared, wallet, intent, registry);
      break;
    case 'stake':
      validateStake(transaction, wallet, intent.vaultId, intent.amountBaseUnits, registry);
      break;
    case 'unstake':
      validateUnstake(transaction, wallet, intent.vaultId, intent.lpAmountBaseUnits, registry);
      break;
    case 'balance_add_funds':
      validateBalanceAddFunds(
        transaction,
        prepared,
        wallet,
        intent.asset,
        intent.amountBaseUnits,
        registry,
      );
      break;
    case 'balance_withdraw':
      validateBalanceWithdraw(
        transaction,
        prepared,
        wallet,
        intent.asset,
        intent.amountBaseUnits,
        registry,
      );
      break;
    default:
      reject();
  }

  requireEveryStaticKeyIsUsed(transaction);
  return transaction;
}

export async function validatePreparedTransactionIntent(
  prepared: PreparedVaultTransaction,
  intent: PreparedTransactionIntent,
  authenticatedWallet: string,
): Promise<Transaction> {
  try {
    return await validatePreparedTransactionIntentInner(prepared, intent, authenticatedWallet);
  } catch (error) {
    if (error instanceof PreparedTransactionIntentError) throw error;
    throw new PreparedTransactionIntentError();
  }
}

export async function validateAndSignPreparedTransaction<T>(
  prepared: PreparedVaultTransaction,
  intent: PreparedTransactionIntent,
  authenticatedWallet: string,
  sign: (transaction: Transaction) => Promise<T>,
): Promise<T> {
  const transaction = await validatePreparedTransactionIntent(
    prepared,
    intent,
    authenticatedWallet,
  );
  return sign(transaction);
}

export async function validateAndSignPreparedTransactionBytes<T>(
  prepared: PreparedVaultTransaction,
  intent: PreparedTransactionIntent,
  authenticatedWallet: string,
  sign: (validatedTransaction: string) => Promise<T>,
): Promise<T> {
  const transaction = await validatePreparedTransactionIntent(
    prepared,
    intent,
    authenticatedWallet,
  );
  const validatedTransaction = Buffer.from(transaction.serialize({
    requireAllSignatures: false,
    verifySignatures: false,
  })).toString('base64');
  return sign(validatedTransaction);
}
