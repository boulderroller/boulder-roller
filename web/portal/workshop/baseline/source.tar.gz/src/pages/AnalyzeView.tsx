import { useQueryClient } from '@tanstack/react-query';
import { AnalysisFrame } from '../components/loading/RoomLoading';
import { FailureSheet } from '../components/portal/FailureSpecies';
import { useBrowserTitleObject } from '../contexts/BrowserTitleContext';
import { Slot, SlotRows } from '../components/loading/Slot';
import { Suspense, lazy, useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowLeft, Mountain, Upload } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useFormatters } from '../hooks/useFormatters';
import RouteMap from '../components/ride/RouteMap';
import ClimbsTable, { ClimbData } from '../components/ride/ClimbsTable';
import { InlinePendingState, LoadingRows } from '../components/loading/LoadingSystem';
import {
  StateRow,
  PortalFrame,
  PortalMetric,
  PortalPage,
  PortalPanel,
  PortalPanelBody,
  PortalPanelHeader,
  PortalStack,
  PortalTruthPill,
} from '../components/portal/PortalSpine';
import { api, Ride, GpsPoint, TelemetryData, PatternsResponse, StreamResponse } from '../lib/api';
import { findGpsIndexForOffset, streamValueForGpsIndex } from '../lib/rideTelemetry';
import { ABSENT_VALUE, formatInteger, formatTokenAmount } from '../lib/formatters';

const AnalyzeChartsColumn = lazy(() => import('../components/ride/AnalyzeChartsColumn'));

const ANALYZE_CHART_FALLBACK_PANELS = [
  { key: 'overview', className: 'analyze-chart-fallback__panel analyze-chart-fallback__panel--overview' },
  { key: 'power', className: 'analyze-chart-fallback__panel analyze-chart-fallback__panel--stream' },
  { key: 'effort', className: 'analyze-chart-fallback__panel analyze-chart-fallback__panel--stream' },
  { key: 'cadence', className: 'analyze-chart-fallback__panel analyze-chart-fallback__panel--stream' },
] as const;

export default function AnalyzeView() {
  const { activityId } = useParams<{ activityId: string }>();
  const { isAuthenticated } = useAuth();
  const { distance: formatDistance, duration: formatDuration, elevation: formatElevation } = useFormatters();

  const queryClient = useQueryClient();
  const [attempt, setAttempt] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [ride, setRide] = useState<Ride | null>(null);
  useBrowserTitleObject(ride?.id === activityId ? ride.title || null : null);
  const [telemetry, setTelemetry] = useState<TelemetryData | null>(null);
  const [patterns, setPatterns] = useState<PatternsResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [selectedClimb, setSelectedClimb] = useState<ClimbData | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!activityId || !isAuthenticated) {
        setError(!isAuthenticated ? 'Sign in to view analysis' : 'Open a saved ride');
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);
        setError(null);

        const [rideData, telemetryData, patternsData] = await queryClient.fetchQuery({ queryKey: ['ride-analysis', activityId], staleTime: 0, retry: false, queryFn: () => Promise.all([
          api.getRide(activityId),
          api.getRideTelemetry(activityId).catch(() => null),
          api.getRidePatterns(activityId).catch(() => null),
        ]) });

        setRide(rideData);
        setTelemetry(telemetryData);
        setPatterns(patternsData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load ride');
      } finally {
        setIsLoading(false);
      }
    };

    void fetchData();
  }, [activityId, isAuthenticated, attempt, queryClient]);

  const gpsPoints: GpsPoint[] = useMemo(() => telemetry?.gps?.gpsPoints || [], [telemetry]);

  const climbs: ClimbData[] = useMemo(() => {
    const climbPatterns = patterns?.patterns?.climbPatterns || [];

    return climbPatterns.map((climb, index) => {
      const startOffset = climb.startOffsetS ?? climb.startTimeOffsetS;
      const endOffset = climb.endOffsetS ?? climb.endTimeOffsetS;

      return {
        id: `climb-${index}`,
        name: climb.name,
        distanceM: climb.distanceM ?? 0,
        elevationM: climb.vertM ?? 0,
        avgGradient: climb.avgGradientPct ?? 0,
        timeS: climb.durationS ?? 0,
        avgSpeedKmh: climb.avgSpeedMps ? climb.avgSpeedMps * 3.6 : undefined,
        vam: climb.vam,
        startIndex: climb.startIdx ?? findGpsIndexForOffset(gpsPoints, startOffset, ride?.durationS),
        endIndex: climb.endIdx ?? findGpsIndexForOffset(gpsPoints, endOffset, ride?.durationS),
      };
    });
  }, [gpsPoints, patterns, ride?.durationS]);

  const chartData = useMemo(() => {
    const points = gpsPoints.map((point, index) => ({
      index,
      distance: point.distanceM || 0,
      elevation: point.elevationM || 0,
      power: null as number | null,
      hr: null as number | null,
      cadence: null as number | null,
      speed: null as number | null,
    }));

    const mapStream = (
      stream: StreamResponse | null,
      key: 'power' | 'hr' | 'cadence' | 'speed',
      transform: (value: number) => number = (value) => value,
    ) => {
      points.forEach((point, index) => {
        point[key] = streamValueForGpsIndex(stream, gpsPoints, index, transform);
      });
    };

    mapStream(telemetry?.power || null, 'power');
    mapStream(telemetry?.heartRate || null, 'hr');
    mapStream(telemetry?.cadence || null, 'cadence');
    mapStream(telemetry?.speed || null, 'speed', (value) => value * 3.6);

    return points;
  }, [gpsPoints, telemetry]);

  const handleHover = useCallback((index: number | null) => {
    setHoverIndex(index);
  }, []);

  const hasData = {
    power: Boolean(telemetry?.power?.values?.length),
    hr: Boolean(telemetry?.heartRate?.values?.length),
    cadence: Boolean(telemetry?.cadence?.values?.length),
    speed: Boolean(telemetry?.speed?.values?.length),
  };

  const streamCount = Object.values(hasData).filter(Boolean).length;

  if (isLoading) return <AnalysisFrame />;
  if (error || !ride) {
    if (!error || /404|not.?found/i.test(error)) return <FailureSheet title="Ride not found" description="Open a saved ride to view analysis." doors={[{label: 'Rides', href: '/profile?tab=rides'}]} />;
    return <AnalysisFrame failure={<StateRow title={error} action={<button onClick={() => setAttempt(value => value + 1)}>Try again</button>} />} />;
  }

  return (
    <div className="analyze-tool" aria-busy={false} aria-live="polite">
      <header className="analyze-tool__header">
        <div className="analyze-tool__titlebar">
          <div className="analyze-tool__identity">
            <Link to={`/activities/${activityId}`} className="portal-sort-button">
              <ArrowLeft size={14} aria-hidden="true" />
              <span>Ride</span>
            </Link>
            <div>
              <h1 className="analyze-tool__title">{ride.title || 'Ride Analysis'}</h1>
            </div>
          </div>

          <div className="analyze-tool__streams" aria-label="Available telemetry streams">
            {hasData.power ? <StreamBadge label="PWR" tone="power" /> : null}
            {hasData.hr ? <StreamBadge label="HR" tone="hr" /> : null}
            {hasData.cadence ? <StreamBadge label="CAD" tone="cadence" /> : null}
            {hasData.speed ? <StreamBadge label="SPD" tone="speed" /> : null}
            <PortalTruthPill tone={telemetry ? 'verified' : 'muted'}>{telemetry ? 'Telemetry' : 'Ride only'}</PortalTruthPill>
          </div>
        </div>

        <div className="analyze-tool__metrics">
          <PortalMetric value={ride.distanceM ? formatDistance(ride.distanceM) : ABSENT_VALUE} label="Distance" />
          <PortalMetric value={formatDuration(ride.durationS)} label="Duration" />
          <PortalMetric value={ride.elevationM ? formatElevation(ride.elevationM) : ABSENT_VALUE} label="Elevation" />
          <PortalMetric value={formatInteger(streamCount)} label="Streams" accent />
          <PortalMetric value={formatInteger(climbs.length)} label="Climbs found" />
          {ride.dungEarned ? <PortalMetric value={`+${formatTokenAmount(ride.dungEarned)}`} label="DUNG" accent /> : null}
        </div>
      </header>

      <main className="analyze-tool__workspace">
        <PortalPanel className="analyze-tool__map">
          <RouteMap
            gpsPoints={gpsPoints}
            height="100%"
            onHoverIndex={handleHover}
            hoverIndex={hoverIndex}
            climbs={climbs.filter(c => c.startIndex !== undefined && c.endIndex !== undefined).map(c => ({
              startIndex: c.startIndex!,
              endIndex: c.endIndex!,
              name: c.name,
            }))}
          />
        </PortalPanel>

        <aside className="analyze-tool__rail">
          <Suspense fallback={<AnalyzeChartsFallback />}>
            <AnalyzeChartsColumn
              chartData={chartData}
              hasData={hasData}
              telemetry={telemetry}
              hoverIndex={hoverIndex}
              onHover={handleHover}
            />
          </Suspense>

          <PortalPanel className="analyze-tool__climbs">
            <PortalPanelHeader
              title={(
                <span className="analyze-tool__panel-title">
                  <Mountain size={15} aria-hidden="true" />
                  <span>Climbs found</span>
                </span>
              )}
              meta={`${formatInteger(climbs.length)} found`}
            />
            <div className="analyze-tool__climb-table">
              <ClimbsTable
                climbs={climbs}
                selectedClimbId={selectedClimb?.id}
                onClimbClick={(climb) => {
                  setSelectedClimb(climb);
                  if (climb.startIndex !== undefined) {
                    setHoverIndex(climb.startIndex);
                  }
                }}
                onClimbHover={(climb) => {
                  if (climb?.startIndex !== undefined) {
                    setHoverIndex(climb.startIndex);
                  } else {
                    setHoverIndex(null);
                  }
                }}
                emptyMessage="No climbs found"
                gpsPoints={gpsPoints}
              />
            </div>
          </PortalPanel>
        </aside>
      </main>

      <PortalPanel className="analyze-tool__footer">
        <PortalPanelBody className="analyze-tool__footer-body">
          <span>Ride {activityId}</span>
          <Link to="/upload" className="portal-action-button">
            <Upload size={14} aria-hidden="true" />
            <span>Upload ride</span>
          </Link>
        </PortalPanelBody>
      </PortalPanel>
    </div>
  );
}

function AnalyzeChartsFallback() {
  return (
    <PortalStack className="analyze-chart-fallback">
      {ANALYZE_CHART_FALLBACK_PANELS.map((panel) => (
        <PortalPanel key={panel.key} className={panel.className}>
          <InlinePendingState label="Loading chart" />
        </PortalPanel>
      ))}
    </PortalStack>
  );
}

function StreamBadge({ label, tone }: { label: string; tone: 'power' | 'hr' | 'cadence' | 'speed' }) {
  return <span className={`analyze-stream-badge analyze-stream-badge--${tone}`}>{label}</span>;
}
